<?php

namespace App\Http\Livewire\Admin\WebsiteContents;

use Illuminate\Support\Facades\Redirect;
use App\Models\WebsiteContent;
use Livewire\Component;

class Index extends Component
{
    public $websiteContents;
    public $contentId;
    public $editableTextId;
    public $editableTextKey;
    public $text;
    public $page = "homePage";

    protected $listeners = ['refreshTable', 'ContentUpdate'];
    public function mount()
    {
        // $this->contentId = $contentId;
        $this->websiteContents = WebsiteContent::all();
    }
    public function toggleSection($page)
    {
        $this->page = $page;
    }
    public function refreshTable()
    {
        $this->websiteContents = WebsiteContent::all();

        // return Redirect::to('/website-contents');
    }

    public function ContentUpdate($contentId)
    {
        $this->text = WebsiteContent::where('id', $contentId)->first()->text;
    }
    public function toggleEditable($contentId)
    {
        $this->editableTextId = $contentId;
        $this->contentId = $contentId;
        $WebsiteContent = WebsiteContent::where('id', $contentId)->first();
        $this->text = $WebsiteContent->text;
    }
    public function toggleEditableByKey($contentKey)
    {
        $this->editableTextKey = $contentKey;
        $WebsiteContent = WebsiteContent::where('key', $contentKey)->first();
        $this->text = $WebsiteContent->text;
        $this->contentId = $WebsiteContent->id;
    }

    public function updateContentText($contentId)
    {
        $WebsiteContent = WebsiteContent::where('id', $contentId)->first();
        $WebsiteContent->text = $this->text;
        $WebsiteContent->save();
        $this->editableTextId = null;
        $this->editableTextKey = null;
        $this->emit('ContentUpdate', $WebsiteContent);
    }
    public function render()
    {
        return view('livewire.admin.website-contents.index')->layout('layouts.admin');
    }

    public function edit($id = null)
    {

        $this->emit('showM', 'add-web-content');
        $this->emit('contentId', $id);
    }

    public function delete($id)
    {
        // Implement the logic for deleting a website content
    }
}

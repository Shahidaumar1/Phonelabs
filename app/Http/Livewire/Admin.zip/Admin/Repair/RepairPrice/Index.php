<?php

namespace App\Http\Livewire\Admin\Repair\RepairPrice;

use App\Helpers\ServiceType;
use App\Models\Category;
use App\Models\DeviceType;
use App\Models\Modal;
use App\Models\RepairType;
use Livewire\Component;

class Index extends Component
{

    public $models = [];
    public $selectedModel;
    public $selectedModelId;
    public $devices;
    public $selectedDeviceId;
    public $selectedDevice;
    public $page;
    public $categories;
    public $selectedCat;
    public $selectedCatId;
    public $data;



    public function mount($page = null)
    {
        $this->page = $page;
        $this->categories = Category::where('service', ServiceType::REPAIR)->get();

        if ($this->categories->count() > 0) {
            $this->devices = DeviceType::where('service', ServiceType::REPAIR)->get();
            $selectedDevice = DeviceType::where('service', ServiceType::REPAIR)->first();
            $this->selectedCat = $this->categories[0];
            $this->selectedCatId = $this->selectedCat->id;
            $this->selectedDeviceId = $selectedDevice->id;
            $this->selectedDevice = $selectedDevice;
            $this->models = $selectedDevice->modals;
            if ($selectedDevice) {
                $this->selectedModel = $selectedDevice->modals[0] ?? [];
                $this->selectedModelId = $selectedDevice->modals[0]->id ?? null;
            }
        }

        $this->loadNextComponentData();
    }

    protected $listeners = ['PriceDeleted', 'UpdateDeviceType', 'RepairCreated'];
    public function PriceDeleted()
    {
        //
    }

    public function RepairCreated(DeviceType $deviceType)
    {
        $this->selectedDevice = $deviceType;
        $this->models = $deviceType->modals;
    }

    public function UpdateDeviceType(DeviceType $deviceType)
    {
        $this->selectedDeviceId = $deviceType->id;
        $this->selectedDevice = $deviceType;
        $this->models = $deviceType->models;
    }

    public function updated($property)
    {

        if ($property == 'selectedCatId') {
            $this->devices = [];
            $this->models = [];
            $this->devices = DeviceType::where('category_id', $this->selectedCatId)->get();
        }

        if ($property == 'selectedDeviceId') {
            $this->selectedDevice = DeviceType::where('id', $this->selectedDeviceId)->first();
            $this->models = $this->selectedDevice->modals;
        }
    }

    public function updateTaskOrder($orders)
    {

        foreach ($orders as $order) {
            $this->selectedDevice->repair_types()->updateExistingPivot((int)$order['value'], ['order_number' => $order['order']]);
        }
        // return back();
    }


    public function loadNextComponentData()
    {

        $this->data = [
            'title' => 'Devices',
            'route' => 'repair-devices',
            'button_text' => 'Back'
        ];
    }




    public function render()
    {
        return view('livewire.admin.repair.repair-price.index')->layout('layouts.admin');
    }
}

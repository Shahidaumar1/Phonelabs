<?php

namespace App\Http\Livewire\Admin\Settings;

use Livewire\Component;

use App\Models\FormStatus;

class ServicesSettings extends Component
{
    public $data = [];
    public $formStatuses;

    function mount()
    {

        $this->loadNextComponentData();

        // Retrieve form status data from the database
        $this->formStatuses = FormStatus::all();
    }

    public function toggleStatus($id, $field)
    {
        // Toggle the status of the specified field for the given form status
        $formStatus = FormStatus::find($id);
        $formStatus->$field = !$formStatus->$field;
        $formStatus->save();

        $this->formStatuses = FormStatus::all();
    }
    public function loadNextComponentData()
    {

        $this->data = [
            'title' => 'Branch',
            'route' => 'branches-settings',
            'button_text' => 'Back'
        ];
    }
    public function render()
    {
        return view('livewire.admin.settings.services-settings')->layout('layouts.admin');
    }
}

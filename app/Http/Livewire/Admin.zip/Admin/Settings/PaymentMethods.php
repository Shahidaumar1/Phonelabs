<?php

namespace App\Http\Livewire\Admin\Settings;

use App\Helpers\ServiceType;
use App\Helpers\Status;
use App\Models\Category;
use App\Models\PaymentMethodSetting;
use Livewire\Component;

class PaymentMethods extends Component
{
    public $data = [];
    public $pm = 'Paypal';

    public function mount()
    {
        $this->loadNextComponentData();
    }

    public function loadNextComponentData()
    {

        $this->data = [
            'title' => 'Branches',
            'route' => 'branches-settings',
            'button_text' => 'Next'
        ];
    }
    public function render()
    {
        return view('livewire.admin.settings.payment-methods')->layout('layouts.admin');
    }
}

<?php

namespace App\Http\Livewire\Admin\Settings\Components;

use App\Models\PaymentMethodSetting;
use Livewire\Component;

class Stripe extends Component
{

    public $client_id;
    public $secret;
    public $dirty = false;

    public function mount()
    {
        $pm = PaymentMethodSetting::where('payment_method_', 'Stripe')->first();
        if ($pm) {
            $this->secret = json_decode($pm->settings)->secret;
        }
    }
    public function updated()
    {
        $this->dirty = true;
    }

    public function connect()
    {
        $this->validate([
            'secret' => 'required',
        ]);
        $pm = PaymentMethodSetting::where('payment_method_', 'Stripe')->first();
        if ($pm) {
            $pm->settings = json_encode([
                'secret' => $this->secret,
            ]);
            $pm->save();
        } else {
            PaymentMethodSetting::create([
                'payment_method_' => 'Stripe',
                'settings' => json_encode([
                    'secret' => $this->secret,
                ]),
            ]);
        }
        $this->dirty = false;
        session()->flash('message', 'Connected successfully!');
    }
    public function render()
    {
        return view('livewire.admin.settings.components.stripe');
    }
}

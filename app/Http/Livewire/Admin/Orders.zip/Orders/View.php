<?php

namespace App\Http\Livewire\Admin\Orders;

use Livewire\Component;

class View extends Component
{
    public $orderDetails;
    public $data;

    public function mount($orderDetails)
    {
        $orders = $this->getOrders();
        $this->data = $orders[$orderDetails];
    }

    public function getOrders()
    {
        $json = file_get_contents(storage_path('app/orders.json'));
        return json_decode($json, true) ?? [];  // Decode JSON or return empty array
    }
    public function render()
    {
        return view('livewire.admin.orders.view')->layout('layouts.admin');
    }
}

<?php

namespace App\Http\Livewire\Admin\Orders;

use Livewire\Component;

class Index extends Component
{
    public $orders;
    public $selectedOrder;
    public $search = '';
    public function mount()
    {

        $this->orders = $this->getOrders();
    }

    public function getOrders()
    {
        $json = file_get_contents(storage_path('app/orders.json'));
        return json_decode($json, true) ?? [];  // Decode JSON or return empty array
    }
    public function viewOrderDetails($orderDetails)
    {
        $this->selectedOrder = json_decode($orderDetails, true);
        $this->emit('showOrderDetailsModal'); // Emit an event to show a modal with order details
    }
    public function updatedSearch()
    {
        // This method will be triggered when the $search property is updated
        $this->emit('searchChanged', $this->search);
    }
    public function render()
    {
        return view('livewire.admin.orders.index')->layout('layouts.admin');
    }
}

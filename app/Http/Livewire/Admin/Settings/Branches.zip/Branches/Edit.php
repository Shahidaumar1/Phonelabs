<?php

namespace App\Http\Livewire\Admin\Settings\Branches;

use Livewire\Component;
use App\Models\Branch;

class Edit extends Component
{
    public $data = [];
    public $rand;
    public $branch;
    public $name;
    public $address_line_1;
    public $address_line_2;
    public $town_city;
    public $post_code;
    public $mobile_number;
    public $landline_number;
    public $email;
    public $latitude;
    public $longitude;

    public function mount($branchId)
    {
        $this->branch = Branch::findOrFail($branchId);

        $this->name = $this->branch->name;
        $this->address_line_1 = $this->branch->address_line_1;
        $this->address_line_2 = $this->branch->address_line_2;
        $this->town_city = $this->branch->town_city;
        $this->post_code = $this->branch->post_code;
        $this->mobile_number = $this->branch->mobile_number;
        $this->landline_number = $this->branch->landline_number;
        $this->email = $this->branch->email;
        $this->latitude = $this->branch->latitude;
        $this->longitude = $this->branch->longitude;
        $this->loadNextComponentData();
    }

    public function rules()
    {
        return [
            'name' => 'required|string|unique:branches,name,' . $this->branch->id,
            'address_line_1' => 'required|string',
            'town_city' => 'required|string',
            'post_code' => 'required|string|min:5|max:8',
            'mobile_number' => 'required|string|min:8|max:14',
            'email' => 'required|email',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
        ];
    }

    protected $listeners = ['selectBranch'];
    public function selectBranch(Branch $branch)
    {
        $this->branch = $branch;
    }
    public function updateBranch()
    {
        $this->validate();

        $this->branch->update([
            'name' => $this->name,
            'address_line_1' => $this->address_line_1,
            'address_line_2' => $this->address_line_2,
            'town_city' => $this->town_city,
            'post_code' => $this->post_code,
            'mobile_number' => $this->mobile_number,
            'landline_number' => $this->landline_number,
            'email' => $this->email,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
        ]);

        session()->flash('message', 'Branch updated successfully!');
        return redirect()->route('branches-settings');
        $this->emit('branchUpdated');
        $this->dispatchBrowserEvent('alert', ['type' => 'success', 'message' => 'Branch updated successfully!']);
    }

    public function loadNextComponentData()
    {

        $this->data = [
            'title' => 'Branch',
            'route' => 'branches-settings',
            'button_text' => 'Back'
        ];
    }
    public function render()
    {
        return view('livewire.admin.settings.branches.edit')->layout('layouts.admin');
    }
}

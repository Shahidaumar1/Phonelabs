<?php

namespace App\Http\Livewire\Admin\Settings\Branches;

use App\Models\Branch;
use Livewire\Component;

class Create extends Component
{
    public $data = [];
    public $name;
    public $address_line_1;
    public $address_line_2;
    public $town_city;
    public $post_code;
    public $mobile_number;
    public $landline_number;
    public $email;
    public $latitude;
    public $longitude;

    public function rules()
    {
        return [
            'name' => 'required|string|unique:branches',
            'address_line_1' => 'required|string',
            'town_city' => 'required|string',
            'post_code' => 'required|string|min:5|max:8',
            'mobile_number' => 'required|string|min:8|max:14',
            'email' => 'required|email',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
        ];
    }
    function mount()
    {

        $this->loadNextComponentData();
    }
    public function saveBranch()
    {
        $this->validate();

        Branch::create([
            'name' => $this->name,
            'address_line_1' => $this->address_line_1,
            'address_line_2' => $this->address_line_2,
            'town_city' => $this->town_city,
            'post_code' => $this->post_code,
            'mobile_number' => $this->mobile_number,
            'landline_number' => $this->landline_number,
            'email' => $this->email,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
        ]);

        session()->flash('message', 'Branch created successfully!');
        return redirect()->route('branches-settings');
        $this->emit('branchCreated');
        $this->resetForm();
        $this->dispatchBrowserEvent('alert', ['type' => 'success', 'message' => 'Branch created successfully!']);
    }

    public function resetForm()
    {
        $this->name = '';
        $this->address_line_1 = '';
        $this->address_line_2 = '';
        $this->town_city = '';
        $this->post_code = '';
        $this->mobile_number = '';
        $this->landline_number = '';
        $this->email = '';
        $this->latitude = '';
        $this->longitude = '';
    }
    public function loadNextComponentData()
    {

        $this->data = [
            'title' => 'Branch',
            'route' => 'branches-settings',
            'button_text' => 'Back'
        ];
    }
    public function render()
    {
        return view('livewire.admin.settings.branches.create')->layout('layouts.admin');
    }
}

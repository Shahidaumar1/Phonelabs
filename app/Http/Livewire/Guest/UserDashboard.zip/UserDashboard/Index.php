<?php

namespace App\Http\Livewire\Guest\UserDashboard;

use Livewire\Component;

class Index extends Component
{

    public $profile;

    public $user;
    public $addresses;
    public $selectedAddress;

    public function mount()
    {
        $this->user = auth()->user();
        $this->addresses = $this->user->addresses;
        $this->selectedAddress = $this->addresses->first();
    }
    public function render()
    {
        return view('livewire.guest.user-dashboard.index')->layout('frontend.layouts.user-app');
    }
}

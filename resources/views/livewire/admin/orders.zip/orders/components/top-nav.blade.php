<nav class="bg-blue px-3" style="padding:4px;">
    <div class="d-flex justify-content-between align-items-center ">
        <i class="fa fa-bars cursor-pointer text-white" aria-hidden="true" onclick="toggleLeftDrawer()"></i>

        <div class="d-flex  align-items-center">
            <div>
                <a href="{{ route('orders') }}" class=" text-white p-3 item  {{ $active == 'orders' ? 'text-danger fw-bold bg-white p-3' : '' }}">Orders Details</a>
            </div>
        </div>

        <livewire:components.avatar />
    </div>

</nav>
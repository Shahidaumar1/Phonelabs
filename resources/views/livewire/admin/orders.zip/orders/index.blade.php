<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="orders" />
        <x-content>
            <livewire:admin.orders.components.top-nav active="" />

            <div class="container my-5">
                <div>


                    <div class="card">
                        <div class="card-header">
                            <h2 class="text-primary">
                                Orders List
                            </h2>
                        </div>
                        <div class="card-body">

                            <div class="d-flex gap-4  flex-wrap table-responive  ">
                                <!-- Search Input -->
                                <input type="text" wire:model="search" class="form-control mb-4" placeholder="Search...">

                                <table class="table table-striped  p-5 shadow">
                                    <thead>
                                        <tr>
                                            <th>Sr. No</th>
                                            <!-- <th>Subject</th> -->
                                            <th>Booking Type</th>
                                            <th>Date Time</th>
                                            <th>Customer Email</th>
                                            <th>Customer Phone</th>
                                            <th>Customer Name</th>
                                            <th>Order Amount</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($orders as $index => $order)
                                        <tr>
                                            <td>{{ $index + 1 }}</td>
                                            <td>{{ $order['Service'] }}</td>
                                            <td>{{ $order['date_time'] }}</td>
                                            <td>{{ $order['patient']['email'] }}</td>
                                            <td>{{ $order['patient']['phone'] }}</td>
                                            <td>{{ $order['patient']['first_name'] . ' ' . $order['patient']['last_name'] }}</td>
                                            <td>{{ $order['repair_detail']['totalPrice'] ?? 0 }}</td>
                                            <td>
                                                <a href="{{ route('orders-details', ['orderDetails' => $index]) }}" class="btn btn-sm btn-primary">View Details</a>
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="8">No orders found.</td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <script>
                document.addEventListener('livewire:load', function() {
                    window.searchTerm = '';

                    Livewire.hook('message.processed', (message, component) => {
                        // Update the table rows based on the search term
                        filterTableRows();
                    });

                    function filterTableRows() {
                        const searchTerm = window.searchTerm.toLowerCase();
                        const tableRows = document.querySelectorAll('.table-row');

                        tableRows.forEach(row => {
                            const rowData = row.innerText.toLowerCase();
                            if (rowData.includes(searchTerm)) {
                                row.style.display = '';
                            } else {
                                row.style.display = 'none';
                            }
                        });
                    }
                });
            </script>
            <script>
                document.addEventListener('livewire:load', function() {
                    Livewire.on('searchChanged', search => {
                        window.searchTerm = search;
                    });
                });
            </script>

        </x-content>


    </div>
</div>
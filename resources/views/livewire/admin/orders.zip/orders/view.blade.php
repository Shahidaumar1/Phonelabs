<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="orders" />
        <x-content>
            <livewire:admin.orders.components.top-nav active="" />

            <div class="container my-5">
                <div>


                    <div class="card">
                        <div class="card-header">
                            <h2 class="text-primary">
                                Orders Details
                            </h2>
                        </div>
                        <div class="card-body">

                            <div class="container">
                                <div class="row">
                                    

                                    <div class="mb-3 col-12">
                                        <h3 class="text-primary text-center"><b>Customer Details</b></h3>
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td>Name:</td>
                                                    <td style="font-weight: 600">
                                                        {{ $data['patient']['first_name'] }} {{ $data['patient']['last_name'] }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Email:</td>
                                                    <td style=" font-weight: 600">
                                                        {{ $data['patient']['email'] }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row">Contact number:</td>
                                                    <td style=" font-weight: 600">
                                                        {{ $data['patient']['phone'] }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row">Existing Customer:</td>
                                                    <td style=" font-weight: 600">
                                                        {{ $data['patient']['existing_patient'] ? 'Yes' : 'No' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row">Business Repair:</td>
                                                    <td style=" font-weight: 600">
                                                        {{ $data['patient']['business_repair'] ? 'Yes' : 'No' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row">Company Name:</td>
                                                    <td style="font-weight: 600">
                                                        {{ $data['patient']['company_name'] ?? 'N/A' }}
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="mb-3 col-12">
                                        <h3 class="text-primary text-center"><b>Repair Details</b></h3>
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td scope="col">Booking Reference:</td>
                                                    <td scope="col">
                                                        This will follow in the acknowledgement email to be sent by
                                                        our Lab Team
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Device:</td>
                                                    <td style=" font-weight: 600">{{ $data['repair_detail']['device'] }}
                                                        {{ $data['repair_detail']['model'] }}
                                                        {{ array_key_exists('emc', $data) ? $data['emc'] : '' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Fault:</td>
                                                    <td style=" font-weight: 600">
                                                        @if (array_key_exists('faults', $data['repair_detail']))
                                                        @foreach ($data['repair_detail']['faults'] as $value)
                                                        @if ($value != 'Other Fault (Please Specify)')
                                                        <span style=" font-weight: 600">{{ $value }}</span><br>
                                                        @endif
                                                        @endforeach
                                                        @endif
                                                        {{ $data['repair_detail']['fault'] }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Turnaround Time:</td>
                                                    <td style=" font-weight: 600">{{ $data['repair_detail']['How_long'] }}
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Part Used:</td>
                                                    <td style=" font-weight: 600">{{ $data['repair_detail']['part_used'] }}</td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Warranty:</td>
                                                    <td style=" font-weight: 600">{{ $data['repair_detail']['warranty'] }}</td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Provisional Quote:</td>
                                                    <td style=" font-weight: 600"> £ {{ $data['repair_detail']['quotePrice'] }}</td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Additional Costs:</td>
                                                    <td style=" font-weight: 600">
                                                        {{ $data['repair_detail']['screen_protector'] }}
                                                        {{ $data['repair_detail']['protective_case'] }}
                                                        {{ $data['repair_detail']['postal_price'] }}
                                                        {{ $data['repair_detail']['fix_form_price'] }}
                                                        {{ $data['repair_detail']['collection_form_price'] }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">appointment at</td>
                                                    <td>
                                                        <span style="color: red"><strong>{{ $data['form']['name'] ?? ""}}</strong></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Date - Time</td>
                                                    <td>
                                                        {{ $data['form']['appointment_date'] ?? ""}} - {{ $data['form']['appointment_time'] ?? ""}}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Repair Note</td>
                                                    <td>
                                                        {{ $data['form']['repair_note'] ?? "" }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td scope="row" style="width: 170px;">Info:</td>
                                                    <td>
                                                        If we can’t repair your device, then under our
                                                        <span style="color: red"><strong>No-Fix, No-Fee </strong></span>promise, there’s nothing
                                                        to pay for the work undertaken.
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </x-content>


    </div>
</div>
<div>
    {{-- Top bar + Nav --}}
    <livewire:components.top-bar />
    <livewire:components.mega-nav />

    <div class="container py-5">
        <div class="row">
            {{-- Sidebar filters --}}
            <div class="col-lg-3 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <a class="text-danger small" wire:click="clearFilter" style="cursor:pointer;">
                        Clear Filter
                    </a>
                </div>

                {{-- Categories --}}
                <div class="card mb-3">
                    <div class="card-header" style="background-color: #EA1555; color: white; padding: 0.5rem 1rem;">
                        Categories
                    </div>
                    <div class="card-body">
                        <div class="form-check mb-1">
                            <input class="form-check-input"
                                   type="radio"
                                   id="cat-all"
                                   value="All"
                                   wire:model="selectedCategoryId">
                            <label for="cat-all" class="form-check-label">All</label>
                        </div>

                        @foreach($categories as $cat)
                            <div class="form-check mb-1">
                                <input class="form-check-input"
                                       type="radio"
                                       id="cat-{{ $cat->id }}"
                                       value="{{ $cat->id }}"
                                       wire:model="selectedCategoryId">
                                <label for="cat-{{ $cat->id }}" class="form-check-label">
                                    {{ $cat->name }}
                                </label>
                            </div>
                        @endforeach
                    </div>
                </div>

                {{-- Devices --}}
                <div class="card mb-3">
                    <div class="card-header" style="background-color: #EA1555; color: white; padding: 0.5rem 1rem;">
                        Devices
                    </div>
                    <div class="card-body">
                        @if($devices->count())
                            @foreach($devices as $device)
                                <button
                                    type="button"
                                    class="btn btn-sm w-100 mb-2 {{ $selectedDevice && $selectedDevice->id === $device->id ? 'btn-danger text-white' : 'btn-outline-secondary' }}"
                                    wire:click="selectDevice({{ $device->id }})"
                                >
                                    {{ $device->name }}
                                </button>
                            @endforeach
                        @else
                            <p class="mb-0 small text-muted">No devices found.</p>
                        @endif
                    </div>
                </div>
            </div>

            {{-- Right side: search + models grid --}}
            <div class="col-lg-9">
                {{-- Search bar --}}
                <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                    <h4 class="mb-0"></h4>
                    <div class="input-group" style="max-width: 320px;">
                        <input type="text"
                               class="form-control"
                               placeholder="Search model..."
                               wire:model.debounce.500ms="search">
                        <span class="input-group-text">
                            <i class="fa fa-search"></i>
                        </span>
                    </div>
                </div>

                {{-- Models grid --}}
                <div class="row">
                    @forelse($models as $model)
                        <div class="col-md-4 mb-4">
                            @php
                                // ✅ Repair/Buy wali tarah — slug use karo
                                $modelSlug = $model->slug ?? $model->id;
                                $catSlug   = $model->device_type?->category?->slug
                                             ?? \Illuminate\Support\Str::slug($model->device_type?->category?->name ?? 'accessories');
                                $devSlug   = $model->device_type?->slug
                                             ?? \Illuminate\Support\Str::slug($model->device_type?->name ?? 'device');
                            @endphp

                            {{-- ✅ NEW SEO URL: /accessories/phones/apple/iphone-15-pro-case --}}
                            <div class="card h-100 text-center">
                                <img
                                    src="{{ $model->file ?? 'https://via.placeholder.com/250x250?text=Accessory' }}"
                                    class="card-img-top p-3"
                                    style="height: 220px; object-fit: contain;"
                                    alt="{{ $model->name }}"
                                >
                                <div class="card-body d-flex flex-column">
                                    <h6 class="fw-bold">{{ $model->name }}</h6>
                                    <p class="small text-muted mb-3">
                                        {{ $model->device_type->name ?? '' }}
                                    </p>
                                    <a href="{{ route('guest-accessories-product-specs', [
                                        'category_slug' => $catSlug,
                                        'device_slug'   => $devSlug,
                                        'model_slug'    => $modelSlug,
                                    ]) }}"
                                       class="btn"
                                       style="background-color: #EA1555; color: white; margin-top: auto;">
                                        View Options
                                    </a>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12">
                            <div class="alert alert-info">
                                No accessories found for this filter/search.
                            </div>
                        </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>
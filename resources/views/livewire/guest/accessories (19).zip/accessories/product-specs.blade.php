<div>
    <livewire:components.top-bar />
    <livewire:components.mega-nav />

    <style>
        /* NEW: top step nav styles */
        .steps-nav {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 12px;
            padding-top: 100px;
            padding-bottom: 40px;
            margin: 0;
            list-style: none;
        }

        .steps-nav-item {
            position: relative;
            display: flex;
            align-items: center;
        }

        .steps-nav-item + .steps-nav-item::before {
            content: "";
            width: 24px;
            height: 2px;
            background-color: #6c757d;
            position: absolute;
            left: -18px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 1;
        }

        .steps-nav-link {
            display: inline-block;
            padding: 0.45rem 1.2rem;
            border-radius: 9999px;
            border: 1px solid #dee2e6;
            background-color: #f8f9fa;
            font-size: 0.95rem;
            color: #000;
            text-decoration: none;
            position: relative;
            z-index: 2;
            white-space: nowrap;
            transition: all 0.2s ease;
        }

        .steps-nav-link:hover {
            color: #dc3545;
            border-color: #dc3545;
            text-decoration: none;
        }

        .steps-nav-link.active {
            background-color: #dc3545;
            border-color: #dc3545;
            color: #fff;
        }

        .button-27 {
            appearance: none;
            background-color: #dc3545;
            border: 2px solid #dc3545;
            border-radius: 15px;
            box-sizing: border-box;
            color: #fff;
            cursor: pointer;
            display: inline-block;
            font-size: 16px;
            font-weight: 600;
            line-height: normal;
            margin: 0;
            min-height: 40px;
            outline: none;
            padding: 8px 18px;
            text-align: center;
            text-decoration: none;
            transition: all 150ms;
            user-select: none;
        }

        .button-27:hover {
            background-color: #b51c37;
            border-color: #b51c37;
        }

        @media (max-width: 767px) {
            .steps-nav {
                padding-top: 80px;
                padding-bottom: 30px;
                flex-wrap: wrap;
            }
        }
    </style>

    {{-- breadcrumb steps (TOP) --}}
    <div class="d-none d-md-block" style="display:flex;justify-content:center;align-items:center;margin:0;">
        <div class="container mt-3" style="text-align:center;">
            <ul class="steps-nav" id="form-navigation">
                <li class="steps-nav-item">
                    <a href="#" data-step="0" class="steps-nav-link active">Product Info</a>
                </li>
                <li class="steps-nav-item">
                    <a href="#" data-step="1" class="steps-nav-link">Select Condition</a>
                </li>
                <li class="steps-nav-item">
                    <a href="#" data-step="2" class="steps-nav-link">Personal Detail</a>
                </li>
                <li class="steps-nav-item">
                    <a href="#" data-step="3" class="steps-nav-link">Book Repair</a>
                </li>
            </ul>
        </div>
    </div>

    {{-- STEP 0: Product info / specs --}}
    <section id="product-info-section" class="form-step">
        <div class="container mt-5">
            <div class="row">
                {{-- image --}}
                <div class="col-lg-6 p-5 mt-5 text-center">
                    @if (json_decode($product_spec_image) === null)
                        <img src="{{ $product_spec_image ?? $model->file }}"
                             class="img-fluid"
                             style="min-width: 75%; max-height: 480px;">
                    @else
                        <div id="imageSlider" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                @foreach (json_decode($product_spec_image) as $index => $image)
                                    <div class="carousel-item {{ $index === 0 ? 'active' : '' }} text-center">
                                        <img src="{{ $image }}"
                                             class="img-fluid"
                                             style="min-width: 75%; max-height: 480px;"
                                             alt="Image {{ $index + 1 }}">
                                    </div>
                                @endforeach
                            </div>
                            <button class="carousel-control-prev text-bg-danger" type="button"
                                    data-bs-target="#imageSlider" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next text-bg-danger" type="button"
                                    data-bs-target="#imageSlider" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    @endif
                </div>

                {{-- options --}}
                <div class="col-lg-6">
                    <div class="mt-4 text-center">
                        <h6 class="fs-2 fw-bold">Please select specifications</h6>
                        <p class="text-danger">(This enables us to offer you a preliminary estimate.)</p>
                    </div>

                    <div class="mt-5">
                        <p class="fs-3 fw-bold">{{ $model->name }}</p>

                        @if (!empty($available_memory_sizes))
                            <p class="fs-6 fw-bold">Select Category:</p>
                            <div class="d-flex flex-wrap gap-2">
                                @foreach ($available_memory_sizes as $memory_size)
                                    <button type="button"
                                            class="btn btn-outline-danger {{ $memory_size == $selectedMemorySize ? 'bg-danger text-white' : '' }}"
                                            wire:click="$set('selectedMemorySize', '{{ $memory_size }}')">
                                        {{ $memory_size }}
                                    </button>
                                @endforeach
                            </div>
                        @endif

                        @php
                            $nonEmptyGrades = [];
                            if (!empty($available_grades)) {
                                foreach ($available_grades as $g) {
                                    if (!is_null($g) && $g !== '') {
                                        $nonEmptyGrades[] = $g;
                                    }
                                }
                            }
                        @endphp

                        @if (!empty($nonEmptyGrades))
                            <p class="fs-6 mt-3 fw-bold">Select Grade:</p>
                            <div class="d-flex flex-wrap gap-2">
                                @foreach ($nonEmptyGrades as $grade)
                                    <button type="button"
                                            class="btn btn-outline-dark {{ $grade == $selectedGrade ? 'bg-danger text-white' : '' }}"
                                            wire:click="$set('selectedGrade', '{{ $grade }}')">
                                        {{ $grade }}
                                    </button>
                                @endforeach
                            </div>
                        @endif

                        @if (!empty($available_colors))
                            <p class="fs-5 mt-3 fw-bold">Color:</p>
                            <div class="d-flex flex-wrap gap-2">
                                @foreach ($available_colors as $color)
                                    <button type="button"
                                            class="btn btn-outline-dark {{ $color == $selectedColor ? 'bg-danger text-white' : '' }}"
                                            wire:click="$set('selectedColor', '{{ $color }}')">
                                        {{ $color }}
                                    </button>
                                @endforeach
                            </div>
                        @endif

                        <div class="mt-3">
                            <label for="quantity">
                                Quantity: only {{ $available_quantity }} Available
                            </label>
                            <div class="input-group mt-2" style="max-width:max-content;">
                                <button type="button" class="btn btn-danger"
                                        wire:click="decreaseQuantity">-</button>
                                <input type="number"
                                       class="form-control border-0 text-center"
                                       wire:model="quantity"
                                       min="1"
                                       max="{{ $available_quantity }}"
                                       step="1"
                                       wire:change="quantityChanged">
                                <button type="button" class="btn btn-success"
                                        wire:click="increaseQuantity">+</button>
                            </div>
                        </div>

                        {{-- accordion Details / Specification / Warranty --}}
                        <div class="accordion mt-4" id="specAccordion">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingDetails">
                                    <button class="accordion-button" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseDetails"
                                            aria-expanded="true" aria-controls="collapseDetails">
                                        Details
                                    </button>
                                </h2>
                                <div id="collapseDetails"
                                     class="accordion-collapse collapse show"
                                     aria-labelledby="headingDetails"
                                     data-bs-parent="#specAccordion">
                                    <div class="accordion-body">
                                        {!! $detail ?? '' !!}
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingSpec">
                                    <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseSpec"
                                            aria-expanded="false" aria-controls="collapseSpec">
                                        Specification
                                    </button>
                                </h2>
                                <div id="collapseSpec"
                                     class="accordion-collapse collapse"
                                     aria-labelledby="headingSpec"
                                     data-bs-parent="#specAccordion">
                                    <div class="accordion-body">
                                        {!! $specification ?? '' !!}
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingWarranty">
                                    <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseWarranty"
                                            aria-expanded="false" aria-controls="collapseWarranty">
                                        Warranty
                                    </button>
                                </h2>
                                <div id="collapseWarranty"
                                     class="accordion-collapse collapse"
                                     aria-labelledby="headingWarranty"
                                     data-bs-parent="#specAccordion">
                                    <div class="accordion-body">
                                        {!! $warranty ?? '' !!}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="p-2 fs-5 text-danger fw-bold mt-4" id="cashText">
                            <h2 style="white-space: nowrap;">
                                Cash Value: £ {{ $price ?? 0 }}.00
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- STEP 1: form-toggle --}}
    <section id="form-toggle-section" class="form-step pt-5" style="display:none;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rounded p-4">
                        <livewire:guest.components.form-toggle :data="$data" :key="uniqid()" />
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- STEP 2: patient details --}}
    <section id="patient-detail-section" class="form-step" style="display:none;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rounded p-4">
                        <livewire:guest.components.patient-detail-form :key="uniqid()" />
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- STEP 3: booking + payment — ✅ FIXED: accessories component use ho raha hai --}}
    <section id="booking-section" class="form-step" style="display:none;">
        <div class="container" wire:ignore>
            <livewire:guest.accessories.book-repair :data="$data" :key="uniqid()" />
        </div>
    </section>

    {{-- Next / Back buttons --}}
    <div class="container mt-3" style="position: relative;">
        <div class="d-flex justify-content-between">
            <button type="button"
                    id="back-button"
                    class="btn btn-link"
                    style="display:none;">
                <img src="https://ik.imagekit.io/b6iqka2sz/prev.png?updatedAt=1719938010352"
                     style="width: 150px; height: auto; margin-left: auto;">
            </button>

            <button id="next-button"
                    type="button"
                    class="button-27"
                    role="button"
                    style="width: 150px; height: auto; margin-left: auto;">
                Next
            </button>
        </div>
    </div>

    {{-- JS for steps --}}
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            const steps = ['#product-info-section', '#form-toggle-section', '#patient-detail-section', '#booking-section'];
            let currentStep = 0;
            let formCompleted = [true, false, false, true];

            function showStep(stepIndex) {
                steps.forEach((step, index) => {
                    $(step).toggle(index === stepIndex);
                });

                $('#back-button').toggle(stepIndex > 0);
                $('#next-button').toggle(stepIndex < steps.length - 1);

                $('#form-navigation .steps-nav-link').removeClass('active');
                $('#form-navigation .steps-nav-link[data-step="' + stepIndex + '"]').addClass('active');
            }

            function moveToNextStep() {
                if (currentStep < steps.length - 1) {
                    currentStep++;
                    showStep(currentStep);
                }
            }

            $('#back-button').click(function () {
                if (currentStep > 0) {
                    currentStep--;
                    showStep(currentStep);
                }
            });

            $('#next-button').click(function () {
                if (formCompleted[currentStep]) {
                    Livewire.emit('formSubmitted', currentStep);
                } else {
                    alert('Please complete the current step.');
                }
            });

            Livewire.on('formSubmitted', function (stepIndex) {
                formCompleted[stepIndex] = true;
                moveToNextStep();
            });

            Livewire.on('formInvalid', function (stepIndex) {
                formCompleted[stepIndex] = false;
                showStep(currentStep);
            });

            $('#form-navigation .steps-nav-link').click(function (e) {
                e.preventDefault();
                const stepIndex = $(this).data('step');
                if (stepIndex !== currentStep) {
                    currentStep = stepIndex;
                    showStep(currentStep);
                }
            });

            showStep(currentStep);
        });
    </script>
</div>
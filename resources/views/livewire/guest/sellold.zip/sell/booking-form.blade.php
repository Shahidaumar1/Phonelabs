<section>
    <style>
        @media only screen and (max-width: 767px) {
            .text-sm {
                font-size: 20px;
                /* Adjust the font size as needed */
                text-align: center;
                /* Center the text */
            }

            .text-m {
                font-size: 25px;
                /* Adjust the font size as needed */
                text-align: center;
                /* Center the text */
                font-weight: bold;
                /* Set the font weight to bold */
                margin-left: 3%;
            }
            
            
            

        }
    </style>
    <style>
        .accordion-button:not(.collapsed) {
            background-color: white;
            box-shadow: none;
        }

        .accordion-button:not(.collapsed)::after {
            display: none;
        }

        .accordion-button::after {
            display: none;
        }

        .accordion-item {
            justify-content: space-between;
        }
    </style>


    @php

        $form_name = 'Post Your Device';
        $paywithcardtext = "send us in our store";
    @endphp

 @if (session('form_type') == 'postal_form')
    @php
        $form_name = 'Post Your Device';
                $paywithcardtext = 'I�ll Pay after Repair'

    @endphp
    @endif
                                            
                        

@if (session('form_type') == 'collection_form')
    @php
        $form_name = 'We Collect Your Device';
                $paywithcardtext = 'I�ll Pay after Repair'

    @endphp
 @endif
                       
@if (session('form_type') == 'clinic_form')
    @php
        $form_name = 'Collect Your Cash AT Store ';
                $paywithcardtext = 'Collect Your Cash AT Store'
    @endphp

@endif


@if (session('form_type') == 'fix_form')
    @php
        $form_name = 'Fix at Your Location';
                $paywithcardtext = 'I�ll Pay after Repair'

    @endphp
@endif

        @php
            $storedCollectionRepairPrice = Session::get('collectionRepairPrice');
        @endphp
        @if ($storedCollectionRepairPrice)
            <p style="font-size:1vw">Delivery Charges For Collection Repair:
                £{{ $storedCollectionRepairPrice }}</p>

            @php
                $price = $price + $storedCollectionRepairPrice;

            @endphp
        @endif

















    <x-alert />





    <!-- In the Blade template for OtherComponent -->







    @if ($success)
        {{-- <div class="col-4">
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Congratulations! 🎉 Your order has been successfully placed.</h4>
                <p>Sit tight while we process your request. Check your email for more instructions.</p>
                <hr>
                <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
            </div>

        </div> --}}
        <!-- Include jQuery -->




        <!-- Bootstrap 5 Modal Example -->
        <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="successModalLabel">Congratulations! 🎉</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h4>Your order has been successfully placed.</h4>
                        <p>Sit tight while we process your request. Check your email for more instructions.</p>
                        <hr>
                        <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                // Open the modal when the page loads if $success is true
                var successModal = new bootstrap.Modal(document.getElementById('successModal'));
                successModal.show();
            });
        </script>
    @else
        <div class = "container mb-4">
<h2 class="text-center" style="color: red;">How would you like to be paid?</h2>

            <div class="row">

                <div class="col-md-6  pt-4 mb-3">
                   
                    <p class="text-center fw-bolder fs-5">Select your payment option</p>
                    <div class=" p-2  " style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 4px">
                        <div class="container p-3">
                            <div class="accordion" id="payment-accodoion">


@if (session('form_type') == 'clinic_form')



                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button d-flex justify-content-between collapsed"
                                            type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                            aria-expanded="false" aria-controls="collapseOne">
                                            <p style="font-size: 1.1rem;"><input type="radio" name="radio-payment"
                                                    style="width: 19px;height: 17px; " checked>
                                                    {{$paywithcardtext}}
                                                    </p>
                                            <p class="d-md-block d-lg-block"></p>
                                            <p style="font-size: 1.3rem; color:red;"> £
                                                {{ $price ? $price : 0 }}
                                            </p>
                                        </button>
                                    </h2>


                                    <div id="collapseOne" class="accordion-collapse collapse"
                                        aria-labelledby="headingOne" data-bs-parent="#payment-accordion">
                                        <div class="accordion-body" style="padding-top: 0px;">
                                            <div class="container">
                                                <div class="d-felx" style="gap: 10px;">

                                                    <div class>
                                                        <p>collect cash at store when you visit our location below</p>
                                                        <p class> <svg xmlns="http://www.w3.org/2000/svg" width="16"
                                                                height="16" fill="currentColor"
                                                                class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                                                                <path
                                                                    d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6" />
                                                            </svg> {{ $name }}, {{ $address_line_1 }},
                                                            {{ $address_line_2 }}{{ $address_line_2 != '' ? ', ' : '' }}
                                                            {{ $town_city }}, {{ $post_code }}</p>
                                                    </div>
                                                    <div class="details-con">
                                                        <p class><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                                                height="16" fill="currentColor"
                                                                class="bi bi-envelope" viewBox="0 0 16 16">
                                                                <path
                                                                    d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                                                            </svg> {{ $email }}</p>
                                                    </div>
                                                    <div class="d-flex justify-content-between">
                                                        <p> <svg xmlns="http://www.w3.org/2000/svg" width="16"
                                                                height="16" fill="currentColor"
                                                                class="bi bi-telephone-forward" viewBox="0 0 16 16">
                                                                <path
                                                                    d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708" />
                                                            </svg> {{ $landline_number }}</p>
                                                        <!--<button type="button "-->
                                                        <!--    class="btn btn-light btn-sm"-->
                                                        <!--    style="border: 1px solid grey">Submit-->
                                                        <!--</button>-->


                                                        <button class="btn btn-danger" type="button"
                                                            wire:click="SellDevice">Submit</button>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
@endif





                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingthree">
                                        <button style = "padding-bottom: 0px;"
                                            class="accordion-button collapsed d-flex  justify-content-between"
                                            type="button" data-bs-toggle="collapse" data-bs-target="#collapsethree"
                                            aria-expanded="false" aria-controls="collapsethree"
                                            onclick="handleRadio(this)">

                                            <div> <input type="radio" onclick="event.stopPropagation();"
                                                    name="radio-payment"
                                                    style=" width: 19px;height: 17px; font-size: 1.3rem;">
                                                <img class="img-fluid" style="width: 100px;"
                                                    src="https://ik.imagekit.io/4csyk445b/PayPal_horizontally_Logo_2014.png?updatedAt=1709738114776"
                                                    alt>
                                            </div>
                                            <p style="font-size: 1.3rem; color:red;">£ {{ $price ?? '' }}.00</p>

                                        </button>
                                    </h2>

                                    <div id="collapsethree" class="accordion-collapse collapse"
                                        aria-labelledby="collapsethree" data-bs-parent="#payment-accodoion">
                                        <div class="accordion-body">
                                            <p style="font-size:15px" class= "text-center">Seamlessly checkout with
                                                PayPal for a trusted payment experience. </p>
                                            <livewire:guest.sell.components.paypal />
                                            <div class="d-flex justify-content-center">

                                            </div>
                                        </div>
                                    </div>
                                </div>



                           <div class="accordion-item container border rounded p-3">
                               
                                        <h2 class="accordion-header " id="headingfour">
                                        <button style="padding-bottom: 0px;"
                                            class="accordion-button d-flex justify-content-between" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapsefour"
                                            aria-expanded="true" aria-controls="collapsefour">
                                            <div>
                                                <p style="font-size: 1.4rem;">
                                                    <input type="radio" name="radio-payment"
                                                        style="width: 19px; height: 17px;" checked> Bank transfer
                                                </p>
                                            </div>
                                            <h4 style="font-size: 1.3rem; color: red;">£ {{ $price ?? '' }}.00</h4>

                                        </button>
                                    </h2>
                                    <div id="collapsefour" class="accordion-collapse collapse show"
                                        aria-labelledby="headingfour" data-bs-parent="#payment-accodoion">
                                        <div class="accordion-body">

                                            {{-- @if ($form == 'bank')
                                                <livewire:guest.sell.components.bank />
                                            @endif --}}
                                            <!-- -------change radio forms------ -->
                                            <div class="d-flex  align-items-center">
                                                <style>
                                                    .col-7 {
                                                        width: 100%;
                                                        height: 100%;
                                                        background: #ffffff 0% 0% no-repeat padding-box;

                                                        border-radius: 15px;
                                                        margin-left: auto;
                                                        margin-right: auto;
                                                    }

                                                    @media (max-width: 767px) {
                                                        .col-7 {
                                                            width: 100%;
                                                            /* Limit maximum width */
                                                        }

                                                        .btn-success {
                                                            margin-top: -20px;
                                                        }

                                                    }
                                                </style>
                                                <div class="my-4 col-12" style="

          ">
                                                    <div id="paymentForm">
                                                        <!--<h2 class="text-center p-2 fw-bold">Bank Transfer</h2>-->

                                                        <div class="px-1 ">
                                                            <!--<label for="disabledSelect" class="form-label">Account Title</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Title" wire:model.debounce.500="bank.account_title">-->

                                                          <div class="row mb-2">
<label for="exampleFormControlInput1" style="font-size: 17px; white-space: nowrap;" class="col-sm-2 col-md-4 col-form-label col-10">Account Name</label>

    <div class="col-sm-10 col-10 col-md-8">
        <input type="text" class="form-control" id="exampleFormControlInput1" style="font-size:12px;" placeholder="Enter Account Title" wire:model.debounce.500="bank.account_title">
    </div>
</div>





                                                            @error('bank.account_title')
                                                                <span class="text-danger error">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="px-1 ">
                                                            <!--<label for="disabledSelect" class="form-label">Account Number</label>-->
                                                            <!--<input type="number" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Number" wire:model.debounce.500="bank.account_number">-->
                                                            <div class="row mb-2">
                                                                <label for="exampleFormControlInput1"
                                                                    style="font-size: 17px; white-space: nowrap;" class="col-sm-2 col-form-label col-md-4 col-10">Account Number</label>
                                                                <div class="col-sm-10 col-10 col-md-8">
                                                                    <input type="number" class="form-control"
                                                                        id="exampleFormControlInput1"
                                                                        style="font-size:11px;"
                                                                        placeholder="Enter Account Number"
                                                                        wire:model="bank.account_number">
                                                                </div>
                                                            </div>


                                                            @error('bank.account_number')
                                                                <span class="text-danger error">{{ $message }}</span>
                                                            @enderror
                                                        </div>
                                                        <div class="px-1 ">
                                                            <!--<label for="disabledSelect" class="form-label">Bank Name</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Bank Name" wire:model.debounce.500="bank.name">-->
                                                            <div class="row mb-2">
                                                                <label for="exampleFormControlInput1"
                                                                    style="font-size: 17px;" class="col-sm-2 col-form-label col-10 col-md-4">Bank</label>
                                                                <div class="col-sm-10 col-md-8">
                                                                    <input type="text" class="form-control "
                                                                        id="exampleFormControlInput1"
                                                                        style="font-size:11px;"
                                                                        placeholder="Enter Bank Name"
                                                                        wire:model="bank.name">
                                                                </div>
                                                            </div>



                                                            @error('bank.name')
                                                                <span class="text-danger error">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="px-1 ">
                                                            <!--<label for="disabledSelect" class="form-label">Sort Code</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Sort Code" wire:model.debounce.500="bank.sort_code">-->
                                                            <div class="row mb-2">
                                                                <label for="exampleFormControlInput1"
                                                                   style="font-size: 18px;" class="col-sm-2 col-form-label col-10 col-md-4">S.code</label>
                                                                <div class="col-sm-10 col-10 col-md-8">
                                                                    <input type="text" class="form-control"
                                                                        id="exampleFormControlInput1"
                                                                        style="font-size:11px;"
                                                                        placeholder="Enter Sort Code"
                                                                        wire:model="bank.sort_code">
                                                                </div>
                                                            </div>



                                                            @error('bank.sort_code')
                                                                <span class="text-danger error">{{ $message }}</span>
                                                            @enderror
                                                        </div>
                                                        <div class="px-2 py-2">
                                                            <div class="form-check">
                                                                <input style="transform: scale(0.8);"
                                                                    class="form-check-input" type="checkbox"
                                                                    value="" id="flexCheckDefault" />
                                                                <label style="font-size: 15px;"
                                                                    class="form-check-label col-10  " for="flexCheckDefault">
                                                                    I Agree with
                                                                    <a href="https://mobilebitz.co.uk/privacy-policy" target="_blank" style="text-decoration: underline !important; color: blue !important;">Privacy Policy</a>
                                                                     and
                                                                    <a href="https://mobilebitz.co.uk/terms-and-conditions" target="_blank" style="text-decoration: underline !important; color: blue !important;">Terms & Conditions</a>
                                                                </label>
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="cursor-point align-items-center d-grid gap-2 col-12 justify-content-center">

                                                            <button class="btn btn-danger text-white"
                                                                wire:click="submit" style="font-size: 20px;" class="col-sm-2 col-form-label col-10">Submit</button>


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                    </div>
                                </div>




<!--                                <div class="accordion-item">-->
<!--                                    <h2 class="accordion-header" id="headingfour">-->
<!--                                        <button style="padding-bottom: 0px;"-->
<!--                                            class="accordion-button d-flex justify-content-between" type="button"-->
<!--                                            data-bs-toggle="collapse" data-bs-target="#collapsefour"-->
<!--                                            aria-expanded="true" aria-controls="collapsefour">-->
<!--                                            <div>-->
<!--                                                <p style="font-size: 1.4rem;">-->
<!--                                                    <input type="radio" name="radio-payment"-->
<!--                                                        style="width: 19px; height: 17px;" checked> Bank transfer-->
<!--                                                </p>-->
<!--                                            </div>-->
<!--                                            <h4 style="font-size: 1.3rem; color: red;">£ {{ $price ?? '' }}.00</h4>-->

<!--                                        </button>-->
<!--                                    </h2>-->
<!--                                    <div id="collapsefour" class="accordion-collapse collapse show"-->
<!--                                        aria-labelledby="headingfour" data-bs-parent="#payment-accodoion">-->
<!--                                        <div class="accordion-body">-->

<!--                                            {{-- @if ($form == 'bank')-->
<!--                                                <livewire:guest.sell.components.bank />-->
<!--                                            @endif --}}-->
                                            <!-- -------change radio forms------ -->
<!--                                            <div class="d-flex  align-items-center">-->
<!--                                                <style>-->
<!--                                                    .col-7 {-->
<!--                                                        width: 100%;-->
<!--                                                        height: 100%;-->
<!--                                                        background: #ffffff 0% 0% no-repeat padding-box;-->

<!--                                                        border-radius: 15px;-->
<!--                                                        margin-left: auto;-->
<!--                                                        margin-right: auto;-->
<!--                                                    }-->

<!--                                                    @media (max-width: 767px) {-->
<!--                                                        .col-7 {-->
<!--                                                            width: 100%;-->
                                                          
<!--                                                        }-->

<!--                                                        .btn-success {-->
<!--                                                            margin-top: -20px;-->
<!--                                                        }-->

<!--                                                    }-->
<!--                                                </style>-->
<!--                                                <div class="my-4 col-12" style="-->

<!--          ">-->
<!--                                                    <div id="paymentForm">-->
                                                        <!--<h2 class="text-center p-2 fw-bold">Bank Transfer</h2>-->

<!--                                                        <div class="px-1 ">-->
                                                            <!--<label for="disabledSelect" class="form-label">Account Title</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Title" wire:model.debounce.500="bank.account_title">-->

<!--                                                          <div class="row mb-2">-->
<!--<label for="exampleFormControlInput1" style="font-size: 17px; white-space: nowrap;" class="col-sm-2 col-md-4 col-form-label col-10">Account Name</label>-->

<!--    <div class="col-sm-10 col-10 col-md-8">-->
<!--        <input type="text" class="form-control" id="exampleFormControlInput1" style="font-size:12px;" placeholder="Enter Account Title" wire:model.debounce.500="bank.account_title">-->
<!--    </div>-->
<!--</div>-->





<!--                                                            @error('bank.account_title')-->
<!--                                                                <span class="text-danger error">{{ $message }}</span>-->
<!--                                                            @enderror-->
<!--                                                        </div>-->

<!--                                                        <div class="px-1 ">-->
                                                            <!--<label for="disabledSelect" class="form-label">Account Number</label>-->
                                                            <!--<input type="number" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Number" wire:model.debounce.500="bank.account_number">-->
<!--                                                            <div class="row mb-2">-->
<!--                                                                <label for="exampleFormControlInput1"-->
<!--                                                                    style="font-size: 17px; white-space: nowrap;" class="col-sm-2 col-form-label col-md-4 col-10">Account Number</label>-->
<!--                                                                <div class="col-sm-10 col-10 col-md-8">-->
<!--                                                                    <input type="number" class="form-control"-->
<!--                                                                        id="exampleFormControlInput1"-->
<!--                                                                        style="font-size:11px;"-->
<!--                                                                        placeholder="Enter Account Number"-->
<!--                                                                        wire:model="bank.account_number">-->
<!--                                                                </div>-->
<!--                                                            </div>-->


<!--                                                            @error('bank.account_number')-->
<!--                                                                <span class="text-danger error">{{ $message }}</span>-->
<!--                                                            @enderror-->
<!--                                                        </div>-->
<!--                                                        <div class="px-1 ">-->
                                                            <!--<label for="disabledSelect" class="form-label">Bank Name</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Bank Name" wire:model.debounce.500="bank.name">-->
<!--                                                            <div class="row mb-2">-->
<!--                                                                <label for="exampleFormControlInput1"-->
<!--                                                                    style="font-size: 17px;" class="col-sm-2 col-form-label col-10 col-md-4">Bank</label>-->
<!--                                                                <div class="col-sm-10 col-md-8">-->
<!--                                                                    <input type="text" class="form-control "-->
<!--                                                                        id="exampleFormControlInput1"-->
<!--                                                                        style="font-size:11px;"-->
<!--                                                                        placeholder="Enter Bank Name"-->
<!--                                                                        wire:model="bank.name">-->
<!--                                                                </div>-->
<!--                                                            </div>-->



<!--                                                            @error('bank.name')-->
<!--                                                                <span class="text-danger error">{{ $message }}</span>-->
<!--                                                            @enderror-->
<!--                                                        </div>-->

<!--                                                        <div class="px-1 ">-->
                                                            <!--<label for="disabledSelect" class="form-label">Sort Code</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Sort Code" wire:model.debounce.500="bank.sort_code">-->
<!--                                                            <div class="row mb-2">-->
<!--                                                                <label for="exampleFormControlInput1"-->
<!--                                                                   style="font-size: 18px;" class="col-sm-2 col-form-label col-10 col-md-4">S.code</label>-->
<!--                                                                <div class="col-sm-10 col-10 col-md-8">-->
<!--                                                                    <input type="text" class="form-control"-->
<!--                                                                        id="exampleFormControlInput1"-->
<!--                                                                        style="font-size:11px;"-->
<!--                                                                        placeholder="Enter Sort Code"-->
<!--                                                                        wire:model="bank.sort_code">-->
<!--                                                                </div>-->
<!--                                                            </div>-->



<!--                                                            @error('bank.sort_code')-->
<!--                                                                <span class="text-danger error">{{ $message }}</span>-->
<!--                                                            @enderror-->
<!--                                                        </div>-->
<!--                                                        <div class="px-2 py-2">-->
<!--                                                            <div class="form-check">-->
<!--                                                                <input style="transform: scale(0.8);"-->
<!--                                                                    class="form-check-input" type="checkbox"-->
<!--                                                                    value="" id="flexCheckDefault" />-->
<!--                                                                <label style="font-size: 15px;"-->
<!--                                                                    class="form-check-label col-10  " for="flexCheckDefault">-->
<!--                                                                    Agree with Privacy Policy Terms & Conditions-->
<!--                                                                </label>-->
<!--                                                            </div>-->
<!--                                                        </div>-->

<!--                                                        <div-->
<!--                                                            class="cursor-point align-items-center d-grid gap-2 col-12 justify-content-center">-->

<!--                                                            <button class="btn btn-danger text-white"-->
<!--                                                                wire:click="submit" style="font-size: 20px;" class="col-sm-2 col-form-label col-10">Submit</button>-->


<!--                                                        </div>-->
<!--                                                    </div>-->
<!--                                                </div>-->
<!--                                            </div>-->



<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </div>-->

                            </div>
                        </div>
                        
                    </div>

                </div>

                <div class="col-md-5  sol-sm-12 mt-3">
                    <div style="position:relative;top:10px;" class="container">

                        <table class="table table-striped border mt-5">
                            <thead>



                                <tr>
                                    <th colspan="2" class="text-center text-danger fw-bolder fs-3">Sell Summary
                                    </th>
                                    <!-- Center-aligned heading -->
                                </tr>



                                <tr>

                                    <td>Model</td>
                                    <td class="text-end">{{ $modelName }}</td>

                                </tr>
                            </thead>
                            <tbody>
                                <tr class="justify-content-between

">

                                    <td>Type</td>
                                    <td class="text-end">{{ $form_name }}</td>

                                </tr>


@if($formType === 'postal_form')

<tr class="justify-content-between">






            <tr>
                <td>Service Charges</td>
                <td class="text-end">{{ $condition4Price }} 
</td>
            </tr>
            
            
        
            <tr>
                <td>Orignal Price</td>
                <td class="text-end">{{$orignalprice}} 
</td>
            </tr>    
            



        @endif


@if($formType === 'collection_form')

<tr class="justify-content-between">

                                                    

            <tr>
                <td>Orignal Price</td>
                <td class="text-end">{{$orignalprice}} 
</td>
            </tr>    
            



            <tr>
                <td>Service Charges</td>
                <td class="text-end">{{ $condition5Price }}</td>
            </tr>




        @endif









                                <tr>
                                    
                                    


                                    <td class="fw-bolder">Total Price</td>


                                    <td class="text-end">£ {{ $price ?? '' }}.00 </td>

                                </tr>

                            </tbody>
                        </table>
                    </div>








                </div>







            </div>


        </div>
    @endif






    <script>
        function handleRadio(button) {
            var radio = button.querySelector('input[name="radio-payment"]');
            var isChecked = radio.checked;

            // Uncheck all radio buttons with name "radio-payment"
            document.querySelectorAll('input[name="radio-payment"]').forEach(function(radioBtn) {
                radioBtn.checked = false;
            });

            // If radio button was not checked, check it
            if (!isChecked) {
                radio.checked = true;
            }
        }
 document.addEventListener('livewire:load', function () {
    // Listen for the formTypeChanged event
    Livewire.on('formTypeChanged', function (formType) {
        console.log('Form type changed:', formType);
        updateComponentUI(formType);
    });

    function updateComponentUI(formType) {
        // Example logic to update UI based on formType
        // This can be customized based on your requirements
        if (formType === 'postal_form') {
            document.getElementById('another-component').innerText = 'Postal Form Selected';
        } else if (formType === 'collection_form') {
            document.getElementById('another-component').innerText = 'Collection Form Selected';
        } else if (formType === 'fix_form') {
            document.getElementById('another-component').innerText = 'Fix Form Selected';
        }
    }
});

    </script>

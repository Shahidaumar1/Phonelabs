<div>

    <livewire:components.top-bar />
    <!-- --------Navbar------------ -->
    <section class="head-sell">
        <div class="container-fluid">
            <livewire:components.mega-nav />
            {{-- --}}

        </div>
    </section>
    <section class="head-sell my-5">
        
        <div class="container">
                    <a href="{{ route('home') }}">
                        
                    <button class="btn btn-danger btn-sm"  ><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
</svg></button>
                    </a>
                    
            <div class="row d-flex align-items-center">
                <div class="col-lg-6 p-3">

                    <p>{!! $webContent->sell_heading_1 !!}{{ $siteSettings->buisness_name ?? '' }}</p>
                    <h1 style=" font-family: heading;">{!! $webContent->sell_heading_2 !!}</h1>

                    {{-- <input type="text" class="form-control my-2 w-75" placeholder="Search e.g.iphone 12"> --}}
                    <p>{!! $webContent->sell_heading_3 !!}</p>
                    <p class="lead">{!! $webContent->sell_heading_4 !!}</p>
                </div>
                <div class="col-lg-6">
                    <img src="https://ik.imagekit.io/2nuimwatr/online-seller-1.jpg?updatedAt=1698831017024" class="img-fluid">
                </div>
            </div>
        </div>
    </section>
    <!-- ------------product-------- -->

    <section class="about">
        <div class="container">
            <h1 class="text-center " style="color: #E31E24">{!! $webContent->sell_heading_5 !!}</h1>
            <hr class="w-25 mx-auto">
            <div class="">

                <div class="d-flex flex-wrap align-items-center justify-content-center my-2 gap-3 ">
                    @forelse($categories as $category)
                    <a href="{{ route('guest-sell-device-types', $category->id) }}" class="col-md-3 mb-3 mr-5">
                        <div class="card mb-3 mr-3">
                            <!-- Add margin-bottom (mb-3) and margin-right (mr-3) for space between cards -->
                            <img src="{{ $category->file ?? '' }}" class="img-thumbnail" style="height:150px;">
                            <div class="icon"><i class="bi bi-tablet"></i></div>
                            <div class="card-body text-dark text-center fs-3">
                                <h4><b>{{ $category->name }}</b></h4>
                            </div>
                        </div>
                    </a>
                    @empty
                    @endforelse
                </div>





            </div>
            {{-- <div class="text-center">
                <br>
                <button class="btn translate-up bg-danger text-white rounded-0">Other Products</button>
            </div> --}}
        </div>

    </section>
    {{-- <section class="types">
        <div class="container">
            <div class="col-lg-8 offset-lg-2 text-center">
                <h1 class="text-danger">New arrival</h1>
                <p>In the dynamic realm of mobile tech, numerous beloved phone models resonate with global consumers.
                    These gadgets expertly fuse style and utility, meeting diverse preferences and demands.</p>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 my-2">
                    <img src="https://ik.imagekit.io/phonelab2/iphone.jpg?updatedAt=1697117090695"
                        class="img-fluid img-thumbnail ">
                    <div class="p-3">
                        <h4>Sell My Iphone </h4>
                        <p>Sell your iPhone with us and we promise to pay you 100% of the price quoted or we'll send it
                            back
                            free of charge!</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 my-2">
                    <img src="https://ik.imagekit.io/phonelab2/galaxy-s-series.jpg?updatedAt=1697117166025"
                        class="img-fluid img-thumbnail ">
                    <div class="p-3">
                        <h4>Sell my Samsung Galaxy S</h4>
                        <p>Sell your Samsung Galaxy series with us and get 100% of the price quoted or we'll send it
                            back, free of charge!</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 my-2">
                    <img src="https://ik.imagekit.io/phonelab2/galaxy-note.jpg?updatedAt=1697117244119"
                        class="img-fluid img-thumbnail ">
                    <div class="p-3">
                        <h4>Sell my Samsung Galaxy Note</h4>
                        <p>We promise to pay you 100% of the price quoted or we’ll send your Samsung Galaxy Note back
                            free
                            of charge!</p>
                    </div>
                </div>
            </div>
        </div>
    </section> --}}
    {{-- <section class="product">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 my-3">
                    <div class="img">
                        <h4 class="text-white">GET 50% OFF</h4>
                        <h2 style="font-family: heading;">iPhone 14</h2>
                        <button class="btn translate-up bg-danger text-white rounded-0" role="button">Sell Now</button>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 my-3">
                    <div class="img2">
                        <h4 class="text-white">GET 50% OFF</h4>
                        <h2 style="font-family: heading;">Samsung S Fold</h2>
                        <button class="btn translate-up bg-danger text-white rounded-0" role="button">Sell Now</button>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-2  ">
                    <div class=" bg-gray rounded-1 p-3 card">
                        <div class="icon"><i class="bi bi-credit-card"></i></div>
                        <h4 class="safe"> Safe Payment</h4>
                        <p>Our secure payment options ensure your transactions are protected, offering peace of mind
                            while selling your devices.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-2 ">
                    <div class=" bg-gray rounded-1 p-3 card">
                        <div class="icon"><i class="bi bi-check-circle-fill"></i></div>
                        <h4 class="shop">Sell With Confidence</h4>
                        <p>
                            List and sell your mobile devices on our trusted platform with transparency and a wide
                            customer base.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-2 ">
                    <div class=" bg-gray rounded-1 p-3 card">

                        <h4 class="shop">World Wide Delivery</h4>
                        <p> We offer global shipping, making it convenient to sell your devices from anywhere, and have reach buyers worldwide.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-2 ">
                    <div class="bg-gray rounded-1 p-3 card">
                        <div class="icon"><i class="bi bi-patch-question"></i></div>
                        <h4 class="safe">24/7 Help Center</h4>
                        <p>Our round-the-clock support is here to assist you at any time, ensuring a smooth and
                            hassle-free experience when selling your mobile phones.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="deals">
        <div class="container">
            <h1>Top rated</h1>
            <div class="row">
                <div class="col-lg-4">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="https://ik.imagekit.io/phonelab2/deal1.jpg?updatedAt=1697118510429"
                                    class="img-fluid rounded-start">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <small>DRONE</small>
                                    <h5 class="fw-bold">Apple iPhone 13 Pro SmartPhone</h5>
                                    <small>₤20.03 <del>₤30.03</del></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="https://ik.imagekit.io/phonelab2/deal2.jpg?updatedAt=1697118584539"
                                    class="img-fluid rounded-start">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <small>HEADPHONES</small>
                                    <h5 class="fw-bold">Uborn P47 Wireless Headphone</h5>
                                    <small>₤20.03 <del>₤30.03</del></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="https://ik.imagekit.io/phonelab2/deal3.jpg?updatedAt=1697118637202"
                                    class="img-fluid rounded-start">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <small>CAMERA LANS</small>
                                    <h5 class="fw-bold">Uborn P47 Camera Lanse</h5>
                                    <small>₤20.03 <del>₤30.03</del></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="https://ik.imagekit.io/phonelab2/deal4.jpg?updatedAt=1697118727400"
                                    class="img-fluid rounded-start">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <small>SMART WATCH</small>
                                    <h5 class="Apple">Fire-Boltt Bluetooth Smartwatch</h5>
                                    <small>₤20.03 <del>₤30.03</del></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="https://ik.imagekit.io/phonelab2/deal5.jpg?updatedAt=1697118774399"
                                    class="img-fluid rounded-start">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <small>VIDEO</small>
                                    <h5 class="Apple">AMKETTE Evo Gamepad Pro 4</h5>
                                    <small>₤20.03 <del>₤30.03</del></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="https://ik.imagekit.io/phonelab2/deal6.jpg?updatedAt=1697118829196"
                                    class="img-fluid rounded-start">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <small>MACKBOOK</small>
                                    <h5 class="Apple">Uborn P47 Mackbook</h5>
                                    <small>₤20.03 <del>₤30.03</del></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section> --}}
    <section class="mobile">
        <div class="container">
            <h1>{!! $webContent->sell_heading_6 !!}</h1>
            <p>{!! $webContent->sell_heading_7 !!}</p>
         

        </div>
    </section>

    <section class="faq mb-5">
        <div class="container">
            <h1>{!! $webContent->sell_heading_8 !!}</h1>
            <p>{{ $siteSettings->buisness_name ?? '' }} {!! $webContent->sell_heading_9 !!}</p>

            <div class="row">
                <div class="col-lg-6">
                    <div class="accordion-container 1   rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-1">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-1"> Why should you sell your mobile phone to {{ $siteSettings->buisness_name ?? '' }}?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                                {!! $webContent->sell_heading_11 !!}
                            </div>
                        </div>





                    </div>

                    <div class="accordion-container 3  rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-3">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-3">What will happen to my phone?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                            {!! $webContent->sell_heading_15 !!}
                            </div>
                        </div>





                    </div>

                    <div class="accordion-container 5  rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-5">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-5"> How much is my device worth?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                                {!! $webContent->sell_heading_19 !!}
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-lg-6">
                    <div class="accordion-container 2   rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-2">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-2">Why should I recycle my phone?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                              {!! $webContent->sell_heading_13 !!}
                            </div>
                        </div>





                    </div>

                    <div class="accordion-container 4   rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-4">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-4"> What will happen to my phone?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                                 {!! $webContent->sell_heading_17 !!}
                            </div>
                        </div>





                    </div>

                </div>










            </div>
        </div>
    </section>

    <style>
        /* Style for the label when the accordion is checked (open) */

        .label::before {
            content: '+';
            font-weight: 600;
            float: right;
        }

        .text-danger {
            color: #737272 !important;
        }

        .accordion:checked+.label::before {
            content: '-';
            float: right;
        }

        /* Style for the content of the accordion */
        .content {
            display: none;
            background-color: white !important;
            padding: 10px;
        }

        /* Style for the content when the accordion is checked (open) */
        .accordion:checked+.label+.content {
            display: block;

        }

        .bg-danger {
            background-color: #E31E24 !important;
        }
        

    </style>
</div>
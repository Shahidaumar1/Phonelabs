<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="settings" />
        <x-content>
            <livewire:admin.settings.components.top-nav active="create" />

            <div class="container">
                <h2 class="text-primary px-5 pt-5 pb-3">Create Branch</h2>

                <div class="row">
                    <div class="col-md-6">

                        <form wire:submit.prevent="saveBranch">
                            @csrf

                            <div class="form-group">
                                <label for="name">Branch Name:</label>
                                <input type="text" wire:model="name" class="form-control" id="name" placeholder="Enter Branch Name">
                                @error('name') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>

                            <div class="form-group">
                                <label for="address_line_1">Address Line 1:</label>
                                <input type="text" wire:model="address_line_1" class="form-control" id="address_line_1" placeholder="Enter Address Line 1">
                                @error('address_line_1') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>

                            <div class="form-group">
                                <label for="address_line_2">Address Line 2:</label>
                                <input type="text" wire:model="address_line_2" class="form-control" id="address_line_2" placeholder="Enter Address Line 2">
                                @error('address_line_2') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>

                            <div class="form-group">
                                <label for="town_city">Town/City:</label>
                                <input type="text" wire:model="town_city" class="form-control" id="town_city" placeholder="Enter Town/City">
                                @error('town_city') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>

                            <div class="form-group">
                                <label for="post_code">Post Code:</label>
                                <input type="text" wire:model="post_code" class="form-control" id="post_code" placeholder="Enter Post Code">

                                <div id="resultContainer">
                                    <p>{{$addressName}}</p>
                                </div>
                                @error('post_code') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>

                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="mobile_number">Mobile Number:</label>
                            <input type="text" wire:model="mobile_number" class="form-control" id="mobile_number" placeholder="Enter Mobile Number">
                            @error('mobile_number') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label for="landline_number">Landline Number:</label>
                            <input type="text" wire:model="landline_number" class="form-control" id="landline_number" placeholder="Enter Landline Number">
                            @error('landline_number') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" wire:model="email" class="form-control" id="email" placeholder="Enter Email">
                            @error('email') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label for="latitude">Latitude:</label>
                            <input type="number" wire:model="latitude" step="any" class="form-control" id="latitude" placeholder="Enter Latitude">
                            @error('latitude') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                        <div class="form-group">
                            <label for="longitude">Longitude:</label>
                            <input type="number" wire:model="longitude" step="any" class="form-control" id="longitude" placeholder="Enter Longitude">
                            @error('longitude') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group"><span class="text-danger" id="locationInfo"></span></div>
                        <button type="submit" class="btn btn-primary">Create Branch</button>

                        </form>

                        <button type="button" id="getLocationButton">Get Location</button>
                    </div>
                </div>
                <div class="row">

                    <div id="mapContainer" class="col-md-6" style="height: 400px"></div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <p>Monday</p>
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>
                            <div class="col-sm-2" style="padding-left: 10px;">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <p>Tuesday</p>
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>
                            <div class="col-sm-2" style="padding-left: 10px;">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <p>Wednesday</p>
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>
                            <div class="col-sm-2" style="padding-left: 10px;">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <p>Thursday</p>
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>
                            <div class="col-sm-2" style="padding-left: 10px;">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <p>Friday</p>
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>
                            <div class="col-sm-2" style="padding-left: 10px;">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <p>Saturday</p>
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>
                            <div class="col-sm-2" style="padding-left: 10px;">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <p>Sunday</p>
                            </div>
                            <div class="col-sm-2">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>
                            <div class="col-sm-2" style="padding-left: 10px;">
                                <input type="text" id="fname" name="fname" size="2">
                            </div>

                        </div>
                        <button type="submit" class="btn btn-primary">Create Branch</button>
                    </div>

                </div>


            </div>


            <script>
                document.getElementById('post_code').addEventListener('change', function() {
                    getLatLong();
                });

                const resultContainer = document.getElementById("resultContainer");
                async function getLatLong() {

                    const postalCode = document.getElementById("post_code").value;

                    try {
                        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                        const data = await response.json();
                        if (data.length > 0) {
                            const result = data[0];

                            resultContainer.innerHTML = `<p>${result.display_name}</p>`;
                            // @this.addressName = result.display_name;
                            // @this.latitude = result.lat;
                            // @this.longitude = result.lon;
                            showMap(result.lat, result.lon);
                        } else {
                            resultContainer.innerHTML =
                                "<p>No results found for the provided postal code.</p>";
                        }
                    } catch (error) {
                        console.error("Error fetching data:", error);
                    }
                }
            </script>
        </x-content>

        <livewire:admin.sell.components.right-nav :data="$data" />

    </div>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>

    <script>
        const getLocationButton = document.getElementById("getLocationButton");
        const locationInfo = document.getElementById("locationInfo");
        const latitudeElement = document.getElementById("latitude");
        const longitudeElement = document.getElementById("longitude");
        const latitudeInput = document.getElementById("latitudeInput");
        const longitudeInput = document.getElementById("longitudeInput");
        const mapContainer = document.getElementById("mapContainer");

        getLocationButton.addEventListener("click", () => {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(onSuccess, onError);
            } else {
                onError({
                    message: "Geolocation is not supported by your browser.",
                });
            }
        });

        function onSuccess(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;

            latitudeElement.textContent = latitude;
            longitudeElement.textContent = longitude;
            latitudeInput.value = latitude;
            longitudeInput.value = longitude;

            showMap(latitude, longitude);
        }

        function onError(error) {
            console.error("Error getting location:", error.message);
        }

        function showMap(latitude, longitude) {
            const map = L.map("mapContainer").setView([latitude, longitude], 15);

            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: "&copy; OpenStreetMap contributors",
            }).addTo(map);

            const marker = L.marker([latitude, longitude], {
                draggable: true,
            }).addTo(map);

            marker.on("dragend", (event) => {
                const updatedLatitude = event.target.getLatLng().lat;
                const updatedLongitude = event.target.getLatLng().lng;

                // latitudeElement.textContent = updatedLatitude;
                // longitudeElement.textContent = updatedLongitude;
                // latitudeInput.value = updatedLatitude;
                // longitudeInput.value = updatedLongitude;
            });
        }
    </script>


</div>
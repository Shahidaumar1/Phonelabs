<table class="table">

    <tbody>
      <tr>
        <td >
          <input
            type="text"
            class="form-control input_form"
            placeholder="Client ID"
            aria-label=""
            wire:model.debounde.500="client_id"
          />
          @error('client_id')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </td>
        <td >
          <input
            type="text"
            class="form-control input_form"
            placeholder="Secret"
            aria-label=""
            wire:model.debounde.500="secret"
          />
          @error('secret')
          <span class="text-danger">{{$message}}</span>
          @enderror

        </td>
      </tr>
     <tr>
        <td >
            <button type="button" class="{{$dirty ? 'bg-blue text-white' : 'disabled bg-light text-dark'}} " wire:click="connect" {{$dirty ? '' : 'disabled'}}>Connect</button>
            <span wire:loading wire:target="connect">connecting....</span>
          </td>
     </tr>

    </tbody>
  </table>

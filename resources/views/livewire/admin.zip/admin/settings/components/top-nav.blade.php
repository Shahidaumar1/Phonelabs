<nav class="bg-blue px-3" style="padding:4px;">
    <div class="d-flex justify-content-between align-items-center ">
        <i class="fa fa-bars cursor-pointer text-white" aria-hidden="true" onclick="toggleLeftDrawer()"></i>

        <div class="d-flex  align-items-center">
            <div>
                <a href="{{ route('payment-methods-settings') }}" class=" text-white item p-3 {{ $active == 'payment' ? 'text-danger fw-bold bg-white p-3' : '' }}">Payment</a>
            </div>
            <div>
                <a href="{{ route('branches-settings') }}" class=" text-white p-3 item  {{ $active == 'branches' ? 'text-danger fw-bold bg-white p-3' : '' }}">Branches</a>
            </div>
            <div>
                <a href="{{ route('create-branches') }}" class=" text-white p-3 item  {{ $active == 'create' ? 'text-danger fw-bold bg-white p-3' : '' }}">Create</a>
            </div>
            <div>
                <a href="{{ route('services-settings') }}" class=" text-white p-3 item  {{ $active == 'services' ? 'text-danger fw-bold bg-white p-3' : '' }}">Services</a>
            </div>


        </div>

        <livewire:components.avatar />
    </div>

</nav>
<div class="bg-blue rounded-lg shadow-lg" style="min-width:15%; min-height:600px;" id="leftDrawer">

    <div class="p-4">
        <a href="/">
            <h3 class="text-white">Admin Panel</h3>
        </a>
    </div>
    <div class="d-flex flex-column">

        <div class="item {{ $active == 'buy' ? 'bg-danger' : '' }}">
            <a href="{{ route('buy-categories') }}" class="text-white d-flex gap-2 align-items-center py-2  px-4">
                <i class="fa fa-shopping-bag"></i>
                <span>Buy</span>
            </a>
        </div>

        <div class="item {{ $active == 'sell' ? 'bg-danger' : '' }}">
            <a href="{{ route('sell-categories') }}" class="text-white d-flex gap-2 align-items-center py-2  px-4">
                <i class="fa fa-shopping-cart"></i>
                <span>Sell</span>
            </a>
        </div>

        <div class="item {{ $active == 'repair' ? 'bg-danger' : '' }}">
            <a href="{{ route('repair-categories') }}" class="text-white d-flex gap-2 align-items-center py-2  px-4">
                <i class="fa fa-wrench"></i>
                <span>Repair</span>
            </a>
        </div>

        {{-- <div class="item {{ $active == 'orders' ? 'bg-danger' : '' }}">
            <a href="#" class="text-white d-flex gap-2 align-items-center py-2  px-4">
                <i class="fa fa-signal"></i>
                <span>Orders</span>
            </a>
        </div>
        <div class="item {{ $active == 'stock' ? 'bg-danger' : '' }}">
            <a href="#" class="text-white d-flex gap-2 align-items-center py-2  px-4">
                <i class="fa fa-list"></i>
                <span>Stock</span>
            </a>
        </div> --}}
        <div class="item {{ $active == 'staff' ? 'bg-danger' : '' }}">
            <a href="#" class="text-white d-flex gap-2 align-items-center py-2  px-4">
                <i class="fa fa-users"></i>
                <span>Add Staff</span>
            </a>
        </div>


        <div class="item {{ $active == 'settings' ? 'bg-danger' : '' }}">
            <a href="{{ route('payment-methods-settings') }}" class="text-white d-flex gap-2 align-items-center py-2  px-4">
                <i class="fa fa-cog"></i>
                <span>Setings</span>
            </a>
        </div>

        <div class="item ">
            <a href="javascript:void(0)" wire:click="logout"
                class="text-white d-flex gap-2 align-items-center py-2  px-4">
                <i class="fa fa-sign-in" aria-hidden="true"></i>
                <span>Logout</span>
            </a>
        </div>


    </div>
    <hr />

</div>

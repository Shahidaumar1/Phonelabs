<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="settings" />
        <x-content>
            <livewire:admin.settings.components.top-nav active="site-settings" />

            <div class="container my-5">

                <div class="row">
                    <div class="col-md-6 text-center">
                        <div>

                            <img style="max-width: 200px;" id="selectedImage" wire:ignore src="{{asset($siteSetting->logo)}}" alt="web site logo" />
                        </div>

                        <div class="btn btn-primary btn-rounded mt-3">
                            <label class="form-label text-white m-1" for="customFile1">Choose Logo</label>
                            <input type="file" wire:model="logo" class="form-control d-none" id="customFile1" name="logo" accept="image/*" onchange="displaySelectedImage(event, 'selectedImage')" />
                            <span wire:loading wire:target="file">loading...</span>
                        </div>
                    </div>
                    <div class="col-md-6 text-center">
                        <div>
                            <img style="max-width: 200px;" id="selectedFav" wire:ignore src="{{ asset($siteSetting->favicon) }}" alt="web site Favicon" />
                        </div>
                        <div class="btn btn-primary btn-rounded mt-3">
                            <label class="form-label text-white m-1" for="customFile">Choose fav</label>
                            <input type="file" class="form-control d-none" wire:model="favicon" id="customFile" name="fav" accept="image/*" onchange="displaySelectedFav(event, 'selectedFav')" />
                            <span wire:loading wire:target="file">loading...</span>
                        </div>
                    </div>

                </div>
                <script>
                    function displaySelectedImage(event, elementId) {
                        const selectedImage = document.getElementById(elementId);
                        const fileInput = event.target;

                        if (fileInput.files && fileInput.files[0]) {
                            const reader = new FileReader();

                            reader.onload = function(e) {
                                selectedImage.src = e.target.result;
                            };

                            reader.readAsDataURL(fileInput.files[0]);
                        }
                    }

                    function displaySelectedFav(event, elementId) {
                        const selectedFav = document.getElementById(elementId);
                        const fileInput = event.target;

                        if (fileInput.files && fileInput.files[0]) {
                            const reader = new FileReader();

                            reader.onload = function(e) {
                                selectedFav.src = e.target.result;
                            };

                            reader.readAsDataURL(fileInput.files[0]);
                        }
                    }
                </script>
            </div>
            <form wire:submit.prevent="updateSiteSettings">

                @csrf
                <div class="container mt-5">

                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <label for="buisness_name" class="form-label">Buisness Name:</label>
                            <input type="text" wire:model="siteSetting.buisness_name" class="form-control" id="buisness_name" placeholder="Enter Buisness Name">
                        </div>
                    </div>

                    <div class="row mt-3 justify-content-center">
                        <div class="col-md-8">
                            <label for="website_url" class="form-label">Website URL:</label>
                            <input type="url" wire:model="siteSetting.website_url" class="form-control" id="website_url" placeholder="Enter Website URL">
                        </div>
                    </div>

                    <div class="row mt-3 justify-content-center">
                        <div class="col-md-8">
                            <label for="fb_link" class="form-label">Facebook Link:</label>
                            <input type="url" wire:model="siteSetting.fb_link" class="form-control" id="fb_link" placeholder="Enter Facebook Link">
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" wire:model="siteSetting.fb_link_status" id="fb_link_status" data-toggle="switch" data-on-text="On" data-off-text="Off">
                                <label class="form-check-label" for="fb_link_status">Status</label>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3 justify-content-center">
                        <div class="col-md-8">
                            <label for="insta_link" class="form-label">Instagram Link:</label>
                            <input type="url" wire:model="siteSetting.insta_link" class="form-control" id="insta_link" placeholder="Enter Instagram Link">
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" wire:model="siteSetting.insta_link_status" id="insta_link_status" data-toggle="switch" data-on-text="On" data-off-text="Off">
                                <label class="form-check-label" for="insta_link_status">Status</label>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3 justify-content-center">
                        <div class="col-md-8">
                            <label for="linkedin_link" class="form-label">LinkedIn Link:</label>
                            <input type="url" wire:model="siteSetting.linkedin_link" class="form-control" id="linkedin_link" placeholder="Enter LinkedIn Link">
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" wire:model="siteSetting.linkedin_link_status" id="linkedin_link_status" data-toggle="switch" data-on-text="On" data-off-text="Off">
                                <label class="form-check-label" for="linkedin_link_status">Status</label>
                            </div>
                        </div>
                    </div>


                    <div class="row mt-3 justify-content-center">
                        <div class="col-md-8">
                            <label for="twitter_link" class="form-label">Twitter Link:</label>
                            <input type="url" wire:model="siteSetting.twitter_link" class="form-control" id="twitter_link" placeholder="Enter Twitter Link">
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" wire:model="siteSetting.twitter_link_status" id="twitter_link_status" data-toggle="switch" data-on-text="On" data-off-text="Off">
                                <label class="form-check-label" for="twitter_link_status">Status</label>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3 justify-content-center">
                        <div class="col-md-8">
                            <label for="tiktok_link" class="form-label">TikTok Link:</label>
                            <input type="url" wire:model="siteSetting.tiktok_link" class="form-control" id="tiktok_link" placeholder="Enter TikTok Link">
                            <div class="form-check form-switch mt-2">
                                <input class="form-check-input" type="checkbox" wire:model="siteSetting.tiktok_link_status" id="tiktok_link_status" data-toggle="switch" data-on-text="On" data-off-text="Off">
                                <label class="form-check-label" for="tiktok_link_status">Status</label>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3 justify-content-center">
                        <div class="col-md-8">
                            <label for="snapchat_link" class="form-label">Snapchat Link:</label>
                            <input type="url" wire:model="siteSetting.snapchat_link" class="form-control" id="snapchat_link" placeholder="Enter Snapchat Link">
                            <div class="form-check form-switch mt-2">
                                <label class="form-check-label">Status</label>
                                <input class="form-check-input" type="checkbox" role="switch" wire:model="siteSetting.snapchat_link_status" data-toggle="switch" data-on-text="On" data-off-text="Off">
                            </div>
                        </div>
                    </div>
                    <!-- Repeat the above structure for other fields -->

                    <div class="row mt-3 justify-content-center">
                        <div class="col-md-8">
                            <label for="map_link" class="form-label">Map Link:</label>
                            <textarea rows="10" wire:model="siteSetting.map_link" class="form-control" id="map_link" placeholder="Enter Map Embedded code"></textarea>
                        </div>
                    </div>
                </div>

                <div class="container mt-3">
                    <div class="row justify-content-center">
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary">Update Site Settings</button>
                        </div>
                        <div class="col-auto">
                            @php
                            $firstBranch = \App\Models\Branch::first();
                            $hasBranches = $firstBranch !== null;
                            @endphp

                            <a href="{{ $hasBranches ? route('edit-branches', ['branchId' => $firstBranch->id]) : route('create-branches') }}" class="text-white item m-1">
                                <button type="button" class="btn btn-primary">
                                    {{ $hasBranches ? 'Edit Main Branch' : 'Create Main Branch' }}
                                </button>
                            </a>
                        </div>
                    </div>

                </div>
                <script>
                    $(function() {
                        $('[data-toggle="switch"]').bootstrapSwitch();
                    });
                </script>
            </form>

            <div class="m-4">{!! $siteSetting->map_link !!}
            </div>
        </x-content>
        <livewire:admin.sell.components.right-nav :data="$data" />
    </div>


</div>
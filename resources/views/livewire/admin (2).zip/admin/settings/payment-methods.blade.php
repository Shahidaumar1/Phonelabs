<div>
  <div class="d-flex">
    <livewire:admin.components.side-nave active="settings" />
    <x-content>
      <livewire:admin.settings.components.top-nav active="payment" />

      <div class="container">
        <h2 class="text-primary px-5 pt-5 pb-3">Payment Gateway</h2>
        <p class="px-5 py-3">
          A payment gateway facilitates secure online payments for businesses.
        </p>

        <div class="px-5 ">
          <div class="mt-5 d-flex justify-content-start gap-2 align-items-center">


            <label class="bg-light rounded p-3 border {{$pm == 'Paypal' ? 'border-success' : 'border-light'}} cursor-pointer" wire:click='$set("pm","Paypal")'>Paypal</label>
            <label class="bg-light rounded p-3 border {{$pm == 'Stripe' ? 'border-success' : 'border-light'}} cursor-pointer" wire:click='$set("pm","Stripe")'>Stripe</label>

          </div>
          @if($pm == 'Paypal')
          <livewire:admin.settings.components.paypal />
          @endif

          @if($pm == 'Stripe')
          <livewire:admin.settings.components.stripe />
          @endif

        </div>

      </div>

    </x-content>

    <livewire:admin.sell.components.right-nav :data="$data" />

  </div>



</div>
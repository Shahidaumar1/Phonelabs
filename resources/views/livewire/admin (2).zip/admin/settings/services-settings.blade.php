<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="settings" />
        <x-content>
            <livewire:admin.settings.components.top-nav active="services" />
            <div style="font-family: 'Segoe UI', Roboto, 'Helvetica Neue', 'Noto Sans', 'Liberation Sans', Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';">
                <div class="container my-5">

                    <div class="row d-flex justify-content-center">
                        <table class="table w-75 table-hover table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col">Sell</th>
                                    <th scope="col">Buy</th>
                                    <th scope="col">Repair</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" role="switch" type="checkbox" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[0]->id }}, 'sell')" {{ $formStatuses[0]->sell ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Sell In Store</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[0]->id }}, 'buy')" {{ $formStatuses[0]->buy ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Buy in Store</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[0]->id }}, 'repair')" {{ $formStatuses[0]->repair ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Store Repair</label>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[1]->id }}, 'sell')" {{ $formStatuses[1]->sell ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Post Your Device</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[1]->id }}, 'buy')" {{ $formStatuses[1]->buy ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Post My Device</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[1]->id }}, 'repair')" {{ $formStatuses[1]->repair ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Postal Repair</label>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[2]->id }}, 'sell')" {{ $formStatuses[2]->sell ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Collect My Device</label>
                                        </div>
                                    </td>
                                    <td></td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[2]->id }}, 'repair')" {{ $formStatuses[2]->repair ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Collect My Device</label>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" wire:click="toggleStatus({{ $formStatuses[3]->id }}, 'repair')" {{ $formStatuses[3]->repair ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Fix At My Address</label>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

        </x-content>

        <livewire:admin.sell.components.right-nav :data="$data" />

    </div>
</div>
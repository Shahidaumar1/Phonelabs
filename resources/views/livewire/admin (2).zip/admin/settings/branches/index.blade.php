<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="settings" />
        <x-content>
            <livewire:admin.settings.components.top-nav active="branches" />

            <div class="container my-5">
                <div>
                    @if(session()->has('message'))
                    <h3 class="alert alert-success">{{session('message')}}</h3>
                    @endif

                    <div class="card">
                        <div class="card-header">
                            <h2 class="text-primary">Registered Branches
                                <a href="{{ route('create-branches') }}" class="btn btn-primary float-end">Create new</a>

                            </h2>

                        </div>
                        <div class="card-body">

                            <div class="d-flex gap-4  flex-wrap table-responive  ">

                                <table class="table table-striped  p-5 shadow">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Address</th>
                                            <th>Town/City</th>
                                            <th>Post Code</th>
                                            <th>Mobile Number</th>
                                            <th>Landline Number</th>
                                            <th>Email</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($branches as $key => $branch)
                                        <tr>
                                            <th>{{ ++$key }}</th>
                                            <td>{{ $branch->name }}</td>
                                            <td>{{ $branch->address_line_1 }}</td>
                                            <td>{{ $branch->town_city }}</td>
                                            <td>{{ $branch->post_code }}</td>
                                            <td>{{ $branch->mobile_number }}</td>
                                            <td>{{ $branch->landline_number }}</td>
                                            <td>{{ $branch->email }}</td>
                                            <td>
                                                <a href="{{ route('edit-branches', $branch->id) }}">
                                                    <i class="fa fa-edit text-success cursor-pointer" aria-hidden="true"></i>
                                                </a>
                                                <span class="me-2"></span>
                                                <i class="fa fa-trash text-danger cursor-pointer" aria-hidden="true" wire:click="confirmDelete({{ $branch->id }})"></i>
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="9">Record Not Found!</td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>



                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </x-content>

        <livewire:admin.sell.components.right-nav :data="$data" />

    </div>
    @if($confirmingDelete)
    <script>
        if (confirm('Are you sure you want to delete this branch?')) {
            @this.delete();
        } else {
            @this.confirmingDelete = false;
        }
    </script>
    @endif
</div>
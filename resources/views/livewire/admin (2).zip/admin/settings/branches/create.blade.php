<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="settings" />
        <x-content>
            <livewire:admin.settings.components.top-nav active="create" />
            <div class="container">
                <h2 class="text-primary px-5 pt-5 pb-3">Create Branch</h2>
                <form wire:submit.prevent="saveBranch">
                    <div class="row">
                        <div class="col-md-6">
                            @csrf
                            <div class="form-group">
                                <label for="name">Branch Name:</label>
                                <input type="text" wire:model="name" class="form-control" id="name" placeholder="Enter Branch Name">
                                @error('name') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label for="address_line_1">Address Line 1:</label>
                                <input type="text" wire:model="address_line_1" class="form-control" id="address_line_1" placeholder="Enter Address Line 1">
                                @error('address_line_1') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label for="address_line_2">Address Line 2:</label>
                                <input type="text" wire:model="address_line_2" class="form-control" id="address_line_2" placeholder="Enter Address Line 2">
                                @error('address_line_2') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label for="town_city">Town/City:</label>
                                <input type="text" wire:model="town_city" class="form-control" id="town_city" placeholder="Enter Town/City">
                                @error('town_city') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label for="post_code">Post Code:</label>
                                <input type="text" wire:model="post_code" class="form-control" id="post_code" placeholder="Enter Post Code">
                                <div id="resultContainer">
                                    <p>{{$addressName}}</p>
                                </div>
                                @error('post_code') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="mobile_number">Mobile Number:</label>
                                <input type="text" wire:model="mobile_number" class="form-control" id="mobile_number" placeholder="Enter Mobile Number">
                                @error('mobile_number') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label for="landline_number">Landline Number:</label>
                                <input type="text" wire:model="landline_number" class="form-control" id="landline_number" placeholder="Enter Landline Number">
                                @error('landline_number') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" wire:model="email" class="form-control" id="email" placeholder="Enter Email">
                                @error('email') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label for="latitude">Latitude:</label>
                                <input type="number" wire:model="latitude" step="any" class="form-control" id="latitude" placeholder="Enter Latitude">
                                @error('latitude') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label for="longitude">Longitude:</label>
                                <input type="number" wire:model="longitude" step="any" class="form-control" id="longitude" placeholder="Enter Longitude">
                                @error('longitude') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group"><span class="text-danger" id="locationInfo"></span></div>
                        </div>
                    </div>

                    <div class="row d-flex justify-content-center">
                        <!-- Display time slots -->
                        <h2 class="text-primary px-5 pt-5 pb-3">Appointment Time Slots</h2>

                        <table class="table w-75 table-hover">
                            <thead class="table-primary">
                                <tr>
                                    <th>Day</th>
                                    <th>Opening Time</th>
                                    <th>Closing Time</th>
                                    <th>Status</th>
                                    <!-- Add more columns if needed -->
                                </tr>
                            </thead>
                            <tbody>

                                @foreach ($timeSlots as $index => $timeSlot)
                                <tr>
                                    <td>{{ $timeSlot['day'] }}</td>
                                    <td>
                                        <input type="time" wire:model="timeSlots.{{ $index }}.opening_time" />
                                        @error("timeSlots.{$index}.opening_time")
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </td>
                                    <td>
                                        <input type="time" wire:model="timeSlots.{{ $index }}.closing_time" />
                                        @error("timeSlots.{$index}.closing_time")
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" role="switch" type="checkbox" id="flexSwitch{{$index}}" wire:click="toggleStatus({{ $index }})" {{ $timeSlot['status'] ? 'checked' : '' }} />
                                            <label class="form-check-label" for="flexSwitch{{$index}}">{{ $timeSlot['status'] ? 'Opened' : 'Closed' }}</label>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                    <div class="row">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary float-end">Create Branch</button>
                        </div>
                    </div>
                </form>
                <div class="row my-5">
                    <div class="col-lg-12" wire:ignore id="mapView">
                        <div class="w-100 h-100" id="mapContainer"></div>
                    </div>
                </div>
            </div>
        </x-content>
        <livewire:admin.sell.components.right-nav :data="$data" />
    </div>
</div>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script>
    document.addEventListener('livewire:load', function() {
        const locationInfo = document.getElementById("locationInfo");
        const resultContainer = document.getElementById("resultContainer");
        var mapContainer = document.getElementById("mapContainer");
        document.getElementById('post_code').addEventListener('change', function() {
            getLatLong();
        });
        navigator.geolocation.getCurrentPosition(onSuccess, onError);

        function onSuccess(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;
            @this.latitude = latitude;
            @this.longitude = longitude;
            showMap(latitude, longitude);
        }

        function onError(error) {
            console.error("Error getting location:", error.message);
        }
        async function getLatLong() {
            var postalCode = document.getElementById("post_code").value;
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                const data = await response.json();
                if (data.length > 0) {
                    const result = data[0];
                    resultContainer.innerHTML = `<p>${result.display_name}</p>`;
                    @this.addressName = result.display_name;
                    @this.latitude = result.lat;
                    @this.longitude = result.lon;
                    // mapContainer.innerHTML = "";
                    showMap(result.lat, result.lon);
                } else {
                    resultContainer.innerHTML =
                        "<p>No results found for the provided postal code.</p>";
                }
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        }

        function showMap(latitude, longitude) {
            // Create a new div element
            var mapDiv = document.createElement("div");
            // Set the classes for the div
            mapDiv.classList.add("w-100", "h-100");
            mapDiv.setAttribute("style", "min-height: 400px;");
            // Set the id for the div
            mapDiv.id = "mapContainer";
            var mapViewDiv = document.getElementById("mapView");
            mapViewDiv.innerHTML = '';
            mapViewDiv.appendChild(mapDiv);
            var map = L.map("mapContainer").setView([latitude, longitude], 15);
            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: "&copy; OpenStreetMap contributors",
            }).addTo(map);
            const marker = L.marker([latitude, longitude], {
                draggable: true,
            }).addTo(map).bindPopup('<b> Branch location </b>').openPopup();
            marker.on("dragend", (event) => {
                const updatedLatitude = event.target.getLatLng().lat;
                const updatedLongitude = event.target.getLatLng().lng;
                @this.latitude = updatedLatitude;
                @this.longitude = updatedLongitude;
            });
        }
    });
</script>
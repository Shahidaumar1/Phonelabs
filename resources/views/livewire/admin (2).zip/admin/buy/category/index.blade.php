<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="buy" />
        <x-content>
            <livewire:admin.buy.components.top-nav active="categories" />
            <div class="container">
                <div class="mt-5">
                    <livewire:admin.buy.components.sub-nav :items="$items" />
                </div>

                <div>
                    <div class="d-flex justify-content-center gap-4  flex-wrap mt-5">
                        @if ($target == 'Publish')
                            <div class="plus-card" onclick="showM('add-buy-cat')">
                                <i class="fa fa-plus text-success " style="font-size:40px;" aria-hidden="true"></i>
                                <h4 class="fw-bold">Create new</h4>
                            </div>
                        @endif
                        @forelse($categories as $category)
                            <div class="card border-0 rounded-0 shadow cursor-pointer">
                                <div class="p-2 d-flex justify-content-between align-items-center">
                                    <div class="form-check form-switch">
                                        <input type="checkbox" role="switch" class="form-check-input"
                                            wire:change="toggleStatus({{ $category->id }})"
                                            {{ $category->status == 'Publish' ? 'checked' : '' }}>
                                    </div>

                                    <div class="dropdown dropend" id="{{ $rand }}" wire:ignore>
                                        <button class="btn btn-light dropdown-toggle bg-light border-0" type="button"
                                            id="{{ $rand }}" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="fa fa-ellipsis-h"></i>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="{{ $rand }}">
                                            <li>
                                                @if ($target != 'Junk')
                                                    <a class="dropdown-item" href="javascirpt:void(0)"
                                                        wire:click="selectCat('{{ $category->id }}')">Edit</a>
                                                @endif
                                            </li>
                                            <li>
                                                    <span class="dropdown-item"
                                                        wire:click="addGradeText('{{ $category->id }}')">Add Grade Text</span>
                                            </li>
                                            <li>
                                                @if ($target == 'Junk')
                                                    <a class="dropdown-item"
                                                        wire:click="restore('{{ $category->id }}')">Restore</a>
                                                @else
                                                    <a class="dropdown-item"
                                                        wire:click="softDelete('{{ $category->id }}')">Delete</a>
                                                @endif
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <a href="{{ route('buy-devices', $category) }}">
                                    <img src="{{ $category->file ?? '#' }}" class="img-fluid"
                                        style="height: 100px; width: 200px" />

                                    <div class="p-2">
                                        <h4 class="fw-bold text-center text-dark">{{ $category->name }}</h4>
                                    </div>
                                </a>
                            </div>

                        @empty
                            <div class="plus-card">
                                <i class="fa fa-times text-danger " style="font-size:40px;" aria-hidden="true"></i>
                                <h4 class="fw-bold">No Records !</h4>
                            </div>
                        @endforelse

                    </div>
                </div>
            </div>
        </x-content>

        <livewire:admin.buy.components.right-nav :data="$data" />

    </div>
    {{-- OTHER MODALS --}}
    <x-modal title="Add Category" id="add-buy-cat">
        <livewire:admin.buy.category.create />
    </x-modal>

    <x-modal title="Add Grades Text" id="add-grade-text" size="lg">
        <livewire:admin.buy.category.grade-text />
    </x-modal>
    @if ($selectedCat)
        <x-modal title="Edit Category" id="edit-buy-cat">
            <livewire:admin.buy.category.edit />
        </x-modal>
    @endif

</div>

 <div>
     <div class="d-flex justify-content-center ">
         <ul class="nav nav-tabs">
             @foreach ($items as $item)
                 <li class="nav-item">
                     <a class="nav-link cursor-pointer  {{ $active == $item['name'] ? 'active text-success' : '' }}"
                         aria-current="page" wire:click="showData('{{ $item['name'] }}')">{{ $item['name'] }}</a>
                 </li>
             @endforeach
         </ul>
     </div>


 </div>

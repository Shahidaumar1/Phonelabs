<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="repair" />
        <x-content>
            <livewire:admin.repair.components.top-nav active="add-ons" />
            <div class="container my-4">
                <div class="text-center mb-3">
                    <strong>Select categeory,device and model to seee product specifications with
                        prices.
                    </strong>
                </div>
                <div class="d-flex align-items-center justify-content-center gap-4 mb-3  ">
                    <div>

                        <select class="" aria-label="Default select example" wire:model="selectedCatId">
                            <option>Select Category</option>
                            @forelse($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @empty
                            @endforelse
                        </select>
                    </div>
                    <div>

                        <select class="" aria-label="Default select example" wire:model="selectedDeviceId">
                            <option>Select device</option>
                            @forelse($devices as $device)
                                <option value="{{ $device->id }}">{{ $device->name }}</option>
                            @empty
                            @endforelse
                        </select>
                    </div>
                    <div>

                        <select aria-label="Default select example" wire:model="selectedModelId">
                            <option>Select moodel</option>
                            @if ($selectedDeviceId)
                                @forelse($models as $model)
                                    <option value="{{ $model->id }}">{{ $model->name }}</option>
                                @empty
                                @endforelse
                            @endif
                        </select>
                    </div>



                    <div class=" d-flex gap-2 cursor-pointer mt-3 " onclick="showM('add-repair-model-spec')">
                        <i class="fa fa-plus text-success " style="font-size:20px;" aria-hidden="true"></i>
                        <h4 class="fw-bold">Create new</h4>
                    </div>

                </div>


                <div>

                    <div class="d-flex justify-content-center gap-4  flex-wrap table-responive  ">
                        <table class="table table-striped  p-5 shadow">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Memory Size</th>
                                    <th>Condition</th>
                                    <th>Color</th>
                                    <th>Price</th>
                                    <th>N/Unlocked</th>
                                    <th>A/Cleared</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>

                                @forelse ($product_specs as $key =>  $product)
                                    <tr>
                                        <th>{{ ++$key }}</th>
                                        <td>{{ $product->memory_size }}</td>
                                        <td>{{ $product->condition }}</td>
                                        <td>{{ $product->color }}</td>
                                        <td>{{ $product->price }} $</td>
                                        <td>{{ $product->network_unlocked ? 'Yes' : 'NO' }}</td>
                                        <td>{{ $product->account_cleared ? 'Yes' : 'NO' }}</td>
                                        <td>
                                            <i class="fa fa-trash text-danger cursor-pointer" aria-hidden="true"
                                                wire:click="delete('{{ $product->id }}')"></i>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9">Record Not Found!</td>
                                    </tr>
                                @endforelse


                            </tbody>
                        </table>
                    </div>

                </div>

            </div>


        </x-content>

        <livewire:admin.repair.components.right-nav :data="$data" />

    </div>
    {{-- OTHER MODALS --}}
    @if ($selectedModel)
        <x-modal title="Add Model" id="add-repair-model-spec" size="lg">
            <livewire:admin.repair.addon.add-spec :model="$selectedModelId" />
        </x-modal>
    @endif

</div>

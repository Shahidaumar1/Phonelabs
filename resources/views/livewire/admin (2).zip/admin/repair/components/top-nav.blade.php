 <nav class="bg-blue px-3" style="padding:4px;">
     <div class="d-flex justify-content-between align-items-center ">
         <i class="fa fa-bars cursor-pointer text-white" aria-hidden="true" onclick="toggleLeftDrawer()"></i>

         <div class="d-flex  align-items-center">
             <div>
                 <a href="{{ route('repair-categories') }}"
                     class=" text-white item p-3 {{ $active == 'categories' ? 'text-danger fw-bold bg-white p-3' : '' }}">Devices</a>
             </div>
             <div>
                 <a href="{{ route('repair-devices') }}"
                     class=" text-white p-3 item  {{ $active == 'devices' ? 'text-danger fw-bold bg-white p-3' : '' }}">Brands</a>
             </div>

             <div>
                 <a href="{{ route('repair-models') }}"
                     class=" text-white p-3 item  {{ $active == 'models' ? 'text-danger fw-bold bg-white p-3' : '' }}">Models</a>
             </div>

             <div>
                <a href="{{ route('repair-price') }}"
                    class=" text-white p-3 item  {{ $active == 'price' ? 'text-danger fw-bold bg-white p-3' : '' }}">Repair</a>
            </div>



         </div>

         <livewire:components.avatar />
     </div>

 </nav>

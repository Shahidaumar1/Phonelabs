
<div>
    <div>
        <div class="d-flex">
            <livewire:admin.components.side-nave active="repair" />
            <x-content>
                <livewire:admin.repair.components.top-nav active="price" />
                <div class="container">
                    <div class="text-center my-3">
                        <strong>Select categeory,device and model to seee product specifications with
                            prices.
                        </strong>
                    </div>
                    <div class="d-flex align-items-center justify-content-center gap-4 mb-3  ">
                        <div>
                            <a href="{{ route('repair-master-type') }}">
                                <div class=" d-flex gap-2 cursor-pointer mt-3 ">
                                    <i class="fa fa-plus text-success " style="font-size:20px;" aria-hidden="true"></i>
                                    <h4 class="fw-bold">Master Repairs</h4>
                                </div>
                            </a>
                        </div>
                        <div>
                            <select class="" aria-label="Default select example" wire:model="selectedCatId">
                                <option disabled>Select Category</option>
                                @forelse($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @empty
                                @endforelse
                            </select>
                        </div>
                        <div>

                            <select class="" aria-label="Default select example" wire:model="selectedDeviceId">
                                <option disabled>Select device</option>
                                @forelse($devices as $device)
                                    <option value="{{ $device->id }}">{{ $device->name }}</option>
                                @empty
                                @endforelse
                            </select>
                        </div>




                        <div class=" d-flex gap-2 cursor-pointer mt-3 " onclick="showM('add-new-repair')">
                            <i class="fa fa-plus text-success " style="font-size:20px;" aria-hidden="true"></i>
                            <h4 class="fw-bold">Add New Repair</h4>
                        </div>

                    </div>

                    <div >
                        <div id="wrap">
                            <div class="container">
                                <script src="https://cdn.jsdelivr.net/gh/livewire/sortable@v0.x.x/dist/livewire-sortable.js"></script>
                                <table class="table table-striped table-bordered" id="table_id">
                                    <thead>
                                        @if ($selectedDevice)
                                            <tr wire:sortable="updateTaskOrder">
                                                <th>{{ $selectedDevice->name }}</th>
                                                @foreach ($selectedDevice->repair_types as $repair_type)
                                                    <td style="cursor: move" wire:sortable.handle
                                                        wire:sortable.item="{{ $repair_type->id }}"
                                                        wire:key="repair-{{ $repair_type->id }}">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            {{ $repair_type->name }}
                                                            <span class="fas fa-arrows-alt"></span>
                                                        </div>
                                                        {{-- <livewire:repair.components.order-number :devicetype="$selectedDevice" :repairtype="$repair_type"/> --}}
                                                    </td>
                                                @endforeach
                                            </tr>
                                        @endif
                                        @foreach ($models as $modal)
                                            <tr>
                                                <td>{{ $modal->name }}</td>
                                                @foreach ($selectedDevice->repair_types as $repairType)
                                                    @if ($price = $modal->prices->where('repair_type_id', $repairType->id)->first())
                                                        <td>
                                                            <livewire:repair.components.price-edit :key="uniqid()" :price="$price" />

                                                        </td>
                                                    @else
                                                        <td>....</td>
                                                    @endif
                                                @endforeach


                                            </tr>
                                        @endforeach

                                    </thead>

                                    <tbody>


                                    </tbody>


                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </x-content>

            <livewire:admin.repair.components.right-nav :data="$data" />

        </div>
        {{-- OTHER MODels --}}
        @if ($selectedDevice)
            <x-modal title="Add Model" id="add-new-repair" size="xl">
                <livewire:admin.repair.repair-price.create :device="$selectedDevice" />
            </x-modal>
        @endif

        <x-modal title="Edit Model" id="edit-repair-model">
            <livewire:admin.repair.model.edit />
        </x-modal>


    </div>








</div>

<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="sell" />
        <x-content>
            <livewire:admin.sell.components.top-nav active="devices" />
            <div class="container">
                <div class="d-flex align-items-center gap-4 justify-content-between my-4">
                    <h3>{{ $selectedCategory->name ?? '' }}</h3>
                    <livewire:admin.sell.components.sub-nav :items="$items" />
                    <select class="form-select form-control" aria-label="Default select example" wire:model="selectedCatId"
                        style="width:30%">
                        @forelse($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @empty
                        @endforelse
                    </select>
                </div>

                <div class="d-flex justify-content-center gap-4  flex-wrap  ">
                    @if ($target == 'Publish')
                        <div class="plus-card" onclick="showM('add-sell-device')">
                            <i class="fa fa-plus text-success " style="font-size:40px;" aria-hidden="true"></i>
                            <h4 class="fw-bold">Create new</h4>
                        </div>

                        <div class="plus-card">
                            <i class="fa fa-question text-success " style="font-size:40px;" aria-hidden="true"></i>
                            <h4 class="fw-bold">Allow Others</h4>
                            <div class="p-2 d-flex justify-content-between align-items-center">
                                <div class="form-check form-switch">
                                    <input type="checkbox" role="switch" class="form-check-input border border-dark"
                                        @if ($selectedCategory) wire:change="toggleOthers({{ $selectedCategory->id }})"
                                        {{ $selectedCategory->others == true ? 'checked' : '' }} @endif>
                                </div>
                            </div>
                        </div>
                    @endif
                    @forelse($devices as $device)
                        <div class="card border-0 rounded-0 shadow cursor-pointer">
                            <div class="p-2 d-flex justify-content-between align-items-center">
                                <div class="form-check form-switch">
                                    <input type="checkbox" role="switch" class="form-check-input border border-dark"
                                        wire:change="toggleStatus({{ $device->id }})"
                                        {{ $device->status == 'Publish' ? 'checked' : '' }}>
                                </div>

                                <div class="dropdown dropend" id="{{ uniqid() }}" wire:ignore>
                                    <button class="btn btn-light dropdown-toggle bg-light border-0" type="button"
                                        id="{{ uniqid() }}" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa fa-ellipsis-h"></i>
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="{{ uniqid() }}">
                                        <li>
                                            @if ($target != 'Junk')
                                                <a class="dropdown-item" href="javascirpt:void(0)"
                                                    wire:click="selectDevice('{{ $device->id }}')">Edit</a>
                                            @endif
                                        </li>
                                        <li>
                                            @if ($target == 'Junk')
                                                <a class="dropdown-item"
                                                    wire:click="restore('{{ $device->id }}')">Restore</a>
                                            @else
                                                <a class="dropdown-item"
                                                    wire:click="softDelete('{{ $device->id }}')">Delete</a>
                                            @endif
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <a href="{{ route('sell-models', $device) }}">
                                <img src="{{ $device->file ?? '#' }}" class="img-fluid"
                                    style="height: 100px; width: 200px" />
                                <div class="p-2">
                                    <h4 class="fw-bold text-center text-dark">{{ $device->name }}</h4>
                                </div>
                            </a>
                        </div>
                    @empty
                        <div class="plus-card">
                            <i class="fa fa-times text-danger " style="font-size:40px;" aria-hidden="true"></i>
                            <h4 class="fw-bold">No Records !</h4>
                        </div>
                    @endforelse
                </div>

            </div>
        </x-content>

        <livewire:admin.sell.components.right-nav :data="$data" />

    </div>
    {{-- OTHER MODALS --}}
    @if ($selectedCategory)
        <x-modal title="Add Device" id="add-sell-device">
            <livewire:admin.sell.device.create :category="$selectedCategory" />
        </x-modal>
    @endif
    <x-modal title="Edit Device" id="edit-sell-device">
        <livewire:admin.sell.device.edit />
    </x-modal>


</div>

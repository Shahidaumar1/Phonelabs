<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="sell" />
        <x-content>
            <livewire:admin.sell.components.top-nav active="add-ons" />
            <div class="container my-4">
                <div class="text-center mb-3">
                    <strong>Select categeory,device and model to seee product specifications with
                        prices.
                    </strong>
                </div>
                <div class="d-flex align-items-center justify-content-center gap-4 mb-3  ">
                    <div>

                        <select class="" aria-label="Default select example" wire:model="selectedCatId">
                            <option>Select Category</option>
                            @forelse($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @empty
                            @endforelse
                        </select>
                    </div>
                    <div>

                        <select class="" aria-label="Default select example" wire:model="selectedDeviceId">
                            <option>Select device</option>
                            @forelse($devices as $device)
                                <option value="{{ $device->id }}">{{ $device->name }}</option>
                            @empty
                            @endforelse
                        </select>
                    </div>
                    <div>

                        <select aria-label="Default select example" wire:model="selectedModelId">
                            <option>Select moodel</option>
                            @if ($selectedDeviceId)
                                @forelse($models as $model)
                                    <option value="{{ $model->id }}">{{ $model->name }}</option>
                                @empty
                                @endforelse
                            @endif
                        </select>
                    </div>
                    <div class=" d-flex gap-2 cursor-pointer mt-3 " onclick="showM('add-sell-model-spec')">
                        <i class="fa fa-plus text-success " style="font-size:20px;" aria-hidden="true"></i>
                        <h4 class="fw-bold">Create new</h4>
                    </div>

                </div>


                <div>
                    <div class="d-flex gap-4  flex-wrap table-responive  ">
                        <table class="table table-striped  p-5 shadow">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Memory Size</th>
                                    <th>Condition</th>
                                    <th>Price</th>
                                    @if ($tabletMode || $mobileMode)
                                        <th>N/Unlocked</th>
                                    @endif
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>

                                @forelse ($product_specs as $key =>  $product)
                                    <tr>
                                        <th>{{ ++$key }}</th>
                                        <td><img src="{{ $product->image ?? 'https://ik.imagekit.io/qml3d7tgz/iphone_14_pro_space_black_3_RIm6bNsLt.png' }}"
                                                style="height:40px; width:50px;" /></td>
                                        <td>{{ $product->memory_size ?? '....' }}</td>
                                        <td>{{ $product->condition }}</td>
                                        @if ($editableProductSpecId == $product->id)
                                            <td><input style="width:30px; height:30px;" type="text"
                                                    wire:keydown.enter="updateProductPrice('{{ $product->id }}')"
                                                    wire:model.debounce.500="price" id="{{ $product->id }}" /></td>
                                        @else
                                            <td wire:click="toggleEditable('{{ $product->id }}')">£
                                                {{ $product->price }}</td>
                                        @endif
                                        @if ($mobileMode || $tabletMode)
                                            <td>{{ $product->network_unlocked ? 'Yes' : 'NO' }}</td>
                                        @endif
                                        <td>
                                            <i class="fa fa-trash text-danger cursor-pointer" aria-hidden="true"
                                                wire:click="delete('{{ $product->id }}')"></i>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9">Record Not Found!</td>
                                    </tr>
                                @endforelse


                            </tbody>
                        </table>

                    </div>

                </div>

            </div>


        </x-content>

        <livewire:admin.sell.components.right-nav :data="$data" />

    </div>
    {{-- OTHER MODALS --}}
    @if ($selectedModel)
        <x-modal title="Add  Specs" id="add-sell-model-spec" size="xl">
            <livewire:admin.sell.addon.add-spec :model="$selectedModelId" />
        </x-modal>
    @endif

</div>

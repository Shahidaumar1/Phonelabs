<div>
    <div class="d-flex flex-column flex-md-row">
        <livewire:admin.components.side-nave active="orders" />
        <x-content class="w-100">
            <div class="container my-5">
                <div>
                    <div class="">
                        <div class="">
                            <livewire:admin.orders.components.top-nav active="" />
                        </div>
                        <div>
                            <div>
                                
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Product Name</th>
                                                <th>Repairs</th>
                                                <th>Other Text</th>
                                                <th>Existing Customer</th>
                                                <th>Is Business</th>
                                                <th>Brand</th>
                                                <th>Model</th>
                                                <th>Additional Description</th>
                                                <th>Created At</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($inquiries as $inquiry)
                                                <tr>
                                                    <td>{{ $inquiry->first_name }}</td>
                                                    <td>{{ $inquiry->last_name }}</td>
                                                    <td>{{ $inquiry->email }}</td>
                                                    <td>{{ $inquiry->phone }}</td>
                                                    <td>{{ $inquiry->product_name }}</td>
                                                    <td>{{ implode(', ', json_decode($inquiry->checkboxes)) }}</td>
                                                    <td>{{ $inquiry->other_text }}</td>
                                                    <td>{{ $inquiry->existing_customer ? 'Yes' : 'No' }}</td>
                                                    <td>{{ $inquiry->is_business ? 'Yes' : 'No' }}</td>
                                                    <td>{{ $inquiry->brand }}</td>
                                                    <td>{{ $inquiry->model }}</td>
                                                    <td>{{ $inquiry->additional_description }}</td>
                                                    <td>{{ $inquiry->created_at->format('d/m/Y H:i') }}</td>
                                                    <td>
                                                        <button class="btn btn-info btn-sm" wire:click="$emit('viewInquiry', {{ $inquiry->id }})">View</button><br>
                                                        <button class="btn btn-danger btn-sm" wire:click="deleteInquiry({{ $inquiry->id }})">Delete</button>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <livewire:admin.inquiry-modal />
        </x-content>
    </div>
</div>

<style>
    .table {
        width: 100%;
        margin-bottom: 1rem;
        background-color: transparent;
    }

    .table th,
    .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }

    .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
    }

    .table tbody + tbody {
        border-top: 2px solid #dee2e6;
    }

    .table-bordered {
        border: 1px solid #dee2e6;
    }

    .table-bordered th,
    .table-bordered td {
        border: 1px solid #dee2e6;
    }

    .table-bordered thead th,
    .table-bordered thead td {
        border-bottom-width: 2px;
    }

    .thead-dark th {
        color: black;
        background-color: #C0C0F0;
        border-color: white;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.05);
    }

    h1 {
        margin-bottom: 20px;
        font-size: 2rem;
        font-weight: bold;
        text-align: center;
    }

    .container {
        padding: 20px;
    }

    @media (max-width: 768px) {
        .table th,
        .table td {
            padding: 0.5rem;
        }

        h1 {
            font-size: 1.5rem;
        }

        .container {
            padding: 10px;
        }
    }
</style>

<div class="" style="overflow: hidden;">
  <!-- Your existing code here -->
  <div class="row">
    <div class="col">
      <div class="d-flex flex-column flex-md-row">
          
        <livewire:admin.components.side-nave active="settings" />
        <x-content>
          <livewire:admin.settings.components.top-nav active="payment" />

          <div class="container">
            <h2 class=" px-3 pt-1 pt-md-5 pb-3"><b> Payment Gateway</b></h2>
            <p class="px-3 py-1">
              A payment gateway facilitates secure online payments for businesses.
            </p>

              <div class="ml-2 d-flex  gap-2 align-items-center">
                <label class="  p-3 text-center  {{$pm == 'Paypal' ? 'selected-button' : 'unselected-button'}} cursor-pointer" wire:click='$set("pm","Paypal")'>Paypal</label>
                <label class=" p-3 text-center {{$pm == 'Stripe' ? 'selected-button' : 'unselected-button'}} cursor-pointer" wire:click='$set("pm","Stripe")'>Stripe</label>
              </div>
              
            <div class="px-3 pt-3">
              @if($pm == 'Paypal')
              <livewire:admin.settings.components.paypal />
              @endif

              @if($pm == 'Stripe')
              <livewire:admin.settings.components.stripe />
              @endif
            </div>
          </div>
        </x-content>

      </div>
    </div>
  </div>
</div>

                
        <!----------------------------- footer-------------------------->
        
        <style>
        .button-sticky {
            height: 60px;
            color: white;
            font-family: sans-serif;
            font-size: 15px;
            line-height: 15px;
            text-align: center;
            position: fixed !important;
            bottom: -2px;
            z-index: 999;
            width: 100%;
         
        }
        
        .home-btn:hover {
            color: orange;
        }
        .button-sticky .col-2 {
            margin-right: 5px; /* Adjust this value to set the desired gap */
        }
        
        
        
        </style>
        <div class="button-sticky container bg-blue d-lg-none d-md-none">
            <div class="row ">
        
                <div class="col-2  mt-4 ml-1">
                    <a href="{{ route('payment-methods-settings') }}" class="text-white item ">  Payment</a>
             
             
                </div>
        
                <div class="col-2  mt-4 ">
                    <a href="{{ route('site-settings') }}" class="text-white  item "> site-settings</a>
                
                </div>
        
                <div class="col-2  mt-4 ">
                    <a href="{{ route('branches-settings') }}" class="text-white  item "> Branches</a>
                </div>
        
                <div class="col-2 mt-4">
                    <a href="{{ route('create-branches') }}" class="text-white  item ">Create</a>
                </div>
                <div class="col-2 mt-4">
                    <a href="{{ route('services-settings') }}" class="text-white  item ">Services</a>
                </div>
            </div>
        </div>
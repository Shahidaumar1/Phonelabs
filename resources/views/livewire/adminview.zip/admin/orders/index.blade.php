<div>
    <div class="d-flex">
        <livewire:admin.components.side-nave active="orders" />
        <x-content>

            <div class="container my-5">
                <div>
                    <div class="">
                        <div class="">
            <livewire:admin.orders.components.top-nav active="" />

                        </div>
                        <div class="" style="border: 0px;">
                            <input type="text" wire:model="search" class="form-control mb-4" placeholder="Search..." style="width: 150px;">
                            <div class="d-flex gap-4 flex-wrap table-responsive" style="overflow-x: auto;">
                                <!-- Search Input -->
                                <table class="table p-5">
                                    <thead style="background-color: #C0C0EF !important;">
                                        <tr style="background-color: #C0C0EF !important;">
                                            <th style="background-color: #C0C0EF !important;">Sr. No</th>
                                            <th style="background-color: #C0C0EF !important;">Booking Type</th>
                                            <th style="background-color: #C0C0EF !important;">Date Time</th>
                                            <th style="background-color: #C0C0EF !important;">Customer Email</th>
                                            
                                            <th style="background-color: #C0C0EF !important;">Customer Name</th>
                                            <th style="background-color: #C0C0EF !important;">Order Amount</th>
                                            <th style="background-color: #C0C0EF !important;">Payment Method</th>
                                            <th style="background-color: #C0C0EF !important;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($orders as $index => $order)
                                        @php
                                        $reversedIndex = count($orders) - $index;
                                        $order = $orders[$reversedIndex - 1]; // Reverse the order of array
                                        @endphp
                                        <tr>
<td>{{ $reversedIndex }}</td>
<td>{{ $order['Service'] }}</td>
<td>{{ $order['date_time'] }}</td>
<td>{{ $order['patient']['email'] }}</td>
<td>
    @if (!empty($order['patient']['name']) && !empty($order['patient']['last_name']))
        {{ $order['patient']['name'] . ' ' . $order['patient']['name'] }}
    @else
        {{ $order['patient']['name'] }}
    @endif

</td>

                                            <td>
                                                @if($order['Service'] === 'Repairing')
                                                £ {{ $order['repair_detail']['quotePrice'] ?? 0 }}
                                                @elseif($order['Service'] === 'Buy')
                                                £ {{ $order['repair_detail']['price'] ?? 0 }}
                                                @elseif($order['Service'] === 'Sell')
                                                £ {{ $order['repair_detail']['specs']['price'] ?? 0 }}
                                                @endif
                                            </td>
                                            <td>{{ $order['payment_method'] ?? 'N/A' }}</td>
                                            <td>
                                                <div class="btn-group" role="group" style="width: 100%;">
                                                    <div style="width: 45%;">
                                                        <button wire:click="deleteOrder({{ $reversedIndex - 1 }})" class="btn btn-sm btn-danger w-100">Delete</button>
                                                    </div>
                                                    <div style="width: 45%;">
                                                        <a href="{{ route('orders-details', ['orderDetails' => $reversedIndex - 1]) }}" class="btn btn-sm btn-primary w-100 ms-4">Details</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                document.addEventListener('livewire:load', function() {
                    window.searchTerm = '';

                    Livewire.hook('message.processed', (message, component) => {
                        // Update the table rows based on the search term
                        filterTableRows();
                    });

                    function filterTableRows() {
                        const searchTerm = window.searchTerm.toLowerCase();
                        const tableRows = document.querySelectorAll('.table-row');

                        tableRows.forEach(row => {
                            const rowData = row.innerText.toLowerCase();
                            if (rowData.includes(searchTerm)) {
                                row.style.display = '';
                            } else {
                                row.style.display = 'none';
                            }
                        });
                    }
                });
            </script>
            <script>
                document.addEventListener('livewire:load', function() {
                    Livewire.on('searchChanged', search => {
                        window.searchTerm = search;
                    });
                });
            </script>

        </x-content>
    </div>
</div>

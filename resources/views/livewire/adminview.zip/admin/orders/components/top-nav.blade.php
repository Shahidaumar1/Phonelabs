<style>
    .nav-box {
        background-color: rgb(192, 192, 239);
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .nav-box a {
        color: #343a40 !important;
        font-weight: bold;
    }

    .nav-box.active-box {
        background-color: #007bff;
    }

    .nav-box.active-box a {
        color: #fff !important;
    }

    .nav-box:hover {
        background-color: #e2e6ea;
    }

    .cursor-pointer {
        cursor: pointer;
    }

    .text-dark {
        color: #343a40 !important;
    }
</style>

<nav class="px-3" style="background-color: transparent; border-bottom: 1px solid #ddd;">
    <div class="d-flex justify-content-between align-items-left py-2">
        <!-- Toggle Sidebar Button -->
        <i class="fa fa-bars cursor-pointer text-black" aria-hidden="true" onclick="toggleLeftDrawer()"></i>

        <!-- Navigation Links -->
        <div class="d-flex align-items-center">
            <div class="nav-box {{ $active == 'orders' ? 'active-box' : '' }} me-3">
                <a href="{{ route('orders') }}" class="text-dark d-flex gap-2 align-items-center py-2 px-4 text-decoration-none">
                    <span>Orders</span>
                </a>
            </div>
            <div class="nav-box {{ $active == 'contacts' ? 'active-box' : '' }} me-3">
                <a href="{{ route('contacts.index') }}" class="text-dark d-flex gap-2 align-items-center py-2 px-4 text-decoration-none">
                    <span>Customer Inquiries</span>
                </a>
            </div>
            <div class="nav-box {{ $active == 'customer-inquiries' ? 'active-box' : '' }}">
                <a href="{{ route('customer-inquiries') }}" class="text-dark d-flex gap-2 align-items-center py-2 px-4 text-decoration-none">
                    <span>Quotation request</span>
                </a>
            </div>
        </div>

        <!-- User Avatar Component -->
        <livewire:components.avatar />
    </div>
</nav>



<div>
    <div>
        <div class="d-flex">
            <livewire:admin.components.side-nave active="repair" />
            <x-content>
                <livewire:admin.repair.components.top-nav active="price" />
                <div class="container">
                    <div class="text-center my-3">
                        <h3>Select category, device, and model to see product specifications with prices.</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-6 mb-3 d-flex justify-content-center">
                            <a href="{{ route('repair-master-type') }}">
                                <button class="btn p-3" style="border-radius: 20px; color: white; background-color: #20375E; padding: 10px">
                                    Master Repairs
                                </button>
                            </a>
                        </div>
                        
                        <div class="col-lg-3 col-md-6 mb-3">
                            <select class="form-select" aria-label="Default select example" wire:model="selectedCatId">
                                <option disabled selected>Select Category</option>
                                @forelse($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @empty
                                    <option>No Categories Available</option>
                                @endforelse
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-3">
                            <select class="form-select" aria-label="Default select example" wire:model="selectedDeviceId">
                                <option disabled selected>Select device</option>
                                @forelse($devices as $device)
                                    <option value="{{ $device->id }}">{{ $device->name }}</option>
                                @empty
                                    <option>No Devices Available</option>
                                @endforelse
                            </select>
                        </div>
                    
                        <div class="col-lg-3 col-md-6 mb-3 d-flex justify-content-center">
                            <button class="btn p-3" onclick="showM('add-new-repair')" style="border-radius: 20px; color: white; background-color: #20375E; padding: 10px">
                                Add New Repair
                            </button>
                        </div>
                    </div>

                    <div style="overflow-x: auto;">
                        <div id="wrap">
                            <div class="container">
                                <script src="https://cdn.jsdelivr.net/gh/livewire/sortable@v0.x.x/dist/livewire-sortable.js"></script>
                                <table class="table table-striped table-bordered" id="table_id">
                                    <thead>
                                        @if ($selectedDevice)
                                            <tr wire:sortable="updateTaskOrder">
                                                <th>{{ $selectedDevice->name }}</th>
                                                @foreach ($selectedDevice->repair_types as $repair_type)
                                                    <td class="sticky-cell" style="cursor: move" wire:sortable.handle wire:sortable.item="{{ $repair_type->id }}" wire:key="repair-{{ $repair_type->id }}">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            {{ $repair_type->name }}
                                                            <span class="fas fa-arrows-alt"></span>
                                                        </div>
                                                    </td>
                                                @endforeach
                                                <th>Status</th>
                                            </tr>
                                        @endif
                                    </thead>
                                    <tbody>
                                        @if ($models->isNotEmpty())
                                            @foreach ($models as $model)
                                                <tr>
                                                    <td>{{ $model->name }}</td>
                                                    @foreach ($selectedDevice->repair_types as $repairType)
                                                        @if ($price = $model->prices->where('repair_type_id', $repairType->id)->first())
                                                            <td>
                                                                <livewire:repair.components.price-edit :key="uniqid()" :price="$price" />
                                                            </td>
                                                        @else
                                                            <td>....</td>
                                                        @endif
                                                    @endforeach
                                                    <td>{{ $model->status }}</td>
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr>
                                                <td colspan="{{ count($selectedDevice->repair_types) + 2 }}">No Models Available</td>
                                            </tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </x-content>

            <div class="button-sticky container bg-blue d-lg-none d-md-none">
                <div class="row justify-content-center">
                    <div class="col-2 mt-4">
                        <a href="{{ route('repair-categories') }}" class="text-white item">Devices</a>
                    </div>
                    <div class="col-2 mt-4">
                        <a href="{{ route('repair-devices') }}" class="text-white item">Brands</a>
                    </div>
                    <div class="col-2 mt-4">
                        <a href="{{ route('repair-models') }}" class="text-white item">Models</a>
                    </div>
                    <div class="col-2 mt-4">
                        <a href="{{ route('repair-price') }}" class="text-white item">Repair</a>
                    </div>
                </div>
            </div>

        </div>

        @if ($selectedDevice)
            <x-modal title="Add Model" id="add-new-repair" size="xl">
                <livewire:admin.repair.repair-price.create :device="$selectedDevice" />
            </x-modal>
        @endif

        <x-modal title="Edit Model" id="edit-repair-model">
            <livewire:admin.repair.model.edit />
        </x-modal>
    </div>

    <style>
        .sticky-cell {
            position: sticky;
            top: 0;
        }
    </style>
</div>


<section class="modals-head">
    <div class="overlay"></div>
    <div class="container-fluid">
        <livewire:components.mega-nav />

        <div class="p-3   d-flex justify-content-between align-items-center gradient-border"
            style="background-color: #EE8787">
            <div class="d-flex flex-column ">
                <h1 style="white-space: nowrap; display: block; text-align:center;">
                    Broken <span class="text-danger">{{ $device->name ?? 'Apple iPhone' }}?</span>
                </h1>
                <p style="display: block; text-align:center;">
                    Whether you've got a broken screen or back glass, a battery problem, water damage, a charging
                    problem, faulty camera, or however else you've broken it, we should be able to repair it for
                    you…
                    But first, we need to know which {{ $device->name ?? '' }} you're fixing!
                </p>
            </div>
           
        </div>
    </div>
</section>
<style>
    .gradient-border {
    border: 5px solid;
    border-image-slice: 1;
    border-width: 5px;
    border-image-source: linear-gradient(to right, white, #FFB1B1);
}
</style>
<style>
    .shah {
        transition: border-color 0.3s ease-in-out !important;
        height: 250px !important;
    }
    .shah:hover {
        border-color: #dc3545 !important;
        box-shadow: 0 0 40px #dc3545 !important;
        cursor: pointer !important; 
    }
</style>

<section>
        <!--Breadcrumb-->
<div class="container mt-3">
<nav aria-label="breadcrumb">
  <ol class="breadcrumb" >
    <li class="breadcrumb-item"><a href="https://mobilebitz.co.uk/">Home</a></li>
    <li class="breadcrumb-item" ><a href="https://mobilebitz.co.uk/categories">Device Type</a></li>
    <li class="breadcrumb-item"><a href="https://mobilebitz.co.uk/device-types/4">Brands</a></li>
    <li class="breadcrumb-item"><a href="https://mobilebitz.co.uk/4/models">Models</a></li>
  </ol>
</nav>
</div>

    <h6 class="text-center" style="font-weight:bold; font-size:25px; color:#DC3545; font-family:Poppins, sans-serif;">SEARCH BY MODEL NAME</h6>
    <div class="container d-flex justify-content-center align-items-center mt-3">
        <div class="input-group  mb-3" style="max-width: 430px;">
            <input type="text" id="modalSearch" class="form-control " placeholder="Search by Model Name">
            <span class="input-group-text " style="margin-left: -28px;">
               
            </span>
        </div>
    </div>



    <div class="container">
        <div class="section-header text-center my-5">
            <h2 style="font-weight:bold; color:#DC3545;"><sup></sup> {{ $device->name ?? 'Apple iPhone' }}<sub></sub></h2>
        </div>

        <div class="row row-cols-2 row-cols-sm-2 row-cols-md-4 row-cols-lg-6 g-1 gx-0 gy-2 justify-content-center" id="modalList" style="margin-top:-30px;">
            @forelse($modals as $key => $modal)
                <div class="col model-card">
                    <div class="card shah my-2 cursor-pointer align-items-center justify-content-center pt-2">
                        <a href="{{ route('repair-types', ['device' => $device->id, 'modal' => $modal->id]) }}">
                            <div class="card-body">
                                <img src="{{ $modal->file ?? '' }}" class="img-fluid mx-auto"
                                    style="max-height:150px; max-width:150px;" alt="{{ $modal->name }}">
                                <h6 class="card-title text-center text-lg-sm mt-3">
                                    {{ $modal->name }}
                                </h6>
                            </div>
                        </a>
                    </div>
                </div>
            @empty
                <span>Not Found</span>
            @endforelse
            <div class="col-2 mt-3 d-none d-lg-block d-md-block-" >
                <div class="card" style="height:250px;">
                    <img style="max-width: 150px; max-height:150px;" onclick="toggleVisibility()" class="img-fluid"
                        src="https://thumbs.dreamstime.com/b/d-white-man-red-questionmark-computer-generated-image-isolated-68105896.jpg"
                        alt="Other">
                    <h6 class="card-text text-center mt-3" onclick="toggleVisibility()">Other</h6>
                    <p class="text-center" style="color:red; font-size:12px;">Have other device, Click Here</p>
                </div>
            </div>
            <!-- for phone-->
                <div class="col-2 mt-3 d-lg-none d-md-none">
                <div class=" card  mycardmy rounded" style="margin-left:-70px !important;">
                    <img style="max-width: 150px; max-height:150px;" onclick="toggleVisibility()" class="img-fluid"
                        src="https://thumbs.dreamstime.com/b/d-white-man-red-questionmark-computer-generated-image-isolated-68105896.jpg"
                        alt="Other">
                    <h6 class="card-text text-center mt-3" onclick="toggleVisibility()">Other</h6>
                    <p class="text-center" style="color:red; font-size:12px;">Have other device, Click Here</p>
                </div>
            </div> 
            
            
        </div>
    </div>

<style>
    .mycardmy{
width:200px !important;
        height:250px;
        
        
    }
</style>


    <div class="hidediv" style="display: none;">
        <div style="position: relative;top:30px;">
            <h1 class="fw-bold text-danger my-3 text-center">Can't Find Your Model?</h1>
            <h2 class="fw-bold my-3 text-center">Ask For Quote Below</h2>
        </div>
        <div style="position: relative;" class="container bg-gray rounded-4 p-5 mt-5 mb-5">
            <form wire:submit.prevent="sendCustomerEmail">
                <div class="row">
                    <div class="container col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="brand">Brand:</label>
                            <input class="form-control" type="text" id="brand" wire:model="brand" placeholder="Enter brand">
                            @error('brand') <span class="error">{{ $message }}</span> @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="model">Model:</label>
                            <input class="form-control" type="text" id="model" wire:model="model" placeholder="Enter model">
                            @error('model') <span class="error">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="form-label" for="additionalDescription">Additional Information:</label>
                            <textarea class="form-control" id="additionalDescription" wire:model="additionalDescription" placeholder="Enter additional information"></textarea>
                            @error('additionalDescription') <span class="error">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="container col-md-6">
                        <!-- Checkboxes -->
                        @foreach(['Broken Screen', 'Battery Replacement', 'Charging Port Repair', 'Housing Issue', 'Audio Fault', 'Water Damage'] as $option)
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label" for="checkbox{{ $loop->index + 1 }}">{{ $option }}</label>
                                </div>
                                <div class="col-md-6">
                                    <input class="form-check-input" type="checkbox" id="checkbox{{ $loop->index + 1 }}" wire:model="checkboxes" value="{{ $option }}">
                                </div>
                            </div>
                        @endforeach
                        <!-- "Other" Checkbox -->
                        <div class="row">
                            <div class="col-md-6 mt-1">
                                <label class="form-label" for="otherCheckbox">Other</label>
                            </div>
                            <div class="col-md-6">
                                <input class="form-check-input" type="checkbox" id="otherCheckbox" wire:model="checkboxes" value="Other">
                            </div>
                        </div>
                        @if (in_array('Other', $checkboxes))
                            <div class="row">
                                <div class="col-md-12">
                                    <label class="form-label" for="otherText">Please specify:</label>
                                    <input class="form-control" type="text" id="otherText" wire:model="otherText" placeholder="Describe other">
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="firstName">First Name:</label>
                            <input class="form-control" type="text" id="firstName" wire:model="firstName" required placeholder="Enter your first name">
                            @error('firstName') <span class="error">{{ $message }}</span> @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="lastName">Last Name:</label>
                            <input class="form-control" type="text" id="lastName" wire:model="lastName" required placeholder="Enter your last name">
                            @error('lastName') <span class="error">{{ $message }}</span> @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="email">Email:</label>
                            <input class="form-control" type="email" id="email" wire:model="email" required placeholder="Enter your email">
                            @error('email') <span class="error">{{ $message }}</span> @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="confirmEmail">Confirm Email:</label>
                            <input class="form-control" type="email" id="confirmEmail" wire:model="confirmEmail" required placeholder="Confirm your email">
                            @error('confirmEmail') <span class="error">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label" for="phone">Phone:</label>
                            <input class="form-control" type="text" id="phone" wire:model="phone" required placeholder="Enter your phone number">
                            @error('phone') <span class="error">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="form-label">Are you an existing customer?</label>
                            <div style="width: 20%; display: flex; align-items: center; gap: 5px;">
                                <input class="form-check-input" type="radio" id="existingCustomerYes" name="existingCustomer" value="yes" wire:model="existingCustomer">
                                <label class="form-check-label" for="existingCustomerYes">Yes</label>
                                <input class="form-check-input ms-5" type="radio" id="existingCustomerNo" name="existingCustomer" value="no" wire:model="existingCustomer">
                                <label class="form-check-label ms-5" for="existingCustomerNo">No</label>
                            </div>
                            @error('existingCustomer') <span class="error">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="form-label">Are you a business?</label>
                            <div style="width: 20%; display: flex; align-items: center; gap: 5px;">
                                <input class="form-check-input" type="radio" id="isBusinessYes" name="isBusiness" value="yes" wire:model="isBusiness">
                                <label for="isBusinessYes">Yes</label>
                                <input class="form-check-input ms-5" type="radio" id="isBusinessNo" name="isBusiness" value="no" wire:model="isBusiness">
                                <label class="ms-5" for="isBusinessNo">No</label>
                            </div>
                            @error('isBusiness') <span class="error">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center mt-5">
                    <button class="btn btn-danger text-white rounded-pill" type="submit">Ask For Quote</button>
                </div>
            </form>
            @if (session()->has('emailSent'))
                <div>
                    <p>Thank you! The information has been sent to your email.</p>
                </div>
            @endif
        </div>
    </div>
</section>

<script>
function searchModals() {
    var input, filter, modalList, modalCards, modalName, i;
    input = document.getElementById('modalSearch');
    filter = input.value.toUpperCase();
    modalList = document.getElementById('modalList');
    modalCards = modalList.getElementsByClassName('model-card');

    for (i = 0; i < modalCards.length; i++) {
        modalName = modalCards[i].getElementsByClassName("card-title")[0];
        if (modalName.innerText.toUpperCase().indexOf(filter) > -1) {
            modalCards[i].style.display = "";
        } else {
            modalCards[i].style.display = "none";
        }
    }
}

document.getElementById('modalSearch').addEventListener('input', searchModals);

function toggleVisibility() {
    var hiddenDiv = document.querySelector('.hidediv');
    if (hiddenDiv.style.display === 'none' || hiddenDiv.style.display === '') {
        hiddenDiv.style.display = 'block';
    } else {
        hiddenDiv.style.display = 'none';
    }
}
</script>

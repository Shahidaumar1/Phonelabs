<div>
    @if (Session::get('serviceType') == 'Repair')
    <div>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>


        <div class="container-fluid " style="background-color:white">
            
            <form x-data="{ step: 0 }" class=" submit-form" wire:submit.prevent="submitForm">
              
              
              
                <section id="section-1" x-show="step === 0" x-cloak class="row map-select">
                    <legend class="mb-3">
                        <h2 class="find">Post your device to this address</h2>
                    </legend>
                    <!--  on phone screen-->
            
                    <div class="col-md-6  fpostcode-map ">
                        @if (session()->has('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                         @foreach ($branches as $branch)
        <div class="">
            <div class="card mb-4 border p-3 h-100">
                <h3 class="fw-bold branch-name">{{ $branch->name }}</h3>
                <p class="address-town-post-code">{{ $branch->address_line_1 }}, 
                   {{ $branch->address_line_2 ?: '' }}, 
                   {{ $branch->town_city }}, 
                   {{ $branch->post_code }}, UK</p>
                
                    @if (!empty($branch->email))
                    <div>Email: {{ $branch->email }}</div>
                    @endif
                    @if (!empty($branch->landline_number))
                    <div>Landline: {{ $branch->landline_number }}</div>
                    @endif
                    @if (!empty($branch->mobile_number))
                    <div>Mobile: {{ $branch->mobile_number }}</div>
                    @endif
                    
                
                <img  src="https://ik.imagekit.io/qml3d7tgz/18_kudrf-_ta.jpeg">
            </div>
        </div>
    
        @endforeach
    
                     
           
                    
                    </div>
                    
                    <!---------------------------------desktop screen-------------->
                    <div class="col-md-6  selection-area ">
                        <div class="col-lg-12 px-3 boxes" style="height: 400px;">
                            <!-- Display nearest branches -->
                        <iframe
        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
        width="100%"  class="h-100" style="border: 0;margin-top:-15px;" allowfullscreen="" loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"></iframe>

    
        
                        
                        
                            @if (!empty($nearestBranches))
                            @foreach ($nearestBranches as $branch)
                        
                            <div class="mb-4  border p-3" >
                                <p class="address-town-post-code text-white">{{ $branch['address_line_1'] }}, {{
                                    $branch['address_line_2'] ?: '' }}, {{ $branch['town_city'] }}, {{
                                    $branch['post_code']
                                    }}, UK</p>
            
                                <div class="form-select-btn text-white">
                                    <select class="form-select text-white" aria-label="Contact Options">
                                        @if (!empty($branch['email']))
                                        <option value="1" selected>Email: {{ $branch['email'] }}</option>
                                        @endif
                                        @if (!empty($branch['landline_number']))
                                        <option value="2">Landline: {{ $branch['landline_number'] }}</option>
                                        @endif
                                        @if (!empty($branch['mobile_number']))
                                        <option value="3">Mobile: {{ $branch['mobile_number'] }}</option>
                                        @endif
                                    </select>
                                    <button type="button" class="btn btn-danger"
                                        wire:click="selectBranch({{ $branch['id'] }})" @click="step = 1">Select</button>
                                </div>
                            </div>
                            @endforeach
                            @elseif (!empty($branches))
                            @foreach ($branches as $branch)
                        
<div  class="mb-4  p-3 ms-5 new-btn d-none d-lg-block d-md-block">
    <div class="form-select-btn">
    <button type="button" class="button-27" role="button"
    wire:click="selectBranch({{  $branch['id'] }})" @click="step = 1" style="width: 150px; height: auto; margin-left: auto;margin-top:-50px;">Next </button>
    <button  class="button-27" role="button" type="button" @click="step = 0" x-show="step === 1"  wire:click="goBack"  style="width: 150px; height: auto; margin-right: auto;">Go Back</button>
                  
                        
                                </div>
                            
                            
                            </div>
    


                        
    <!-- for phone screen -->
    
    <div  class="mb-4  p-3 ms-5 new-btn d-lg-none d-md-none">
                                <div class="form-select-btn">
                                    <button type="button" class="mbbutton-27" role="button"
                                        wire:click="selectBranch({{ $branch->id }})" @click="step = 1" >Next </button>
                            
                            
                                    <button class="mbbutton-27" role="button" type="button"
                        @click="step = 0" x-show="step === 1" wire:click="goBack" >Go Back</button>
                            
                                
                                </div>
                            
                            
                            </div>
    
    
                            
                        
                        <style>
                            .new-btn {
margin-top:80px;
                                
                            }





/* Media query for screens smaller than 768px (tablets and phones) */
@media (max-width: 768px) {
    .new-btn {
margin-top:10px;
    }
}

/* Media query for screens smaller than 576px (phones) */
@media (max-width: 576px) {
    .new-btn {
        padding: 6px 12px; /* Further reduce padding for very small screens */
        font-size: 12px; /* Further reduce font size */
    }
}


                        </style>
                        
                            @endforeach
                            @endif
                        </div>
                    </div>



                </section>

  <section id="section-2" x-show="step === 1" x-cloak>
                    <div style="    background-color: #ffffff;
    border-radius: 10px;
    width: 100%;
    margin: 0 auto;
    padding: 20px;">


                        <h5 class="fw-bold mt-3 mb-3">Please Provide your address</h5>


                        <div class="p-10">
                            <div class="form-group">
                                <label for="post_code">Post Code:</label>
                                <input type="text" wire:model="post_code" class="form-control w-50" id="post_code"
                                    placeholder="Enter Post Code">
                                <div id="resultContainer">
                                    <p>{{ $addressName }}</p>
                                </div>
                                @error('post_code')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <button wire:click.prevent="changeApiData" class="mb-2">Search</button>
                            @if ($responseData)


                            {{-- <br> --}}
                            <select wire:model="selectedOption" class="form-select w-50"
                                wire:change.prevent="updateAddressFields">
                                <option value="" selected>Select an option</option>
                                @foreach ($responseData['knownAddresses'] as $key => $address)
                                <option key="{{ $key }}" value="{{ $address }}">{{ $address }}</option>
                                @endforeach
                            </select>


                            <!-- Display the error message if set -->
                            @if ($errorMessage)
                            <div class="text-danger">{{ $errorMessage }}</div>
                            @endif

                            @endif


                            @if ($responseData)
                            <button class=" text-danger bg-white border-radius rounded-pill mt-3"
                                wire:click.prevent="toggleInputFields">I can't find my address..</button>

                            <!-- Conditional rendering for input fields -->
                            @if ($showInputFields)
                            <div class="mb-3 mt-3">
                                <label for="address_line_1">Address Line 1*:</label>
                                <input type="text" class="form-control form-control-sm"
                                    wire:model.lazy="postal.address_line_1" placeholder="Address Line 1"
                                    name="postal.address_line_1" required="">
                                @error('postal.address_line_1')
                                <span class="text-xs text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="address_line_2">Address Line 2:</label>
                                <input type="text" class="form-control form-control-sm"
                                    wire:model.lazy="postal.address_line_2" placeholder="Address Line 2"
                                    name="postal.address_line_2">
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="city">Town/City*:</label>
                                <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.city"
                                    placeholder="Town/City" name="postal.city" required="">
                                @error('postal.city')
                                <span class="text-xs text-danger">{{ $message }}</span>
                                @enderror
                            </div>




                            <div class="mb-3 mt-3">
                                <label for="postal_code">Post Code*:</label>
                                <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.code"
                                    placeholder="Post Code" name="postal.code" required="">
                                @error('postal.code')
                                <span class="text-xs text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            @endif
                            @endif
                        </div>


                        <!-- Include this script in your Livewire component or wherever necessary -->
                        <script>
                            document.addEventListener('DOMContentLoaded', function () {
                                // Listen for the Livewire event indicating data update
                                Livewire.on('addressFieldsUpdated', function () {
                                    // Find the relevant input fields by name attribute
                                    var address1 = document.querySelector("input[name='postal.address_line_1']");
                                    var address2 = document.querySelector("input[name='postal.address_line_2']");
                                    var city = document.querySelector("input[name='postal.city']");
                                    var post_code = document.querySelector("input[name='postal.code']");

                                    // Append five dots to each field if they exist
                                    if (address1) {
                                        address1.value += '.....';
                                        // Trigger input event to simulate user interaction
                                        var event = new Event('input', {
                                            bubbles: true
                                        });
                                        address1.dispatchEvent(event);
                                    }

                                    if (address2) {
                                        address2.value += '.....';
                                        var event = new Event('input', {
                                            bubbles: true
                                        });
                                        address2.dispatchEvent(event);
                                    }

                                    if (city) {
                                        city.value += '.....';
                                        var event = new Event('input', {
                                            bubbles: true
                                        });
                                        city.dispatchEvent(event);
                                    }

                                    if (post_code) {
                                        post_code.value += '.....';
                                        var event = new Event('input', {
                                            bubbles: true
                                        });
                                        post_code.dispatchEvent(event);
                                    }
                                });
                            });
                        </script>




                    </div>
                </section>

                <!-- Submit button  desktop-->
                <div class="d-none d-lg-block d-md-block">
                    <div class="btn-style ">

                        <!--<button class="button-20 " role="button" type="submit" x-show="step === 1">Next</button>-->

                        <!--<button class="button-20" role="button" type="button" @click="step = 0" x-show="step === 1"-->
                        <!--    wire:click="goBack">Go-->
                        <!--    Back</button>-->
                            <button type="submit" class="button-27" role="button" x-show="step === 1" style="width: 150px; height: auto; margin-left: auto;">Next</button>
                            
                             <button class="button-27" role="button" type="button" @click="step = 0" x-show="step === 1"
                            wire:click="goBack" style="width: 150px; height: auto; margin-right: auto;">Go Back</button>
                    </div>
                </div>
                <!--------------------phone screen-------------->
                <div class=" d-lg-none d-md-none ">
                    <div class="btn-style ">

                        <button class="mbbutton-27"  role="button" type="submit"
                            x-show="step === 1">Next</button>

                        <button class="mbbutton-27"  role="button" type="button"
                            @click="step = 0" x-show="step === 1" wire:click="goBack">Go Back</button>
                    </div>
                </div>

        </div>
        </form>
    </div>

    <style>
        .submit-form {
            position: relative;
        }

        .button-20 {
            appearance: button;
            /*width: 11%;*/
            background-color: #dc3545;
            background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
            border: 1px solid #dc3545;
            border-radius: 1rem;
            box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px;
            box-sizing: border-box;
            color: #FFFFFF;
            cursor: pointer;
            display: inline-block;
            font-family: Inter, sans-serif;
            font-size: 1rem;
            font-weight: 500;
            line-height: 1.7;
            margin: 0;
            padding: 6px 50px;
            text-align: center;
            text-transform: none;
            transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            vertical-align: middle;
        }

        .button-20:focus:not(:focus-visible),
        .button-20:focus {
            outline: 0;
        }

        .button-20:hover {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .button-20:focus {
            background-color: #dc3545;
            border-color: #dc3545;
            box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
        }

        .button-20:active {
            background-color: #dc3545;
            background-image: none;
            border-color: #dc3545;
            box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
        }

        .button-20:active:focus {
            box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
        }

        .button-20:disabled {
            background-image: none;
            box-shadow: none;
            opacity: .65;
            pointer-events: none;
        }

        .calendar-container {
            border: 1px solid #dee2e6;
            border-radius: 10px;
            box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
            padding: 1rem;
            width: max-content;
        }

        .calendar-table {
            margin-bottom: 1rem;
        }

        .calendar-table th,
        .calendar-table td {
            text-align: center;
            vertical-align: middle;
            padding: 0.5rem;
        }

        .calendar-table td {
            cursor: pointer;
        }

        .calendar-table td.today {
            background-color: #f8f9fa;
        }

        .calendar-table td.selected {
            background-color: #dc3545;
            color: white;
        }

        .calendar-table td.disabled {
            color: #dee2e6;
            cursor: not-allowed;
        }

        .time-slots-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }

        .time-slot-btn {
            padding: 10px;
            text-align: center;
        }

        .time-slot-btn.active {
            background-color: #dc3545;
            color: white;
            border-color: #dc3545;
        }

        .selected-datetime {
            font-weight: bold;
        }

        .search {
            width: 70px;
        }

        .map-setting {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);
            padding: 17px 14px 14px;
        }

        .fpostcode-map {
            width: 40%;
            background-color: #fff;
            border-radius: 15px;
            /*box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);*/
            /*padding: 17px 14px 14px 14px;*/
        }

        .input-group {
            display: flex;
            gap: 20px;
        }

        .form-select-btn {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .distance_color {
            color: #dc3545;
        }

        .search_input {
            border-radius: 20px;
            border-top-right-radius: 20px !important;
            border-bottom-right-radius: 20px !important;
            /*box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;*/
            box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
        }

        .search-btn {
            border-radius: 20px;
            border-top-left-radius: 20px !important;
            border-bottom-left-radius: 20px !important;
            box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

        }

        .address-town-post-code {
            padding-bottom: 6px;
        }

        .boxes {
            width: 1000px;
            margin-top: 25px;
            height: 920px;
        
            /*scrollbar-color: rgb(233, 163, 163) transparent;*/
        
            /*scroll-padding: 50px;*/
        }

        .boxes div {
            border-radius: 20px;
        }

        .boxes div:nth-child(1) {
            margin-top: 0px !important;
        }

        .boxes::-webkit-scrollbar {
            width: 20px;
            height: 100px;
        }

        .btn-style {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-direction: row-reverse;
            margin-top: 50px;
        }

        .boxes::-webkit-scrollbar-track {
            background: #d1d1d1;
            border-radius: 40px;
        }

        .boxes::-webkit-scrollbar-thumb {
            background-color: #dc3545;
            border-radius: 40px;
            border: 3px solid transparent;
        }

        .find {
            color: rgb(240, 88, 88);
            font-size: 44px;
            font-weight: 900;
            text-align: center;
        }

        .search-btn {
            background-color: #da3847;
            color: white;
        }

        .s-card {
            height: 120px;
        }

        .left-side {
            width: 30%;
        }

        @media (max-width: 576px) {

            h2.find,
            p.text-center {
                margin-left: -20px;
                font-size: 15px;
            }

            .input-group {
                flex-wrap: wrap;
            }

            .input-group .form-control {
                flex: 1 1 100%;
                width: 100%;
                margin-right: 0;
                margin-bottom: 10px;
            }

            .input-group .search-btn {
                flex: 1 1 100%;
                width: 100%;
            }

            /* width: 133%;
        height: 850px;
        border: 0; */
        }

        .slot-container {
            justify-content: center;
        }

        /*///////////// Slot Responsive /////////////*/
        @media (max-width: 1400px) {
            .left-side {
                width: 35%;
            }
        }

        @media (max-width: 1400px) {
            .left-side {
                width: 40%;
            }
        }

        @media (max-width: 1024px) {
            .map-select {
                flex-direction: column;
            }

            .fpostcode-map {
                width: 100%;
            }

            .selection-area {
                width: 100%;
            }

            .boxes {
                width: 100%;
            }
        }

        @media (max-width: 900px) {
            .slot-container {
                flex-direction: column;
            }

            .select-slot-div {
                width: 100%;
            }

            .left-side {
                width: 100%;
            }

        }

        /*///////////// Slot Responsive /////////////*/
        /*-------------------------------------phone reponsive--- start-----------------*/
        @media (max-width: 320px) {

            .col-md-6 {
                flex: 0 0 auto;
                width: 300% !important;
            }
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            flatpickr("#appointment_date", {
                dateFormat: "Y-m-d",
                minDate: "today"
            });
        });
    </script>


</div>


<div style="    background-color: #ffffff;
    border-radius: 10px;
    width: 100%;
    margin: 0 auto;
    padding: 20px;">

    @elseif (Session::get('serviceType') == 'Buy')

    <h5 class="fw-bold mt-3 mb-3">Please post your device to this address</h5>


    <div class="p-10">
        <div class="form-group">
            <label for="post_code">Post Code:</label>
            <input type="text" wire:model="post_code" class="form-control" id="post_code" placeholder="Enter Post Code">
            <div id="resultContainer">
                <p>{{ $addressName }}</p>
            </div>
            @error('post_code')
            <span class="text-danger">{{ $message }}</span>
            @enderror
        </div>

        <button wire:click.prevent="changeApiData" class="mb-2">Search</button>
        @if ($responseData)


        {{-- <br> --}}
        <select wire:model="selectedOption" class="form-select" wire:change.prevent="updateAddressFields">
            <option value="" selected>Select an option</option>
            @foreach ($responseData['knownAddresses'] as $key => $address)
            <option key="{{ $key }}" value="{{ $address }}">{{ $address }}</option>
            @endforeach
        </select>


        <!-- Display the error message if set -->
        @if ($errorMessage)
        <div class="text-danger">{{ $errorMessage }}</div>
        @endif

        @endif


        @if ($responseData)
        <button class=" text-danger bg-white border-radius rounded-pill mt-3" wire:click.prevent="toggleInputFields">I
            can't find my address..</button>

        <!-- Conditional rendering for input fields -->
        @if ($showInputFields)
        <div class="mb-3 mt-3">
            <label for="address_line_1">Address Line 1*:</label>
            <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.address_line_1"
                placeholder="Address Line 1" name="postal.address_line_1" required="">
            @error('postal.address_line_1')
            <span class="text-xs text-danger">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3 mt-3">
            <label for="address_line_2">Address Line 2:</label>
            <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.address_line_2"
                placeholder="Address Line 2" name="postal.address_line_2">
        </div>

        <div class="mb-3 mt-3">
            <label for="city">Town/City*:</label>
            <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.city"
                placeholder="Town/City" name="postal.city" required="">
            @error('postal.city')
            <span class="text-xs text-danger">{{ $message }}</span>
            @enderror
        </div>




        <div class="mb-3 mt-3">
            <label for="postal_code">Post Code*:</label>
            <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.code"
                placeholder="Post Code" name="postal.code" required="">
            @error('postal.code')
            <span class="text-xs text-danger">{{ $message }}</span>
            @enderror
        </div>
        @endif
        @endif
    </div>
    <!-- Include this script in your Livewire component or wherever necessary -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Listen for the Livewire event indicating data update
            Livewire.on('addressFieldsUpdated', function () {
                // Find the relevant input fields by name attribute
                var address1 = document.querySelector("input[name='postal.address_line_1']");
                var address2 = document.querySelector("input[name='postal.address_line_2']");
                var city = document.querySelector("input[name='postal.city']");
                var post_code = document.querySelector("input[name='postal.code']");

                // Append five dots to each field if they exist
                if (address1) {
                    address1.value += '.....';
                    // Trigger input event to simulate user interaction
                    var event = new Event('input', {
                        bubbles: true
                    });
                    address1.dispatchEvent(event);
                }

                if (address2) {
                    address2.value += '.....';
                    var event = new Event('input', {
                        bubbles: true
                    });
                    address2.dispatchEvent(event);
                }

                if (city) {
                    city.value += '.....';
                    var event = new Event('input', {
                        bubbles: true
                    });
                    city.dispatchEvent(event);
                }

                if (post_code) {
                    post_code.value += '.....';
                    var event = new Event('input', {
                        bubbles: true
                    });
                    post_code.dispatchEvent(event);
                }
            });
        });
    </script>
    <button wire:click.prevent="submitForm" class="button-27" role="button"
        style="width: 150px; height: auto; margin-left: auto;">Next</button>




@elseif (Session::get('serviceType') == 'Sell')
    @if (!empty($branches))

<div class="justify-content-center">
    <h4> Post your device to this address </h4>
</div>


    <div class="row  ">
        @foreach ($branches as $branch)
        <div class="col-md-6">
            <div class="card mb-4 border p-3 h-100">
                <h3 class="fw-bold branch-name">{{ $branch->name }}</h3>
                <p class="address-town-post-code">{{ $branch->address_line_1 }}, 
                   {{ $branch->address_line_2 ?: '' }}, 
                   {{ $branch->town_city }}, 
                   {{ $branch->post_code }}, UK</p>
                <div class="form-select-btn">
                    @if (!empty($branch->email))
                    <div>Email: {{ $branch->email }}</div>
                    @endif
                    @if (!empty($branch->landline_number))
                    <div>Landline: {{ $branch->landline_number }}</div>
                    @endif
                    @if (!empty($branch->mobile_number))
                    <div>Mobile: {{ $branch->mobile_number }}</div>
                    @endif
                    
                </div>
                <img  src="https://ik.imagekit.io/qml3d7tgz/18_kudrf-_ta.jpeg">
            </div>
        </div>
    
        @endforeach
        
    <div class="col-md-6">
                 
                 
        <iframe
        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
        width="100%"  class="h-100" style="border: 0" allowfullscreen="" loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"></iframe>

<div  class="d-none d-lg-block d-md-block">
    <button wire:click.prevent="submitForm" class="button-27"  style="width: 150px; height: auto; margin-left: auto;float:right;">Next</button>
     </div>
     
     <div class="d-lg-none d-md-none">
     <button wire:click.prevent="submitForm" class="mbbutton-27" style="float:right;">Next</button>
     
     </div>

        
        
        </div>
        
    </div>

    @endif
     
      
@endif



    <style>
            .button-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 16px;
  font-weight: 600;
  line-height: normal;
  margin: 0;
  min-height: 60px;
  min-width: 0;
  outline: none;
  padding: 16px 24px;
  text-align: center;
>  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  width: 100%;
  will-change: transform;
}

.button-27:disabled {
  pointer-events: none;
}

.button-27:hover {
  box-shadow: #DC3545 0 8px 15px;
  transform: translateY(-2px);
}

.button-27:active {
  box-shadow: none;
  transform: translateY(0);
}


.mbbutton-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 12px;
  font-weight: 400;
  line-height: normal;
  margin: 0;
  min-height: 40px;
  min-width: 100px;
  outline: none;
  
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  will-change: transform;
}

.mbbutton-27:disabled {
  pointer-events: none;
}

.mbbutton-27:hover {
  box-shadow: #DC3545 0 8px 15px;
  transform: translateY(-2px);
}

.mbbutton-27:active {
  box-shadow: none;
  transform: translateY(0);
}



    </style>










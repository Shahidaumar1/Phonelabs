<div>
    @php

    $form_name = 'Fix at my address';
    $paywithcardtext = 'pay in store';
    @endphp

    <div>
        @php
        $storedInputValue = Session::get('storedInputValue');
        @endphp
        @if ($storedInputValue)
        <p>Delievry Charges For Postal Repair: ${{ $storedInputValue }}</p>
        @endif

        @php
        $storedCollectionRepairPrice = Session::get('collectionRepairPrice');
        @endphp
        @if ($storedCollectionRepairPrice)
        <p style="font-size:1vw">Delivery Charges For Collection Repair: £{{ $storedCollectionRepairPrice }}</p>
        @endif

        <div>
            <div class="rounded p-4">
                <div class="z ">
                    <div class="col-md-12">


                        @if (session('form_type') == 'postal_form')
                        @php
                        $form_name = 'Post Your Device';
                        $paywithcardtext = 'Pay At our Store '

                        @endphp
                        <!--<div class="form-check">-->
                        <!--    <input class="form-check-input" type="radio" checked disabled />-->
                        <!--    <label class="form-check-label">-->
                        <!--        Surcharge for UK return delivery : £ 15-->
                        <!--    </label>-->

                        <!--</div>-->
                        @endif

                        @if (session('form_type') == 'collection_form')
                        @php
                        $form_name = 'We Collect Your Device';
                        $paywithcardtext = 'I’ll Pay after Repair'

                        @endphp
                        @endif

                        @if (session('form_type') == 'clinic_form')
                        @php
                        $form_name = 'store Repair';
                        $paywithcardtext = 'I’ll Pay after Repair'
                        @endphp

                        @endif


                        @if (session('form_type') == 'fix_form')
                        @php
                        $form_name = 'Fix at Your Location';
                        $paywithcardtext = 'I’ll Pay after Repair'

                        @endphp
                        @endif

                        <x-alert />

                        <h2 class="text-center" style="color: red;">How would you like to Pay?</h2>

                        <div class="row   d-md-flex d-lg-flex">


                            <div class="col-lg-4 col-12 mt-5 ">

                                <div style="position:relative;top:10px; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);">

                                    <table class="table table-striped border mt-4;">
                                        <thead>

                                            <tr>
                                                <th colspan="2" class="text-center text-danger fw-bolder fs-3">
                                                    Repair Summary</th> 
                                            </tr>
                                            <tr>

                                                <td>Model</td>
                                                <td class="text-end">
                                                    {{ $data['modal']['name'] }}
                                                </td>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="justify-content-between">

                                                <td>Type</td>
                                                <td class="text-end">{{ $form_name }}</td>

                                            </tr>
                                            @if($formType === 'postal_form')

                                            <tr class="justify-content-between">



                                                <td>{{ $data['repair_type']['name'] }}</td>

                                                <td class="text-end">
                                                    £ {{ ($price - $condition1Price) ?? '' }}.00
                                                </td>
                                            <tr>
                                                <td>Service Charges</td>
                                                <td class="text-end">{{ $condition1Price }}</td>
                                            </tr>

                                            @endif

                                            @if($formType ==='collection_form')
                                            <tr class="justify-content-between">

                                                <td>{{ $data['repair_type']['name'] }}</td>

                                                <td class="text-end">
                                                    £ {{ ($price - $condition2Price) ?? '' }}.00
                                                </td>


                                            <tr class="justify-content-between">




                                                <td>Service Charges</td>
                                                <td class="text-end">{{ $condition2Price }}</td>

                                            </tr>
                                            @endif




                                            @if($formType ==='fix_form')



                                            <tr class="justify-content-between">



                                                <td>{{ $data['repair_type']['name'] }}</td>

                                                <td class="text-end">
                                                    £ {{ ($price - $condition3Price) ?? '' }}.00
                                                </td>

                                            <tr class="justify-content-between">

                                                <td>Service Charges</td>
                                                <td class="text-end">{{ $condition3Price }}</td>

                                            </tr>
                                            @endif



                                            <tr>

                                                <td style="white-space: nowrap;">Total Price</td>


                                                <td class="text-end">

                                                    <div>
                                                        {{-- <h3>Service charges </h3> --}}
                                                        £ {{ $price ?? '' }}.00

                                                </td>

                                            </tr>

                                            <tr>

                                                <td>Repair time</td>
                                                <td class="text-end">1 Hour </td>

                                            </tr>
                                            <tr>

                                                <td>Warranty</td>
                                                <td class="text-end"> 12 months </td>

                                            </tr>

                                        </tbody>
                                    </table>
                                </div>

                            </div>
                            <div class="col-lg-1"></div>
                            <style>
/* Ensures that radio buttons are visible and not hidden by default */
.form-check-input {
    display: inline-block;
    margin-right: 10px;
    cursor: pointer;
    /* Ensure radio buttons are visible */
    opacity: 1;
}

.form-check-label {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    cursor: pointer;
}

.tab__label {
    cursor: pointer;
    /* Add padding for better interaction */
    padding: 10px;
}

.tab__label:hover {
    background-color: #f0f0f0; /* Highlight on hover */
}

/* Style the radio button container */
.tab__content {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.35s ease-out;
}

.tab input:checked~.tab__content {
    max-height: 200px; /* Adjust as needed */
}

/* Add basic styling for labels and content */
.tab__label {
    border: 1px solid #ddd;
    border-radius: 5px;
    background: #fff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 10px;
    padding: 10px;
}

.tab__content p {
    margin: 0;
    padding: 10px;
}

/* Style for the active tab */
.tab input:checked+.tab__label {
    background-color: #E35F6B; /* Highlight the active tab */
}

/* Responsive design adjustments */
@media (max-width: 480px) {
    .myklarna {
        margin-bottom: 20px;
    }
}

</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Function to handle tab switch
    function handleTabSwitch() {
        const tabs = document.querySelectorAll('.tab input[type="radio"]');
        tabs.forEach(tab => {
            tab.addEventListener('change', function () {
                // Hide all tab contents
                document.querySelectorAll('.tab__content').forEach(content => {
                    content.style.maxHeight = '0';
                });

                // Show the selected tab content
                if (this.checked) {
                    const content = this.nextElementSibling.nextElementSibling;
                    content.style.maxHeight = content.scrollHeight + 'px';
                }
            });
        });
    }

    handleTabSwitch();
});
</script>
<br>
                            <div class="col-lg-6 col-12 " style="border:1px red;background-color:#EE8787;" >
                                
                                <p class="text-center fw-bolder fs-5 mt-3">Select your payment option</p>

                                <div class="row ">
                                    <div class="container-fluid ">
                                        @if ($form_type == 'clinic_form')
                                       <section class="accordion">
    <div class="tab">
        <input 
            class="form-check-input w-50" 
            type="radio" 
            name="accordion-1" 
            id="cb4" 
            wire:click="changePm('drop_at')"
        >
        <label for="cb4" class="tab__label">
            <div 
                class="flex space-between mysetting col-12 shadow-sm border rounded bg-white"
                style="margin-left:04px;display:flex;align-items:center;justify-content:space-between;"
            >
                <div class="text-start">
                    <div style="font-weight:800;">
                        &nbsp;&nbsp; {{$paywithcardtext}}
                    </div>
                </div>
                <div class="text-end">
                    <h4 class="text-danger fw-bold">£{{ $price }}</h4>
                </div>
            </div>
        </label>

        <div class="tab__content col-12 d-flex flex-column justify-content-center text-black">
            <!-- radio -->
            <input 
                class="form-check-input" 
                type="radio" 
                wire:model="isChecked" 
                id="radio"
            >

            <div class="d-flex justify-content-center">
                <p class="mt-1 fw-bolder soft">
                    Pay at store when you visit our location below
                </p>
            </div>

            <div style="margin-top:-5%; color:black;">
                <p class="soft">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                        <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6" />
                    </svg> 
                    {{ $name }}, {{ $address_line_1 }}, {{ $address_line_2 }}{{ $address_line_2 != '' ? ', ' : '' }} {{ $town_city }}, {{ $post_code }}
                </p>
                <div class="details-con">
                    <p style="margin-top:-4%;color:black;" class="soft">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                            <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                        </svg> 
                        &nbsp; &nbsp;{{ $email }}
                    </p>
                </div>
            </div>

            <div style="margin-top:-4%;" class="d-flex soft">
                <p class="soft d-flex" style="color:black;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-forward" viewBox="0 0 16 16">
                        <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708" />
                    </svg>
                    &nbsp; &nbsp; {{ $landline_number }}
                </p>

                <!-- Button -->
                <div class="d-flex justify-content-end" style="margin-left:20%;">
                    @if ($pm == 'drop_at')
                        <button 
                            class="btn bg-white  mb-4 text-danger" 
                            type="button" 
                            wire:click="BookRepair"
                         
                        >
                            Submit
                        </button>
                    @endif
                </div>
            </div>
        </div>
    </div>
</section>

                                        @endif


                                        <section class="accordion">
                                            <div class="tab  ">
                                                <input type="radio" class="form-check-input"
                                                    wire:click="changePm('stripe')" name="accordion-1" id="cb3" check>

                                                <label for="cb3" class="tab__label">
                                                    <div class="flex space-between  mysetting    col-12 shadow-sm  border   rounded bg-white "
                                                        style="margin-top:5px;margin-left:04px;display:flex;align-items:center;justify-content:space-between;">

                                                        <div class=" text-start">
                                                            <div style="font-weight:800;" >
                                                                &nbsp;&nbsp; Pay With
                                                                Card</div>
                                                            <img class="img-fluid " style="width:30%; "
                                                                src="https://ik.imagekit.io/4csyk445b/2560px-Stripe_Logo__revised_2016%205.png?updatedAt=1711551636602"
                                                                alt="">
                                                        </div>

                                                        <div class=" text-end ">
                                                            <h4 class="text-danger fw-bold ">£{{ $price }}</h4>
                                                        </div>

                                                    </div>
                                                </label>
                                                <div
                                                    class="tab__content col-12 d-flex justify-content-center align-items-center">

                                                    @if ($pm == 'stripe')
                                                    <div class="mt-5">
                                                        <livewire:payment-methods.stripe :price="$price" color="success"
                                                            service="Repair" />
                                                    </div>
                                                    @endif

                                                </div>
                                            </div>

                                        </section>

                                        <section class="accordion  ">
                                            <div class="tab ">
                                                <input class="form-check-input" type="radio" name="payment" id="payment1">
                                                <input class="form-check-input w-50" type="radio"
                                                    wire:click="changePm('paypal')" name="accordion-1" id="cb1" checked>

                                                <label for="cb1" class="tab__label">
                                                    <div class="flex space-between  mysetting    col-12 shadow-sm  border   rounded bg-white "
                                                        style="margin-top:5px;margin-left:04px;display:flex;align-items:center;justify-content:space-between;">

                                                        <div class=" text-start ">

                                                            <img class="img-fluid "
                                                                src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png"
                                                                alt="" style="width: 50px; height: auto;">
                                                        </div>

                                                        <div class=" text-end ">
                                                            <h4 class="text-danger fw-bold">£{{ $price }}</h4>
                                                        </div>

                                                    </div>

                                                </label>
                                                <div
                                                    class="tab__content col-12 d-flex justify-content-center align-items-center">
                                                    @if ($pm == 'paypal')

                                                    <div class="">

                                                        <livewire:payment-methods.paypal :price="$price" color="success"
                                                            service="Repair" />
                                                    </div>
                                                    @endif
                                                </div>


                                            </div>

                                        </section>

                                        <section class="accordion">
                                            <div class="tab ">
                                                <input class="form-check-input w-50" wire:click="changePm('klarna')" 
                                                   type="radio" name="accordion-1" id="cb2">

                                                <label for="cb2" class="tab__label">
                                                    <div class="flex space-between  mysetting    col-12 shadow-sm  border   rounded bg-white "
                                                        style="margin-top:5px;margin-left:04px;display:flex;align-items:center;justify-content:space-between;">

                                                        <div style="">
                                                            <h4>
                                                            &nbsp;&nbsp;
                                                            <img class="img-fluid myklarna"
                                                                src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Klarna_Payment_Badge.svg/2560px-Klarna_Payment_Badge.svg.png"
                                                                alt="" style="width: 50px; height:auto;object-fit:cover;">
                                                            </h4>
                                                        </div>

                                                        <div class="text-start border ">
                                                            

                                                                <small style="font-size:10px !important;">Make 3 payments
                                                                    of <b class="fw-bolder">Klarana</b> £{{
                                                                    number_format($price / 3, 2) }} in
                                                                    installment.Terms and conditions apply.  </small>
                                                        
                                                        </div>


                                                        <div class=" text-end  ">
                                                            <h4 class="text-danger fw-bold">£{{ $price }}</h4>
                                                        </div>

                                                    </div>
                                                </label>
                                                <div
                                                    class="tab__content col-12 d-flex justify-content-center align-items-center">
                                                    @if ($pm == 'klarna')
                                                    <livewire:payment-methods.klarna :price="$price" color="success"
                                                        service="Repair" />
                                                    @endif

                                                </div>
                                            </div>

                                        </section>
                                        

                                    </div>

                                    <style>
                                    
                                        :root {
                                            --primary: #227093;
                                            --secondary: #ff5252;
                                            --background: #eee;
                                            --highlight: #ffda79;
                                            /* Theme color */
                                            --theme: var(--primary);
                                        }

                                      @media (max-width: 480px) {
                                              
                                              .myklarna{
                                                  margin-bottom:20px;
                                              }
                                           
                                                  }



                                        /* Core styles/functionality */
                                        .tab input {
                                            position: absolute;
                                            opacity: 0;
                                            z-index: -1;
                                        }

                                        .tab__content {
                                            max-height: 0;
                                            overflow: hidden;
                                            transition: all 0.35s;
                                        }

                                        .tab input:checked~.tab__content {
                                            max-height: 10rem;
                                        }

                                        /* Visual styles */
                                        .accordion {
                                            color: var(--theme);
                                            /* border: 2px solid; */
                                            border-radius: 0.5rem;
                                            overflow: hidden;
                                        }

                                        .tab__label,
                                        .tab__close {
                                            display: flex;
                                            color: black;
                                            /* background: var(--theme); */
                                            cursor: pointer;
                                        }

                                        .tab__label {
                                            justify-content: space-between;
                                            padding: 1rem;
                                        }

                                        .tab__label::after {
                                            /* content: "\276F"; */
                                            width: 1em;
                                            height: 1em;
                                            text-align: center;
                                            transform: rotate(90deg);
                                            transition: all 0.35s;
                                        }

                                        .tab input:checked+.tab__label::after {
                                            transform: rotate(270deg);
                                        }

                                        .tab__content p {
                                            margin: 0;
                                            padding: 1rem;
                                        }

                                        .tab__close {
                                            justify-content: flex-end;
                                            padding: 0.5rem 1rem;
                                            font-size: 0.75rem;
                                        }

                                        .accordion--radio {
                                            --theme: var(--secondary);
                                        }

                                        /* Arrow animation */
                                        .tab input:not(:checked)+.tab__label:hover::after {
                                            animation: bounce .5s infinite;
                                        }

                                        @keyframes bounce {
                                            25% {
                                                transform: rotate(90deg) translate(.25rem);
                                            }

                                            75% {
                                                transform: rotate(90deg) translate(-.25rem);
                                            }
                                        }
                                    </style>




                                    <div class=" gap-2">
                                        @if ($form_type == 'clinic_form')
                                        @endif

                                    </div>





                                </div>

                            </div>

                            
                        </div>


                        @if ($pm == 'stripe')
                        @endif
                        @if ($pm == 'paypal')
                        @endif

                        @if ($pm == 'klarna')
                        @endif

                        @if ($pm == 'drop_at' && $form_type == 'clinic_form')

                        <div class="d-flex justify-content-between align-items-center">
                            @if ($success)
                            <div class="alert alert-success" role="alert">
                                <h4 class="alert-heading">Congratulations! 🎉 Your order has been successfully
                                    placed.
                                </h4>
                                <p>Sit tight while we process your request. Check your email for more
                                    instructions.
                                </p>
                                <hr>
                                <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
                            </div>
                            @else
                            @endif
                        </div>

                        @endif
                    </div>
                </div>

                <!----------------------------------------mobile screen------>
                <div class="row d-md-none d-lg-none d-none " style="width:126%; margin-left:-13%">
                    <p class="text-center fw-bolder fs-5">Select your payment option</p>

                    <div class="col-lg-6 col-12 ">

                        <div class="row">
                            <div>
                                <div class=""
                                    style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 10px ;">
                                    <div>

                                        @if ($form_type == 'clinic_form')
                                        <section class="accordion">
                                            <div class="tab mt-2"
                                                style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 10px">
                                                <input class="form-check-input w-75" wire:click="changePm('drop_at')"
                                                    type="radio" name="accordion-1" id="cb5" check>

                                                <label for="cb5" class="tab__label">
                                                    <div class="row  p-2 col-12   rounded">

                                                        <div class="col-6 text-start">
    <div class="form-check d-flex align-items-center">
        <input class="form-check-input" type="radio" name="payment" id="payWithCard" value="card">
        <label class="form-check-label" for="payWithCard">
            <b class="fw-5" style="font-size: large;">{{$paywithcardtext}}</b>
        </label>
    </div>
</div>
<style>
    .form-check-input {
    display: none;
}

.form-check-input + .form-check-label::before {
    content: '';
    display: inline-block;
    width: 20px;
    height: 20px;
    margin-right: 10px;
    border-radius: 50%;
    border: 2px solid #007bff; /* Default border color */
    background-color: #fff; /* Default background color */
    vertical-align: middle;
    transition: background-color 0.3s, border-color 0.3s;
}

.form-check-input:checked + .form-check-label::before {
    background-color: #007bff; /* Selected background color */
    border-color: #007bff; /* Selected border color */
}

.form-check-label:hover::before {
    background-color: #e9ecef; /* Hover background color */
}

</style>

                                                        <div class="col-6 text-end mt-2">
                                                            <h3 class="text-danger fw-bold">£{{ $price }}</h3>
                                                        </div>

                                                    </div>
                                                </label>

                                                <div class="tab__content col-12 d-flex text-black flex-column justify-content-center "
                                                    style="border-top: 2px solid rgba(128, 128, 128, 0.367);">
                                                    <!-- radio -->
                                                    <input class="form-check-input mb-3" type="radio"
                                                        wire:model="isChecked" id="radio">

                                                    <div class="d-flex justify-content-center">
                                                        <p style="font-size:10px;" class="mt-1 fw-bolder">Pay at
                                                            store when you visit our location below</p>
                                                    </div>

                                                    <div style="margin-top:-10%; ">
                                                        <p style="font-size:10px;"> <svg
                                                                xmlns="http://www.w3.org/2000/svg" width="16"
                                                                height="16" fill="currentColor"
                                                                class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                                                                <path
                                                                    d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6" />
                                                            </svg> {{ $name }}, {{ $address_line_1 }},
                                                            {{ $address_line_2 }}{{ $address_line_2 != '' ? ', ' : '' }}
                                                            {{ $town_city }}, {{ $post_code }}
                                                        </p>
                                                        <div class="details-con">
                                                            <p style="margin-top:-10%;font-size:10px;"><svg
                                                                    xmlns="http://www.w3.org/2000/svg" width="16"
                                                                    fill="currentColor" class="bi bi-envelope"
                                                                    viewBox="0 0 16 16">
                                                                    <path
                                                                        d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                                                                </svg> {{ $email }}</p>
                                                        </div>
                                                    </div>
                                                    <div style="margin-top:-8%;font-size:10px;" class="d-flex ">
                                                        <p style="float: left;font-size:10px;">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16"
                                                                height="16" fill="currentColor"
                                                                class="bi bi-telephone-forward" viewBox="0 0 16 16">
                                                                <path
                                                                    d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708" />
                                                            </svg>
                                                            {{ $landline_number }}
                                                        </p>
                                                        <!-- Button -->
                                                        <div class="d-flex justify-content-end" style="margin-left:23%">
                                                            @if ($pm == 'drop_at')
                                                            <button class="btn btn-danger mb-4" type="button"
                                                                wire:click="BookRepair">
                                                                Submit
                                                            </button>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                        </section>
                                        @endif




                                        <section class="accordion  " style="margin-left:5%; margin-right:5%">
                                            <div class="tab mt-2"
                                                style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 10px">
                                                <input class="form-check-input w-75" type="radio"
                                                    wire:click="changePm('paypal')" name="accordion-1" id="cb7" checked>

                                                <label for="cb7" class="tab__label">
                                                    <div class="row  p-2 col-12  rounded">

                                                        <div class="col-6 text-start ">
                                                            <img class="img-fluid w-25"
                                                                src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png"
                                                                alt="">
                                                        </div>

                                                        <div class="col-6 text-end mt-2">
                                                            <h3 class="text-danger fw-bold">£{{ $price }}</h3>
                                                        </div>

                                                    </div>

                                                </label>
                                                <div class="tab__content col-12 d-flex justify-content-center align-items-center"
                                                    style="border-top: 2px solid rgba(128, 128, 128, 0.367);">
                                                    @if ($pm == 'paypal')
                                                    <div class=" mt-2">
                                                        <livewire:payment-methods.paypal :price="$price" color="success"
                                                            service="Repair" />
                                                    </div>
                                                    @endif
                                                </div>


                                            </div>

                                        </section>

                                    </div>

                                    <style>
                                        :root {
                                            --primary: #227093;
                                            --secondary: #ff5252;
                                            --background: #eee;
                                            --highlight: #ffda79;
                                            /* Theme color */
                                            --theme: var(--primary);
                                        }



                                        /* Core styles/functionality */
                                        .tab input {
                                            position: absolute;
                                            opacity: 0;
                                            z-index: -1;
                                        }

                                        .tab__content {
                                            max-height: 0;
                                            overflow: hidden;
                                            transition: all 0.35s;
                                        }

                                        .tab input:checked~.tab__content {
                                            max-height: 10rem;
                                        }

                                        /* Visual styles */
                                        .accordion {
                                            color: var(--theme);
                                            /* border: 2px solid; */
                                            border-radius: 0.5rem;
                                            overflow: hidden;
                                        }

                                        .tab__label,
                                        .tab__close {
                                            display: flex;
                                            color: black;
                                            /* background: var(--theme); */
                                            cursor: pointer;
                                        }

                                        .tab__label {
                                            justify-content: space-between;
                                            padding: 1rem;
                                        }

                                        .tab__label::after {
                                            /* content: "\276F"; */
                                            width: 1em;
                                            height: 1em;
                                            text-align: center;
                                            transform: rotate(90deg);
                                            transition: all 0.35s;
                                        }

                                        .tab input:checked+.tab__label::after {
                                            transform: rotate(270deg);
                                        }

                                        .tab__content p {
                                            margin: 0;
                                            padding: 1rem;
                                        }

                                        .tab__close {
                                            justify-content: flex-end;
                                            padding: 0.5rem 1rem;
                                            font-size: 0.75rem;
                                        }

                                        .accordion--radio {
                                            --theme: var(--secondary);
                                        }

                                        /* Arrow animation */
                                        .tab input:not(:checked)+.tab__label:hover::after {
                                            animation: bounce .5s infinite;
                                        }

                                        @keyframes bounce {
                                            25% {
                                                transform: rotate(90deg) translate(.25rem);
                                            }

                                            75% {
                                                transform: rotate(90deg) translate(-.25rem);
                                            }
                                        }
                                    </style>

                                    <div class=" gap-2">
                                        @if ($form_type == 'clinic_form')
                                        @endif

                                    </div>
                                </div>

                            </div>


                        </div>

                    </div>
                    <div class="col-lg-6">

                        <div style="position:relative;top:10px;" class="container">

                            <table class="table table-striped border mt-2">
                                <thead>
                                    <tr>
                                        <th colspan="2" class="text-center text-danger fw-bolder fs-3">
                                            Repair
                                            Summary</th> <!-- Center-aligned heading -->
                                    </tr>
                                    <tr>

                                        <td>Model</td>
                                        <td class="text-end">
                                            {{ $data['modal']['name'] }}
                                        </td>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="justify-content-between">

                                        <td>Type</td>
                                        <td class="text-end">{{ $form_name }}</td>

                                    </tr>
                                    <tr>
                                        <td style="white-space: nowrap;">Total Price</td>
                                        <td class="text-end">

                                            <div>
                                                {{-- <h3>Service charges </h3> --}}
                                                £ {{ $price ?? '' }}.00

                                        </td>

                                    </tr>

                                    <tr>

                                        <td>Repair time</td>
                                        <td class="text-end">1 Hour </td>

                                    </tr>


                                    <tr>

                                        <td>Warranty</td>
                                        <td class="text-end"> 12 months </td>

                                    </tr>

                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>


                @if ($pm == 'stripe')
                @endif
                @if ($pm == 'paypal')
                @endif

                @if ($pm == 'klarna')
                @endif

                @if ($pm == 'drop_at' && $form_type == 'clinic_form')

                <div class="d-flex justify-content-between align-items-center">
                    @if ($success)
                    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="successModalLabel">Congratulations! ðŸŽ‰</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <h4>Your order has been successfully placed.</h4>
                                    <p>Sit tight while we process your request. Check your email for more
                                        instructions.</p>
                                    <hr>
                                    <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <script>
                        $(document).ready(function () {
                            // Open the modal when the page loads if $success is true
                            var successModal = new bootstrap.Modal(document.getElementById('successModal'));
                            successModal.show();
                        });
                    </script>
                    @else
                    @endif
                </div>
                @endif
            </div>

        </div>

    </div>

    <!-------------------------------mobil phone------------------>
    <style>
        @media (max-width: 576px) {
            .ali {
                font-size: 13px;
            }

            .usman {
                width: 140%;
                margin-left: -20% !important;
            }


            .soft {
                font-size: 10px;
            }

        }

        .mysetting {
            height: 70px;
            width: 100%;
        }
    </style>
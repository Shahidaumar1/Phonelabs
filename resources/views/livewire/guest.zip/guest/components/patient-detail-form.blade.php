   
<div class="container p-5 rounded" style="border: 1px solid grey;">
     <!--button css-->
    <style>
        .mybutton-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
 
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 16px;
  font-weight: 600;
  line-height: normal;
  min-height: 60px;
  min-width: 0;
  outline: none;
  padding: 16px 24px;
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  width: 100%;
  will-change: transform;
}

.mybutton-27:disabled {
  pointer-events: none;
}

.mybutton-27:hover {
  box-shadow: #DC3545 0 8px 15px;
  transform: translateY(-2px);
}

.mybutton-27:active {
  box-shadow: none;
  transform: translateY(0);
}


.mbbutton-27 {
    
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 12px;
  font-weight: 400;
  line-height: normal;
  margin: 0;
  min-height: 40px;
  min-width: 100px;
  outline: none;
  
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  will-change: transform;
}

.mbbutton-27:disabled {
  pointer-events: none;
}

.mbbutton-27:hover {
  box-shadow: #DC3545 0 8px 15px;
  transform: translateY(-2px);
}

.mbbutton-27:active {
  box-shadow: none;
  transform: translateY(0);
}



    </style>
    <div class=" container pt-4 pb-4">
        <h2 class="text-danger text-center mb-2">Customer Details</h2>
        <h4 class="text-danger text-center mb-4">Tell us about yourself</h4>
        <form wire:submit.prevent="submitForm">
            <div class="row ">
                <div class="col-md-6">
                    <label for="first_name" class="form-label fw-bold">Full Name</label>
                    <input type="text" class="form-control" style="border:1px solid #B0B0B0;" id="first_name" placeholder="Enter your first name"
                        wire:model.lazy="patient.name">
                    @error('patient.name')
                    <div class="text-danger" style="font-size: 12px;">{{ $message }}</div>
                    @enderror

                    <label for="email" class="form-label fw-bold mt-3">Email address</label>
                    <input type="email" class="form-control" style="border:1px solid #B0B0B0;" id="email" placeholder="Enter your email address"
                        wire:model.lazy="patient.email">
                    @error('patient.email')
                    <div class="text-danger" style="font-size: 12px;">{{ $message }}</div>
                    @enderror

                    <label for="phone" class="form-label fw-bold mt-3">Phone Number</label>
                    <input type="tel" class="form-control" style="border:1px solid #B0B0B0;" id="phone" placeholder="Enter Phone Number"
                        wire:model.lazy="patient.phone">
                    @error('patient.phone')
                    <div class="text-danger" style="font-size: 12px;">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-6">
                    <label for="repair_note" class="form-label fw-bold">Note</label>
                    <textarea id="repair_note" name="repair_note" rows="4" cols="40" class="form-control" style="border:1px solid #B0B0B0;"
                        wire:model.lazy="patient.RepairNote" placeholder="Write text here"></textarea>
                    @error('patient.RepairNote')
                    <div class="text-danger" style="font-size: 12px;">{{ $message }}</div>
                    @enderror
                </div>
            </div>


            <!--<button type="submit" class="btn btn-danger customer-btn"-->
            <!--    style="position: absolute; margin-left:800px;  bottom: 0; right: 0; padding: 8px 50px; border-radius: 15px;">-->
            <!--    Next-->
            <!--</button>-->


<style>
    .responsive-button {
    width: 150px;
    height: auto;
    position: absolute;
    right: 20px;
    top: 20px;
}

@media (min-width: 576px) {
    .responsive-button {
        right: 50px;
        top: 600px;
    }
}

@media (min-width: 768px) {
    .responsive-button {
        right: 70px;
        top: 650px;
    }
}

@media (min-width: 992px) {
    .responsive-button {
        right: 80px;
        top: 700px;
    }
}

@media (min-width: 1200px) {
    .responsive-button {
        right: 94px;
        top: 735px;
    }
}

</style>
    <div class=" d-none d-lg-block d-md-block ">
    <button type="submit" class=" mybutton-27 responsive-button " role="button" style="width: 150px;
    width: 150px;
    height: auto;
    float: right;
    position: absolute;
    right: 94px;
    top: 480px;
   ">Next</button>
</div>
    <div class=" d-lg-none d-md-none mt-5">

    <button type="submit" class=" mbbutton-27  " role="button" style="float:right;" >Next</button>
</div>
<br>

<!--for phone screen-->




        </form>
        
    </div>
</div>


                <!-- <div class="col-md-6">
                    <label for="last_name" class="form-label fw-bold">Last Name</label>
                    <input type="text" class="form-control" id="last_name" placeholder="Enter your last name"
                        wire:model.lazy="patient.last_name">
                    @error('patient.last_name')
                    <div class="text-danger" style="font-size: 12px;">{{ $message }}</div>
                    @enderror
                </div> -->
                                <!-- <div class="col-md-6">
                    <label for="confirm_email" class="form-label fw-bold">Confirm Email</label>
                    <input type="email" class="form-control" id="confirm_email" placeholder="Confirm your email address"
                        wire:model.lazy="patient.confirm_email">
                    @error('patient.confirm_email')
                    <div class="text-danger" style="font-size: 12px;">{{ $message }}</div>
                    @enderror
                </div> -->
                
                                <!--<div class="col-md-3 mt-4">-->
                <!--  <label class="form-label fw-bold d-block">Are you an exsiting customer?</label>-->
                <!--  <div class="form-check form-check-inline">-->
                <!--    <input class="form-check-input" type="radio" id="existing_customer_yes" value="1"-->
                <!--      wire:model.lazy="patient.existing_patient">-->
                <!--    <label class="form-check-label" for="existing_customer_yes">Yes</label>-->
                <!--  </div>-->
                <!--  <div class="form-check form-check-inline ml-5">-->
                <!--    <input class="form-check-input" type="radio" id="existing_customer_no" value="0"-->
                <!--      wire:model.lazy="patient.existing_patient">-->
                <!--    <label class="form-check-label" for="existing_customer_no">No</label>-->
                <!--  </div>-->
                <!--  @error('patient.existing_patient')-->
                <!--  <div class="text-danger" style="font-size: 12px;">{{ $message }}</div>-->
                <!--@enderror-->
                <!--</div>-->

                <!--<div class="col-md-3 mt-4">-->
                <!--  <label class="form-label fw-bold d-block">Are you a business?</label>-->
                <!--  <div class="form-check form-check-inline">-->
                <!--    <input class="form-check-input" type="radio" id="existing_business_yes" value="1"-->
                <!--      wire:model.lazy="patient.business_repair">-->
                <!--    <label class="form-check-label" for="existing_business_yes">Yes</label>-->
                <!--  </div>-->
                <!--  <div class="form-check form-check-inline">-->
                <!--    <input class="form-check-input" type="radio" id="existing_business_no" value="0"-->
                <!--      wire:model.lazy="patient.business_repair">-->
                <!--    <label class="form-check-label" for="existing_business_no">No</label>-->
                <!--  </div>-->
                <!--  @error('patient.business_repair')-->
                <!--  <div class="text-danger" style="font-size: 12px;">{{ $message }}</div>-->
                <!--@enderror-->
                <!--</div>-->

                <!--<div class="col-md-6">-->
                <!--  @if ($patient['business_repair'] == '1')-->
                <!--  <label for="company_name" class="form-label fw-bold">Company Name *</label>-->
                <!--  <input type="text" class="form-control" id="company_name" placeholder="Enter company name"-->
                <!--  wire:model.lazy="patient.company_name">-->
                <!--@endif-->
                <!--</div>-->
                    <!-- <script>
      document.addEventListener('livewire:load', function () {
        Livewire.on('formValidated', () => {
          // Handle form validation success here
          console.log('Form validated successfully');
        });
      });
      
  
    </script> -->
                
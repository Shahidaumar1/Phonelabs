
<div>
    <script>
        window.onbeforeunload = function () {
  window.scrollTo(0, 0);
                    }
    </script>
    <!--button css-->
    <style>
        .button-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 16px;
  font-weight: 600;
  line-height: normal;
  margin: 0;
  min-height: 60px;
  min-width: 0;
  outline: none;
  padding: 16px 24px;
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  width: 100%;
  will-change: transform;
}

.button-27:disabled {
  pointer-events: none;
}

.button-27:hover {
  box-shadow: #DC3545 0 8px 15px;
  transform: translateY(-2px);
}

.button-27:active {
  box-shadow: none;
  transform: translateY(0);
}


.mbbutton-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 12px;
  font-weight: 400;
  line-height: normal;
  margin: 0;
  min-height: 40px;
  min-width: 100px;
  outline: none;
  
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  will-change: transform;
}

.mbbutton-27:disabled {
  pointer-events: none;
}

.mbbutton-27:hover {
  box-shadow: #DC3545 0 8px 15px;
  transform: translateY(-2px);
}
.loading-text {
    font-size: 18px;
    font-weight: bold;
    color: #007bff; /* Bootstrap primary color */
    text-align: center;
    margin-top: 20px;
}
.mbbutton-27:active {
  box-shadow: none;
  transform: translateY(0);
}



    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>


    <div class=" " style="background-color:white;!important;">
    <div wire:loading wire:target="getLatLong" class="loading-text">
        Loading, please wait...
    </div>
        <!-- Display branch selection and appointment form -->
        <form x-data="{ step: 0 }" class="p-4 submit-form" wire:submit.prevent="submitForm">
            <!-- Step 1: Select nearest branch -->
            <section id="section-1" x-show="step === 0" x-cloak class="row map-select">
                <legend class="mb-3">
                    <h2 class="find">Select your Store</h2>
                    
                </legend>
                <!--  on phone screen-->
                <!--<div class="col-md-6 mt-4   d-lg-none d-md-none" style=" width:840% !important;">-->
                    

                <!--    <div style="margin-left:-20%; width="120%!important" height="530px"; border: 0;">-->
                        <!-- Display map or iframe -->
                <!--        @if (!empty($mapLink))-->
                <!--        {!! $mapLink !!}-->
                <!--        @else-->
                <!--        <iframe-->
                <!--            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"-->
                <!--            width="120%" height="530px" style="border: 0" allowfullscreen="" loading="lazy"-->
                <!--            referrerpolicy="no-referrer-when-downgrade"></iframe>-->
                <!--        @endif-->
                <!--    </div>-->
                <!--</div>-->
                
                <!--Show on desktop screen-->
                
                
                <div class="col-md-5 mt-4 fpostcode-map d-none d-lg-block d-md-block">
                
                <h5>Enter your Post Code to find nearest branch. </h5>
                
                        @if (session()->has('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                    
                    <div class="input-group mb-3">
                        
                        <input type="text" class="form-control search search_input" wire:model.defer="postalCode"
                            required placeholder="Enter Your Post Code">
                        <button type="button" class="btn btn-danger search-btn" wire:click="getLatLong">Search</button>
                    </div>
                    <div class="map-setting" style="width: 100%; height: 470px; border: 0;">
                        <!-- Display map or iframe -->
                        @if (!empty($mapLink))
                        {!! $mapLink !!}
                        @else
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                            width="100%" height="430px" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        @endif
                    </div>
                </div>
                <!---------------------------------on phone screen-------------->

                <div class=" col-md-12 d-lg-none d-md-none" style="margin-left:-50px;">
                    
                    <h6> Enter your Post Code to find nearest branch.</h6>
                    
                    
                        <div class="d-flex">
                        
                        <input type="text" class="form-control search search_input" wire:model.defer="postalCode"
                            required placeholder="Enter Your Post Code" style="width:200px;">
                        <button type="button" class="btn btn-danger search-btn" wire:click="getLatLong" style="margin-left:20px;">Search</button>
                        
                    </div>
                    
                    <div class="col-lg-12  boxes     shadow-lg " style="width:370px;border-radius:20px;">
                        <!-- Display nearest branches -->
                        @if (!empty($nearestBranches))
                        @foreach ($nearestBranches as $branch)
                        <div class="mb-4 border p-3">
                            <p class="fw-bold branch-name" style="font-size:12px">{{ $branch['name'] }}, <span
                                    class="distance_color">{{ number_format($branch['distance'], 2) }} miles</span></p>
                            <p class="address-town-post-code" style="font-size:12px;margin-top:-10px">{{
                                $branch['address_line_1'] }}, {{ $branch['address_line_2'] ?: '' }}, {{
                                $branch['town_city'] }}, {{ $branch['post_code'] }}, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    @if (!empty($branch['landline_number']))
                                    <option value="1" selected>Landline: {{ $branch['landline_number'] }}</option>
                                    @endif
                                    @if (!empty($branch['mobile_number']))
                                    <option value="2">Mobile: {{ $branch['mobile_number'] }}</option>
                                    @endif
                                    @if (!empty($branch['email']))
                                    <option value="3" >Email: {{ $branch['email'] }}</option>
                                    @endif


                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch({{ $branch['id'] }})" @click="step = 1">Select</button>
                            </div>
                        </div>
                        @endforeach
                        @elseif (!empty($branches))
                        @foreach ($branches as $branch)
                        <div class="mb-4 border p-3">
                            <p class="fw-bold branch-name">{{ $branch->name }}</p>
                            <p class="address-town-post-code" style="margin-top:-10px">{{ $branch->address_line_1 }}, {{
                                $branch->address_line_2 ?: '' }}, {{ $branch->town_city }}, {{ $branch->post_code }}, UK
                            </p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    @if (!empty($branch->email))
                                    <option value="3" >Email: {{ $branch->email }}</option>
                                    @endif
                                    @if (!empty($branch->landline_number))
                                    <option value="1"selected>Landline: {{ $branch->landline_number }}</option>
                                    @endif
                                    @if (!empty($branch->mobile_number))
                                    <option value="2" >Mobile: {{ $branch->mobile_number }}</option>
                                    @endif
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch({{ $branch->id }})" @click="step = 1">Select</button>
                            </div>
                        </div>
                        @endforeach
                        @endif
                    </div>
                </div>
                <!---------------------------------desktop screen-------------->
                <div class="col-md-6 d-none d-lg-block mb-3  shadow-sm d-md-block selection-area"   style="border-radius:20px;">
                    <div class="col-lg-12 px-3 boxes" style="height: 580px;">
                        <!-- Display nearest branches -->
                        @if (!empty($nearestBranches))
                        @foreach ($nearestBranches as $branch)
                        <div class="mb-4 border p-3">
                            <h3 class="fw-bold branch-name">{{ $branch['name'] }}, <span class="distance_color">{{
                                    number_format($branch['distance'], 2) }} miles</span></h3>
                            <p class="address-town-post-code">{{ $branch['address_line_1'] }}, {{
                                $branch['address_line_2'] ?: '' }}, {{ $branch['town_city'] }}, {{ $branch['post_code']
                                }}, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    @if (!empty($branch['email']))
                                    <option value="1" >Email: {{ $branch['email'] }}</option>
                                    @endif
                                    @if (!empty($branch['landline_number']))
                                    <option value="2" selected>Landline: {{ $branch['landline_number'] }}</option>
                                    @endif
                                    @if (!empty($branch['mobile_number']))
                                    <option value="3" >Mobile: {{ $branch['mobile_number'] }}</option>
                                    @endif
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch({{ $branch['id'] }})" @click="step = 1">Select</button>
                            </div>
                        </div>
                        @endforeach
                        @elseif (!empty($branches))
                        @foreach ($branches as $branch)
                        <div class="mb-4 border p-3">
                            <h3 class="fw-bold branch-name">{{ $branch->name }}</h3>
                            <p class="address-town-post-code">{{ $branch->address_line_1 }}, {{ $branch->address_line_2
                                ?: '' }}, {{ $branch->town_city }}, {{ $branch->post_code }}, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    @if (!empty($branch->email))
                                    <option value="1" >Email: {{ $branch->email }}</option>
                                    @endif
                                    @if (!empty($branch->landline_number))
                                    <option value="2" selected>Landline: {{ $branch->landline_number }}</option>
                                    @endif
                                    @if (!empty($branch->mobile_number))
                                    <option value="3" >Mobile: {{ $branch->mobile_number }}</option>
                                    @endif
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch({{ $branch->id }})" @click="step = 1">Select</button>
                            </div>
                        </div>
                        @endforeach
                        @endif
                    </div>
                </div>
             
             
 
            </section>

<!-- For desktop-->
    <div class="d-none d-lg-block d-md-block">
                

                 
                  <button  class="bg-white " role="button" type="button" @click="step = 0" x-show="step === 1"  wire:click="goBack" 
                  style="float:left;margin-top:-95px;margin-left:15px;">
                      <b>  <i class="fa-solid  fa-circle-chevron-left"></i> Go Back   </b>
                  </button>
                 <!--<button  type="submit" class="bg-white" role="button" x-show="step === 1" -->
                 <!--style=" float:right;margin-top:-95px;margin-right:-15px;">-->
                 <!--    <b> Next <i class="fa-solid  fa-circle-chevron-right"></i>   </b>-->
                     
                 <!--</button>       -->
                
            </div>

<!--for mobile-->
    <div class="d-lg-none d-md-none">
                

                 
                  <button  class="bg-white " role="button" type="button" @click="step = 0" x-show="step === 1"  wire:click="goBack" 
                  style="float:left;margin-top:-95px;">
                      <b>  <i class="fa-solid  fa-circle-chevron-left"></i> Go Back   </b>
                  </button>
                 <!--<button  type="submit" class="bg-white" role="button" x-show="step === 1" -->
                 <!--style=" float:right;margin-top:-95px;margin-right:-60px;">-->
                 <!--    <b> Next <i class="fa-solid  fa-circle-chevron-right"></i>   </b>-->
                     
                 <!--</button>       -->
                
            </div>


            <!-- Step 2: Appointment Form -->
            <section id="section-2" x-show="step === 1" x-cloak    style="margin-top:-20px;margin-bottom:-100px;">
    
    <!--desktop-->
                <div class="d-none d-lg-block d-md-block" >
                   <h2 class="mb-4 text-danger text-center">
@switch(session()->get('serviceType'))
        @case(\App\Helpers\ServiceType::ACCESSORIES)
            Fix your accessories at my address
            @break

        @case(\App\Helpers\ServiceType::BUY)
            Buy at my address
            @break

        @case(\App\Helpers\ServiceType::SELL)
            Sell at Store
            @break

        @case(\App\Helpers\ServiceType::REPAIR)
             Repair At Store
            @break

        @case(\App\Helpers\ServiceType::UNLOCKING)
            Unlock your device at my address
            @break

        @default
            Fix at my address
    @endswitch

</h2>
<p class="mb-4 text-center">
     <span class="text-danger">date</span> {{$clinic['appointment_date']}} and <span class="text-danger">time</span> {{$clinic['appointment_time']}}
</p>


                    <div class="row d-flex justify-content-evenly slot-container" >
                        <!-- Calendar Column -->
                        <div class="col-md-4 mb-3 left-side">

                            <div class="calendar-container" style="width: 100%">
                                <div class="calendar-header d-flex justify-content-between align-items-center" style="background-color: #EE8787;">
                                    <button type="button" class="btn btn-link text-danger" wire:click="previousMonth">&lt;</button>
                                    <span>{{ $this->currentMonth->format('F Y') }}</span>
                                    <button type="button" class="btn btn-link text-danger" wire:click="nextMonth">&gt;</button>
                                </div>
                                <table class="table table-bordered calendar-table" style="background-color: #EE8787;">
                                    <thead style="background-color: #EE8787;">
                                        <tr>
                                            <th style="background-color: #EE8787;">Mo</th>
                                            <th style="background-color: #EE8787;">Tu</th>
                                            <th style="background-color: #EE8787;">We</th>
                                            <th style="background-color: #EE8787;">Th</th>
                                            <th style="background-color: #EE8787;">Fr</th>
                                            <th style="background-color: #EE8787;">Sa</th>
                                            <th style="background-color: #EE8787;">Su</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if($this->calendarDays)
                                        @foreach ($this->calendarDays as $week)
                                        <tr>
                                            @foreach ($week as $day)
                                            <td class="{{ $day['class'] }}"
                                                wire:click="selectDate('{{ $day['date'] }}')" @if($day['disabled'])
                                                style="pointer-events: none; opacity: 0.5;" @endif>
                                                {{ $day['day'] }}
                                            </td>
                                            @endforeach
                                        </tr>
                                        @endforeach
                                        @else
                                        <tr>
                                            <td colspan="7">No dates available</td>
                                        </tr>
                                        @endif
                                    </tbody>
                                </table>
                                <!--<div class="calendar-footer d-flex justify-content-between">-->
                                <!--    <button type="button" class="btn btn-secondary" wire:click="cancelDateSelection">Cancel</button>-->
                                <!--    <button type="button" class="btn btn-danger" wire:click="confirmDateSelection">Choose Date</button>-->
                                <!--</div>-->
                            </div>
                            @error('clinic.appointment_date')
                            <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Time Slot Column -->
                        <div class="col-md-6">
                            @php
    use Carbon\Carbon;
    $formattedTime = Carbon::parse($clinic['appointment_time'])->format('g:i A'); // 12-hour format with AM/PM
@endphp

                                                    <label class="form-label fw-bold container-fluid" aria-placeholder="Date" for="appointment_time" style="font-weight: 400 !important; height: 35px; border-radius: 10px; border: 1px solid silver; padding: 5px 0 5px 16px; box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px; font-size: 15px;">
                                  @if(($clinic['appointment_time']))
       <span>Selected Time  is</span> {{ $clinic['appointment_time'] }} ( {{$formattedTime}} )

    @else
        Please Select Appointment Date
    @endif
   
                                </label>
                                 </div>
                        <div class="col-md-6 mb-4 select-slot-div">
                            
                            <label class="form-label fw-bold" for="appointment_time" style="font-size: 16px; margin-left:10px;">Select
                                Your Appointment Time</label>
                            <div class="time-slots-grid">
                                @foreach ($timeSlots as $timeSlot)
                                <button type="button"
                                    class="btn  time-slot-btn {{ $clinic['appointment_time'] === $timeSlot ? 'active' : '' }}"
                                    wire:click="$set('clinic.appointment_time', '{{ $timeSlot }}')" >
                                    {{ $timeSlot }}
                                </button>
                                @endforeach
                            </div>
                            @error('clinic.appointment_time')
                            <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>


                        <style>
           
                            .select-slot-div {
                                margin-top:-355px;
                                margin-left:435px;
                                /*border: 1px solid #d1d1d1;*/
                                padding: 20px 20px 0 20px;
                                /*border-radius: 20px;*/
                                /*box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;*/
                                height: 380px;
                            }

                            .time-slots-grid {
                                max-height: 300px;
                                /* Adjust the height as needed */
                                overflow-y: scroll;

                                padding: 10px;
                                /* Optional: add padding for better spacing */
                            }

                            /* Scrollbar styles for WebKit browsers (Chrome, Safari) */
                            .time-slots-grid::-webkit-scrollbar {
                                width: 50px;
                                /* Adjust width as needed */
                            }

                            .time-slots-grid::-webkit-scrollbar-track {
                                background: #dc3545;
                                /* Background of the track */
                            }

                            .time-slots-grid::-webkit-scrollbar-thumb {
                                background-color: #dc3545;
                                /* Scrollbar thumb color */
                                border-radius: 10px;
                                /* Optional: round the corners */
                                border: 2px solid #dc3545;
                                /* Scrollbar thumb border color */
                            }

                            /* Scrollbar styles for Firefox */
                            .time-slots-grid {
                                scrollbar-width: thin;
                                /* "auto" or "thin" */
                            }
                        </style>
                    </div>

                    <!--<div class="selected-datetime mb-4 d-flex justify-content-center" style="margin-left:10%">-->
                    <!--    {{ $clinic['appointment_date'] ? date('l jS F', strtotime($clinic['appointment_date'])) : '' }}-->
                    <!--    {{ $clinic['appointment_time'] ? 'at ' . $clinic['appointment_time'] : '' }}-->
                    <!--</div>-->
                </div>
                
                
                
                <!--  the phone screen---->
                <div class=" d-lg-none d-md-none" >
                  
                  <div style="margin-left:-40px;">
                      
                   <h3 class="mb-2 text-danger text-center"
                   >
                       <br>
        @switch(session()->get('serviceType'))
        @case(\App\Helpers\ServiceType::ACCESSORIES)
            Fix your accessories at my address
            @break

        @case(\App\Helpers\ServiceType::BUY)
            Buy at my address
            @break

        @case(\App\Helpers\ServiceType::SELL)
            Sell at Store
            @break

        @case(\App\Helpers\ServiceType::REPAIR)
             Repair At Store
            @break

        @case(\App\Helpers\ServiceType::UNLOCKING)
            Unlock your device at my address
            @break

        @default
            Fix at my address
    @endswitch
</h3>

                  <p class=" text-center" style="width: 100%; margin: 0 auto;">
     <span class="text-danger">Date</span> {{$clinic['appointment_date']}} and <b><span class="text-danger">Time</span> {{$clinic['appointment_time']}}</b> 
</p>

</div>
        
        
                    <div class="row slot-container" >
                        <!-- Calendar Column -->
                        <div class="col-md-4 mb-3 left-side"  style="margin-left:-40px;margin-top:-40px;">

                            <div class="calendar-container" style="width: 100%;">
                                <div class="calendar-header d-flex justify-content-between align-items-center">
                                    <button type="button" class="btn btn-link text-danger" wire:click="previousMonth">&lt;</button>
                                    <span>{{ $this->currentMonth->format('F Y') }}</span>
                                    <button type="button" class="btn btn-link text-danger" wire:click="nextMonth">&gt;</button>
                                </div>
                                <table class="table table-bordered calendar-table" style="background-color: #EE8787;">
                                    <thead style="background-color: #EE8787;">
                                        <tr>
                                            <th style="background-color: #EE8787;">Mo</th>
                                            <th style="background-color: #EE8787;">Tu</th>
                                            <th style="background-color: #EE8787;">We</th>
                                            <th style="background-color: #EE8787;">Th</th>
                                            <th style="background-color: #EE8787;">Fr</th>
                                            <th style="background-color: #EE8787;">Sa</th>
                                            <th style="background-color: #EE8787;">Su</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if($this->calendarDays)
                                        @foreach ($this->calendarDays as $week)
                                        <tr>
                                            @foreach ($week as $day)
                                            <td class="{{ $day['class'] }}"
                                                wire:click="selectDate('{{ $day['date'] }}')" @if($day['disabled'])
                                                style="pointer-events: none; opacity: 0.5;" @endif>
                                                {{ $day['day'] }}
                                            </td>
                                            @endforeach
                                        </tr>
                                        @endforeach
                                        @else
                                        <tr>
                                            <td colspan="7">No dates available</td>
                                        </tr>
                                        @endif
                                    </tbody>
                                </table>
                                <!--<div class="calendar-footer d-flex justify-content-between">-->
                                <!--    <button type="button" class="btn btn-secondary" wire:click="cancelDateSelection">Cancel</button>-->
                                <!--    <button type="button" class="btn btn-danger" wire:click="confirmDateSelection">Choose Date</button>-->
                                <!--</div>-->
                            </div>
                            @error('clinic.appointment_date')
                            <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                   @php
    $formattedTime = Carbon::parse($clinic['appointment_time'])->format('g:i A'); // 12-hour format with AM/PM
@endphp      


           <hr style="border-bottom:2px solid black;margin-left:-20px;">
        <br>


                        <!-- Time Slot Column -->
                         <label class="form-label fw-bold container-fluid" aria-placeholder="Date" for="appointment_time" style=" height: 30px;  border-radius: 10px; border: 1px solid silver; padding: 5px 0 5px 16px; box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px; font-size: 10px;">
                                  @if(($clinic['appointment_time']))
       <span>Selected Time  is</span> {{ $clinic['appointment_time'] }} ( {{$formattedTime}} )
    @else
        Please Select Appointment Date
    @endif
   
                                </label>
                    <div class="col-md-6 mb-8" style="width: 100%;border:none !important;">
    <label class="form-label fw-bold" for="appointment_time" style="font-size: 12px;">Select Your Appointment Time</label>
    <div class="time-slots-grid d-flex flex-wrap" style="width:100%; margin-left:-20px;">
        @foreach ($timeSlots as $timeSlot)
        <button type="button"
            class="btn btn-outline-secondary time-slot-btn {{ $clinic['appointment_time'] === $timeSlot ? 'active' : '' }}"
            wire:click="$set('clinic.appointment_time', '{{ $timeSlot }}')" style="width:70px; background-color: #EE8787;">
            {{ $timeSlot }}
        </button>
        @endforeach
    </div>
    @error('clinic.appointment_time')
    <span class="text-danger">{{ $message }}</span>
    @enderror
</div>



                        <style>
                            .select-slot-div {
                                /*border: 1px solid #d1d1d1;*/

                                /*border-radius: 20px;*/
                                /*box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;*/

                            }

                            .time-slots-grid {
                                max-height: 300px;
                                /* Adjust the height as needed */
                                overflow-y: scroll;
                                
                                padding: 8px;
                                /* Optional: add padding for better spacing */
                                
                            }

                            /* Scrollbar styles for WebKit browsers (Chrome, Safari) */
                            .time-slots-grid::-webkit-scrollbar {
                                width: 20px;
                                /* Adjust width as needed */
                            }

                            .time-slots-grid::-webkit-scrollbar-track {
                                background: #dc3545;
                                /* Background of the track */
                            }

                            .time-slots-grid::-webkit-scrollbar-thumb {
                                background-color: #dc3545;
                                /* Scrollbar thumb color */
                                border-radius: 10px;
                                /* Optional: round the corners */
                                border: 2px solid #dc3545;
                                /* Scrollbar thumb border color */
                            }

                            /* Scrollbar styles for Firefox */
                            .time-slots-grid {
                                scrollbar-width: thin;
                                /* "auto" or "thin" */
                            }
                        </style>
                 
                    
                    </div>
                    <!--<div style="display: inline;  white-space: nowrap;">-->
                    <!--    {{ $clinic['appointment_date'] ? date('l jS F', strtotime($clinic['appointment_date'])) : '' }}-->
                    <!--    {{ $clinic['appointment_time'] ? 'at ' . $clinic['appointment_time'] : '' }}-->
                    <!--</div>-->

                </div>
                
                
            </section>








      <div class="d-none d-lg-block d-md-block">
                <div class="btn-style ">

                 <button  type="submit" class="button-27" role="button" x-show="step === 1"  style="width: 150px; height: auto; margin-left: auto;">Next</button>
                  <!--<button  class="button-27" role="button" type="button" @click="step = 0" x-show="step === 1"  wire:click="goBack"  style="width: 150px; height: auto; margin-right: auto;">Go Back</button>-->
                        
                </div>
            </div>
            
            <!--------------------phone screen-------------->
            <div class=" d-lg-none d-md-none " >
                <div class="btn-style ">

                    <button class="mbbutton-27"  role="button" type="submit"
                        x-show="step === 1" style="margin-top:50px;margin-bottom:-100px;">Next</button>

                    <!--<button class="mbbutton-27" role="button" type="button"-->
                    <!--    @click="step = 0" x-show="step === 1" wire:click="goBack" >Go Back</button>-->
            
                </div>
            </div>

    </div>
    </form>
</div>

<style>
    .submit-form {
        position: relative;
    }

    .button-20 {
        appearance: button;
        /*width: 11%;*/
        background-color: #dc3545;
        background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
        border: 1px solid #dc3545;
        border-radius: 1rem;
        box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px;
        box-sizing: border-box;
        color: #FFFFFF;
        cursor: pointer;
        display: inline-block;
        font-family: Inter, sans-serif;
        font-size: 1rem;
        font-weight: 500;
        line-height: 1.7;
        margin: 0;
        padding: 6px 50px;
        text-align: center;
        text-transform: none;
        transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
        vertical-align: middle;
    }

    .button-20:focus:not(:focus-visible),
    .button-20:focus {
        outline: 0;
    }

    .button-20:hover {
        background-color: #dc3545;
        border-color: #dc3545;
    }

    .button-20:focus {
        background-color: #dc3545;
        border-color: #dc3545;
        box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
    }

    .button-20:active {
        background-color: #dc3545;
        background-image: none;
        border-color: #dc3545;
        box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
    }

    .button-20:active:focus {
        box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
    }

    .button-20:disabled {
        background-image: none;
        box-shadow: none;
        opacity: .65;
        pointer-events: none;
    }

    .calendar-container {
        /*border: 1px solid #dee2e6;*/
        /*border-radius: 10px;*/
        /*box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;*/
        /*background-color:#EE8787;*/
        padding: 1rem;
        width: max-content;
    }

    .calendar-table {
        margin-bottom: 1rem;
        
    }

    .calendar-table th,
    .calendar-table td {
        text-align: center;
        vertical-align: middle;
        padding: 0.5rem;
    }

    .calendar-table td {
        cursor: pointer;
    }

    .calendar-table td.today {
        background-color: #f8f9fa;
    }

    .calendar-table td.selected {
        background-color: #dc3545;
        color: white;
    }

    .calendar-table td.disabled {
        color: #dee2e6;
        cursor: not-allowed;
    }

    .time-slots-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 10px;
    }

    .time-slot-btn {
        padding: 10px;
        text-align: center;
    }

    .time-slot-btn.active {
        background-color: #EE8787;
        color: white;
        border-color: #F6C3C3;
    }

    .selected-datetime {
        font-weight: bold;
    }

    .search {
        width: 70px;
    }

    .map-setting {
        background-color: #fff;
        border-radius: 15px;
        box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);
        padding: 17px 14px 14px;
    }

    .fpostcode-map {
        width: 40%;
        background-color: #fff;
        border-radius: 15px;
        /*box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);*/
        /*padding: 17px 14px 14px 14px;*/
    }

    .input-group {
        display: flex;
        
    }

    .form-select-btn {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .distance_color {
        color: #dc3545;
    }

    .search_input {
        border-radius: 20px;
        border-top-right-radius: 20px !important;
        border-bottom-right-radius: 20px !important;
        /*box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;*/
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
    }

    .search-btn {
        border-radius: 20px;
        border-top-left-radius: 20px !important;
        border-bottom-left-radius: 20px !important;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
         max-width:100px;
    }

    .address-town-post-code {
        padding-bottom: 6px;
    }

    .boxes {
        width: 700px;
        margin-top: 25px;
        height: 920px;
        overflow-y: scroll;
        /*scrollbar-color: rgb(233, 163, 163) transparent;*/
        scroll-behavior: smooth;
        /*scroll-padding: 50px;*/
    }

    .boxes div {
        border-radius: 20px;
    }

    .boxes div:nth-child(1) {
        margin-top: 0px !important;
    }

    .boxes::-webkit-scrollbar {
        width: 20px;
        height: 100px;
    }

    .btn-style {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-direction: row-reverse;
        margin-top: 100px;
    }

    .boxes::-webkit-scrollbar-track {
        background: #d1d1d1;
        border-radius: 40px;
    }

    .boxes::-webkit-scrollbar-thumb {
        background-color: #dc3545;
        border-radius: 40px;
        border: 3px solid transparent;
    }

    .find {
        color: rgb(240, 88, 88);
        font-size: 44px;
        font-weight: 900;
        text-align: center;
    }

    .search-btn {
        background-color: #da3847;
        color: white;
    }

    .s-card {
        height: 120px;
    }

    .left-side {
        width: 30%;
    }

    @media (max-width: 576px) {

        h2.find {
            
            font-size: 22px;
            margin-bottom:30px;
        }

        .input-group {
            flex-wrap: wrap;
        }

        .input-group .form-control {
            flex: 1 1 100%;
            width: 100%;
            margin-right: 0;
            margin-bottom: 10px;
        }

        .input-group .search-btn {
            flex: 1 1 100%;
            width: 100%;
        }

        /* width: 133%;
        height: 850px;
        border: 0; */
    }

    .slot-container {
        justify-content: center;
    }

    /*///////////// Slot Responsive /////////////*/
    @media (max-width: 1400px) {
        .left-side {
            width: 35%;
        }
    }

    @media (max-width: 1400px) {
        .left-side {
            width: 40%;
        }
    }

    @media (max-width: 1024px) {
        .map-select {
            flex-direction: column;
        }

        .fpostcode-map {
            width: 100%;
        }

        .selection-area {
            width: 100%;
        }

        .boxes {
            width: 100%;
        }
    }

    @media (max-width: 900px) {
        .slot-container {
            flex-direction: column;
        }

        .select-slot-div {
            width: 100%;
        }

        .left-side {
            width: 100%;
        }

    }

    /*///////////// Slot Responsive /////////////*/
    /*-------------------------------------phone reponsive--- start-----------------*/
    @media (max-width: 320px) {

        .col-md-6 {
            flex: 0 0 auto;
            width: 300% !important;
        }
    }
    
    

</style>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        flatpickr("#appointment_date", {
            dateFormat: "Y-m-d",
            minDate: "today"
        });
    });
</script>


</div>
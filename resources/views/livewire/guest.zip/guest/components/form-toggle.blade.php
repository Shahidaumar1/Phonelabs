


<div>
    @php
        $tagline = [
            'sell' => 'How you’ll send your device',
            'repair' => 'How would you like us to repair your device?',
            'buy' => 'How you’ll get your device',
        ];

        $heading = [
            'sell' => 'Selling Options',
            'repair' => 'Repair Options',
            'buy' => 'Buying Options',
        ];

        $postalText = [
            'sell' => 'Post Your Device',
            'repair' => 'Postal Repair',
            'buy' => 'Post My Device',
        ];

        $formService = strtolower($data['service']);
    @endphp


<script>
if ('scrollRestoration' in history) {
    history.scrollRestoration = 'manual';
}

 window.onload = function () {
            window.scrollTo(0, 0);
        };

window.onbeforeunload = function () {
    window.scrollTo(0, 0);
};
</script>


    @if ($showGrid)
        <div class="grid-heading" style="margin-top:-50px !important;">
            <h3 class="text-center text-danger ">{{ $heading[$formService] }}</h3>
            <p class="text-center">{{ $tagline[$formService] }} </p>
        </div>

        <div class="bg-white d-none d-lg-block d-md-block " style="margin-bottom:-100px;margin-top:-20px;" >
            <section>
                <div class="grid-container" role="grid">
                    @if ($formStatuses[0]->$formService)
                        <div class="grid-item" wire:click="showForm('clinic_form')">
                            <div class="icon-container text-danger">
                                <img src="https://ik.imagekit.io/b6iqka2sz/Store%20Repair.png?updatedAt=1719830430304" alt="" style="width: 90px; height: 75px;">
                            </div>
                            <div class="option-label text-dark">{{ $optionLabels['Store Repair'] }}  &nbsp; - &nbsp;  Visit Us  </div>
                            <div class="option-description"><a href="">Choose from one of our 65 nationwide locations.</a></div>
                        </div>
                    @endif

                    @if ($formStatuses[1]->$formService)
                        <div class="grid-item" wire:click="showForm('postal_form')" style="border: 2px solid black;">
                            <div class="icon-container text-danger">
                                <img src="https://ik.imagekit.io/b6iqka2sz/Postal%20Repair.png?updatedAt=1719830318561" alt="" style="width: 75px; height: 75px;">
                            </div>
                            <div class="option-label text-dark">{{ $optionLabels['Postal Repair'] }}  </div>
                            <div class="option-description"><a href="">No stores close to you? Send your device to us!</a></div>
                        </div>
                    @endif

                    @if ($formStatuses[2]->$formService && $formService != 'buy')
                        <div class="grid-item mb-5" wire:click="showForm('collection_form')" style="border: 2px solid black;">
                            <div class="icon-container text-danger">
                                <img src="https://i.imghippo.com/files/xat891724411729.png" alt="" style="width: 75px; height: 75px;">
                            </div>
                            <div class="option-label text-dark">{{ $optionLabels['Collect My Device'] }}  </div>
                            <div class="option-description"><a href="">We'll pick up your device for repair and return it to you afterward.</a></div>
                        </div>
                    @endif

                    @if ($formStatuses[3]->$formService && $data['device']['name'] != 'Apple iPad' && $formService == 'repair')
                        <div class="grid-item mb-5" wire:click="showForm('fix_form')" style="border: 2px solid black;">
                            <div class="icon-container text-danger" >
                                <img src="https://ik.imagekit.io/b6iqka2sz/Fix%20At%20My%20Address.png?updatedAt=1719830266710" alt="" style="width: 75px; height: 75px;">
                            </div>
                            <div class="option-label text-dark">{{ $optionLabels['Fix At My Address'] }}</div>
                            <div class="option-description"><a href="">Our technicians will visit your residence to repair your mobile device.</a></div>
                        </div>
                    @endif
                </div>
            </section>
        </div>
        
        <!--Mobile-->
        <div class="bg-white d-lg-none d-md-none" style="margin-bottom:-100px;">
            <section>
                <div class="d-flex gap-4 flex-wrap justify-content-center">
                    @if ($formStatuses[0]->$formService)
                        <div class="p-3" wire:click="showForm('clinic_form')" 
                        style="width:330px !important;height:150px;border:1px solid #ddd; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);overflow:hidden;border-radius:20px;" >
                            <div class=" text-danger d-flex  " >
                                <img src="https://ik.imagekit.io/b6iqka2sz/Store%20Repair.png?updatedAt=1719830430304" alt="" style="width: 90px; height: 75px;">
                            <p class=" text-wrap text-dark pt-2 pl-2" style="font-size:16px;"> <b>  {{ $optionLabels['Store Repair'] }} -  Visit Us </b> </p>
                            <p class="" style="font-size:10px;padding-top:70px;margin-left:-130px;color:#EE8787;"><a href="">Choose from one of our 65 nationwide locations.</a></p>
                            </div>
                            
                            
                        </div>
                    @endif

                    @if ($formStatuses[1]->$formService)
                        <div class="p-3" wire:click="showForm('postal_form')" 
                        style="width:330px !important;height:150px;border:1px solid #ddd; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);overflow:hidden;border-radius:20px;">
                            <div class="text-danger d-flex ">
                                <img src="https://ik.imagekit.io/b6iqka2sz/Postal%20Repair.png?updatedAt=1719830318561" alt="" style="width: 75px; height: 75px;">
                            
                            <p class="text-wrap text-dark pt-3 pl-2" style="font-size:16px;"> <b> {{ $optionLabels['Postal Repair'] }} </b>  </p>
                             
                                         <p class="" style="font-size:10px;padding-top:70px;margin-left:-110px;color:#EE8787;"><a href="">No stores close to you? Send your <br> device to us!</a></p>
                
                    </div>
                    
                        </div>
                    @endif

                    @if ($formStatuses[2]->$formService && $formService != 'buy')
                        <div class="p-3" wire:click="showForm('collection_form')" 
                     style="width:330px !important;height:150px;border:1px solid #ddd; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);overflow:hidden;border-radius:20px;">
                            <div class="text-danger d-flex ">
                                <img src="https://i.imghippo.com/files/xat891724411729.png" alt="" style="width: 75px; height: 75px;">
                            
                            <p class="text-wrap text-dark pt-2 pl-2"><b> {{ $optionLabels['Collect My Device'] }} </b>  </p>
                            <p class="" style="font-size:10px;padding-top:60px;margin-left:-125px;color:#EE8787;"><a href="">We'll pick up your device  for<br>  repair   and return it to you afterward.</a></p>
                        </div>
                        </div>
                    @endif

                    @if ($formStatuses[3]->$formService && $data['device']['name'] != 'Apple iPad' && $formService == 'repair')
                        <div class="grid-item mb-5" wire:click="showForm('fix_form')" style="border: 2px solid black;">
                            <div class="icon-container text-danger" >
                                <img src="https://ik.imagekit.io/b6iqka2sz/Fix%20At%20My%20Address.png?updatedAt=1719830266710" alt="" style="width: 75px; height: 75px;">
                            </div>
                            <div class="option-label text-dark">{{ $optionLabels['Fix At My Address'] }}</div>
                            <div class="option-description"><a href="">Our technicians will visit your residence to repair your mobile device.</a></div>
                        </div>
                    @endif
                </div>
            </section>
        </div>
        
        
    @endif

    @if ($showForm)
        <section>
            <div style="background-color:black">
                <div wire:loading wire:target="form_type" class="w-100">
                    <div class="overlay rounded d-flex flex-column justify-content-center align-items-center bg-pink-linear text-white" style="height:400px;">
                        <x-spinner color="danger" />
                    </div>
                </div>
                <div class="bg-white">
                    <div wire:loading.remove wire:target="form_type">
<!--for desktop-->
<div class="d-none d-lg-block d-md-block">
                          <button class="bg-white " role="button" type="button" wire:click="hideForm" 
            style="float:left;margin-left:50px;margin-top:-70px;" >  <b>  <i class="fa-solid  fa-circle-chevron-left"></i> Go Back </b></button>             
</div>
<!--for phone-->
<div class="d-lg-none d-md-none ">
                          <button class="bg-white " role="button" type="button" wire:click="hideForm" 
            style="float:left;margin-top:-70px;" >  <b>  <i class="fa-solid  fa-circle-chevron-left"></i> Go Back </b></button>             
</div>

                        @if ($showForm)
                            @if ($form_type == 'postal_form')
                                <div class="bg-white">
                                    <livewire:guest.components.postal-repair-form initialBranchId="13" />
                                </div>
                            @elseif($form_type == 'clinic_form')
                                <livewire:guest.components.clinic-repair-form :key="uniqid()" />
                            @elseif($form_type == 'collection_form')
                                <div wire:ignore>
                                    <livewire:guest.collection-form :key="uniqid()" />
                                </div>
                            @elseif($form_type == 'fix_form')
                                <div wire:ignore>
                                    <livewire:guest.fix-form :key="uniqid()" />
                                </div>
                            @endif
                        @endif
                        
                    </div>
                </div>
            </div>
        
        
        </section>
    
    @endif
    
</div>

<style>
    .nav-tabs {
        display: flex;
        flex-wrap: nowrap;
        overflow-x: auto;
        border-bottom: none;
        background-color: transparent;
        scrollbar-width: none;
    }

    .nav-item {
        white-space: nowrap;
        color: green;
    }

    .nav-link {
        color: #3E3E3E;
    }

    .nav-link:hover {
        color: black !important;
    }

    .nav-link.active {
        color: #3E3E3E;
    }

    .nav-tabs::-webkit-scrollbar {
        display: none;
    }

    .nav-tabs .nav-link.active {
        background-color: white;
        position: relative;
        z-index: 1;
    }

    .tab-content {
        background-color: #ffffff;
        border-radius: 10px;
        width: 100%;
        margin: 0 auto;
        padding: 20px;
    }

    @media only screen and (max-width: 767px) {
        .tab-content {
            width: 100%;
            margin-left: -2%;
        }
    }

    .tab-content.postal-form {
        background-color: #f0f0f0;
    }

    .tab-content.clinic-form {
        background-color: #e0e0e0;
    }

    .grid-container {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        margin-bottom: 20px;
        padding-left: 200px;
        padding-right: 200px;
        padding-top: 40px;
    }

    .grid-item {
        background-color: hsl(0, 100%, 99%);
        padding: 20px;
        border-radius: 5px;
        text-align: center;
        transition: all 0.3s ease;
        cursor:pointer;
    }

    .grid-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
    }

    .icon-container {
        font-size: 2rem;
        margin-bottom: 10px;
    }

    .option-label {
        font-weight: bold;
        margin-bottom: 5px;
        cursor:text;
    }

    .option-description {
        font-size: 0.9rem;
        color: #666;
        cursor:text;
    }

    a {
        text-decoration: none;
    }


    /* Responsive Styles */
    @media (max-width: 576px) {
        .grid-container {
            grid-template-columns: repeat(1, 1fr);
            padding-left: 5px;
            padding-right: 5px;
        }
    }

    .grid-item {
        border: 2px solid black;
    }

    .grid-item:hover .option-label,
    .grid-item:hover .option-description a {
        color: #e21f18 !important; /* Change to desired hover color */
    }
</style>

<script>
    document.addEventListener('livewire:load', function () {
        Livewire.on('formShown', function () {
            document.querySelectorAll('.tab-pane').forEach(function (tabPane) {
                tabPane.classList.remove('active', 'show');
            });
        });

        Livewire.on('BranchSelected', function () {
            document.querySelector('.back-button').style.display = 'none';
        });

        Livewire.on('childGoBack', function () {
            document.querySelector('.back-button').style.display = 'block';
        });
    });

    function forgetPreviousForm() {
        @this.forgetSession('form_type');
    }
</script>

@push('scripts')
<script>
    function forgetPreviousForm() {
        @this.call('forgetFormType');
    }

    document.addEventListener('livewire:load', function () {
        Livewire.on('someEvent', function () {
            forgetPreviousForm();
        });
    });
</script>
@endpush

</div>

<style>

        .button-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 16px;
  font-weight: 600;
  line-height: normal;
  margin: 0;
  min-height: 60px;
  min-width: 0;
  outline: none;
  padding: 16px 24px;
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  width:150px;
  will-change: transform;
}

.button-27:disabled {
  pointer-events: none;
}

.button-27:hover {
  box-shadow: #DC3545 0 8px 15px;
  transform: translateY(-2px);
}

.button-27:active {
  box-shadow: none;
  transform: translateY(0);
}


    /* Adjust button size for screens smaller than 768px */
    @media (max-width: 768px) {
     
.button-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 12px;
  font-weight: 400;
  line-height: normal;
  margin: 0;
  min-height: 40px;
  min-width: 100px;
  outline: none;
  
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  will-change: transform;
}
   
        
    }

    /* Further adjust button size for screens smaller than 480px */
    @media (max-width: 480px) {
        .button-27 {
            margin-top:50px;
            font-weight:800;
            font-size: 14px;
            min-height:40px;  /* Further reduce height */
            width:120px;  /* Further adjust width */
            
        }
    }



    </style>
    <script>
        document.addEventListener('livewire:load', function () {
    // Initial setup based on the form type loaded event
    Livewire.on('formTypeLoaded', function (formType) {
        console.log('Initial form type loaded:', formType);
        updateFormDisplay(formType);
    });

    // Handle form type changes
    Livewire.on('formToggle', function (formType, data) {
        console.log('Form type toggled:', formType);
        updateFormDisplay(formType);
    });

    function updateFormDisplay(formType) {
        // Hide all forms
        document.querySelectorAll('.form-section').forEach(function (element) {
            element.style.display = 'none';
        });

        // Show the relevant form based on formType
        if (formType === 'postal_form') {
            document.getElementById('postal-form').style.display = 'block';
        } else if (formType === 'collection_form') {
            document.getElementById('collection-form').style.display = 'block';
        } else if (formType === 'fix_form') {
            document.getElementById('fix-form').style.display = 'block';
        }
    }
});
</script>
    
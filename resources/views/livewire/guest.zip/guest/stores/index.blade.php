<div>
    <div>
        <!-- --------------------------top bar----------------- -->
        <livewire:components.top-bar />
        <!-- --------------------navbar--------------------- -->
        <livewire:components.mega-nav />
        <div class="container-fluid mt-5">
            <h1 class="text-center text-danger">Locations</h1>
            <div class="row d-flex align-items-between p-2 mt-5">
                <div class="col-lg-6">
                    <div>
                        @if($map_link)
                        {!! $map_link !!}
                        @else
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus" width="100%" height="550" style="border: 0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        @endif
                    </div>
                </div>

                <div class="col-lg-6">
                    <h4>
                        Enter your postcode, select from the map or pick the store location
                    </h4>

                    <input type="text" class="form-control my-2 w-100 rounded-0" id="postalCode" placeholder="Postcode..." />
                    <button type="button" class="btn w-100 btn-outline-danger my-2 rounded-0" onclick="getLatLong()">
                        Submit
                    </button>

                    <div id="resultContainer"></div>

                    @push('scripts')
                    <script>
                        document.addEventListener('livewire:load', function() {
                            const resultContainer = document.getElementById("resultContainer");

                            Livewire.on('getLatLong', function() {
                                // Call the JavaScript function when the Livewire event is triggered

                                getLatLong();
                            });
                            async function getLatLong() {
                                const postalCode = document.getElementById("postalCode").value;

                                try {
                                    const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                                    const data = await response.json();

                                    if (data.length > 0) {
                                        const result = data[0];
                                        resultContainer.innerHTML = `<p>${result.display_name}</p>`;

                                        Livewire.emit('updateLocation', {
                                            latitude: result.lat,
                                            longitude: result.lon
                                        });
                                    } else {
                                        resultContainer.innerHTML = "<p>No results found for the provided postal code.</p>";
                                    }
                                } catch (error) {
                                    console.error("Error fetching data:", error);
                                }
                            }

                            // Add Livewire listener for location update
                            Livewire.on('updateLocation', (location) => {
                                // Handle location update if needed
                                console.log('Received location update:', location);
                            });

                            // Your existing function call
                            window.getLatLong = getLatLong;
                        });
                    </script>
                    @endpush
                    <h3 class="text-danger mt-4 ">All Branches</h3>
                    <div class="row justify-content-between">
                        @foreach($branches as $branch)
                        <div class="col-lg-4 col-md-6">
                            <li wire:click="getMap({{ $branch->id }})">{{ $branch->name }} >> </li>
                        </div>
                        @endforeach
                    </div>

                </div>
            </div>
        </div>


        <div class="container-fluid mt-5 p-5 branches">
            <h1 class="text-center text-danger">Our Stores</h1>
            <div class="row text-center justify-content-center mt-3">

                @foreach($branches->unique('town_city') as $branch)
                <div class="col-lg-3 col-md-6 mb-3">
                    <a href="#{{$branch->town_city}}">
                        <button type="button" class="btn bg-black text-white w-100">{{ $branch->town_city }}</button>
                    </a>
                </div>
                @endforeach
            </div>

        </div>

<div class="container mt-5">
        <h1 class="text-center text-danger mt-5">Find Our Stores</h1>
        <div class="row justify-content-center mt-5 g-4"> <!-- Added g-4 for spacing -->
            @foreach($branches as $branch)

            <div class="col-lg-3 col-md-6" id="{{$branch->town_city}}">
                <div class="card border-0" >
                    <a href="{{ route('store-details', $branch->id) }}">
                    <img src="{{ $branch->image ? $branch->image : 'https://ik.imagekit.io/qml3d7tgz/118771222_3248867385205903_5573724224360234256_n_nW6iVMHYK.jpg' }}" class="card-img-top fixed-size-img" alt="...">
                    <div class="card-body">
                        <h4 class="card-title text-danger">{{ $branch->town_city }} - {{ $branch->name }}</h4>
                        <p class="card-text">{{ $branch->address_line_1 }}, {{ $branch->address_line_2 }}{{ $branch->address_line_2 != '' ? ', ' : '' }} {{ $branch->town_city }}, {{ $branch->post_code }}</p>
                    </div>
                   </a>
                </div>
            </div>
            
            @endforeach
        </div>
    </div>

    </div>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
    ul {
        list-style-type: none;
    }

    li {
        list-style-type: none;
        color: black;
        cursor: pointer;
    }

    li:hover {
        color: rgb(220, 30, 30);
    }

    p {
        color: black;
        cursor: pointer;
    }

    p:hover {
        color: rgb(220, 30, 30);
    }

    .branches {
        background-color: rgb(242, 242, 242);
    }
        .fixed-size-img {
            width: 100%;
            height: 180px; /* Adjust height as needed */
            object-fit: cover; /* Ensures images are properly scaled */
        }
</style>
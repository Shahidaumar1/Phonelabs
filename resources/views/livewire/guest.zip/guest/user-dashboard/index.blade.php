<div class="col-lg-6 rounded" >
    <h1 class="text-center mb-4" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #333;">Contact US</h1>
            <div class="bg-light" style=" background-size: cover; background-position: center; background-color: rgba(255, 255, 255, 0.5); padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);">
                <div class="bg-white p-4" style="border-radius: 10px;">
                    @if (session()->has('message'))
                        <div class="alert alert-success">{{ session('message') }}</div>
                    @endif

                    <form wire:submit.prevent="sendEmail">
                        <div class="row">
                            <div class="col-lg-6 mb-3">
                                <label for="name" class="form-label">Name:</label>
                                <input type="text" id="name" class="form-control" wire:model="name" style="height: 50px; border-radius: 5px;" />
                                @error('name') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" id="email" class="form-control" wire:model="email" style="height: 50px; border-radius: 5px;" />
                                @error('email') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label for="phone" class="form-label">Phone:</label>
                                <input type="text" id="phone" class="form-control" wire:model="phone" style="height: 50px; border-radius: 5px;" />
                                @error('phone') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label for="selectedOption" class="form-label">Subject:</label>
                                <select id="selectedOption" class="form-select" wire:model="selectedOption" style="height: 50px; border-radius: 5px;">
                                    <option value="">Select</option>
                                    <option value="Buying a Device">Buying a Device</option>
                                    <option value="Selling A Device">Selling A Device</option>
                                    <option value="Repairing A device">Repairing A device</option>
                                    <option value="Other">Other</option>
                                </select>
                                @error('selectedOption') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            @if($selectedOption == 'Other')
                                <div class="col-lg-12 mb-3">
                                    <label for="otherOption" class="form-label">Other Option:</label>
                                    <input type="text" id="otherOption" class="form-control" wire:model="otherOption" style="border-radius: 5px;" />
                                    @error('otherOption') <span class="text-danger">{{ $message }}</span> @enderror
                                </div>
                            @endif
                            <div class="col-lg-12 mb-3">
                                <label for="message" class="form-label">Message:</label>
                                <textarea id="message" class="form-control" wire:model="message" placeholder="Type Your Message" style="height: 170px; border-radius: 5px;"></textarea>
                                @error('message') <span class="text-danger">{{ $message }}</span> @enderror
                            </div>
                            <div class="col-lg-12 text-center mt-4">
                                <button type="submit" class="btn btn-danger" style="border-radius: 5px; padding: 10px 20px;">
                                    Submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

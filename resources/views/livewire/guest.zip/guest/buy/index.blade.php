<div>
    <div>
        <!-- --------------------------top bar----------------- -->
        <livewire:components.top-bar />
        <!-- --------------------navbar--------------------- -->
        <livewire:components.mega-nav />
        <!-- --------------search filter-------- -->

        <div>
        <!-- --------------------navbar--------------------- -->
        <!-- --------------search filter-------- -->

        <div class="container ">
             <a href="{{ route('home') }}">
                        
                    <button class="btn btn-danger btn-sm mt-2"  ><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
</svg> </button>
                    </a>
            {{-- search filter --}}
            <div class="row">
                <div class="d-flex my-3 align-items-center justify-content-center  ">

                    <div class="col-lg-6 col-md-4">
                        <form class="d-flex " role="search">
                            <div class="wrapper">
                                <div class="search_box khuram">
                                    <div class="d-flex gap-2 ">
                                        <div class="dropdown ">

                                            <select class="form-control categories-k rounded-pill " wire:model="selectedCategoryId">

                                                <option class="text-center font-weight-bold kh" value="All">All</option>
                                                @forelse($categories as $key => $category)
                                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                                                @empty
                                                <option value="">Not Found!</option>
                                                @endforelse


                                            </select>
                                        </div>
                                        <div class="search_field ">
                                            <input type="text" class="form-control rounded-pill" placeholder="Search" wire:model.debounce.500="search">
                                            {{-- <i class="bi bi-search "></i> --}}

                                            <img class="bi" src="{{ asset('assets/kimges/icon.webp') }}" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        {{-- devices --}}
        <div class="d-flex flex-wrap justify-content-center mb-4">
            @if ($selectedCategoryId != 'All')
            @forelse ($devices as $device)
            <div class="bubble logo1 bg-light cursor-pointer mb-2 {{ $selectedDevice && $selectedDevice->id == $device->id ? 'border border-success border-2 ' : '' }}" wire:click="selectDevice('{{ $device->id }}')">
                <img src="{{ $device->file ?? '#' }}" alt="" class="img-fluid">
            </div>
            @empty
            <div>Not Found !</div>
            @endforelse
            @endif
        </div>


        {{-- left card filter with right models data --}}
        <section class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="d-flex justify-content-end">
                        <a class="text-primary cursor-pointer" wire:click="clearFilter">Clear Filter</a>
                    </div>
                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> device</h3>
                        <div class="p-2">
                            <div class="form-check">
                                <input {{ $selectedCategoryId == 'All' ? 'checked' : '' }} class="form-check-input" type="radio" name="category" value="{{ 'All' }}" wire:model="selectedCategoryId">
                                <label class="form-check-label">
                                    All
                                </label>
                            </div>
                            @foreach ($categories as $key => $category)
                            <div class="form-check">
                                <input {{ $selectedCategoryId == $category->id ? 'checked' : '' }} class="form-check-input" type="radio" name="category" value="{{ $category->id }}" wire:model="selectedCategoryId">
                                <label class="form-check-label">
                                    {{ $category->name }}
                                </label>
                            </div>
                            @endforeach


                        </div>
                    </div>
                    @if ($selectedCategoryId != 'All')
                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> Models</h3>
                        @forelse ($devices as $device)
                        <div class="p-2">
                            <div class="form-check">
                                <input {{ $selectedDevice && $selectedDevice->id  == $device->id ? 'checked' : '' }} class="form-check-input" type="radio" name="device" value="{{ $device->id }}" wire:click="selectDevice('{{ $device->id }}')">
                                <label class="form-check-label">
                                    {{ $device->name }}
                                </label>
                            </div>
                        </div>
                        @empty
                        <div>Not Found !</div>
                        @endforelse
                    </div>
                    @endif

                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> Memory Sizes</h3>
                        <div class="p-2">
                            @foreach ($memory_sizes as $memory_size)
                            <div class="form-check">
                                <input {{ $selectedMemorySize == $memory_size ? 'checked' : '' }} class="form-check-input" type="radio" name="memory_size" value="{{ $memory_size }}" wire:click="filterByMemorySize('{{ $memory_size }}')">
                                <label class="form-check-label">
                                    {{ $memory_size }}
                                </label>
                            </div>
                            @endforeach


                        </div>
                    </div>
                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> Grade</h3>
                        <div class="p-2">
                            @foreach ($grades as $key => $g)
                            <div class="form-check">
                                <input {{ $selectedGrade == $g ? 'checked' : '' }} class="form-check-input" type="radio" name="grade" value="{{ $g }}" wire:click="filterByGrade('{{ $g }}')">
                                <label class="form-check-label">
                                    {{ $g }}
                                </label>
                            </div>
                            @endforeach

                        </div>
                    </div>

                    <!-- ---------------Color-------- -->

                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> Color</h3>
                        <div class="p-2">
                            @foreach ($colors as $color)
                            <div class="form-check">
                                <input {{ $selectedColor == $color ? 'checked' : '' }} class="form-check-input" type="radio" name="color" value="{{ $color }}" wire:click="filterByColor('{{ $color }}')">
                                <label class="form-check-label">
                                    {{ $color }}
                                </label>
                            </div>
                            @endforeach


                        </div>
                    </div>
                    <!-- -------------------------price----------- -->
                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> PRICE</h3>
                        <div class="p-2">
                            <label for="customRange1" class="form-label">£0</label>
                            <input type="range" class="form-range" id="customRange1" min="0" max="12000" wire:model="price">
                            <span style="float:right;">£ {{ $price ?? '12000' }}</span>
                        </div>
                    </div>

                </div>
<div class="col-lg-9">
    <div class="row row-cols-2 row-cols-md-4 g-3 justify-content-center">
        @forelse($models as $model)
        <div class="col">
            <a href="{{ route('guest-buy-product-specs', $model['id']) }}">
                <div class="card pt-1 text-center">
                    <div class="d-flex justify-content-center">
                        <img src="{{ $model['file'] ?? '#' }}" class="img-fluid" style="width: 140px;height: 140px;" />
                    </div>
                    <div class="card-body">
                        <h6 style="font-size:13px;" class="card-text ">{{ $model['name'] }}</h6>
                        <!-- Added "d-grid" class to make the button responsive -->
                        <span style="font-size:12px;" class="btn btn-danger d-grid w-100">View Details</span>
                    </div>
                </div>
            </a>
        </div>
        @empty
        <div class="col">
            <span>Not Found!</span>
        </div>
        @endforelse
    </div>
</div>




            </div>

        </section>




    </div>



    </div>
</div>
<style>
    .kh {
        font-weight: 900 !important;
    }
</style>

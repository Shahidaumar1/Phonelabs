<div style="font-family: 'Segoe UI', Roboto, 'Helvetica Neue', 'Noto Sans', 'Liberation Sans', Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';">
    {{-- <div style="font-family: 'Segoe UI', Roboto, 'Helvetica Neue', 'Noto Sans', 'Liberation Sans', Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';" class=" mb-3 mt-3">
        <label for="post_code_area">Post Code Area</label>
        <select id="single" class="js-states form-control" wire:model.lazy="fixed.post_code_area" name="post_code_area">
            <option value="">Select Post Code Area</option>
            @foreach ($post_code_areas as $post_code_area)
                <option value="{{ $post_code_area->post_code_area . '-' . $post_code_area->price }}">
                    {{ $post_code_area->post_code_area }} --
                    {{ $post_code_area->price }}
                </option>
            @endforeach
        </select>
        @error('fixed.post_code_area')
            <span class="text-xs" style="color: red; font-size:12px;">{{ $message }}</span>
        @enderror
        
    </div> --}}

    <div class="row" style="display: flex; justify-content: center; align-items: center;">
        <div class="col-md-6 col-sm-12 col-12">
            <div>
                <div class="form-group">
                    <label for="post_code">Post Code:</label>
                    <input type="text" wire:model.debounce.500ms="post_code" wire:model.lazy="collection.post_code" class="form-control" id="post_code" placeholder="Enter Post Code">
                    @error('post_code')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <div id="resultContainer" class="mt-3">
                    @if (isset($responseData['knownAddresses']) && count($responseData['knownAddresses']) > 0)
<select wire:model="selectedAddress" class="form-select">
    <option value="" selected>Select an option</option>
    @foreach ($responseData['knownAddresses'] as $address)
        <option value="{{ $address['address_line_1'] }}">
            {{ $address['address_line_1'] }} - {{ $address['city'] }} - {{ $address['post_code'] }}
        </option>
    @endforeach
</select>


                    @else
                        <p>No addresses found or API call failed.</p>
                    @endif
                </div>
            </div>

            {{-- fixed --}}
            <div class="mb-3 mt-3">
                <label for="address_line_1">Address Line 1*:</label>
                <input type="text" class="form-control form-control-sm" id="address_line_1" wire:model.lazy="fixed.address_line_1"
                    placeholder="Address Line 1" name="address_line_1" required>
                @error('fixed.address_line_1')
                    <span class="text-xs" style="color: red; font-size:12px;">{{ $message }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="address_line_2">Address Line 2:</label>
                <input type="text" class="form-control form-control-sm" wire:model="fixed.address_line_2" id="address_line_2"
                    placeholder="Address Line 2" name="address_line_2">
            </div>
            {{-- Town/City --}}
            <div class="mb-3 mt-3">
                <label for="city">Town/City*:</label>
                <input type="text" class="form-control form-control-sm" id="city" wire:model.lazy="fixed.city"
                    placeholder="Town/City" name="city" required>
                @error('fixed.city')
                    <span class="text-xs" style="color: red; font-size:12px;">{{ $message }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="post_code">Post Code*:</label>
                <input type="text" class="form-control form-control-sm" id="post_code" wire:model.lazy="fixed.post_code"
                    placeholder="Post Code" name="post_code" required>
                @error('fixed.post_code')
                    <span class="text-xs" style="color: red; font-size:12px;">{{ $message }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="repair_date">Repair Date</label>
                <select class="form-control form-select form-control-sm" id="repair_date" name="repair_date"
                    wire:model.lazy="fixed.repair_date">
                    <option>Select Repair Date</option>
                    @php
                        use Carbon\Carbon;
                        use Carbon\CarbonInterval;
                        $currentDate = Carbon::now('Europe/London');
                        $workingDays = 0;

                        // Fetch public holidays using API
                        $year = $currentDate->year;
                        $publicHolidaysURL = "https://date.nager.at/Api/v2/PublicHolidays/{$year}/GB";

                        $publicHolidaysResponse = file_get_contents($publicHolidaysURL);
                        $publicHolidays = json_decode($publicHolidaysResponse);

                        while ($workingDays < 10) {
                            $currentDate->addDay();

                            if ($currentDate->isWeekday() && !$this->isPublicHoliday($currentDate, $publicHolidays)) {
                                $workingDays++;
                                echo '<option value="' . $currentDate->toDateString() . '">' . $currentDate->format('D d/m/Y') . '</option>';
                            }
                        }

                        function isPublicHoliday($date, $publicHolidays)
                        {
                            foreach ($publicHolidays as $holiday) {
                                if ($date->toDateString() === $holiday->date) {
                                    return true;
                                }
                            }
                            return false;
                        }
                    @endphp
                </select>
                @error('fixed.repair_date')
                    <span class="text-xs" style="color: red; font-size:12px;">{{ $message }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="repair_slot">Repair Slot</label>
                <select class="form-control form-select form-control-sm" wire:model="fixed.repair_slot" id="repair_slot">
                    <option>Select Repair Slot</option>
                    <option value="11:00 - 14:00">11:00 - 14:00</option>
                    <option value="14:00 - 17:00">14:00 - 17:00</option>
                    <option value="17:00 - 20:00">17:00 - 20:00</option>
                </select>
                @error('fixed.repair_slot')
                    <span class="text-xs" style="color: red; font-size:12px;">{{ $message }}</span>
                @enderror
            </div>
            <div class="mb-2">
                <div class="mb-3">
                    <label for="repair_note" class="form-label">Repair Note</label>
                    <textarea class="form-control" id="repair_note" wire:model="fixed.repair_note" rows="3" name="repair_note">
                        Please write any comment...
                    </textarea>
                    @error('fixed.repair_note')
                        <span class="text-xs" style="color: red; font-size:12px;">{{ $message }}</span>
                    @enderror
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col d-flex justify-content-end">
                <button type="submit" wire:click.prevent="submitForm" class="btn p-0 border-0" style="background: none;">
                    <!--<img id="next-button" src="https://ik.imagekit.io/li8bg5tjv3/1.png?updatedAt=1715028228699" style="width: 150px; height: auto;" />-->
                    <button type="submit" class="btn btn-danger customer-btn" style="margin-top: 20px; padding: 10px 4px; width: 10%; border-radius: 15px;">Next</button>
                </button>
            </div>
        </div>
    </div>
</div>

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<div>
    <livewire:components.top-bar />

    <section class="device-type-head">
        <div class="overlay"></div>
        <div class="container-fluid">
            <livewire:components.mega-nav />
            <!--<a href="{{ route('home') }}">-->


            <!--    <button class="btn btn-danger btn-sm mt-2"><svg xmlns="http://www.w3.org/2000/svg" width="35"-->
            <!--            height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">-->
            <!--            <path fill-rule="evenodd"-->
            <!--                d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z" />-->
            <!--        </svg></button>-->
            <!--</a>-->
            <div class="   align-items-center gradient-border"
                style="background-color: #EE8787; ">
                <div class="mt-3">
                    <p class="text-white" style="font-family:Space Grotesk,  Sans-Serif; font-weight:bolder; font-size:12px; text-align:center;">{!! $webContent->repair_page_heading_1 !!}
                   {!! $webContent->repair_page_heading_2 !!}</p>
                </div>
<style>
    .gradient-border {
    border: 5px solid;
    border-image-slice: 1;
    border-width: 5px;
    border-image-source: linear-gradient(to right, white, #FFB1B1);
}
</style>
                <div class="d-flex justify-content-end align-items-center">
                    {{-- <img
                        src="https://ik.imagekit.io/2nuimwatr/university-of-york-logo-3047BD6538-seeklogo.com.png?updatedAt=1699261188648"
                        style="width: 9rem; margin: 3px;" /> --}}
                    <!--<h2 class=" mt-3 ml-3 " style="color: #da0a0a"><b>Students can get 10% Off on all repairs</b></h2>-->
                </div>

            </div>
        </div>
    </section>
        <!--Breadcrumb-->
<div class="container" style="margin-top:100px; ">
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="https://mobilebitz.co.uk/">Home</a></li>
    <li class="breadcrumb-item" ><a href="https://mobilebitz.co.uk/categories">Device Type</a></li>
    <!--<li class="breadcrumb-item"><a href="https://mobilebitz.co.uk/device-types/4">Brands</a></li>-->
    <!--<li class="breadcrumb-item"><a href="https://mobilebitz.co.uk/4/models">Models</a></li>-->
  </ol>
</nav>
</div>
    <!--Progress Bar-->
    <div class="container">
        <div class="progress" style="width: 95%;">
            <div class="progress-bar progress-bar-custom" role="progressbar" style="width: 50%; " aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
    </div>
        <style>
        .progress-bar-custom {
            background-color: #EE8787; /* Dark purple color */
            border-radius: 0;
        }
                .progress {
                margin-left: 0.5rem;
                margin-right: 0.5rem;
                height: 15px;
                border-radius: 4px;
                overflow: hidden;
                background: #eee; /* Removes the rounded corners of the progress container */
        }
    </style>
    <section class="device-type-section mt-3">
        <div class="container">
            <div class="phone-section p-3" style="background-color:#EE8787; border-radius: 4px;">
                <div class="section-header text-center mt-2 p-1 text-black" 
                >
                    <h3 style="font-family: Merriweather, serif;"><sup></sup> {!! $webContent->repair_page_heading_3 !!} <sub></sub>
                    </h3>
                    <p style="font-family:Poppins;">
                        {!! $webContent->repair_page_heading_4 !!}
                    </p>

                </div>
                <div class="d-flex justify-content-center gap-3 flex-wrap  mt-3">

                    @forelse($categories as $category)
                        {{-- @php
                            $device = App\Helpers\SeoUrl::encodeUrl($category->name);
                        @endphp --}}
                        <div class="black-cards">
                            <a href="{{ route('device-types', $category->id) }}">
                                @if ($category->name != 'Apple iPad')
                                    <div class="card">
                                        <div class="card-header">
                                            <img src="{{ $category->file ?? '' }}" class="img-thumbnail border-0"
                                                style="height:150px;">
                                        </div>
                                        <div class="card-body">
                                            <h4 class="text-center">
                                                <b>{{ $category['name'] }}</b>
                                            </h4>
                                        </div>
                                    </div>
                                @endif
                            </a>
                        </div>

                    @empty
                        <span>Not Found</span>
                    @endforelse
                    
                    
                      <div class="black-cards">
                         
                                    <div class="card">
                                        <div class="card-header">
                                            <img  onclick="toggleVisibility()" class="img-thumbnail border-0"
                                                style="height:150px; width:225px;"
                                src="https://thumbs.dreamstime.com/b/d-white-man-red-questionmark-computer-generated-image-isolated-68105896.jpg"
                                alt="">
                                        </div>
                                        <div class="card-body">
                                            <h4 class="text-center" onclick="toggleVisibility()">
                                                <b>Other</b>
                                            </h4>
                                        </div>
                                    </div>
                             
                        </div>
               

                </div>

                <div class="hidediv">

                    <div style="position: relative;top:30px;">
                        <h1 class="fw-bold text-danger my-3 text-center">Can't Find Your Model?</h1>
                        <h2 class="fw-bold  my-3 text-center">Ask For Qoute Below</h2>
                    </div>
                    <div style="position: relative;" class="hidediv container bg-gray rounded-4 p-5 mt-5  mb-5">




                        <div>
                            <!-- Livewire form to collect customer information -->
                            <form wire:submit.prevent="sendCustomerEmail">
                                <!-- Form fields for customer information -->

                                <!-- Additional Input Boxes for Brand and Model -->
                                <div class="row">

                                    <div class="container col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="brand">Brand:</label>
                                            <input class="form-control" type="text" id="brand" wire:model="brand"
                                                placeholder="Enter brand">
                                            @error('brand')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="model">Model:</label>
                                            <input class="form-control" type="text" id="model" wire:model="model"
                                                placeholder="Enter model">
                                            @error('model')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div>
                                            <label class="form-label" for="additionalDescription">Additional
                                                Information:</label>
                                            <textarea class="form-control" class="form-control" id="additionalDescription" wire:model="additionalDescription"
                                                placeholder="Enter additional information"></textarea>
                                            @error('additionalDescription')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>

                                    </div>



                                    <div class="container col-md-6">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox1">Broken Screen</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox1"
                                                    wire:model="checkboxes" value="Broken Screen">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox2">Battery
                                                    Replacement</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox2"
                                                    wire:model="checkboxes" value="Battery Replacement">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox3">Charging Port
                                                    Repair</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox3"
                                                    wire:model="checkboxes" value="Charging Port Repair">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox4">Housing Issue</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox4"
                                                    wire:model="checkboxes" value="Housing Issue">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox5">Audio Fault</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox5"
                                                    wire:model="checkboxes" value="Audio Fault">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox6">Water Damage</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox6"
                                                    wire:model="checkboxes" value="Water Damage">
                                            </div>
                                        </div>

                                        <!-- "Other" Checkbox with Conditional Text Input -->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="otherCheckbox">Other</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="otherCheckbox"
                                                    wire:model="checkboxes" value="Other">
                                            </div>
                                        </div>

                                        @if (in_array('Other', $checkboxes))
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label class="form-label" for="otherText">Please
                                                        specify:</label>
                                                    <input class="form-control" type="text" id="otherText"
                                                        wire:model="otherText" placeholder="Describe other">
                                                </div>
                                            </div>
                                        @endif
                                    </div>


                                </div>


                                <div class="row mt-5">

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="firstName">First Name:</label>
                                            <input class="form-control" type="text" id="firstName"
                                                wire:model="firstName" required placeholder="Enter your first name">
                                            @error('firstName')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="lastName">Last Name:</label>
                                            <input class="form-control" type="text" id="lastName"
                                                wire:model="lastName" required placeholder="Enter your last name">
                                            @error('lastName')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="email">Email:</label>
                                            <input class="form-control" type="email" id="email"
                                                wire:model="email" required placeholder="Enter your email">
                                            @error('email')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="productName">Confirm Email</label>
                                            <input class="form-control" type="email" id="productName"
                                                wire:model="productName" required
                                                placeholder="Enter the product name">
                                            @error('productName')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="phone">Phone:</label>
                                            <input class="form-control" type="text" id="phone"
                                                wire:model="phone" required placeholder="Enter your phone number">
                                            @error('phone')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>



                                        {{-- <div>
                                        <label class="form-label" for="productDescription">Additional Info:</label>
                                        <textarea class="form-control" id="productDescription" wire:model="productDescription"
                                            placeholder="Describe More About YourSelf"></textarea>
                                        @error('productDescription')
                                            <span class="error">{{ $message }}</span>
                                        @enderror
                                    </div> --}}



                                        <div>
                                            <label class="form-label">Are you an existing customer?</label>
                                            <!-- Use Flexbox for close alignment -->
                                            <div style="width: 20%; display: flex; align-items: center; gap: 5px; ">
                                                <!-- Smaller gap -->
                                                <input class="form-check-input" type="radio"
                                                    id="existingCustomerYes" name="existingCustomer" value="yes"
                                                    wire:model="existingCustomer">
                                                <label class="form-check-label" for="existingCustomerYes">Yes</label>
                                                <!-- Label close to radio button -->

                                                <input class="form-check-input" type="radio"
                                                    id="existingCustomerNo" name="existingCustomer" value="no"
                                                    wire:model="existingCustomer">
                                                <label class="form-check-label" for="existingCustomerNo">No</label>
                                                <!-- Label close to radio button -->
                                            </div>

                                            @error('existingCustomer')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>


                                        <div>
                                            <label class="form-label">Are you a business?</label>
                                            <div style="width: 20%; display: flex; align-items: center; gap: 5px;">
                                                <!-- Minimal gap -->
                                                <input class="form-check-input" type="radio" id="isBusinessYes"
                                                    name="isBusiness" value="yes" wire:model="isBusiness">
                                                <label for="isBusinessYes">Yes</label>

                                                <input class="form-check-input" type="radio" id="isBusinessNo"
                                                    name="isBusiness" value="no" wire:model="isBusiness">
                                                <label for="isBusinessNo">No</label>
                                            </div>

                                            @error('isBusiness')
                                                <span class="error">{{ $message }}</span>
                                            @enderror
                                        </div>


                                    </div>
                                </div>
                        </div>
                        <script>
                            // Function to toggle the visibility of the target div
                            function toggleVisibility() {
                                // Select the div with class "container bg-gray rounded-4 p-5 mt-5"
                                const contentDiv = document.querySelector('.hidediv');
                                // Toggle the "d-none" class to hide/show the div
                                if (contentDiv) {
                                    // Toggle between 'none' and 'block' to show/hide
                                    contentDiv.style.display = contentDiv.style.display === 'none' ? 'block' : 'none';
                                }
                            }

                            document.addEventListener('DOMContentLoaded', () => {
                                // Hide the content div at the start of the page
                                const contentDiv = document.querySelector('.hidediv');
                                if (contentDiv) {
                                    contentDiv.style.display = 'none'; // Hide the div
                                }
                            });
                        </script>


                        <!-- Checkboxes for user selection -->



                        <!-- Submit Button -->
                        <div class="d-flex justify-content-center mt-5">
                            <button class="btn btn-danger text-white rounded-pill" type="submit">Ask For
                                Qoute</button>
                            <!-- Button to submit the form -->
                        </div>
                        </form>

                        <!-- Display success message when the email is sent -->
                        @if (session()->has('emailSent'))
                            <div>
                                <p>Thank you! The information has been sent to your email.</p>
                            </div>
                        @endif
                    </div>
                </div>


            </div>


        </div>
    </section>
<section class="container-fluid">
    <div class="row">
        <div class="col-md-12 mb-5 d-flex justify-content-center">
            <a href="https://www.trustpilot.com/review/www.mobilebitzltd.com">
                <button type="button" class="btn myreviewbtn" style="font-family: Space Grotesk; font-weight: 400; font-size: 18px;">
                    Review us on &nbsp;
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <span class="fw-bold" style="font-family: Space Grotesk; font-weight: 700; font-size: 18px;">Trustpilot</span>
                </button>
            </a>
        </div>
    </div>
    <style>
        .myreviewbtn {
            color: #003d34; /* Trustpilot's brand color for text */
            border: 1px solid #003d34; /* Trustpilot's brand color for border */
            background-color: #ffffff; /* White background */
            display: flex;
            align-items: center;
            padding: 5px 15px; /* Add some padding for better spacing */
        }

        .myreviewbtn:hover {
            background-color: #e6f8f5; /* Light green background on hover */
        }

        .fa-star {
            color: #00b067; /* Trustpilot's green color for stars */
            font-size: 16px; /* Adjust font size for better visibility */
            margin-right: 5px; /* Add space between stars */
        }

        .fw-bold {
            color: #003d34; /* Trustpilot's brand color for text */
        }
    </style>
</section>

</div>

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<div>
    <livewire:components.top-bar />

    <section class="repair-types ">
        <livewire:components.mega-nav theme="white" />
        <div class="  align-items-center gradient-border"
            style="background-color: #EE8787">
            <div class="mt-3">
                <p class="text-white" style="font-family:Space Grotesk,  Sans-Serif; font-weight:bolder; font-size:12px; text-align:center;">Need a Repair? Tell Us Which Device You Have…</p>
            </div>
            <style>
    .gradient-border {
    border: 5px solid;
    border-image-slice: 1;
    border-width: 5px;
    border-image-source: linear-gradient(to right, white, #FFB1B1);
}
</style>

            <div class="d-flex justify-content-end align-items-center">
                {{-- <img
                    src="https://ik.imagekit.io/2nuimwatr/university-of-york-logo-3047BD6538-seeklogo.com.png?updatedAt=1699261188648"
                    style="width: 9rem; margin: 3px;" /> --}}
                <!--<h2 class="text-danger mt-3 ml-3 "><b>Students can get 10% Off on all repairs</b></h2>-->
            </div>

        </div>
        <div class="text-center my-4">
            <h2 class="text-danger">Broken {{ $modal->name ?? '' }}</h2>
            <span class="tagline text-black">We can fix that!</span>
        </div>
    </section>
<!--desktop-->
<div class="d-none d-lg-block d-md-block">
    @if ($device)

        <section>
            <div class="container my-5">
                <div class=" d-flex align-items-center justify-content-center text-center">
                    <div class="d-flex gap-5 flex-wrap justify-content-center ">
               
              
                        @forelse   ($device->repair_types as $repair_type) 
                            @php
                                $price = App\Models\Price::where('modal_id', $modal->id)
                                    ->where('repair_type_id', $repair_type->id)
                                    ->first();
                                $deviceSeo = App\Helpers\SeoUrl::encodeUrl($device->name);
                                $modelSeo = App\Helpers\SeoUrl::encodeUrl($modal->name);
                                $repairSeo = App\Helpers\SeoUrl::encodeUrl($repair_type->name);
                            @endphp

                            @if ($price && $price->price > 0)
                                <div class="card p-3 d-flex justify-content-center align-items-center custom-hover"
                                    style="width: 300px; height: 350px; text-align: center; border: 1px solid #ddd; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); overflow: hidden;"
                                    data-url="{{ route('repair-detail', ['device' => $deviceSeo, 'modal' => $modelSeo, 'repair' => $repairSeo]) }}">
                                    <img src="{{ asset($repair_type->image) ?? '' }}" class="img-fluid p-3" style="height: 150px; width: auto;" alt="{{ $repair_type->name }}">
                                    <h4 class="text-center text-wrap" style="font-size: 1.2rem; margin: 10px 0;"> <b> {{ $repair_type->name }} </b></h4>
                                    <h3 style="font-size: 1.5rem; margin: 10px 0;color:#EE8787;">£ {{ $price->price }}</h3>
                                    <button class="btn btn-danger"  type="button"> Book Instant Repair</button>
                                </div>

                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        document.querySelectorAll('.card.custom-hover').forEach(function(card) {
                                            card.addEventListener('click', function() {
                                                const url = this.getAttribute('data-url');
                                                window.location.href = url;
                                            });
                                        });
                                    });
                                </script>
                                <style>
                                .custom-hover{
                                    border-radius:20px !important;
                                    width:250px !important;
                                     
                                }
                                    .custom-hover:hover {
                                        border-color: #dc3545 !important;
                                        box-shadow: 0 4px 40px #dc3545 !important;
                                        transition: border-color 0.3s ease-in-out !important;
                                        cursor: pointer !important;
                                        
                                    }
                                </style>
                            @endif

                        @empty
                            <p>No repair types found.</p>
                        @endforelse
                    </div>
                </div>
            </div>
        </section>
    @endif
    
</div>
    <!--for mobile-->
<div class="d-lg-none d-md-none">
    @if ($device)

        <section>
            <div class="container my-5">
                <div class=" d-flex align-items-center justify-content-center ">
                    <div class="d-flex gap-5 flex-wrap justify-content-center ">
               
              
                        @forelse   ($device->repair_types as $repair_type) 
                            @php
                                $price = App\Models\Price::where('modal_id', $modal->id)
                                    ->where('repair_type_id', $repair_type->id)
                                    ->first();
                                $deviceSeo = App\Helpers\SeoUrl::encodeUrl($device->name);
                                $modelSeo = App\Helpers\SeoUrl::encodeUrl($modal->name);
                                $repairSeo = App\Helpers\SeoUrl::encodeUrl($repair_type->name);
                            @endphp

                            @if ($price && $price->price > 0)
                                <div class=" card1 p-3 d-flex custom-hover"
                                    style="width: 330px !important; height: 150px; border: 1px solid #ddd; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); overflow: hidden;"
                                    data-url="{{ route('repair-detail', ['device' => $deviceSeo, 'modal' => $modelSeo, 'repair' => $repairSeo]) }}">
                                    <img src="{{ asset($repair_type->image) ?? '' }}" class="img-fluid pt-2" style="height: 100px; width: 90px" alt="{{ $repair_type->name }}">
                                    <p class=" text-wrap pt-2" style="font-size:16px;"> <b> {{ $repair_type->name }} </b></p>
                                    <h2 style="font-size:20px;padding-top:90px;margin-left:-150px;color:#EE8787;">£{{ $price->price }}</h2>
                                    
                                     <h1 class="bg-white mt-5"  type="button" style="border:none !important;margin-left:140px !important;"><i class="fa-solid fa-circle-chevron-right"></i></h1>
                                </div>

                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        document.querySelectorAll('.card1.custom-hover').forEach(function(card1) {
                                            card1.addEventListener('click', function() {
                                                const url = this.getAttribute('data-url');
                                                window.location.href = url;
                                            });
                                        });
                                    });
                                </script>
                                <style>
                                .custom-hover{
                                    border-radius:20px !important;
                                    width:250px !important;
                                     
                                }
                                    .custom-hover:hover {
                                        border-color: #dc3545 !important;
                                        box-shadow: 0 4px 40px #dc3545 !important;
                                        transition: border-color 0.3s ease-in-out !important;
                                        cursor: pointer !important;
                                        
                                    }
                                </style>
                            @endif

                        @empty
                            <p>No repair types found.</p>
                        @endforelse
                    </div>
                </div>
            </div>
        </section>
    @endif
    
</div>

    
</div>


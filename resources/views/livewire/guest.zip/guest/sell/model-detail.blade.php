<div>
        <style>
        .breadcrumb-thread {
            
            display: flex;
            flex-wrap: wrap;
            padding-top: 100px;
            padding-bottom: 50px;
            margin-bottom: 1rem;
            list-style: none;
            background-color: transparent;
            border-radius: .25rem;
        }
        .breadcrumb-thread .breadcrumb-item {
            display: flex;
            align-items: center;
            position: relative;
            
        }
        .breadcrumb-thread .breadcrumb-item + .breadcrumb-item::before {
            content: '';
            width: 200px;
            height: 2px;
            background-color: #6c757d;
            position: absolute;
            left: -190px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 1;
        }
        .breadcrumb-thread .breadcrumb-item a {
      color: #007bff;
      text-decoration: none;
      padding: 0.5rem 1rem;
      background-color: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 9999px 9999px 9999px 9999px;
      position: relative;
      z-index: 2;
      color:black;
    }
        .breadcrumb-thread .breadcrumb-item a:hover {
            color: #dc3545;
            text-decoration: none;
            border: 1px solid #dc3545;
        }
        .breadcrumb-thread .breadcrumb-item a.active {
            color: #fff;
            background-color: #dc3545;
            border-color: #dc3545;
        }
.btnn-style{
    display:flex;
    align-items: center;
    justify-content: space-between;
    flex-direction: row;
    margin: 50px 0;
    position: relative;
}
.button-20-back {
  appearance: button;
  position: absolute;
  bottom: 0;
  left: 0;
  /*width: 11%;*/
  background-color: #dc3545;
  background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
  border: 1px solid #dc3545;
  border-radius: 1rem;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset,rgba(46, 54, 80, 0.075) 0 1px 1px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Inter,sans-serif;
  font-size: 1rem;
  font-weight: 500;
  line-height: 1.7;
  margin: 0;
  padding: 6px 50px;
  text-align: center;
  text-transform: none;
  transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: middle;
}

.button-20-back:focus:not(:focus-visible),
.button-20-back:focus {
  outline: 0;
}

.button-20-back:hover {
  background-color: #dc3545;
  border-color: #dc3545;
}

.button-20-back:focus {
  background-color: #dc3545;
  border-color: #dc3545;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20-back:active {
  background-color: #dc3545;
  background-image: none;
  border-color: #dc3545;
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
}

.button-20-back:active:focus {
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20-back:disabled {
  background-image: none;
  box-shadow: none;
  opacity: .65;
  pointer-events: none;
}
.button-20-next {
  appearance: button;
  position: absolute;
  bottom: 0;
  right: 0;
  /*width: 11%;*/
  background-color: #dc3545;
  background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
  border: 1px solid #dc3545;
  border-radius: 1rem;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset,rgba(46, 54, 80, 0.075) 0 1px 1px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Inter,sans-serif;
  font-size: 1rem;
  font-weight: 500;
  line-height: 1.7;
  margin: 0;
  padding:6px 50px;
  text-align: center;
  text-transform: none;
  transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: middle;
}

.button-20-next:focus:not(:focus-visible),
.button-20-next:focus {
  outline: 0;
}

.button-20-next:hover {
  background-color: #dc3545;
  border-color: #dc3545;
}

.button-20-next:focus {
  background-color: #dc3545;
  border-color: #dc3545;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20-next:active {
  background-color: #dc3545;
  background-image: none;
  border-color: #dc3545;
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
}

.button-20-next:active:focus {
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20-next:disabled {
  background-image: none;
  box-shadow: none;
  opacity: .65;
  pointer-events: none;
}
.multi-container{
    position: relative;
}
</style>
    <livewire:components.mega-nav theme="white" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://kit.fontawesome.com/09d3c3a997.js" crossorigin="anonymous"></script>

    <!-- Navigation Bar -->
<div class="d-none d-lg-block d-md-block" style="display: flex; justify-content: center; align-items: center; margin: 0; width: 100%;">
  <div class="container mt-3" style="text-align: center; width: 100%; position: relative; left: -3%;">
    <ul class="breadcrumb-thread" id="form-navigation" style="list-style: none; padding: 0; display: flex; justify-content: space-evenly; align-items: center; width: 110%;">
      <li class="breadcrumb-item" style="margin: 0;">
        <a href="#" data-step="0">Select Option</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0;">
        <a href="#" data-step="1">Select Option</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0;">
        <a href="#" data-step="2">Personal Detail</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0;">
        <a href="#" data-step="3">Book Your Order</a>
      </li>
    </ul>
  </div>
</div>

   
        <!-- Multi-step Form Sections -->
        <div class="container mt-5" id="multi-step-form">

            <!-- Product Info Section -->
            <section id="product-info-section" class="form-step">
                
                <div class="container mt-5 ">
                    <div class="row">
                        <h6 class="text-center fs-1 fw-bold">Sell {{ $model->name }}- Mobilebitz</h6>


                        <!-- Parent View -->


                        <p class="text-center text-danger">(This enables us to offer you a preliminary estimate.)</p>
                        <div class="col-lg-6 p-5 mt-5">
                            <img src="{{ $product_spec_image ?? $model->file }}" class="img-fluid"
                                alt="Responsive Image" style="max-height: 380px;">
                        </div>

                        {{-- <div class="col-lg-6">
                            <img src="{{ $product_spec_image ?? $model->file }}" height="300px; width:300px">
                        </div> --}}
                        @php
                            $product_specs = App\Models\ProductSpec::where('model_id', $model->id)->get();
                        @endphp
                        <div class="col-lg-6  p-5 ">
                            <div>
                                @if (in_array(!null, $available_memory_sizes))
                                    <p class="fs-6 fw-bold">Select Memory Size:</p>
                                @endif

                                @forelse($available_memory_sizes as $memory_size)
                                    @if ($memory_size != null)
                                        <button type="button"
                                            class="btn btn-outline-danger {{ $memory_size == $selectedMemorySize ? 'bg-danger text-white' : '' }}"
                                            wire:click="$set('selectedMemorySize','{{ $memory_size }}')">{{ $memory_size }}</button>
                                    @endif
                                @empty
                                @endforelse

                                <div>
                                    @php
                                        // Define the custom order
                                        $customOrder = ['Excellent', 'Good', 'Fair', 'Poor', 'Faulty'];
                                        // Sort the grades array based on the custom order
                                        usort($available_conditions, function ($a, $b) use ($customOrder) {
                                            return array_search($a, $customOrder) - array_search($b, $customOrder);
                                        });
                                    @endphp
                                    <p class="fs-6 mt-3 fw-bold">Select Condition:</p>
                                    <div class="d-flex  gap-2 border-0  align-items-center" style="margin-bottom: -7px">
                                        @forelse($available_conditions as $condition)
                                            <label
                                                class=" cursor-pointer px-3  py-2 rounded-top border border-2  {{ $condition == $selectedCondition ? '  bg-gray text-black' : '' }} "
                                                wire:click="$set('selectedCondition','{{ $condition }}')">
                                                {{ $condition }}
                                            </label>

                                        @empty
                                        @endforelse
                                    </div>



                                    @if ($selectedCondition)
                                        <div class="bg-gray border-0 text-black  rounded p-2 mt-1   ">
                                            {!! $condition_text !!}
                                        </div>
                                    @endif

                                    <div class="mt-3">

                                        @if ($mobileMode || $tabletMode)
                                                                                @php
                                                                                    $network_images = [
                                                                                        'Vodafone' =>
                                                                                            'https://upload.wikimedia.org/wikipedia/commons/f/ff/Logo_vodafone_new.png',
                                                                                        'o2' => 'https://cdn2.downdetector.com/static/uploads/logo/O2-logo.jpg',
                                                                                        'Smarty' =>
                                                                                            'https://media.product.which.co.uk/prod/images/original/gm-9642cb8d-b24b-4ce6-afd6-cfac01256877-smarty.jpg',
                                                                                        'EE' =>
                                                                                            'https://c8.alamy.com/comp/EFEKFE/ee-logo-or-sign-for-mobile-network-operator-and-internet-provider-EFEKFE.jpg',
                                                                                        'Asda' =>
                                                                                            'https://media.product.which.co.uk/prod/images/original/gm-99fb2e68-49d9-4b68-be97-57f35c5e8314-asda-mobile.jpg',
                                                                                        'Tesco' =>
                                                                                            'https://media.product.which.co.uk/prod/images/original/gm-989813fb-0b40-4582-a0e8-2ab7a437429e-tesco-mobile.jpg',
                                                                                    ];
                                                                                @endphp
                                                                                <div class="col-lg-12 p-5">
                                                                                    <div>
                                                                                        @if (count($network_providers) > 0)
                                                                                            <p class="fs-6 fw-bold">Select Network:</p>
                                                                                        @endif

                                                                                        @forelse($network_providers as $network_name)
                                                                                            <!-- Adjusted to work with names -->
                                                                                            @isset($network_images[$network_name])
                                                                                                <!-- Check if the network has an image -->
                                                                                                <button type="button"
                                                                                                    class="btn {{ $network_name == $selectedNetwork ? 'bg-danger text-white' : 'btn-outline-success' }}"
                                                                                                    wire:click="selectNetwork('{{ $network_name }}')">
                                                                                                    <!-- Select network on click -->
                                                                                                    <img src="{{ $network_images[$network_name] }}"
                                                                                                        alt="{{ $network_name }}" style="width: 30px; height: 30px;" />
                                                                                                    <!-- Correctly set the image source -->
                                                                                                </button>
                                                                                            @else
                                                                                                <button type="button" class="btn btn-outline-primary">
                                                                                                    {{ $network_name }} <!-- Fallback if there's no image -->
                                                                                                </button>
                                                                                            @endisset
                                                                                        @empty
                                                                                            <p>No networks available</p> <!-- Fallback message -->
                                                                                        @endforelse
                                                                                    </div>
                                                                                </div>


                                                                                {{-- <div class="col-lg-6 p-5">
                                                                                    <div>
                                                                                        @if (count($network_providers) > 0)
                                                                                        <p class="fs-6 fw-bold">Select Network:</p>
                                                                                        @endif

                                                                                        @forelse($network_providers as $network)
                                                                                        <button type="button"
                                                                                            class="btn btn-outline-primary {{ $network == $selectedNetwork ? 'bg-primary text-white' : '' }}"
                                                                                            wire:click="selectNetwork('{{ $network }}')">
                                                                                            {{ $network }}
                                                                                        </button>
                                                                                        @empty
                                                                                        <p>No networks available for the selected memory size and condition</p>
                                                                                        <!-- Fallback message -->
                                                                                        @endforelse
                                                                                    </div>
                                                                                </div> --}}

                                                                                {{-- <tr>
                                                                                    <th>Network/unlocked</th>
                                                                                    <td>
                                                                                        <div class="form-check form-switch">
                                                                                            <input type="checkbox" role="switch"
                                                                                                class="form-check-input border border-dark"
                                                                                                wire:model="network_unlocked" id="{{ $rand . 'nu' }}" />
                                                                                        </div>
                                                                                    </td>
                                                                                </tr> --}}
                                                                                <!--<tr>-->
                                                                                <!--    <th>Account/cleared</th>-->
                                                                                <!--    <td>-->
                                                                                <!--        <div class="form-check form-switch">-->
                                                                                <!--            <input type="checkbox" role="switch"-->
                                                                                <!--                class="form-check-input border border-dark"-->
                                                                                <!--                wire:change="toggleAccountCleared" id="{{ $rand . 'ac' }}" />-->
                                                                                <!--        </div>-->
                                                                                <!--    </td>-->
                                                                                <!--</tr>-->
                                        @endif

                                        <div class="mt-3 mb-1">
                                            <div class=" mt-5 d-flex align-items-end flex-column  mb-3">
                                                <div class="text-center" id="cashText">
                                                    <h2 class=" text-danger fw-bold">Cash Value: £ {{ $price }}.00</h2>
                                                    <small>select device specification above to see price</small>
                                                </div>
                                                <div class="p-2 fs-3 fw-bold text-secondary ">
                                                    {{-- <strong>Gift e-card up to: $467.50</strong> --}}
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
            </section>

            <!-- Form Toggle Section -->
            <section id="form-toggle-section" class="form-step" style="display: none;">
                   <div class="container">
                <div class="row">
                    <!-- Form Toggle Column -->
                    <div class="col-lg-12">
                       <div class="rounded p-4" style="background-color:white; ">
  <livewire:guest.components.form-toggle :data="$data" :key="uniqid()" />
</div>

                    </div>
                </div>
            </div>
            </section>

            <!-- Patient Detail Section -->
            <section id="patient-detail-section" class="form-step" style="display: none;">
              <div>
                <div class="row justify-content-center">
                    <!-- Patient Detail Form Column -->
                    <div class="col-12 col-lg-12 rounded p-4">
                        <div>
                            <livewire:guest.components.patient-detail-form :key="uniqid()" />
                        </div>
                    </div>
                </div>
            </div>
            </section>

            <!-- Booking Section -->
            <section id="booking-section" class="form-step" style="display: none;">
                <livewire:guest.sell.booking-form />
            </section>
        </div>

        <!-- Next and Back Buttons -->
        <div class="container mt-3" style="position: relative;">
    <div class="d-flex justify-content-between">
                        <button>sell</button>

        <button type="reset" id="back-button" class="btn " style="display: block;"><img src="https://ik.imagekit.io/b6iqka2sz/prev.png?updatedAt=1719938010352" style="width: 150px; height: auto; margin-left: auto;"></button>
        <img id="next-button" type="reset" src="https://ik.imagekit.io/li8bg5tjv3/1.png?updatedAt=1715028228699" style="width: 150px; height: auto; margin-left: auto;">
    </div>
</div>
    </div>

    <!-- JavaScript for Form Navigation -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            const steps = ['#product-info-section', '#form-toggle-section', '#patient-detail-section', '#booking-section'];
            let currentStep = 0;
            let formCompleted = [true, false, false, true]; // Initialize with `false` for all steps

            function showStep(stepIndex) {
                $('.form-step').hide(); // Hide all form steps
                $(steps[stepIndex]).show(); // Show the current step

                // Show "Next" button only in the first section
                $('#next-button').toggle(stepIndex === 0);

                // Show "Back" button in the second-to-last and last sections
                $('#back-button').toggle(stepIndex === steps.length - 1 || stepIndex === steps.length - 2);
                 // Update navigation bar
                $('#form-navigation .breadcrumb-item a').removeClass('active');
                $('#form-navigation .breadcrumb-item a[data-step="' + stepIndex + '"]').addClass('active');

            }

            function moveToNextStep() {
                if (currentStep < steps.length - 1) {
                    currentStep++;
                    showStep(currentStep);
                }
            }

            $('#back-button').click(function () {
                if (currentStep > 0) {
                    currentStep--;
                    showStep(currentStep);
                }
            });

            $('#next-button').click(function () {
                // Check if form is completed for the current step
                if (formCompleted[currentStep]) {
                    moveToNextStep(); // Move to the next step
                } else {
                    alert('Please complete the current step.'); // Display validation message
                }
            });

            // Livewire event: Form submission completed successfully
            Livewire.on('formSubmitted', function () {
                formCompleted[currentStep] = true;
                moveToNextStep();
            });

            // Livewire event: Form submission failed validation
            Livewire.on('formInvalid', function () {
                formCompleted[currentStep] = false;
                showStep(currentStep); // Show current step again on validation failure
            });

            // Initial display setup
            showStep(currentStep);
        });
    </script>

    </script>
    <!-- Livewire Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/livewire/2.x/livewire.js"></script>
    <script src="https://kit.fontawesome.com/09d3c3a997.js" crossorigin="anonymous"></script>

    <!-- Livewire Scripts -->

</div>
<div>

    <livewire:components.top-bar />
    <section class="head-sell">
        <div class="container">
            <livewire:components.mega-nav />
        </div>
    </section>
    <section class="head-sell sell-bg-gradient">
        <div class="container">
            <div class="row d-flex align-items-center ">
                <div class="col-lg-6">
                    <h3 class="display-3"> {{ $model->name }}</h3>
                    <p class="lead mt-4">Sell your iphone 13 pro max series with us and get 100% of the price quoted
                        or we'll
                        send it back, free of charge!</p>
                </div>
                <div class="col-lg-2"></div>
                <div class="col-lg-4">
                    <img src="https://ik.imagekit.io/phonelab2/img1.png?updatedAt=1697193111803" class="img-fluid">
                </div>
            </div>
        </div>
    </section>


    <section>

        <div class="container mt-5 ">
            <div class="row">
                <h6 class="text-center fs-1 fw-bold">Tell us about your {{ $model->name }}</h6>
                <p class="text-center text-danger">(This enables us to offer you a preliminary estimate.)</p>
                <div class="col-lg-6 p-5">
                    <img src="https://ik.imagekit.io/phonelab2/img1.png?updatedAt=1697193111803"
                        style="margin-top:-100px;" class="img-fluid">
                </div>

                <div class="col-lg-6  p-5 ">
                    <div class="">

                        <p class="fs-6  fw-bold">Select Memory Size:</p>

                        @forelse($memory_sizes as $memory_size)
                            @if (in_array($memory_size, $available_memory_sizes))
                                <button type="button"
                                    class="btn btn-outline-danger {{ $memory_size == $selectedMemorySize ? 'bg-danger text-white' : '' }}"
                                    wire:click="$set('selectedMemorySize','{{ $memory_size }}')">{{ $memory_size }}</button>
                            @else
                                <button type="button" class="btn bg-gray" disabled>{{ $memory_size }}</button>
                            @endif
                        @empty
                        @endforelse

                    </div>

                    <p class="fs-6 mt-3 fw-bold">Select Condition:</p>


                    <div class="d-flex justify-content-between  align-items-center  ">
                        @forelse($conditions as $condition)
                            @if (in_array($condition, $available_conditions))
                                <label
                                    class="cursor-pointer d-flex gap-2 align-items-center p-2 {{ $condition == $selectedCondition ? 'bg-danger text-white' : 'bg-dark text-white' }} "
                                    wire:click="$set('selectedCondition','{{ $condition }}')">
                                    <span>&#x2713;</span>
                                    {{ $condition }}
                                </label> |
                            @else
                                <label class="d-flex gap-2 align-items-center p-2">
                                    <span>&#x2713;</span>
                                    {{ $condition }}
                                </label> |
                            @endif
                        @empty
                        @endforelse


                    </div>



                    <p class="fs-5 mt-3 fw-bold">Color: </p>
                    @php
                        $replaceColorCode = [
                            'Black' => 'black',
                            'White' => 'white',
                            'Red' => 'danger',
                            'Green' => 'success',
                            'Yellow' => 'warning',
                        ];
                    @endphp

                    <div>
                        @forelse($colors as $key => $color)
                            @if (in_array($color, $available_colors))
                                <button type="button" wire:click="$set('selectedColor','{{ $color }}')"
                                    class="p-3  btn bg-{{ $replaceColorCode[$color] }} rounded-circle shadow-sm border border-warning {{ $color == $selectedColor ? 'bg-danger text-white' : '' }}"></button>
                            @else
                                <button type="button"
                                    class="p-3  btn bg-{{ $replaceColorCode[$color] }} rounded-circle shadow-sm border "
                                    disabled></button>
                            @endif
                        @empty
                        @endforelse
                    </div>

                    <p class="fs-5 mt-3 fw-bold">Network unlocked:</p>
                    <div class="smart-bt">
                        @if ($network_unlocked)
                            <button class="fw-bold fs-5">Yes</button>
                        @else
                            <button class="fw-bold fs-5">No</button>
                        @endif
                    </div>


                    <div class=" mt-5 d-flex align-items-end flex-column  mb-3">
                        <div class="p-2 fs-1 text-danger fw-bold" id="cashText">
                            <h2>Cash Value: £{{ $price }}.00</h2>
                        </div>
                        <div class="p-2 fs-3 fw-bold text-secondary ">
                            <strong>Gift e-card up to: £467.50</strong>
                        </div>
                        <div class="mt-auto p-2 ">
                            <button type="button" class=" p-4 fs-5 rounded-pill btn btn-primary text-white ">SELL
                                THE
                                DEVICE</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>


</div>
</div>
</div>
</div>
</section>



{{-- --------------SELL PAGE 3 CODE-------------  --}}

<section>
    <div class="container p-5 mt-5 bg-gray text-black ">
        <div class="row">

            <!-- customer details form -->
            <div class="col-lg-6 p-2 ">
                <div class="">
                    <p class=" fs-1 mt-3 fw-bold text-danger">Customer Details</p>
                    <p class="">Tell us about yourself</p>

                    <form class="">
                        <div class="row">
                            <div class="col">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">First Name*</label>
                                    <input type="text" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Last Name*</label>
                                    <input type="text" class="form-control" placeholder="">
                                </div>
                            </div>

                        </div>


                        <div class="row">
                            <div class="col">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Email Address*</label>
                                    <input type="text" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Confirm Email*</label>
                                    <input type="text" class="form-control" placeholder="">
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Phone Number*</label>
                                    <input type="number" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">City/Town*</label>
                                    <input type="text" class="form-control" placeholder="">
                                </div>
                            </div>

                        </div>


                        <p class="fw-bold">Are you an existing customer?</p>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1"
                                value="option1">
                            <label class="form-check-label" for="inlineRadio1">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions"
                                id="inlineRadio2" value="option2">
                            <label class="form-check-label" for="inlineRadio2">No</label>
                        </div>
                        <p class="fw-bold">Is this a business sell?</p>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions"
                                id="inlineRadio1" value="option1">
                            <label class="form-check-label" for="inlineRadio1">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions"
                                id="inlineRadio2" value="option2">
                            <label class="form-check-label" for="inlineRadio2">No</label>
                        </div>


                    </form>

                </div>
            </div>




            {{-- ---- sell option form ----- --}}
            <div class="col-lg-6">
                <div class=" p-2">
                    <p class="fs-1 fw-bold mt-3 text-danger">Sell Options</p>
                    <p>How you'll sell your device</p>
                    <div class="d-flex justify-content-center align-items-center  ">
                        <div class="form-check address">

                            <label class="form-check-label fw-bold p-3 active" id="opt1" for="flexRadioDefault1"
                                onclick="sellStore()">
                                Sell In Store*
                            </label>
                        </div>
                        <div class="form-check">

                            <label class="form-check-label fw-bold p-3 " id="opt2" for="flexRadioDefault2"
                                onclick="postDevice()">
                                Post Your Device*
                            </label>
                        </div>
                        <div class="form-check">

                            <label class="form-check-label fw-bold p-3" id="opt3" for="flexRadioDefault2"
                                onclick="collectDevice()">
                                Collect My Device*
                            </label>
                        </div>

                    </div>
                </div>

                <!-- -------change radio forms------ -->
                <div id="style-div" class=" text-black  bg-white p-3" style="margin-top: -18px;">
                    <div id="result">
                        <div class="mb-3 mt-3">
                            <label for="disabledSelect" class="form-label fw-bold">Choose Store</label>
                            <select id="disabledSelect" class="form-select">
                                <option>Select Store</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="disabledSelect" class="form-label fw-bold">Appointment Date</label>
                            <select id="disabledSelect" class="form-select">
                                <option>Select a date</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="disabledSelect" class="form-label fw-bold">Appointment Time</label>
                            <select id="disabledSelect" class="form-select">
                                <option>Select a time</option>
                            </select>
                        </div>


                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
</section>



<section>
    <div class="container mt-5">


        <div class="container-fluid mb-5 bg-gray p-5">
            <div class="row ">


                <div class="col-lg-6  bg-gray ">
                    <h2 class="fw-bold">Billing Address</h2>
                    <div class=" p-3 mt-5">


                        <!-- -------change radio forms------ -->
                        <div id="style-div" class=" text-black bg-white p-5 border-3 border border-primary rounded-1">
                            <div id="result1">

                                <div class="mb-3">
                                    <label for="disabledSelect" class="form-label fw-bold">Your Name</label>
                                    <input type="number" class="form-control" placeholder="enter your Name">
                                </div>

                                <div class="mb-3">
                                    <label for="disabledSelect" class="form-label fw-bold">Your Account Name</label>
                                    <input type="number" class="form-control" placeholder="enter your account name">
                                </div>
                                <div class="mb-3">
                                    <label for="disabledSelect" class="form-label fw-bold">Your Account Email
                                        Address</label>
                                    <input type="number" class="form-control"
                                        placeholder=" enter your account email address">
                                </div>

                                <div class="mb-3">
                                    <label for="disabledSelect" class="form-label fw-bold">Confirm Email</label>
                                    <input type="number" class="form-control"
                                        placeholder="confirm your email address">
                                </div>


                            </div>
                        </div>
                    </div>


                </div>

                <div class="col-lg-1"></div>

                <div class="col-lg-3 p-5" style="margin-top: 58px;">
                    <div class="card text-center mb-2 border-3 border border-primary rounded-1"
                        style="width: 15rem; height:145px;">
                        <div class="card-body ">
                            <p class="card-title">PAYPAL</p>
                            <p class="card-text" style="font-size: 12px;">We will pay through paypal</p>
                            <img src="https://cdn3.iconfinder.com/data/icons/logos-and-brands-adobe/512/249_Paypal_Credit_Card-512.png"
                                width="60px" style="margin-top: -12px;">
                        </div>
                    </div>
                    <div class="card text-center mb-2" style="width: 15rem; height:149px ;">
                        <div class="card-body">
                            <p class="card-title">Bank Transfer</p>
                            <p class="card-text" style="font-size: 12px;">We will pay directly to your bank account.
                            </p>
                            <img src="https://cdn4.iconfinder.com/data/icons/simple-peyment-methods/512/bank_transfer-512.png"
                                width="60px" style="margin-top: -20px;">
                        </div>
                    </div>
                    <div class="card text-center" style="width: 15rem; height:140px;">
                        <div class="card-body">
                            <p class="card-title">Voucher</p>
                            <p class="card-text" style="font-size: 12px;">We will pay through voucher</p>
                            <img src="https://cdn-icons-png.flaticon.com/512/5939/5939991.png" width="60px"
                                style="margin-top: -12px;">
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</section>

<!-- -----------------------Product------------------- -->
<section class=" mb-4">
    <div class="container bg-gray rounded-4 p-5">
        <h1 class="fw-bold text-danger">Find your iphone Model </h1>
        <p>Choose your iphone 13 pro model and memory size to see what it’s worth...</p>
        <div class="card p-2">
            <div class="row">
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/im2.webp?updatedAt=1697193847328"
                                class="w-50">
                        </div>
                        <div class="card-body">
                            <p>iphone 13 pro max</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img2(13).jpg?updatedAt=1697193931991"
                                class="w-50">
                        </div>

                        <div class="card-body">
                            <p>iphone 13 pro </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img3(11).png?updatedAt=1697193983509"
                                class="w-50">
                        </div>

                        <div class="card-body">
                            <p>iphone 11 pro</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/images.jpeg?updatedAt=1697194026960"
                                class="w-50">
                        </div>

                        <div class="card-body">
                            <p>iphone 12 pro max</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img2(13).jpg?updatedAt=1697193931991"
                                class="w-50">
                        </div>
                        <div class="card-body">
                            <p>iphone 12 pro</p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img5(14).webp?updatedAt=1697198317015"
                                class="w-50">
                        </div>

                        <div class="card-body">
                            <p>iphone 14 pro</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img6(14).webp?updatedAt=1697198360828"
                                class="w-50">
                        </div>
                        <div class="card-body">
                            <p>iphone 14 pro max</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img7(15).webp?updatedAt=1697198405867"
                                class="w-50">
                        </div>
                        <div class="card-body">
                            <p>iphone 15 pro max</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img10(12).jpg?updatedAt=1697198454545"
                                class="w-50">
                        </div>
                        <div class="card-body">
                            <p>iphone 14 pro max</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img9(12).jpg?updatedAt=1697198504571"
                                class="w-50">
                        </div>
                        <div class="card-body">
                            <p>iphone 15 pro max</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 my-3">
                    <div class="card text-center p-3">
                        <div class="text-center">
                            <img src="https://ik.imagekit.io/phonelab2/img11(11).jpg?updatedAt=1697198565693"
                                class="w-50">
                        </div>
                        <div class="card-body">
                            <p>iphone 13 pro max</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</div>
</div>

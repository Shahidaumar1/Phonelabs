<div>
    <div>
        <livewire:components.top-bar />
        <section class="head-sell">
            <div class="container">
                <livewire:components.mega-nav />

            </div>
        </section>
        <section class="head-sell mt-5">
            <div class="container">
                 <a href="{{ route('guest-sell-categories') }}">
                        
                    <button class="btn btn-danger btn-sm"  ><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
                  <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
                </svg></button>
                    </a>
                <div class="row d-flex align-items-center">
                    <div class="col-lg-6 p-3 mt-5">
                        <h1 style="font-family: heading; ">{!! $webContent->brand_page_heading_1 !!}</h1>
                        <p style="text-align: justify;">{!! $webContent->brand_page_heading_2 !!}</p>
                    </div>
                    <div class="col-lg-6 p-3 ">
                        <img src="https://ik.imagekit.io/p2slevyg1/Best_Smartphones_US_2022-scaled.jpg?updatedAt=1698830519194" class="img-fluid">
                    </div>

                </div>
            </div>
            <div class="container mt-5 d-flex justify-content-center">
                <div class="d-flex flex-wrap col-lg-10 justify-content-center align-items-center my-4 gap-5">
                    @forelse($devices as $key => $device)
                    <a href="{{ route('guest-sell-models', $device->id) }}">
                        <div class="card shadow-sm p-3 mb-5 rounded cursor-pointer justify-content-center align-items-center">
                            <img src="{{ $device->file ?? '' }}" class="img-fluid" style="height:120px; width:140px;">
                            <!--<div class="card-body">-->
                            <!--    {{ $device->name }}-->
                            <!--</div>-->
                        </div>
                    </a>
                    @empty
                    @endforelse
                </div>
            </div>
        </section>

        {{-- <section class="select-brand">
            <div class="container py-4">
                <h2>new arrival</h2>
                <div class="row mt-4">
                    <div class="col-lg-3 col-md-6 my-2">
                        <div class="card">
                            <a href="/mobilemodel.device-type/iphonemodel.html"> <img
                                    src="https://ik.imagekit.io/phonelab2/iphone12.png?updatedAt=1697183402202"
                                    class="img-fluid"></a>
                            <div class="card-body">
                                <h3 class="card-title">IPHONE 12</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 my-2">
                        <div class="card">
                            <a href="/mobilemodel.device-type/nokiamodel.html"> <img
                                    src="https://ik.imagekit.io/phonelab2/samsung.jpg?updatedAt=1697183476627"
                                    class="img-fluid"></a>
                            <div class="card-body">
                                <a href="/mobilemodel.device-type/sumsungmodel.html">
                                    <h3 class="card-title ">Samsung</h3>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 my-2">
                        <div class="card">
                            <a href="/mobilemodel.device-type/huaweimodel.html"> <img
                                    src="https://ik.imagekit.io/phonelab2/Huawei.jpg?updatedAt=1697183531502"
                                    class="img-fluid"></a>
                            <div class="card-body">
                                <h3 class="card-title">Huawei</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 my-2">
                        <div class="card">
                            <a href="/mobilemodel.device-type/nokiamodel.html">
                                <img src="https://ik.imagekit.io/phonelab2/itel.jpg?updatedAt=1697183709404"
                                    class="img-fluid"></a>
                            <div class="card-body">
                                <h3 class="card-title">Itel</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> --}}
        <div class="container border rounded p-3 my-3">
            <h2 class="fw-bold">{!! $webContent->brand_page_heading_3 !!}</h2>
            <p>{!! $webContent->brand_page_heading_4 !!}.</p>
        </div>
    </div>

</div>
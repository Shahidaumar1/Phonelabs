
<div >
        <style>
        .breadcrumb-thread {
            
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 1rem;
            list-style: none;
            background-color: transparent;
            border-radius: .25rem;
        }
        .breadcrumb-thread .breadcrumb-item {
            display: flex;
            align-items: center;
            position: relative;
            
        }
        .breadcrumb-thread .breadcrumb-item + .breadcrumb-item::before {
            content: '';
            width: 200px;
            height: 2px;
            background-color: #6c757d;
            position: absolute;
            left: -190px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 1;
        }
        .breadcrumb-thread .breadcrumb-item a {
      color: #007bff;
      text-decoration: none;
      padding: 0.5rem 1rem;
      background-color: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 9999px 9999px 9999px 9999px;
      position: relative;
      z-index: 2;
      color:black;
    }
        .breadcrumb-thread .breadcrumb-item a:hover {
            color: #dc3545;
            text-decoration: none;
            border: 1px solid #dc3545;
        }
        .breadcrumb-thread .breadcrumb-item a.active {
            color: #fff;
            background-color: #dc3545;
            border-color: #dc3545;
        }
.btnn-style{
    display:flex;
    align-items: center;
    justify-content: space-between;
    flex-direction: row;
    position: relative;
}

</style>

    <livewire:components.mega-nav theme="white" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://kit.fontawesome.com/09d3c3a997.js" crossorigin="anonymous"></script>

     <!--Navigation Bar -->
<div class="d-none d-lg-block d-md-block" style="display: flex; justify-content: center; align-items: center; margin: 0; width: 100%;">
  <div class="container mt-3" style="text-align: center; width: 100%; position: relative; left: -3%;">
    <ul class="breadcrumb-thread" id="form-navigation" style="list-style: none; padding: 0; display: flex; justify-content: space-evenly; align-items: center; width: 110%;">
      <li class="breadcrumb-item" style="margin: 0;">
        <a href="#" data-step="0">Repair Info</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0;">
        <a href="#" data-step="1">Select Repair</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0;">
        <a href="#" data-step="2">Personal Detail</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0;">
        <a href="#" data-step="3">Book Repair</a>
      </li>
    </ul>
  </div>
</div>


        <div class="btnn-style">    
           <button class="bg-white myset " id="back-button" style="display:none;float:left;margin-left:200px;">
               <b> <i class="fa-solid  fa-circle-chevron-left"></i>   Go Back    </b> </button>
        
            <!--<button id="next-button" type="reset" class="bg-white mysetnext " role="button" style="margin-left:auto;margin-top:-50px;margin-right:175px;">-->
            <!--     <b> Next <i class="fa-solid  fa-circle-chevron-right"></i>   </b>  </button>-->
    
        </div>




    <!-- Main Content Section -->
    <div class="container multi-container" id="multi-step-form">
     
        <!-- Pre-Repair Checklist and Service Information -->
<section id="repair-info-section" class="form-step" style="margin-left:10%">
    <div class="container">
        <div class="row" >
            <!-- Checklist Column -->
<!--mobile -->
            <div class="col-lg-5 col-md-5   justify-content-center d-lg-none d-md-none " style="margin-top:-30px !important;">
                            
            <center>
                <img src="{{ asset($data['modal']['file']) ?? 'https://ik.imagekit.io/qml3d7tgz/iphone1_9JHn-8RLU.jpg' }}" style="height:210px; width:180px" />
         </center>
   <h6 class="text-danger justify-content-center mt-3">
                <center> {{ $data['modal']['name'] }}  <br> {{ $data['repair_type']['name'] }} </center></h6>

            </div>
            
            
            <div class="col-lg-6 col-md-6 ml-lg-5 ml-md-5">
               
                <div><br></div>
            
            <div class="accordion accordion-flush" id="accordionFlushExample">
    
    <div class="accordion-item">
      <h6 class="accordion-header" id="flush-heading1">
        <button class="   collapsed bg-white" type="button" style="height:40px;" data-bs-toggle="collapse" data-bs-target="#flush-collapse1" aria-expanded="false" aria-controls="flush-collapse1">
          <b class="text-danger">&#10003; How long? <i class=" ml-3 fa-solid fa-circle-right  "></i> </b>
        </button>
      </h6>
      <div id="flush-collapse1" class="accordion-collapse collapse" aria-labelledby="flush-heading1" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">  
        <h6> {{ $data['repair_type']['duration'] ?? '' }} </h6>
        </div>
      
      </div>
    </div>
    
    <div class="accordion-item">
      <h6 class="accordion-header" id="flush-heading2">
        <button class=" collapsed bg-white" type="button" style="height:40px;" data-bs-toggle="collapse" data-bs-target="#flush-collapse2" aria-expanded="false" aria-controls="flush-collapse2">
          <b class="text-danger">&#10003; Part Used? <i class=" ml-3 fa-solid fa-circle-right "></i> </b>
        </button>
      </h6>
      <div id="flush-collapse2" class="accordion-collapse collapse" aria-labelledby="flush-heading2" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">  
      <h6>  {{ $data['repair_type']['part_used'] ?? '' }} </h6>
      
        </div>
      </div>
    </div>
    
    <div class="accordion-item">
      <h6 class="accordion-header" id="flush-heading3">
        <button class=" collapsed bg-white" type="button" style="height:40px;" data-bs-toggle="collapse" data-bs-target="#flush-collapse3" aria-expanded="false" aria-controls="flush-collapse3">
          <b class="text-danger">&#10003; Warranty? <i class=" ml-3 fa-solid fa-circle-right "></i>  </b>
        </button>
      </h6>
      <div id="flush-collapse3" class="accordion-collapse collapse" aria-labelledby="flush-heading3" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">  
          <h6> {{ $data['repair_type']['warranty'] ?? '' }} </h6>       
        </div>
      
      </div>
    </div>
    
    <div class="accordion-item">
      <h6 class="accordion-header" id="flush-heading4">
        <button class=" collapsed bg-white" style="height:40px;" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse4" aria-expanded="false" aria-controls="flush-collapse4">
          <b class="text-danger">&#10003; Will my data be lost? <i class=" ml-3 fa-solid fa-circle-right "></i> </b>
        </button>
      </h6>
      <div id="flush-collapse4" class="accordion-collapse collapse" aria-labelledby="flush-heading4" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">  
         <h6> {{ $data['repair_type']['data_loss'] ?? '' }} </h6>
        </div>
      
      </div>
    </div>
    
    <div class="accordion-item">
      <h6 class="accordion-header" id="flush-heading5">
        <button class=" collapsed bg-white" style="height:40px;" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse5" aria-expanded="false" aria-controls="flush-collapse5">
          <b class="text-danger">&#10003; Post Repair Advice? <i class=" ml-3 fa-solid fa-circle-right "></i> </b>
        </button>
      </h6>
      <div id="flush-collapse5" class="accordion-collapse collapse" aria-labelledby="flush-heading5" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">  
        <h6> {!! $data['repair_type']['advice'] ?? '' !!} </h6>
        </div>
      
      </div>
    </div>
    
    <div class="accordion-item">
      <h6 class="accordion-header" id="flush-heading6">
        <button class=" myalign collapsed bg-white" style="height:40px;" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse6" aria-expanded="false" aria-controls="flush-collapse6">
          <b class="text-danger">&#10003; What if you can’t fix my device? <i class=" ml-3 fa-solid fa-circle-right "></i> </b>
        </button>
      </h6>
      <div id="flush-collapse6" class="accordion-collapse collapse" aria-labelledby="flush-heading6" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">  
        <h6> {!! $data['repair_type']['no_fix_no_fee'] ?? '' !!} </h6>
        </div>
      
      </div>
    </div>

  
  </div>
            
            
            
            
            
            
            
                
                <!--<h6><b class="text-danger">&#10003; How long?</b> {{ $data['repair_type']['duration'] ?? '' }}</h6>-->
                <!--<h6><b class="text-danger">&#10003; Part Used?</b> {{ $data['repair_type']['part_used'] ?? '' }}</h6>-->

                <!-- Hidden Content -->
                <!--<div id="moreContent" style="display: none;">-->
                <!--    <h6><b class="text-danger">&#10003; Warranty?</b> {{ $data['repair_type']['warranty'] ?? '' }}</h6>-->
                <!--    <h6><b class="text-danger">&#10003; Will my data be lost?</b> {{ $data['repair_type']['data_loss'] ?? '' }}</h6>-->
                <!--    <h6><b class="text-danger">&#10003; Post Repair Advice?</b> {!! $data['repair_type']['advice'] ?? '' !!}</h6>-->
                <!--    <h6><b class="text-danger">&#10003; What if you can’t fix my device?</b> {!! $data['repair_type']['no_fix_no_fee'] ?? '' !!}</h6>-->
                <!--</div>-->
                <!--<button id="toggleButton" class="btn bg-white text-danger" onclick="toggleContent()">See More</button>-->
            
            
            
            
            </div>
<!--Desktop-->
            <div class="col-lg-5 col-md-5   justify-content-center d-none d-lg-block d-md-block  ">
                            
            <center>
                <img src="{{ asset($data['modal']['file']) ?? 'https://ik.imagekit.io/qml3d7tgz/iphone1_9JHn-8RLU.jpg' }}" style="height:220px; width:200px" />
         </center>
   <h6 class="text-danger justify-content-center mt-1">
                <center> {{ $data['modal']['name'] }}  <br> {{ $data['repair_type']['name'] }} </center></h6>

            </div>

            
        </div>
    </div>
</section>




        <!-- Form Section Part 1 (Initial Hidden) -->
        <section id="form-section-1" class="form-step" style="display:none;">
            <div>
                <div class="row justify-content-center">
                    <!-- Patient Detail Form Column -->
                    <div class="col-12 col-lg-12 rounded p-4">
                        <div>
                            <livewire:guest.components.patient-detail-form :key="uniqid()" />
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Form Section Part 2 (Initial Hidden) -->
        <section id="form-section-2" class="form-step bg-white" style="display:none;">
            <div class="container">
                <div class="row">
                    <!-- Form Toggle Column -->
                    <div class="col-lg-12">
                        <div class="rounded p-4" style="background-color:white; ">
                            <livewire:guest.components.form-toggle :data="$data" :key="uniqid()" />
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Book Repair Component (Initial Hidden) -->
        <section id="book-repair-section" class="form-step" style="display:none;">
            <livewire:guest.components.book-repair :data="$data" :key="uniqid()" />
        
        </section>

        <!-- Back and Next Buttons -->
        <!--<div class="container-fluid mt-4">-->
        <!--    <div class="row justify-content-between">-->
        <!--        <div class="col-auto">-->
        <!--            <span id="back-button"><img src="https://ik.imagekit.io/b6iqka2sz/prev.png?updatedAt=1719938010352" style="width: 150px; height: auto; margin-left: auto;"></span>-->
        <!--        </div>-->
        <!--        <div class="col-auto">-->
        <!--          <span><img id="next-button" src="https://ik.imagekit.io/li8bg5tjv3/1.png?updatedAt=1715028228699" style="width: 150px; height: auto;" /></span>  -->
        <!--        </div>-->
        <!--        <button>Khalli balli</button>-->
        <!--    </div>-->
        <!--</div>-->
        
         <div class="btnn-style">    
           <!--<button class="button-27" id="back-button" style="display:none; height: auto;float:left;margin-left:150px;">Go Back</button>-->
        
            <button id="next-button" type="reset" class="button-27 " role="button" style=" height: auto; margin-left: auto;margin-right:20px;">Next</button>
    
        </div>
        
    </div>




    <script>
        $(document).ready(function () {
            const steps = ['repair-info-section', 'form-section-2', 'form-section-1', 'book-repair-section'];
            let currentStep = {{ $currentStep }};
            let formCompleted = [true, false, false, false]; // Initialize with `true` for intro section and `false` for others

            function showStep(stepIndex) {
                $('.form-step').hide();
                $('#' + steps[stepIndex]).show();

                if (stepIndex === 0 || stepIndex === 1) {
                    $('#back-button').hide();
                } else {
                    $('#back-button').show();
                }
                if (stepIndex == 3) {
                    $('#heading').hide();
                }

                if (stepIndex === 1 || stepIndex === 2 || stepIndex === 3) {
                    $('#next-button').hide();
                } else {
                    $('#next-button').show();
                    $('#next-button').prop('disabled', !formCompleted[stepIndex]);
                    if (!formCompleted[stepIndex]) {
                        $('#next-button').hide(); // Hide the Next button if the form is not validated
                    } else {
                        $('#next-button').show(); // Show the Next button if the form is validated
                    }
                }

                // Update navigation bar
                $('#form-navigation .breadcrumb-item a').removeClass('active');
                $('#form-navigation .breadcrumb-item a[data-step="' + stepIndex + '"]').addClass('active');
            }

            function moveToNextStep() {
                if (currentStep < steps.length - 1) {
                    currentStep++;
                    showStep(currentStep);
                }
            }

            $('#back-button').click(function () {
                if (currentStep > 0) {
                    currentStep--;
                    showStep(currentStep);
                }
            });

            $('#next-button').click(function () {
                moveToNextStep();
            });

            $('#form-navigation .breadcrumb-item a').click(function (e) {
                e.preventDefault();
                const stepIndex = $(this).data('step');
                if (stepIndex <= currentStep) {
                    currentStep = stepIndex;
                    showStep(currentStep);
                }
            });

            Livewire.on('formSubmitted', function () {
                formCompleted[currentStep] = true;
                moveToNextStep();
            });

            Livewire.on('formInvalid', function () {
                formCompleted[currentStep] = false;
                showStep(currentStep);
            });

            // Initial display setup
            showStep(currentStep);
        });

        document.addEventListener('livewire:load', function () {
            Livewire.on('formShown', function () {
                // Hide the grid container when a form is shown
                document.querySelector('.grid-container').style.display = 'none';
            });
        });

        function toggleContent() {
            var moreContent = document.getElementById("moreContent");
            var toggleButton = document.getElementById("toggleButton");

            if (moreContent.style.display === "none") {
                moreContent.style.display = "block";
                toggleButton.textContent = "See Less";
            } else {
                moreContent.style.display = "none";
                toggleButton.textContent = "See More";
            }
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/livewire/2.x/livewire.js"></script>
</div>
<style>
        .button-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 16px;
  font-weight: 600;
  line-height: normal;
  
  min-height: 60px;
  min-width: 0;
  outline: none;
  padding: 16px 24px;
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  width: 150px;
  will-change: transform;
}

.button-27:disabled {
  pointer-events: none;
}

.button-27:hover {
  box-shadow: #DC3545 0 8px 15px;
  transform: translateY(-2px);
}

.button-27:active {
  box-shadow: none;
  transform: translateY(0);
}


    /* Adjust button size for screens smaller than 768px */
    @media (max-width: 768px) {
     
.button-27 {
  appearance: none;
  background-color: #E54956;
  border: 2px solid #E54956;
  border-radius: 15px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
  font-size: 12px;
  font-weight: 400;
  line-height: normal;
  margin: 0;
  min-height: 40px;
  min-width: 100px;
  outline: none;
  
  text-align: center;
  text-decoration: none;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  will-change: transform;
}
   
        
    }

    /* Further adjust button size for screens smaller than 480px */
    @media (max-width: 480px) {
        .button-27 {
            text-align:center!important;
        width:70px !important;
        height:40px !important;
        padding:10px !important;
        font-size:16px;
        font-weight:bolder;
        margin-bottom:-100px;
        }
     
       .myalign{
           margin-right:80px !important;
       }
        
    }
       

    </style>


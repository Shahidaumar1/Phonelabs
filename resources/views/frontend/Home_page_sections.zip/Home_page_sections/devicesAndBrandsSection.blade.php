<div>
      <style>
      /* custom section 2 device and brands css start  */
      .custom-sec2 {
          padding: 0px 15px 100px 15px;
          text-align: center;
           float: left;
      }

      .custom-sec2-main small {
          font-size: 18px;
          font-family: 800;
          line-height: 24.59px;
          padding-bottom: 22px;
          color: #EA1555;
          font-family: "Manrope", sans-serif;
          font-style: normal;

      }

      .custom-sec2-main h3 {
          font-size: 32px;
          text-align: center;
          line-height: 60px;
          font-weight: 700;
          color: #000;
          font-family: "Manrope", sans-serif;
          font-style: normal;
          margin: 0 !important;
      }

      .custom-sec2-inner {
          padding: 50px 0px;
          margin-top: 0 !important;
      }

      .custom-sec2-inner .custom-sec2-box {
          display: flex;
          padding: 55px;
          flex-direction: column;
          align-items: center;
          border-radius: 20px;
          box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.25);
          background-color: #fff;
      }

      .custom-sec2-box figure {
          width: 100%;
          height: 250px;
          margin-bottom: 20px;
      }

      .custom-sec2-box figure img {
          margin: auto;
          display: block;
      }

      .custom-sec2-box a {
          width: 249px;
          height: 65px;
          font-size: 20px;
          line-height: 27.32px;
          text-decoration: none;
          font-weight: 500;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;
          border-radius: 10px;
          transition: 0.3s ease;
          font-family: "Manrope", sans-serif;
          font-style: normal;
          border: 1px solid #EA1555;
          color: #EA1555 !important;
      }

      .custom-sec2-viewAllBtn {
          width: 145px;
          height: 65px;
          font-size: 20px;
          line-height: 27.32px;
          text-decoration: none;
          font-weight: 500;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;
          border-radius: 10px;
          transition: 0.3s ease;
          font-family: "Manrope", sans-serif;
          font-style: normal;
          border: 1px solid #EA1555;
          color: #EA1555!important;
      }

      .custom-sec2-box a:hover,
      .custom-sec2-viewAllBtn:hover {
          background-color: #EA1555;
          border: 1px solid #EA1555;
          color: #fff !important;
      }

      @media(max-width:1200px) {
          .custom-sec2-inner .custom-sec2-box {
              display: flex;
              padding: 30px 15px !important;
          }

          .custom-sec2-box figure {
              height: 250px;
          }

      }

      @media(max-width:991px) {
          .custom-sec2 {
              padding: 0px 15px 50px 15px;
              text-align: center;
          }

          .custom-sec2-main small {
              font-size: 16px;
              line-height: 20px;
              padding-bottom: 10px;

          }

          .custom-sec2-main h3 {
              font-size: 24px;
              line-height: 40px;
          }

          .row.custom-sec2-inner {
              margin: 0 -7.5px !important;
              padding: 30px 0;
          }

          .row.custom-sec2-inner .col-sm-4 {
              padding: 0 7.5px !important;
          }

          .custom-sec2-inner .custom-sec2-box {
              padding: 30px 15px !important;
          }

          .custom-sec2-box a {
              width: 168px;
              height: 40px;
              font-size: 16px;
              line-height: 21.86px;
              border-radius: 10px;
          }

          .custom-sec2-viewAllBtn {
              width: 132px;
              height: 40px;
              font-size: 16px;
              line-height: 21.86px;
              border-radius: 10px;
          }

          .custom-sec2-box figure {
              width: 100%;
              height: 235px;
              margin-bottom: 20px;
          }

      }

      @media(max-width: 768px) {
          .custom-sec2 {
              padding: 0px 15px 40px 15px;
          }
          .row.custom-sec2-inner {
              row-gap:24px;
          }
      }

      @media(max-width:576px) {
          
          .custom-sec2 {
              padding: 0px 10px 30px 10px;
          }

          .custom-sec2-main small {
              font-size: 14px;
              line-height: 20px;
              padding-bottom: 8px;

          }

          .custom-sec2-main h3 {
              font-size: 20px;
              line-height: 35px;
          }


          .row.custom-sec2-inner .col-sm-4 {
              padding: 0 7.5px !important;
          }

          .custom-sec2-inner .custom-sec2-box {
              padding: 25px 15px !important;
              max-width: 293px;
              margin: 0 auto;
          }

          .custom-sec2-box a,
          .custom-sec2-viewAllBtn {
              width: 105px;
              height: 25px;
              font-size: 10px;
              line-height: 13.66px;
              border-radius: 5px;
          }


          .custom-sec2-box figure img { 
              max-width: 112px;
          }

          .custom-sec2-box figure {
              width: 100%;
              height: 140px;
              margin-bottom: 20px;
          }

      }
  </style>

  <!-- custom section 2 device and brands start  -->
  <section class="custom-sec2 w-100 float-left d-block">
      <div class="custom-container">
          <div class="custom-sec2-main">
              <small>Devices </small>
              <h3>Devices & Brands We Repair</h3>
              <div class="row custom-sec2-inner justify-content-center">
                  <!-- box 1 -->

                  <div class="col-sm-6 col-md-4 ">
                      @if ($formStatuses->repair)
                      <div class="custom-sec2-box">
                          <figure>
                              <img src="https://ik.imagekit.io/myfirstKit/irepairLondon/DeviceAndBrandsRepair/pngwing.com%20(17)%201.png?updatedAt=1731255607317" alt="feature iamge"
                                  class="img-fluid">
                          </figure>
                          <a href="/guest-buy-products">Repair Tablets</a>
                      </div>
                      @endif
                  </div>
                  <!-- box 2 -->
                  <div class="col-sm-6 col-md-4 ">
                      @if ($formStatuses->repair)
                      <div class="custom-sec2-box">
                          <figure>
                              <img src="https://ik.imagekit.io/myfirstKit/irepairLondon/DeviceAndBrandsRepair/pngwing.com%20(19)%201.png?updatedAt=1731255648604" alt="feature iamge"
                                  class="img-fluid">
                          </figure>
                          <a href="/device-types/4">Repair Phones</a>
                      </div>
                      @endif
                  </div>
                  <!-- box 3 -->
                  <div class="col-sm-6 col-md-4 ">
                      @if ($formStatuses->repair)
                      <div class="custom-sec2-box">
                          <figure>
                              <img src="https://ik.imagekit.io/myfirstKit/irepairLondon/DeviceAndBrandsRepair/pngwing.com%20(12)%201.png?updatedAt=1731255648432" alt="feature iamge"
                                  class="img-fluid">
                          </figure>
                          <a href="/guest-sell-categories">Repair Laptops</a>
                      </div>
                      @endif
                  </div>

              </div>
              <a class="mx-auto custom-sec2-viewAllBtn" href="/categories">See All</a>
          </div>
      </div>
  </section>
  <!-- custom section 2 device and brands start  -->

</div>
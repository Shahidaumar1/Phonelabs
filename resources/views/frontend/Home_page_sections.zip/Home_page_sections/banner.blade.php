
<div>
  
  <style>
      /* manorop */
      @import url('https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap');
      /* manual font */
      @import url('https://fonts.googleapis.com/css2?family=Manuale:ital,wght@0,300..800;1,300..800&display=swap');

      /* home banner sec css start */
      .home-banner-sec {
          padding: 72px 15px 155px 15px;
          background-image: url("https://ik.imagekit.io/myfirstKit/irepairLondon/bannerSecImages/Home.png?updatedAt=1731255413364");
          background-position: right top;
          background-repeat: no-repeat;
          background-color:#fff;
          background-size: cover;
          box-shadow: 0px 0px 2px 0px #00000040;
          float: left;
      }
       

      .custom-container {
          max-width: 1283px;
          margin: 0 auto;
      }

      .banner-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          align-items: center;
      }

      .banner-content .content-box1 {
          display: flex;
          flex-direction: column;
          max-width: 650px;
      }

      .banner-content .content-box1 h2 {
          font-size: 40px;
          line-height: 54.64px;
          font-weight: 700;
          padding-bottom: 50px;
          margin: 0 !important;
          font-family: "Manrope", serif;  
          font-style: normal;
      }

      .banner-btns-box1 {
          display: flex;
          margin-bottom: 51px;
      }

      .banner-btns-box1 a {
          width: 215px;
          height: 65px;
          font-size: 17px;
          line-height: 27.32px;
          text-decoration: none;
          font-weight: 500;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;
          border-radius: 10px;
          transition: 0.3s ease;
          font-family: "Manrope", serif;  
          font-style: normal;
      }

      .banner-btns-box1 a:nth-child(1) {
          background: #EA1555;
          color: white !important;
          border: 1px solid #EA1555;
          font-family: "Manrope", serif;  
          font-style: normal;
      }

      .banner-btns-box1 a:nth-child(2) {
          margin-left: 34px;
          background: #fff;
          color: #000 !important;
          border: 1px solid #000;
          font-family: "Manrope", serif;  
          font-style: normal;
      }

      .banner-btns-box1 a:nth-child(1):hover {
          background: #fff;
          color: #000 !important;
          border: 1px solid #000;
      }

      .banner-btns-box1 a:nth-child(2):hover {
          background: #EA1555;
          color: white !important;
          border: 1px solid #EA1555;
      }

      .review-banner-btn {
          font-family: "Manrope", serif;  
          font-style: normal;
          width: 421px;
          height: 65px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 17px;
          line-height: 27.32px;
          text-decoration: none;
          font-weight: 500;
          border-radius: 10px;
          color: #000;
          border: 1px solid black;
      }

      .review-banner-btn:hover {
          background: #EA1555;
          color: white !important;
          border: 1px solid #EA1555;
      }

      .review-banner-btn .banner-stars {
          padding: 0 20px;
      }

      .review-banner-btn .banner-stars i {
          color: #72AA6D !important;
          font-size: 15px;
      }

      @media(max-width: 991px) {
          .home-banner-sec {
              padding: 50px 15px 98px 15px;
          }

          .banner-content {
              grid-template-columns: 1fr;
              justify-content: center;
          }

          .banner-content .content-box1 {
              max-width: 567px;
              margin: 0 auto;
              align-items: center;
          }

          .banner-content .content-box1 h2 {
              font-size: 36px;
              line-height: 46.64px;
              padding-bottom: 34px;
              text-align: center;
          }

          .banner-btns-box1 {
              margin-bottom: 13px;
          }

          .banner-btns-box1 i {
              font-size: 11px;
          }

          .banner-btns-box1 a {
              width: 137px;
              height: 40px;
              font-size: 15px;
              border-radius: 5px;
          }

          .review-banner-btn {
              width: 100%;
              max-width: 324px;
              height: 40px;
              font-size: 15px;
              line-height: 21.32px;
              border-radius: 5px;
          }

          .review-banner-btn .banner-stars i {
              font-size: 13px;
          }

          .banner-btns-box1 a:nth-child(2) {
              margin-left: 8px;
          }
      }

      @media(max-width: 768px) {
          .banner-content .content-box1 h2 {
              font-size: 32px;
              line-height: 37.64px;
              padding-bottom: 30px;
          }

          .review-banner-btn .banner-stars {
              padding: 0 10px;
          }
      }


      @media(max-width: 576px) {
          .banner-content .content-box1 h2 {
              font-size: 26px;
              line-height: 32.64px;
              padding-bottom: 25px;
          }

          .review-banner-btn,
          .banner-btns-box1 a {
              font-size: 13px;
          }

          .home-banner-sec {
              padding: 40px 15px 80px 15px;
          }
      }

      /* home banner css end */
  </style>
  <!-- banner section start -->
  <section class="home-banner-sec w-100 float-left d-block">
      <div class="custom-container">
          <div class="banner-content">
              <div class="content-box1">
                  <h2>Your One-Stop Shop for Buying, Selling, and Repairing Devices</h2>
                  <div class="banner-btns-box1"><a href="/categories"> Book a Repair <i
                              class="fa-solid fa-arrow-right ms-2"></i></a> </div>
                  <a class="review-banner-btn" href="https://www.trustpilot.com/review/www.mobilebitzltd.com" target="blank">
                      <span>Review Us on </span>
                      <span class="banner-stars">
                          <i class="fa-solid fa-star"></i>
                          <i class="fa-solid fa-star"></i>
                          <i class="fa-solid fa-star"></i>
                          <i class="fa-solid fa-star"></i>
                          <i class="fa-solid fa-star"></i>
                      </span>
                      <span>Trustpilot</span></a>
              </div>
              <figure class="d-none d-lg-block">
                  <img src="https://ik.imagekit.io/eiqvhw193/33bf67d8fcd7bd4754281f8f80ca9a5f.gif?updatedAt=1732804327302" class="img-fluid">
              </figure>
          </div>
      </div>
  </section>

</div>
<div>
     <style> 
        .custom-container {
            max-width: 1283px;
            margin: 0 auto;

        } 
        .custom-sec6 {
            display: block;
            width: 100%;
            float: left;
            padding: 0px 15px 72px 15px;
            overflow: hidden;
        }

        .custom-sec6-content small {
            font-size: 18px;
            line-height: 24.59px;
            color: #EA1555;
            font-weight: 800 !important;
            padding-bottom: 32px;
            margin: 0 !important;
            text-transform: uppercase;
            font-family: "Manrope", serif;
            font-style: normal;
        }

        .custom-sec6-content h3 {
            font-size: 48px;
            line-height: 62px;
            letter-spacing: -1.44px;
            color: #000;
            font-weight: 700 !important;
            padding-bottom: 32px;
            margin: 0 !important;
            font-family: "Manrope", serif;
            font-style: normal;
            margin: 0 !important;
            padding-bottom: 50px;
        }

        .custom-sec6-content .content-box {
            display: flex;
            gap: 21px;
            align-items: center;
            margin-bottom: 36.14px;

        }

        .custom-sec6-content .content-box .icon-box {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background-color: #EA1555;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .custom-sec6-content .content-box .icon-box img {
            max-width: 40px;
        }

        .custom-sec6-content .content-box h5 {
            font-size: 24px;
            line-height: 24px;
            letter-spacing: -0.48px;
            color: #000;
            padding-bottom: 5px;
            margin: 0 !important;
            font-weight: 700;
            font-family: "Manrope", serif;
            font-style: normal;
        }

        .custom-sec6-content .content-box p {
            color: rgba(68, 68, 68, 0.7);
            font-size: 18px;
            letter-spacing: -0.48px;
            line-height: 24px;
            font-weight: 400;
            margin: 0 !important;
            font-family: "Manrope", serif;
            font-style: normal;
            max-width: 367px;
        }

        @media(max-width: 991px) {
            .custom-sec6 {
                padding: 0px 15px 50px 15px;
            }

            .custom-sec6-content small {
                font-size: 16px;
                line-height: 21.86px;
                padding-bottom: 10px;
                width: 100%;
                display: block;
                text-align: center;
            }

            .custom-sec6-content h3 {
                font-size: 35px;
                line-height: 30px;
                padding-bottom: 50px;
                text-align: center;
            }

            .custom-sec6-content .content-box-main {
                display: flex;
                gap: 10px;
                justify-content: center;
            }

            .custom-sec6-content .content-box {
                flex-direction: column;
                justify-content: center;
                align-items: center;
                text-align: center;
            }

            .custom-sec6-content .content-box h5 {
                font-size: 18px;
                line-height: 24px;
                padding-bottom: 0px;
            }

            .custom-sec6-content .content-box p {
                font-size: 15px;
                line-height: 20px;
                max-width: 253px;
                margin: 0 auto;
            }
        }

        @media(max-width: 768px) {
            .custom-sec6 {
                padding: 0px 15px 40px 15px;
            }

            .custom-sec6-content small {
                font-size: 10px;
                line-height: 12px;
                padding-bottom: 5px;
            }

            .custom-sec6-content h3 {
                font-size: 20px;
                line-height: 20px;
                padding-bottom: 30px;
                text-align: center;
            }


            .custom-sec6-content .content-box-main {
                justify-content: space-around;
                gap: 0;
                flex-wrap: wrap;
                margin: 0 -15px;


            }

            .custom-sec6-content .content-box {
                padding: 0 15px;
                flex: 0 0 50%;
            }


        }

        @media(max-width: 548px) {
            .custom-sec6 {
                padding: 0px 10px 30px 10px;
            }

            .custom-sec6-content .content-box-main {
                margin: 0 -5px;
            }

            .custom-sec6-content .content-box {
                padding: 0 5px;
            }

            .custom-sec6-content .content-box h5 {
                font-size: 15px;
                line-height: 15px;
            }

            .custom-sec6-content .content-box p {
                font-size: 10px;
                line-height: 12px;
                max-width: 183px;
            }

            .custom-sec6-content .content-box .icon-box {
                width: 56px;
                height: 56px;
            }

            .custom-sec6-content .content-box {
                display: flex;
                gap: 11px;
            }
        } 
    </style>
      <section class="custom-sec6">
        <div class="custom-container">
            <div class="row custom-sec6-main justify-content-center align-items-center">
                <div class="col-lg-6 order-1 order-lg-0">
                    <img src="https://ik.imagekit.io/myfirstKit/irepairLondon/whyChooseUs/Group%201000003705.png" alt="image-sec6" class="img-fluid d-block mx-auto">
                </div>
                <div class="col-lg-6 custom-sec6-content order-0 order-lg-1 pb-3 pb-lg-0">
                    <div class="ps-xl-5">
                        <small>WHY CHOOSE US</small>
                        <h3>Choose us today.</h3>
                        <div class="content-box-main">
                            <!-- box 1 -->
                            <div class="content-box">
                                <div class="icon-box"><img src="https://ik.imagekit.io/myfirstKit/irepairLondon/whyChooseUs/Frame%20(1).png" alt="icon"></div>
                                <div>
                                    <h5>Fast Working Process</h5>
                                    <p>Streamlined and efficient workflow for faster results.</p>
                                </div>
                            </div>
                            <!-- box 2 -->
                            <div class="content-box">
                                <div class="icon-box"><img src="https://ik.imagekit.io/myfirstKit/irepairLondon/whyChooseUs/Vector%20(5).png?updatedAt=1731257143609" alt="icon"></div>
                                <div>
                                    <h5>Warranty</h5>
                                    <p>Comprehensive warranty coverage for all Mobilebitz products.</p>
                                </div>
                            </div>
                            <!-- box 3 -->
                            <div class="content-box">
                                <div class="icon-box"><img src="https://ik.imagekit.io/myfirstKit/irepairLondon/whyChooseUs/Group.png?updatedAt=1731257143618" alt="icon"></div>
                                <div>
                                    <h5>24/7 Hours Support</h5>
                                    <p>Round-the-clock 24/7 customer support service available.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
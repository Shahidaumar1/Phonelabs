{{-- <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Information</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    @extends('layouts.admin')
    @php
        $slot = '';
    @endphp
    <div class="d-flex justify-content-center">
        <livewire:admin.components.side-nave active="buy" />

        <div class="container mt-5">



            <h1 class="mb-4">Contact Information</h1>

            @if (session()->has('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Selected Option</th>
                        <th scope="col">Other Option</th>
                        <th scope="col">Message</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($contacts as $contact)
                        <tr>
                            <th scope="row">{{ $contact->id }}</th>
                            <td>{{ $contact->name }}</td>
                            <td>{{ $contact->email }}</td>
                            <td>{{ $contact->phone }}</td>
                            <td>{{ $contact->selected_option }}</td>
                            <td>{{ $contact->other_option }}</td>
                            <td>{{ $contact->message }}</td>
                            <td>
                                <a href="{{ route('contacts.show', $contact->id) }}"
                                    class="btn btn-info btn-sm">View</a>
                                <a href="{{ route('contacts.edit', $contact->id) }}"
                                    class="btn btn-primary btn-sm">Edit</a>
                                <form action="{{ route('contacts.destroy', $contact->id) }}" method="POST"
                                    style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>


        </div>
    </div>
</body>

</html> --}}
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Information</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>

<body>

    @extends('layouts.admin')
    @php
        $slot = '';
    @endphp
    <div class="d-flex justify-content-center">
        <livewire:admin.components.side-nave active="buy" />

        <div class="container mt-5">
            <h1 class="mb-4">Contact Information</h1>

            @if (session()->has('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Selected Option</th>
                        <th scope="col">Other Option</th>
                        <th scope="col">Message</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($contacts as $contact)
                        <tr>
                            <th scope="row">{{ $contact->id }}</th>
                            <td>{{ $contact->name }}</td>
                            <td>{{ $contact->email }}</td>
                            <td>{{ $contact->phone }}</td>
                            <td>{{ $contact->selected_option }}</td>
                            <td>{{ $contact->other_option }}</td>
                            <td>{{ $contact->message }}</td>
                            <td class="d-flex justify-content-center gap-2">
                                <a href="{{ route('contacts.show', $contact->id) }}" class="btn btn-info btn-sm"
                                    title="View"><i class="fas fa-eye"></i></a>
                                <a href="{{ route('contacts.edit', $contact->id) }}" class="btn btn-primary btn-sm"
                                    title="Edit"><i class="fas fa-edit"></i></a>
                                <form action="{{ route('contacts.destroy', $contact->id) }}" method="POST"
                                    style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete"><i
                                            class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>

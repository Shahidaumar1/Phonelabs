<div>
    <div class="d-flex justify-content-center admin-sub-nav">
        <ul class="pt-2 gap-3" role="group">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class=" btn m-2 btn <?php echo e($active == $item['name'] ? 'selected-button' : 'unselected-button'); ?>" aria-current="page" wire:click="showData('<?php echo e($item['name']); ?>')"><?php echo e($item['name']); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/livewire/admin/sell/components/sub-nav.blade.php ENDPATH**/ ?>
<div>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l556311841-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l556311841-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l556311841-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l556311841-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l556311841-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <section class="head-sell">
            <div class="container">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l556311841-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l556311841-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l556311841-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l556311841-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l556311841-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            </div>
        </section>
        <div class="container">

            <section class="fech">
                <div class="container">
                    <div class="d-flex flex-wrap  align-items-center gap-2 px-4 p-2 rounded my-3"
                        style="box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;">
                        <h1 class="fw-bold text-dark my-3">Choose your Model</h1>
                        
                    </div>






                                        <div class="d-flex flex-wrap align-items-center justify-content-center my-2 gap-3">

                                            <?php $__empty_1 = true; $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                           <div class="card my-2 cursor-pointer align-items-center justify-content-cente pt-2">
                        <a href="<?php echo e(route('guest-sell-model-detail', $model)); ?>">
                            <img src="<?php echo e($model->file ?? ''); ?>" class="img-fluid p-3" style="height:150px; width:150px;">
                            <div class="card-body">
                                <span><?php echo e($model->name); ?></span>
                            </div>
                        </a>
                    </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="text-danger">Not Found</span>
                    
<?php endif; ?>

                                        </div>



                    <div class="container  ">
                        <!-- Search Bar -->
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-12 col-md-6">
                                    <div class="input-group mb-3">
                                        <input type="text" id="modelSearch" class="form-control rounded-pill"
                                            placeholder="Search by Model Name">
                                        <button class="btn btn-outline-secondary rounded-pill" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>


               
                    </div>

                    <!-- Include Font Awesome -->
                    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

                    <script>
                        // Function to handle model search
                        function searchModels() {
                            // Declare variables
                            var input, filter, models, modelCards, modelName, i;
                            input = document.getElementById('modelSearch');
                            filter = input.value.toUpperCase();
                            models = document.getElementById('modelContainer');
                            modelCards = models.getElementsByClassName('model-card');

                            // Loop through all model cards, and hide those that don't match the search query
                            for (i = 0; i < modelCards.length; i++) {
                                modelName = modelCards[i].getElementsByClassName("card-title")[0];
                                if (modelName.innerText.toUpperCase().indexOf(filter) > -1) {
                                    modelCards[i].style.display = "";
                                } else {
                                    modelCards[i].style.display = "none";
                                }
                            }
                        }

                        // Attach event listener to the search input
                        document.getElementById('modelSearch').addEventListener('keyup', searchModels);
                    </script>





                </div>
            </section>
            
            <div class="container border rounded p-3 my-3">
                <h2 class="fw-bold">How do I sell my mobile phone?</h2>
                <p><?php echo e($siteSettings->buisness_name ?? ''); ?> has made selling your mobile phones surprisingly easy and
                    extremely fast. We know
                    you'll be
                    pleasantly surprised
                    with the brilliant prices we offer and we're absolutely sure you'll be amazed with the simplicity
                    and
                    speed of our
                    service.</p>
                <p>We’re here to help you recycle your phone. Whether you want to sell your iPhone to upgrade to the
                    latest
                    Apple
                    smartphone or want to trade in an old Android device for the latest Samsung.</p>
            </div>
        </div>
    </div>

</div>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/guest/sell/models.blade.php ENDPATH**/ ?>
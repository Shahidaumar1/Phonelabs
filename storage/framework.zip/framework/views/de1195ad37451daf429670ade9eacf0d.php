<div>

    <?php

        $form_name = 'Fix at my address';

    ?>

    <div>

        <?php
            $storedInputValue = Session::get('storedInputValue');
        ?>
        <?php if($storedInputValue): ?>
            <p>Delievry Charges For Postal Repair: $<?php echo e($storedInputValue); ?></p>
        <?php endif; ?>






        <?php
            $storedCollectionRepairPrice = Session::get('collectionRepairPrice');
        ?>
        <?php if($storedCollectionRepairPrice): ?>
            <p style="font-size:1vw">Delivery Charges For Collection Repair: £<?php echo e($storedCollectionRepairPrice); ?></p>
        <?php endif; ?>















        <div class="rounded p-4">
            <div class="z ">
                <div class="col-md-12">
                    <?php if($data['service'] == \App\Helpers\ServiceType::REPAIR): ?>
                        <div class="form-check mb-1">
                            <input class="form-check-input" type="checkbox" checked disabled>
                            <label class="form-check-label">
                                <?php echo e($data['modal']['name']); ?> <?php echo e($data['repair_type']['name']); ?>: £
                                <?php echo e($price ? $price : 0); ?>

                            </label>
                        </div>
                    <?php endif; ?>

                    <?php if($form_type == 'postal_form'): ?>
                        <?php

                            $form_name = 'Post Your Device';

                        ?>

                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" checked disabled />
                            <label class="form-check-label">
                                Surcharge for UK return delivery : £ 15
                            </label>

                        </div>
                    <?php endif; ?>

                    <?php if($form_type == 'collection_form'): ?>
                        <?php

                            $form_name = 'Collect My Device';

                        ?>
                    <?php endif; ?>

                    <div class="my-3" wi re:ign ore.self>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.total-price', ['repairprice' => $price])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.total-price', ['repairprice' => $price]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>



                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>




                    <?php if($form_type == 'clinic_form'): ?>
                        <?php

                            $form_name = 'Store Repair';

                        ?>
                    <?php endif; ?>









                    <div class="rounded p-4">
                        <div class="row mx-5">
                            <div class="col-md-12">
                                <?php if($data['service'] == \App\Helpers\ServiceType::REPAIR): ?>
                                    <div class="form-check mb-1">
                                        <input class="form-check-input" type="checkbox" checked disabled>
                                        <label class="form-check-label">
                                            <?php echo e($data['modal']['name']); ?> <?php echo e($data['repair_type']['name']); ?>: £
                                            <?php echo e($price ? $price : 0); ?>

                                        </label>
                                    </div>
                                <?php endif; ?>

                                <?php if($form_type == 'postal_form'): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" checked disabled />
                                        <label class="form-check-label">
                                            Surcharge for UK return delivery : £ 15
                                        </label>
                                    </div>
                                <?php endif; ?>

                                <?php if($form_type == 'collection_form'): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" checked disabled />
                                        <label class="form-check-label">
                                            Surcharge for UK return delivery : £ 15
                                        </label>
                                    </div>
                                <?php endif; ?>

                                <div class="my-3" wire:ignore.self>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.total-price', ['repairprice' => $price])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.total-price', ['repairprice' => $price]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>


                                <div class="row">
                                    <div class="col-9">
                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="row justify-content-center">
                            <div class="col-lg-6  ">
                                <div class="row">
                                    <div class="col-md-12">





                                        <section class="accordion">
                                            <div class="tab ">
                                                <input class="form-check-input w-75" type="checkbox"
                                                    wire:click="changePm('paypal')" name="accordion-1" id="cb1"
                                                    checked>

                                                <label for="cb1" class="tab__label">
                                                    <div class="row border p-2 col-10 border-2 border-dark rounded">

                                                        <div class="col-6 text-start ">
                                                            <img class="img-fluid w-25"
                                                                src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png"
                                                                alt="">
                                                        </div>

                                                        <div class="col-6 text-end mt-2">
                                                            <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                        </div>

                                                    </div>

                                                </label>
                                                <div class="tab__content col-10 ">
                                                    <?php if($pm == 'paypal'): ?>
                                                        <div class="d-flex border justify-content-center">
                                                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2236549571-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l2236549571-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2236549571-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2236549571-2');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2236549571-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                        </div>
                                                    <?php endif; ?>

                                                </div>
                                            </div>

                                        </section>

                                        <section class="accordion">
                                            <div class="tab">
                                                <input class="form-check-input" wire:click="changePm('stripe')"
                                                    type="checkbox" name="accordion-1" id="cb3" check>

                                                <label for="cb3" class="tab__label">
                                                    <div class="row border p-2 col-10 border-2 border-dark rounded">

                                                        <div class="col-6 text-start ">
                                                            <img class="img-fluid w-25"
                                                                src="https://media.designrush.com/inspiration_images/135143/conversions/_1510164528_150_social-mobile.jpg"
                                                                alt="">
                                                        </div>

                                                        <div class="col-6 text-end mt-2">
                                                            <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                        </div>

                                                    </div>
                                                </label>
                                                <div class="tab__content w-75">
                                                    <?php if($pm == 'stripe'): ?>
                                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2236549571-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l2236549571-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2236549571-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2236549571-3');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2236549571-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                    <?php endif; ?>

                                                </div>
                                            </div>

                                        </section>

                                        <section class="accordion">
                                            <div class="tab">
                                                <input class="form-check-input w-75" wire:click="changePm('drop_at')"
                                                    type="checkbox" name="accordion-1" id="cb4" check>

                                                <label for="cb4" class="tab__label">
                                                    <div class="row border p-2 col-10 border-2 border-dark rounded">

                                                        <div class="col-6 text-start ">
                                                            <img class="img-fluid w-25"
                                                                src="https://cdn.shopify.com/s/files/1/0059/2435/6185/files/sp_pay_480x480.png?v=1623658014"
                                                                alt="">
                                                        </div>

                                                        <div class="col-6 text-end mt-2">
                                                            <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                        </div>

                                                    </div>
                                                </label>
                                                <div class="tab__content d-flex justify-content-center">
                                                    <?php if($pm == 'drop_at'): ?>
                                                        <button class="btn btn-success" type="button"
                                                            wire:click="BookRepair">Submit</button>
                                                    <?php endif; ?>

                                                </div>
                                            </div>

                                        </section>

                                        <section class="accordion">
                                            <div class="tab">
                                                <input class="form-check-input w-75" wire:click="changePm('klarna')"
                                                    type="checkbox" name="accordion-1" id="cb2" check>

                                                <label for="cb2" class="tab__label">
                                                    <div class="row border p-2 col-10 border-2 border-dark rounded">

                                                        <div class="col-6 text-start ">
                                                            <img class="img-fluid w-25"
                                                                src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Klarna_Payment_Badge.svg/2560px-Klarna_Payment_Badge.svg.png"
                                                                alt="">
                                                        </div>

                                                        <div class="col-6 text-end mt-2">
                                                            <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                        </div>

                                                    </div>
                                                </label>
                                                <div class="tab__content ">
                                                    <?php if($pm == 'klarna'): ?>
                                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2236549571-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l2236549571-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2236549571-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2236549571-4');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2236549571-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                    <?php endif; ?>

                                                </div>
                                            </div>

                                        </section>



                                        <style>
                                            :root {
                                                --primary: #227093;
                                                --secondary: #ff5252;
                                                --background: #eee;
                                                --highlight: #ffda79;
                                                /* Theme color */
                                                --theme: var(--primary);
                                            }



                                            /* Core styles/functionality */
                                            .tab input {
                                                position: absolute;
                                                opacity: 0;
                                                z-index: -1;
                                            }

                                            .tab__content {
                                                max-height: 0;
                                                overflow: hidden;
                                                transition: all 0.35s;
                                            }

                                            .tab input:checked~.tab__content {
                                                max-height: 10rem;
                                            }

                                            /* Visual styles */
                                            .accordion {
                                                color: var(--theme);
                                                /* border: 2px solid; */
                                                border-radius: 0.5rem;
                                                overflow: hidden;
                                            }

                                            .tab__label,
                                            .tab__close {
                                                display: flex;
                                                color: black;
                                                /* background: var(--theme); */
                                                cursor: pointer;
                                            }

                                            .tab__label {
                                                justify-content: space-between;
                                                padding: 1rem;
                                            }

                                            .tab__label::after {
                                                /* content: "\276F"; */
                                                width: 1em;
                                                height: 1em;
                                                text-align: center;
                                                transform: rotate(90deg);
                                                transition: all 0.35s;
                                            }

                                            .tab input:checked+.tab__label::after {
                                                transform: rotate(270deg);
                                            }

                                            .tab__content p {
                                                margin: 0;
                                                padding: 1rem;
                                            }

                                            .tab__close {
                                                justify-content: flex-end;
                                                padding: 0.5rem 1rem;
                                                font-size: 0.75rem;
                                            }

                                            .accordion--radio {
                                                --theme: var(--secondary);
                                            }

                                            /* Arrow animation */
                                            .tab input:not(:checked)+.tab__label:hover::after {
                                                animation: bounce .5s infinite;
                                            }

                                            @keyframes bounce {
                                                25% {
                                                    transform: rotate(90deg) translate(.25rem);
                                                }

                                                75% {
                                                    transform: rotate(90deg) translate(-.25rem);
                                                }
                                            }
                                        </style>




                                        <div class=" gap-2">
                                            <?php if($form_type == 'clinic_form'): ?>
                                            <?php endif; ?>

                                        </div>
                                    </div>



                                </div>

                            </div>
                            <div class="col-lg-6">

                                <div style="position:relative;top:10px;" class="container">

                                    <table class="table table-striped border mt-2">
                                        <thead>



                                            <tr>
                                                <th colspan="2" class="text-center text-danger fw-bolder fs-3">
                                                    Repair
                                                    Summary</th> <!-- Center-aligned heading -->
                                            </tr>





                                            <tr>

                                                <td>Model</td>
                                                <td class="text-end">
                                                    <?php echo e($data['modal']['name']); ?>

                                                </td>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="justify-content-between">

                                                <td>Type</td>
                                                <td class="text-end"><?php echo e($form_name); ?></td>

                                            </tr>





                                            <tr>
                                                <?php if($form_type == 'postal_form'): ?>
                                                    <td style="white-space: nowrap;">Postal Charges</td>
                                                <?php endif; ?>

                                                <?php if($form_type == 'collection_form'): ?>
                                                    <td style="white-space: nowrap;">Collection Charges</td>
                                                <?php endif; ?>

                                                <?php if($form_type == 'fix_form'): ?>
                                                    <td style="white-space: nowrap;">Fix Charges</td>
                                                <?php endif; ?>
                                                <?php if($form_type == 'clinic_form'): ?>
                                                    <td>Service Charges</td>
                                                <?php endif; ?>

                                                <td class="text-end">

                                                    <div>
                                                        
                                                        <?php if($form_type == 'postal_form'): ?>
                                                            £ <?php echo e($condition1Price); ?>

                                                        <?php endif; ?>

                                                        <?php if($form_type == 'collection_form'): ?>
                                                            £ <?php echo e($condition2Price); ?>

                                                        <?php endif; ?>

                                                        <?php if($form_type == 'fix_form'): ?>
                                                            £ <?php echo e($condition3Price); ?>

                                                        <?php endif; ?>
                                                        <?php if($form_type == 'clinic_form'): ?>
                                                            0
                                                        <?php endif; ?>

                                                    </div>

                                                    

                                                </td>

                                            </tr>


                                            <tr>

                                                <td style="white-space: nowrap;">Prodcut Price</td>


                                                <td class="text-end">

                                                    <div>
                                                        

                                                        <?php if($form_type == 'postal_form'): ?>
                                                            £<?php echo e($price - $condition1Price); ?>

                                                        <?php endif; ?>

                                                        <?php if($form_type == 'collection_form'): ?>
                                                            £<?php echo e($price - $condition2Price); ?>

                                                        <?php endif; ?>

                                                        <?php if($form_type == 'fix_form'): ?>
                                                            £<?php echo e($price - $condition3Price); ?>

                                                        <?php endif; ?>
                                                        <?php if($form_type == 'clinic_form'): ?>
                                                            £ <?php echo e($price); ?>

                                                        <?php endif; ?>
                                                        

                                                </td>

                                            </tr>

                                            <tr>

                                                <td style="white-space: nowrap;">Total Price</td>


                                                <td class="text-end">

                                                    <div>
                                                        
                                                        £ <?php echo e($price ?? ''); ?>.00

                                                </td>

                                            </tr>





                                            <tr>

                                                <td>Repair time</td>
                                                <td class="text-end">1 Hour </td>

                                            </tr>


                                            <tr>

                                                <td>Warrenty</td>
                                                <td class="text-end"> 12 months </td>

                                            </tr>

                                        </tbody>
                                    </table>
                                </div>










                            </div>
                        </div>


                        <?php if($pm == 'stripe'): ?>
                        <?php endif; ?>
                        <?php if($pm == 'paypal'): ?>
                        <?php endif; ?>

                        <?php if($pm == 'klarna'): ?>
                        <?php endif; ?>

                        <?php if($pm == 'drop_at' && $form_type == 'clinic_form'): ?>

                            <div class="d-flex justify-content-between align-items-center">
                                <?php if($success): ?>
                                    <div class="alert alert-success" role="alert">
                                        <h4 class="alert-heading">Congratulations! 🎉 Your order has been successfully
                                            placed.
                                        </h4>
                                        <p>Sit tight while we process your request. Check your email for more
                                            instructions.
                                        </p>
                                        <hr>
                                        <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
                                    </div>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>

                        <?php endif; ?>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>
</div>
<?php /**PATH /home/mobilebitz/test.mobilebitz.co.uk/resources/views/livewire/guest/components/book-repair.blade.php ENDPATH**/ ?>
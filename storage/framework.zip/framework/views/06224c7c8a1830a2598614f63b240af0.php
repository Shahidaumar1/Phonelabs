<div class="" style="overflow: hidden;">
  <!-- Your existing code here -->
  <div class="row">
    <div class="col">
      <div class="d-flex flex-column flex-md-row">
          
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'settings'])->html();
} elseif ($_instance->childHasBeenRendered('l1169510851-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1169510851-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1169510851-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1169510851-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'settings']);
    $html = $response->html();
    $_instance->logRenderedChild('l1169510851-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald033566f468fc7bb3a8d0f946fdab616 = $attributes; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.settings.components.top-nav', ['active' => 'payment'])->html();
} elseif ($_instance->childHasBeenRendered('l1169510851-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1169510851-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1169510851-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1169510851-1');
} else {
    $response = \Livewire\Livewire::mount('admin.settings.components.top-nav', ['active' => 'payment']);
    $html = $response->html();
    $_instance->logRenderedChild('l1169510851-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

          <div class="container">
            <h2 class=" px-3 pt-1 pt-md-5 pb-3"><b> Payment Gateway</b></h2>
            <p class="px-3 py-1">
              A payment gateway facilitates secure online payments for businesses.
            </p>

              <div class="ml-2 d-flex  gap-2 align-items-center">
                <label class="  p-3 text-center  <?php echo e($pm == 'Paypal' ? 'selected-button' : 'unselected-button'); ?> cursor-pointer" wire:click='$set("pm","Paypal")'>Paypal</label>
                <label class=" p-3 text-center <?php echo e($pm == 'Stripe' ? 'selected-button' : 'unselected-button'); ?> cursor-pointer" wire:click='$set("pm","Stripe")'>Stripe</label>
              </div>
              
            <div class="px-3 pt-3">
              <?php if($pm == 'Paypal'): ?>
              <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.settings.components.paypal', [])->html();
} elseif ($_instance->childHasBeenRendered('l1169510851-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l1169510851-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1169510851-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1169510851-2');
} else {
    $response = \Livewire\Livewire::mount('admin.settings.components.paypal', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1169510851-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              <?php endif; ?>

              <?php if($pm == 'Stripe'): ?>
              <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.settings.components.stripe', [])->html();
} elseif ($_instance->childHasBeenRendered('l1169510851-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l1169510851-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1169510851-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1169510851-3');
} else {
    $response = \Livewire\Livewire::mount('admin.settings.components.stripe', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1169510851-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              <?php endif; ?>
            </div>
          </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $attributes = $__attributesOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__attributesOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>

      </div>
    </div>
  </div>
</div>

                
        <!----------------------------- footer-------------------------->
        
        <style>
        .button-sticky {
            height: 60px;
            color: white;
            font-family: sans-serif;
            font-size: 15px;
            line-height: 15px;
            text-align: center;
            position: fixed !important;
            bottom: -2px;
            z-index: 999;
            width: 100%;
         
        }
        
        .home-btn:hover {
            color: orange;
        }
        .button-sticky .col-2 {
            margin-right: 5px; /* Adjust this value to set the desired gap */
        }
        
        
        
        </style>
        <div class="button-sticky container bg-blue d-lg-none d-md-none">
            <div class="row ">
        
                <div class="col-2  mt-4 ml-1">
                    <a href="<?php echo e(route('payment-methods-settings')); ?>" class="text-white item ">  Payment</a>
             
             
                </div>
        
                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('site-settings')); ?>" class="text-white  item "> site-settings</a>
                
                </div>
        
                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('branches-settings')); ?>" class="text-white  item "> Branches</a>
                </div>
        
                <div class="col-2 mt-4">
                    <a href="<?php echo e(route('create-branches')); ?>" class="text-white  item ">Create</a>
                </div>
                <div class="col-2 mt-4">
                    <a href="<?php echo e(route('services-settings')); ?>" class="text-white  item ">Services</a>
                </div>
            </div>
        </div><?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/livewire/admin/settings/payment-methods.blade.php ENDPATH**/ ?>
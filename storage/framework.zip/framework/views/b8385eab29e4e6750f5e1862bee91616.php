<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<?php
use App\Models\FormStatus;

$formStatuses = FormStatus::where('name', 'services')->first();

?>

<div>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('CZxyOht')) {
    $componentId = $_instance->getRenderedChildComponentId('CZxyOht');
    $componentTag = $_instance->getRenderedChildComponentTagName('CZxyOht');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CZxyOht');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('CZxyOht', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                  

<section class="home overflow: hidden;" ">
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('B0UsyCk')) {
    $componentId = $_instance->getRenderedChildComponentId('B0UsyCk');
    $componentTag = $_instance->getRenderedChildComponentTagName('B0UsyCk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('B0UsyCk');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('B0UsyCk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div class="col-lg-6 card-home p-5 bg-white text-black" style="width: 600px; margin-top:146px; position: absolute; top: 146px;">
    <h1><?php echo $webContent->getstarted1; ?></h1>
    <h1 class="animated" style="font-family: heading;font-size:20px;"><?php echo $webContent->getstarted2; ?></h1>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.search-bar')->html();
} elseif ($_instance->childHasBeenRendered('uZS1MRG')) {
    $componentId = $_instance->getRenderedChildComponentId('uZS1MRG');
    $componentTag = $_instance->getRenderedChildComponentTagName('uZS1MRG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uZS1MRG');
} else {
    $response = \Livewire\Livewire::mount('components.search-bar');
    $html = $response->html();
    $_instance->logRenderedChild('uZS1MRG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <p><?php echo $webContent->getstarted3; ?></p>
    <a class="btn btn-danger bg-danger px-5" href="#services"><?php echo $webContent->getstarted_btn; ?></a>
</div>

    </div>
</section>


    <section class="device-Fixed" id="services">
        <div class="container">
         <h1 class="text-center my-3 bg-white p-2 rounded" style="font-family: heading; font-size: 50px;"><?php echo $webContent->home_sec_1; ?></h1>

            <div class="row my-5 justify-content-center">
                
                <?php if($formStatuses->sell): ?>
                <div class="col-lg-4 col-md-6 my-2">
                    <a href="<?php echo e(route('guest-sell-categories')); ?>">
                        <div class="card j">
                            <img src="<?php echo e(asset('assets/kimges/sell-phone-online.jpg')); ?>" class="img-fluid img-thumbnail ">
                            <div class="card-body align-self-center">
                                <h3><?php echo $webContent->home_sell_btn; ?></h3>
                            </div>
                        </div>
                    </a>
                </div>
                
                <?php endif; ?>
                <?php if($formStatuses->buy): ?>
                <div class="col-lg-4 col-md-6 my-2">
                    <a href="<?php echo e(route('guest-buy-products')); ?>">
                        <div class="card">
                            <img src="<?php echo e(asset('assets/kimges/buycard.jpg')); ?>" class=" img-fluid img-thumbnail Device ">
                            <div class="card-body align-self-center">
                                <h3 class=""><?php echo $webContent->home_buy_btn; ?></h3 class="pl-3">
                            </div>
                        </div>
                    </a>
                </div>
                
                <?php endif; ?>
                <?php if($formStatuses->repair): ?>
                <div class="col-lg-4 col-md-6 my-2">
                    <a href="<?php echo e(route('categories')); ?>">
                        <div class="card ">
                            <img src="<?php echo e(asset('assets/kimges/repair.jpg')); ?>" class="img-fluid img-thumbnail ">
                            <div class="card-body d-flex align-items-center justify-content-center">
    <h3><?php echo $webContent->home_repair_btn; ?></h3>
</div>

                            
                            <!--<div class="card-body align-self-cente  justify-content-center">-->
                            <!--    <h3 >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $webContent->home_repair_btn; ?></h3 class="">-->
                            <!--</div>-->
                    </a>
                </div>
            </div>
                <?php endif; ?>
                   <?php if($formStatuses->accessories): ?>
                <div class="col-lg-4 col-md-6 my-2">
                    <!--<a href="<?php echo e(route('guest-sell-categories')); ?>">-->
            <a href="<?php echo e(route('khuram')); ?>">


                        <div class="card j">
                            <img src="<?php echo e(asset('assets/kimges/sell-phone-online.jpg')); ?>" class="img-fluid img-thumbnail ">
                            <div class="card-body align-self-center">
                                <h3>Accessroires</h3>
                            </div>
                        </div>
                    </a>
                </div>
                
                <?php endif; ?>
                
            <br><br>
          
            <div class="row my-5" style="margin-top:20px;">
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card p-4 text-center">
                        <img src="<?php echo e(asset('assets/img/c1.png')); ?>" class="w-25 mx-auto" alt="icon">
                        <h5 style="font-size: 17px;" class="pt-3 fw-bold">Eco Friendly</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card p-4 text-center">
                        <img src="<?php echo e(asset('assets/img/c2.png')); ?>" class="w-25 mx-auto" alt="icon">
                        <h5 style="font-size: 15px;" class="pt-3 fw-bold">Over 1M Customers</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card p-4 text-center">
                        <img src="<?php echo e(asset('assets/img/c3.png')); ?>" class="w-25 mx-auto" alt="icon">
                        <h5 style="font-size: 15px;" class="pt-3 fw-bold">Fast Delievery</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 my-3">
                    <div class="card p-4 text-center">
                        <img src="<?php echo e(asset('assets/img/c4.png')); ?>" class="w-25 mx-auto" alt="icon">
                        <h5 style="font-size: 15px;" class="pt-3 fw-bold">Over 20 years of experience</h5>
                    </div>
                </div>
            </div>
        </div>
     
</div>
</section>
<!--     <div class="container" data-aos="fade-up">-->
<!--    <img src="<?php echo e(asset('assets/img/gr.png')); ?>" class="img-fluid py-3">-->
<!--</div>-->
<!-----------------------------------slider---------->

<!--<div class="container-d">-->
<!--    <div class="row align-items-center ">-->
<!--        <div class="container rounded">-->
<!--            <div class="slider">-->
<!--                <div class="logos">-->
<!--                    <img class="pp"-->
<!--                        src="https://www.freepnglogos.com/uploads/apple-logo-png/apple-logo-png-ios-support-the-pipeline-virtual-ecotourism-9.png"-->
<!--                        class="img-fluid " width="30" height="100">-->
<!--                    <img class="pp"src="<?php echo e(asset('assets/img/10.png')); ?>" class="img-fluid">-->
<!--                    <img class="pp"src="<?php echo e(asset('assets/img/6.png')); ?>" class="img-fluid">-->
<!--                    <img class="pp"src="<?php echo e(asset('assets/img/16.png')); ?>" class="img-fluid">-->
<!--                    <img class="pp"src="<?php echo e(asset('assets/img/14.png')); ?>" class="img-fluid">-->


<!--                </div>-->
<!--                <div class="logos">-->
<!--                    <img class="pp"src="<?php echo e(asset('assets/img/12.png')); ?>" class="img-fluid">-->
<!--                    <img class="pp"src="<?php echo e(asset('assets/img/15.png')); ?>" class="img-fluid">-->
<!--                    <img class="pp" src="<?php echo e(asset('assets/img/6.png')); ?>" class="img-fluid"-->
<!--                        style="margin-left: 10px;">-->
<!--                    <img class="pp" src="<?php echo e(asset('assets/img/16.png')); ?>" class="img-fluid"-->
<!--                        style="margin-left: 10px;">-->
<!--                    <img class="pp" src="<?php echo e(asset('assets/img/14.png')); ?>" class="img-fluid"-->
<!--                        style="margin-left: 10px;">-->
<!--                    <img class="pp" src="<?php echo e(asset('assets/img/12.png')); ?>" class="img-fluid"-->
<!--                        style="margin-left: 10px;">-->
<!--                    <img class="pp" src="<?php echo e(asset('assets/img/15.png')); ?>" class="img-fluid"-->
<!--                        style="margin-left: 10px;">-->
<!--                </div>-->

<!--            </div>-->
<!--        </div>-->
<!--    </div>-->

<!--</div>-->




<!--<section class="Expert bg-danger">-->
<!--    <div class="container">-->
<!--        <div class="row d-flex align-items-center">-->
<!--            <div class="col-lg-5" data-aos="fade-up" data-aos-duration="1000">-->
<!--                <h1 class=" text-white display-2 p-4">Expert Support</h1>-->
<!--                <p class="lead text-white my-5">Faulty phone battery? Slow laptop? We have <br>-->
<!--                    tech experts who can assist you. Visit us in stores!</p>-->
<!--                <h5 class="h4">-->
<!--                    Empower your device's potential with expert repairs.-->
<!--                </h5>-->
<!--            </div>-->
<!--            <div class="col-lg-2"></div>-->
<!--            <div class="col-lg-4" data-aos="fade-up" data-aos-duration="2000">-->
<!--                <img src="<?php echo e(asset('assets/img/Rectangle 16.png')); ?>" class="img-fluid">-->
<!--            </div>-->
<!--            <div class="col-lg-1"></div>-->
<!--        </div>-->
<!--        <div class="row my-4 d-flex justify-content-between">-->
<!--            <div class="col-lg-3 col-md-5 box2 my-3 " data-aos="fade-up" data-aos-duration="1000">-->
<!--                <a href="<?php echo e(route('categories')); ?>">-->
<!--                    <img src="<?php echo e(asset('assets/img/Send.png')); ?>" width="70px">-->
<!--                    <h2 class="mt-4 text-white">Book Repair <br>-->
<!--                        Visit us</h2>-->
<!--                </a>-->
<!--            </div>-->
<!--            <div class="col-lg-3 col-md-5 box2 my-3" data-aos="fade-up" data-aos-duration="2000">-->
<!--                <a href="<?php echo e(route('categories')); ?>">-->
<!--                    <img src="<?php echo e(asset('assets/img/bi.png')); ?>" width="70px">-->
<!--                    <h2 class="mt-4 text-white">Book Repair <br>-->
<!--                        Call out Servive</h2>-->
<!--                </a>-->
<!--            </div>-->
<!--            <div class="col-lg-3 box2 my-3" data-aos="fade-up" data-aos-duration="3000">-->
<!--                <a href="<?php echo e(route('categories')); ?>">-->
<!--                    <img src="<?php echo e(asset('assets/img/Plus.png')); ?>" width="70px">-->
<!--                    <h2 class="mt-4 text-white">Post Your <br>-->
<!--                        Device</h2>-->
<!--                </a>-->
<!--            </div>-->
<!--        </div>-->

<!--    </div>-->
<!--</section>-->

<div class="container">
    <div class="row my-5 d-flex align-items-center">
        <div class="col-lg-4">
          <h1 style="font-family: heading; font-size: 50px;">Store Repair - Postal Repair
</h1>
<p>Most repairs are done while you wait.
</p>

            <a href="<?php echo e(route('categories')); ?>"> <button class="btn btn-danger px-5">Book Repair </button></a>
        </div>
        <div class="col-lg-4"><img src="<?php echo e(asset('assets/kimges/iphone14.jpg')); ?>" class="img-fluid"></div>
        <div class="col-lg-4"><img src="<?php echo e(asset('assets/kimges/phon.jpg')); ?>" class="img-fluid"></div>
    </div>
</div>

</section>


<!-- <section class="Expert bg-danger">
    <div class="container">


        <div class="row">
            <div class="col-lg-3  col-md-6 my-3" data-aos="fade-up" data-aos-duration="1000">
                <div class="card">
                    <img src="<?php echo e(asset('assets/img/ll1.png')); ?>" class="img-fluid img-thumbnail">
                    <div class="p-3">
                        <h2>iCrack Norwich</h2>
                        <p><img class="img-thumbnail" src="<?php echo e(asset('assets/img/plus1.png')); ?>" />
                            109 st stephen
                            arcade, Chapelfied RD,
                            Norwich
                            NR2 1SB</p>
                        &#9734;
                        &#9733;
                        &#9733;
                        &#9733;
                        &#9733;


                        <span style="float: right;">4.8</span>
                    </div>
                </div>
            </div>
            <div class=" col-lg-3  col-md-6 my-3" data-aos="fade-up" data-aos-duration="2000">
                <div class="card">
                    <img src="<?php echo e(asset('assets/img/l2.png')); ?>" class="img-fluid img-thumbnail">
                    <div class=" p-3">
                        <h2>iRepair Norwich</h2>
                        <p><img class="img-thumbnail" src="<?php echo e(asset('assets/img/plus1.png')); ?>" />25 Gentleman’s
                            walk
                            Norwich NR2 1NA</p>
                        &#9733;
                        &#9733;
                        &#9733;
                        &#9733;
                        &#9733;
                        <span style="float: right;">4.9</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-3  col-md-6 my-3" data-aos="fade-up" data-aos-duration="3000">
                <div class="card">
                    <img src="<?php echo e(asset('assets/img/l3.png')); ?>" class="img-fluid img-thumbnail" />
                    <div class=" p-3">
                        <h2>Phone Land </h2>
                        <p><img class="img-thumbnail" src="<?php echo e(asset('assets/img/plus1.png')); ?>" />106, London RD
                            N,
                            lowestoft NR32 1HA</p>
                        &#9734;
                        &#9733;
                        &#9733;
                        &#9733;
                        &#9733;
                        <span style="float: right;">4.7</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 my-3" data-aos="fade-up" data-aos-duration="3000">
                <div class="card">
                    <img src="<?php echo e(asset('assets/img/l4.png')); ?>" class="img-fluid img-thumbnail">
                    <div class=" p-3">
                        <h2>iRepair York</h2>
                        <p><img class="img-thumbnail" src="<?php echo e(asset('assets/img/plus1.png')); ?>">22-24
                            Spurriengate,
                            York YO1 9QR </p>
                        <br />
                        &#9734;
                        &#9733;
                        &#9733;
                        &#9733;
                        &#9733;
                        <span style="float: right;">4.8</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->
<div class="container">
        <div class="row no-gutters">
            <div class="col-6 no-gap d-md-flex d-none d-lg-flex" style="margin-top:123px">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d9934.189251394382!2d-0.3701165!3d51.5031742!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2s!4v1720787968724!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <div class="col-md-6 col-12 no-gap">
            
              <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.user-dashboard.index', [])->html();
} elseif ($_instance->childHasBeenRendered('9i4jvzS')) {
    $componentId = $_instance->getRenderedChildComponentId('9i4jvzS');
    $componentTag = $_instance->getRenderedChildComponentTagName('9i4jvzS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9i4jvzS');
} else {
    $response = \Livewire\Livewire::mount('guest.user-dashboard.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('9i4jvzS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
       </div>
        </div>
    </div>
<div class="container-fluid mb-5">
    <?php echo $siteSettings->map_link; ?>

</div>



</div>

<?php echo \Livewire\Livewire::scripts(); ?>



<?php $__env->stopSection(); ?>
<style>
    .box {
        background-color: white;
        padding: 20px 20px;
        border-radius: 0px 50px 0px 50px;
        border-top: 5px solid black;
        border-left: 5px solid black;
    }

    .box2 {
        border-radius: 0px 100px 0px 0px;
        background-color: #da0a0a;
        padding: 70px 0px;
        text-align: center;
        flex-direction: column;
        display: flex;
        align-items: center;
        border: 10px double white;
    }

    .h4 {
        background: white;
        padding: 20px 10px;
        border-radius: 0px 40px 0px 0px;
    }

   .home {
        width: 100%;
        height: 100vh;
        background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://itouchrepair.com/wp-content/uploads/2019/02/trusted-repair-shop-in-arlington-va-itouch.jpg');
        background-size: cover;
        background-attachment: fixed;
    }

@media screen and (max-width: 600px) {
    .home {
        background-attachment: scroll; /* Allow scrolling on small screens */
        background-size: contain; /* Maintain image aspect ratio */
    }
}
    .container-d {
        overflow: hidden;

        .slider {
            animation: slidein 30s linear infinite;
            white-space: nowrap;

            .logos {
                width: 100%;
                display: inline-block;
                margin: 0px 0;

                .pp {
                    width: calc(100% / 5);
                    animation: fade-in 0.5s cubic-bezier(0.455, 0.03, 0.515, 0.955) forwards;
                }
            }
        }
    }

    @keyframes slidein {
        from {
            transform: translate3d(0, 0, 0);
        }

        to {
            transform: translate3d(-100%, 0, 0);
        }
    }
    
    

    @keyframes fade-in {
        0% {
            opacity: 0;
        }

        100% {
            opacity: 1;
        }
    }
</style>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/home.blade.php ENDPATH**/ ?>
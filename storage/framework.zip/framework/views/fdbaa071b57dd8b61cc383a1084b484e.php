<div class="">




    <?php if($data['service'] == \App\Helpers\ServiceType::REPAIR): ?>
    <?php endif; ?>



    <?php if($form_type == 'postal_form'): ?>
    <?php endif; ?>



    <?php
        if ($data['service'] == \App\Helpers\ServiceType::REPAIR) {
            $price = $data['repair_priece'];
        } else {
            $price = $data['price'];
        }
    ?>




    <p class="text-danger fs-5 fw-bold">
        £<?php echo e(($price ?? 0) + 9); ?>.00
    </p>









    <div>


        <?php
            $form_name = 'Post my device';

        ?>



        <?php
            if ($data['service'] == \App\Helpers\ServiceType::REPAIR) {
                $price = \App\Models\Price::findPrice($data['repair_type']['id'], $data['modal']['id']);
            }
        ?>
        <div class=" ">

            <div class="row mx-5">

                <?php if($data['service'] == \App\Helpers\ServiceType::REPAIR): ?>
                    <div class="form-check mb-1">
                        <input class="form-check-input" type="checkbox" checked disabled>
                        <label class="form-check-label">
                            <?php echo e($data['modal']['name']); ?> <?php echo e($data['repair_type']['name']); ?>: £ <?php echo e($price ? $price : 0); ?>

                        </label>
                    </div>
                <?php endif; ?>

                <div>
                    <?php if($form_type == 'postal_form'): ?>
                        <?php

                            $form_name = 'Post Your Device';

                        ?>



                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" checked disabled />
                            <label class="form-check-label">
                                Surcharge for UK return delivery : £ 9
                            </label>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="my-3" wire:ignore>
                    <?php
                        if ($data['service'] == \App\Helpers\ServiceType::REPAIR) {
                            $price = $data['repair_priece'];
                        } else {
                            $price = $data['price'];
                        }
                    ?>

                </div>


                <div class="row">
                    <div class="col-9">
                        <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
                    </div>
                </div>


            </div>

        </div>
    </div>
    <div class = "container mb-5">


        <div class="row">

            <div class="col-md-5  pt-4 mb-3">
                <h2 class="text-center" style="color: red;">Payment Details</h2>
                <p class="text-center">Select your payment option</p>
                <div class=" p-2  " style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 4px">
                    <div class="container p-3">
                        <div class="accordion" id="payment-accodoion">



                            <div class="accordion-item ">
                                <h2 class="accordion-header " id="headingTwo">
                                    <button style = "padding-bottom: 0px;"
                                        class="accordion-button collapsed d-flex  justify-content-between"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                        aria-expanded="false" aria-controls="collapseTwo" onclick="handleRadio(this)">

                                        <p style="font-size: 1.3rem;">
                                            <input type="radio" name="radio-payment"
                                                style="height: 18px; width: 20px">
                                            Pay with card
                                        </p>
                                        <img src="https://ik.imagekit.io/4csyk445b/2560px-Stripe_Logo__revised_2016%205.png?updatedAt=1711551636602"
                                            alt height="31px">
                                        <p style="font-size: 1.3rem; color:red;">£ <?php echo e($price ? $price : 0); ?></p>

                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#payment-accodoion">
                                    <div class="accordion-body " style="padding-top: 0px;">
                                        <div class="container">
                                            <div class="accordion-body p-0">
                                                <p style="font-size:0.9vw;" class="text-center">Securely pay with your
                                                    card using Stripe for hassle-free transactions!</p>

                                                <div class="d-flex justify-content-center pt-3">
                                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Buy'])->html();
} elseif ($_instance->childHasBeenRendered('l3239423365-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3239423365-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3239423365-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3239423365-0');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Buy']);
    $html = $response->html();
    $_instance->logRenderedChild('l3239423365-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingthree">
                                    <button style = "padding-bottom: 0px;"
                                        class="accordion-button collapsed d-flex  justify-content-between"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#collapsethree"
                                        aria-expanded="false" aria-controls="collapsethree" onclick="handleRadio(this)">

                                        <div> <input type="radio" name="radio-payment"
                                                style=" width: 19px;height: 17px; font-size: 1.3rem;">
                                            <img class="img-fluid" style="width: 100px;"
                                                src="https://ik.imagekit.io/4csyk445b/PayPal_horizontally_Logo_2014.png?updatedAt=1709738114776"
                                                alt>
                                        </div>
                                        <p style="font-size: 1.3rem; color:red;">£ <?php echo e($price ? $price : 0); ?></p>

                                    </button>
                                </h2>
                                <div id="collapsethree" class="accordion-collapse collapse"
                                    aria-labelledby="collapsethree" data-bs-parent="#payment-accodoion">
                                    <div class="accordion-body">
                                        <p style="font-size:0.9vw;" class= "text-center">Seamlessly checkout with PayPal
                                            for a trusted payment experience. </p>
                                        <div class="d-flex justify-content-center">
                                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Buy'])->html();
} elseif ($_instance->childHasBeenRendered('l3239423365-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3239423365-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3239423365-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3239423365-1');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Buy']);
    $html = $response->html();
    $_instance->logRenderedChild('l3239423365-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfour">
                                    <button style = "padding-bottom: 0px;"
                                        class="accordion-button collapsed d-flex  justify-content-between"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#collapsefour"
                                        aria-expanded="false" aria-controls="collapsefour" onclick="handleRadio(this)">
                                        <div class="row g-4">

                                            <div class="col-1">
                                                <input type="radio" name="radio-payment"
                                                    style=" width: 19px;height: 17px; ">
                                            </div>
                                            <div class="col-2">
                                                <img src="https://ik.imagekit.io/4csyk445b/download__13_-removebg-preview%207%20(1).png?updatedAt=1711553724733"
                                                    class="img-fluid" alt>
                                            </div>
                                            <div class="col-7">
                                                <div style="border-radius:5px;" class=" ">
                                                    <small
                                                        style="font-size:10px;line-height: 1;white-space:nowrap;">make
                                                        3 payments of £<?php echo e(number_format($price / 3, 2)); ?> <b>Klarna</b>.
                                                    </small>
                                                    <small style="font-size:10px;line-height:1;">Terms and condition
                                                        apply</small>
                                                </div>
                                            </div>

                                            <div class="col-1 ">
                                                <h4 style="font-size: 1.3rem; color:red;">
                                                    £<?php echo e($price ? $price : 0); ?>

                                                </h4>


                                            </div>

                                        </div>


                                    </button>
                                </h2>
                                <div id="collapsefour" class="accordion-collapse collapse"
                                    aria-labelledby="collapsefour" data-bs-parent="#payment-accodoion">
                                    <div class="accordion-body">
                                        <p style="font-size:0.9vw;" class = "text-center">Enjoy the convenience of
                                            paying in 3 installments with Klarna!</p>
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Buy'])->html();
} elseif ($_instance->childHasBeenRendered('l3239423365-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l3239423365-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3239423365-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3239423365-2');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Buy']);
    $html = $response->html();
    $_instance->logRenderedChild('l3239423365-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-2 d-sm-none d-md-none d-lg-block"></div>

            <div class="col-md-4 col-lg-4 sol-sm-12 mt-5 ">
                <!--<div class="mt-5">-->
                <!--    <div class=" pt-1 justify-content-center">-->
                <!--        <div class>-->
                <!--            <div class="container"-->
                <!--                style="width: 100%; max-width: 380px; height: 240px; border: 2px solid rgba(128, 128, 128, 0.3); border-radius: 8px">-->
                <!--                <div class="container p-4">-->
                <!--                    <p class="text-center"-->
                <!--                        style="font-size: 30px;">Buy-->
                <!--                        Summary</p>-->
                <!--                    <div-->
                <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                <!--                        <span><b>Model</b> </span>-->
                <!--                        <span class="text-muted"><?php echo e($data['modal']['name']); ?></span>-->
                <!--                    </div>-->
                <!--                    <div-->
                <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                <!--                        <span><b>Type</b> </span>-->


                <!--                        <span class="text-muted"> <?php echo e($form_name); ?></span>-->
                <!--                    </div>-->
                <!--                    <div-->
                <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                <!--                        <span><b> Price </b></span>-->
                <!--                        <span class="text-muted">£ <?php echo e($price ? $price : 0); ?></span>-->
                <!--                    </div>-->
                <!-- hr -->
                <!--<hr-->
                <!--    style="  border-top: 2px dotted black;">-->
                <!--                    <div-->
                <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                <!--                        <span></span>-->
                <!--                        <span class="text-muted"></span>-->
                <!--                    </div>-->
                <!--                    <div-->
                <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                <!--                        <span> </span>-->
                <!--                        <span-->
                <!--                            class="text-muted"></span>-->
                <!--                    </div>-->
                <!--                    <div-->
                <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                <!--                        <span> </span>-->
                <!--                        <span class="text-muted"></span>-->
                <!--                    </div>-->
                <!--                </div>-->
                <!--<div class="d-flex justify-content-center">-->
                <!--    <button type="button"-->
                <!--        class="btn  btn-lg "-->
                <!--        style="width: 100%; border-radius: 0;background-color: red ; color: white">-->
                <!--        Proceed To Checkout-->
                <!--    </button>-->
                <!--</div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->

                <div style="position:relative;top:10px;" class="container">

                    <table class="table table-striped border mt-5">
                        <thead>



                            <tr>
                                <th colspan="2" class="text-center text-danger fw-bolder fs-3">Buy Summary</th>
                                <!-- Center-aligned heading -->
                            </tr>



                            <tr>

                                <th scope="col">Model</th>
                                <th class="text-end" scope="col"><?php echo e($data['modal']['name']); ?></th>

                            </tr>
                        </thead>
                        <tbody>
                            <tr class="justify-content-between

">

                                <td>Type</td>
                                <td class="text-end"><?php echo e($form_name); ?></td>

                            </tr>





                            <tr>

                                <th scope="col">Price</th>
                                <th class="text-end" scope="col">£ <?php echo e($price ? $price : 0); ?></th>

                            </tr>

                        </tbody>
                    </table>
                </div>


            </div>
        </div>


    </div>
    <script>
        function handleRadio(button) {
            var radio = button.querySelector('input[name="radio-payment"]');
            var isChecked = radio.checked;

            // Uncheck all radio buttons with name "radio-payment"
            document.querySelectorAll('input[name="radio-payment"]').forEach(function(radioBtn) {
                radioBtn.checked = false;
            });

            // If radio button was not checked, check it
            if (!isChecked) {
                radio.checked = true;
            }
        }
    </script>


    <style>
        .accordion-button:not(.collapsed) {
            background-color: white;
            box-shadow: none;
        }

        .accordion-button:not(.collapsed)::after {
            display: none;
        }

        .accordion-button::after {
            display: none;
        }

        .accordion-item {
            justify-content: space-between;
        }
    </style>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/buy/book-repair.blade.php ENDPATH**/ ?>
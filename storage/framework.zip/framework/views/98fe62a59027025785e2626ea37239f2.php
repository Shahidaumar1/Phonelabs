<div>
    <div class="d-flex flex-column flex-md-row">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'orders'])->html();
} elseif ($_instance->childHasBeenRendered('l858801000-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l858801000-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l858801000-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l858801000-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'orders']);
    $html = $response->html();
    $_instance->logRenderedChild('l858801000-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald033566f468fc7bb3a8d0f946fdab616 = $attributes; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-100']); ?>
            <div class="container my-5">
                <div>
                    <div class="">
                        <div class="">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.orders.components.top-nav', ['active' => ''])->html();
} elseif ($_instance->childHasBeenRendered('l858801000-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l858801000-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l858801000-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l858801000-1');
} else {
    $response = \Livewire\Livewire::mount('admin.orders.components.top-nav', ['active' => '']);
    $html = $response->html();
    $_instance->logRenderedChild('l858801000-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        <div>
                            <div>
                                
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Product Name</th>
                                                <th>Repairs</th>
                                                <th>Other Text</th>
                                                <th>Existing Customer</th>
                                                <th>Is Business</th>
                                                <th>Brand</th>
                                                <th>Model</th>
                                                <th>Additional Description</th>
                                                <th>Created At</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($inquiry->first_name); ?></td>
                                                    <td><?php echo e($inquiry->last_name); ?></td>
                                                    <td><?php echo e($inquiry->email); ?></td>
                                                    <td><?php echo e($inquiry->phone); ?></td>
                                                    <td><?php echo e($inquiry->product_name); ?></td>
                                                    <td><?php echo e(implode(', ', json_decode($inquiry->checkboxes))); ?></td>
                                                    <td><?php echo e($inquiry->other_text); ?></td>
                                                    <td><?php echo e($inquiry->existing_customer ? 'Yes' : 'No'); ?></td>
                                                    <td><?php echo e($inquiry->is_business ? 'Yes' : 'No'); ?></td>
                                                    <td><?php echo e($inquiry->brand); ?></td>
                                                    <td><?php echo e($inquiry->model); ?></td>
                                                    <td><?php echo e($inquiry->additional_description); ?></td>
                                                    <td><?php echo e($inquiry->created_at->format('d/m/Y H:i')); ?></td>
                                                    <td>
                                                        <button class="btn btn-info btn-sm" wire:click="$emit('viewInquiry', <?php echo e($inquiry->id); ?>)">View</button><br>
                                                        <button class="btn btn-danger btn-sm" wire:click="deleteInquiry(<?php echo e($inquiry->id); ?>)">Delete</button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.inquiry-modal', [])->html();
} elseif ($_instance->childHasBeenRendered('l858801000-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l858801000-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l858801000-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l858801000-2');
} else {
    $response = \Livewire\Livewire::mount('admin.inquiry-modal', []);
    $html = $response->html();
    $_instance->logRenderedChild('l858801000-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $attributes = $__attributesOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__attributesOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>
    </div>
</div>

<style>
    .table {
        width: 100%;
        margin-bottom: 1rem;
        background-color: transparent;
    }

    .table th,
    .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }

    .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
    }

    .table tbody + tbody {
        border-top: 2px solid #dee2e6;
    }

    .table-bordered {
        border: 1px solid #dee2e6;
    }

    .table-bordered th,
    .table-bordered td {
        border: 1px solid #dee2e6;
    }

    .table-bordered thead th,
    .table-bordered thead td {
        border-bottom-width: 2px;
    }

    .thead-dark th {
        color: black;
        background-color: #C0C0F0;
        border-color: white;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.05);
    }

    h1 {
        margin-bottom: 20px;
        font-size: 2rem;
        font-weight: bold;
        text-align: center;
    }

    .container {
        padding: 20px;
    }

    @media (max-width: 768px) {
        .table th,
        .table td {
            padding: 0.5rem;
        }

        h1 {
            font-size: 1.5rem;
        }

        .container {
            padding: 10px;
        }
    }
</style>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/customer-inquiries.blade.php ENDPATH**/ ?>
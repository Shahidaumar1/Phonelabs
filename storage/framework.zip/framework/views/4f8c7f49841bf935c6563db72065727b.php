<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Details</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    

    <?php
        $slot = '';
    ?>
    <div class="d-flex justify-content-center">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'buy'])->html();
} elseif ($_instance->childHasBeenRendered('QBD47d5')) {
    $componentId = $_instance->getRenderedChildComponentId('QBD47d5');
    $componentTag = $_instance->getRenderedChildComponentTagName('QBD47d5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QBD47d5');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'buy']);
    $html = $response->html();
    $_instance->logRenderedChild('QBD47d5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Contact Details</h5>
                <div class="card-body">
                    <p><strong>Name:</strong> <?php echo e($contact->name); ?></p>
                    <p><strong>Email:</strong> <?php echo e($contact->email); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($contact->phone); ?></p>
                    <p><strong>Selected Option:</strong> <?php echo e($contact->selected_option); ?></p>
                    <p><strong>Other Option:</strong> <?php echo e($contact->other_option); ?></p>
                    <p><strong>Message:</strong> <?php echo e($contact->message); ?></p>
                    <a href="<?php echo e(route('contacts.index')); ?>" class="btn btn-primary">Back to list</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mobilebitz/public_html/resources/views/contacts/show.blade.php ENDPATH**/ ?>
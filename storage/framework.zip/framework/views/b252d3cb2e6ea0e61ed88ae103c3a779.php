<div>
    <?php
        $tagline = [
            'Sell' => 'How you’ll send your device',
            'Repair' => 'How would you like us to repair your device?',
            'Buy' => 'How you’ll get your device',
        ];

        $heading = [
            'Sell' => 'Selling Options',
            'Repair' => 'Repair Options',
            'Buy' => 'Buy Options',
        ];
        $formService = strtolower($data['service']);
    ?>


    <h2 class="text-danger"><?php echo e($heading[$data['service']] ?? 'Options'); ?></h2>
    <p><?php echo e($tagline[$data['service']] ?? ''); ?> </p>
    <!-- File: resources/views/livewire/admin/settings/service-price-display.blade.php -->

    <div>
        <h2>Service Charge Prices Based on Conditions</h2>


        <p>Condition 1 Price: <?php echo e($condition1Price); ?></p>


        <p>Condition 2 Price: <?php echo e($condition2Price); ?></p>


        <p>Condition 3 Price: <?php echo e($condition3Price); ?></p>


        <p>Condition 4 Price: <?php echo e($condition4Price); ?></p>

        <?php if($condition5Price): ?>
            <p>Condition 5 Price: <?php echo e($condition5Price); ?></p>
        <?php endif; ?>

        <?php if($condition6Price): ?>
            <p>Condition 6 Price: <?php echo e($condition6Price); ?></p>
        <?php endif; ?>
    </div>



    <ul class="nav nav-tabs" role="tablist">

        <li class="nav-item">
            <?php
                $postalText = [
                    'Sell' => 'Post Your Device ',
                    'Repair' => 'Postal Repair',
                    'Buy' => 'Post My Device',
                ];
            ?>

        </li>
    </ul>

    <!-- Tab Content -->





    <ul class="nav nav-tabs " role="tablist">
        <?php if($formStatuses[0]->$formService): ?>
            <li class="nav-item ">
                <a class="nav-link <?php if($form_type === 'clinic_form'): ?> active <?php endif; ?>"
                    wire:click="$set('form_type', 'clinic_form')  " href="#tab-clinic">
                    <?php if($data['service'] == 'Buy'): ?>
                        Buy in Store
                    <?php elseif($data['service'] == 'Sell'): ?>
                        Sell In Store
                    <?php else: ?>
                        Store Repair
                    <?php endif; ?>
                </a>
            </li>
        <?php endif; ?>
        <?php if($formStatuses[1]->$formService): ?>
            <li class="nav-item">
                <a class="nav-link <?php if($form_type === 'postal_form'): ?> active <?php endif; ?>"
                    wire:click="$set('form_type', 'postal_form')" href="#tab-postal">
                    <?php echo e($postalText[$data['service']] ?? ''); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if($formStatuses[2]->$formService): ?>
            <?php if($data['service'] != 'Buy'): ?>
                <li class="nav-item">
                    <a class="nav-link <?php if($form_type === 'collection_form'): ?> active <?php endif; ?>"
                        wire:click="$set('form_type', 'collection_form')" href="#tab-collection">
                        <?php if($data['service'] != 'Buy'): ?>
                            Collect My Device
                        <?php endif; ?>
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
        <?php if($formStatuses[3]->$formService): ?>
            <?php if($data && $data['device']['name'] != 'Apple iPad' && $data['service'] == 'Repair'): ?>
                <li class="nav-item">
                    <a class="nav-link <?php if($form_type === 'fix_form'): ?> active <?php endif; ?>"
                        wire:click="$set('form_type', 'fix_form')" href="#tab-fix">
                        Fix At My Address
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
    </ul>

    <!-- Tab Content -->
    <div class="tab-content">
        <div class="tab-pane <?php if($form_type === 'clinic_form'): ?> active show <?php endif; ?> " id="tab-clinic">
            <?php if($data['service'] == 'Buy'): ?>
                Buy in Store
            <?php elseif($data['service'] == 'Sell'): ?>
                <!--Sell In Store-->
            <?php else: ?>
                Store Repair
            <?php endif; ?>
        </div>
        <div class="tab-pane <?php if($form_type === 'postal_form'): ?> active show <?php endif; ?>" id="tab-postal">
            <?php if($data['service'] != 'Buy'): ?>
                <?php echo e($postalText[$data['service']]); ?>

            <?php endif; ?>
        </div>

        <!--<button id="changeBackgroundButton">Change Background</button>-->

        <div class="tab-pane <?php if($form_type === 'collection_form'): ?> active show <?php endif; ?>" id="tab-collection">
            <?php if($data['service'] != 'Buy'): ?>
                <!-- Collection Form Content -->
                <!-- ... -->
            <?php endif; ?>
        </div>
        <div class="tab-pane <?php if($form_type === 'fix_form'): ?> active show <?php endif; ?>" id="tab-fix">
            <?php if($data && $data['device']['name'] != 'Apple iPad' && $data['service'] == 'Repair'): ?>
                <!-- Fix Form Content -->
                <!-- ... -->
            <?php endif; ?>
        </div>





        <!--<div class="form-check d-flex gap-2">-->
        <!--    <input class="form-check-input " type="radio" wire:model="form_type" value="clinic_form" />-->
        <!--    <label class="form-check-label ">-->
        <!--        <?php if($data['service'] == 'Buy'): ?>
-->
        <!--            Buy in Store-->
        <!--
<?php elseif($data['service'] == 'Sell'): ?>
-->
        <!--            Sell In Store-->
    <!--        <?php else: ?>-->
        <!--            Store Repair-->
        <!--
<?php endif; ?>-->
        <!--    </label>-->
        <!--</div>-->
        <!--<div class="form-check d-flex gap-2">-->
        <!--    <?php-->
                                <!--        $postalText = [-->
                                <!--            'Sell' => 'Post Your Device ',-->
                                <!--            'Repair' => 'Postal Repair (£15 surcharge)',-->
                                <!--            'Buy' => 'Post My Device',-->
                                <!--        ];-->
                        <!--    ?> ?> ?>-->
        <!--    <input class="form-check-input " type="radio" wire:model="form_type" value="postal_form" />-->
        <!--    <label class="form-check-label">-->
        <!--        <?php echo e($postalText[$data['service']]); ?>-->
        <!--    </label>-->
        <!--</div>-->
        <!--<?php if($data['service'] != 'Buy'): ?>
-->
        <!--    <div class="form-check d-flex gap-2">-->
        <!--        <input class="form-check-input " type="radio" wire:model="form_type" value="collection_form" />-->
        <!--        <label class="form-check-label">-->
        <!--            Collect My Device* (£15 surcharge)-->
        <!--        </label>-->
        <!--    </div>-->
        <!--
<?php endif; ?>-->

        <!--<?php if($data && $data['device']['name'] != 'Apple iPad' && $data['service'] == 'Repair'): ?>
-->
        <!--    <div class="form-check">-->
        <!--        <input class="form-check-input" type="radio" wire:model="form_type" value="fix_form" />-->
        <!--        <label class="form-check-label">-->
        <!--            Fix At My Address-->
        <!--        </label>-->
        <!--        <br>-->
        <!--        -->
        <!--    </div>-->
        <!--
<?php endif; ?>-->
        <div>
            <div>
                <div wire:loading wire:target='form_type' class="w-100">
                    <div class="overlay rounded d-flex flex-column justify-content-center align-items-center bg-pink-linear text-white"
                        style="height:400px;">
                        <?php if (isset($component)) { $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0 = $component; } ?>
<?php $component = App\View\Components\Spinner::resolve(['color' => 'danger'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Spinner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0)): ?>
<?php $component = $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0; ?>
<?php unset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
            <div wire:loading.remove wire:target='form_type'>
                <?php if($form_type == 'postal_form'): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.postal-repair-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.postal-repair-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php elseif($form_type == 'clinic_form'): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.clinic-repair-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.clinic-repair-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php elseif($form_type == 'collection_form'): ?>
                    <div wire:ignore>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.collection-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.collection-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                <?php elseif($form_type == 'fix_form'): ?>
                    <div wire:ignore>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.fix-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.fix-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <style>
        /*    input[type="radio"]{*/
        /*     visibility:hidden;*/
        /*}*/
    </style>
    <style>
        /* Custom CSS for one-line nav-tabs and red color */
        .nav-tabs {
            display: flex;
            flex-wrap: nowrap;
            overflow-x: auto;
            border-bottom: none;
            background-color: transparent;
            scrollbar-width: none;
            /* Optional: hide scrollbar in case of overflow */
        }

        .nav-item {
            white-space: nowrap;
            color: green;
            /* Adding the color property to set text color to green */
        }


        .nav-link {
            color: #3E3E3E;
            /* Change to your preferred color */
        }

        .nav-link.active {
            color: #3E3E3E;
            /* Change to your preferred active color */
        }

        /* Optional: Hide arrows for horizontal scroll in nav-tabs */
        .nav-tabs::-webkit-scrollbar {
            display: none;
        }


        .nav-tabs .nav-link.active {
            background-color: white;

            /* Red shadow with a negative vertical offset */
            position: relative;
            z-index: 1;
        }
    </style>
    <style>
        .tab-content {
            background-color: #ffffff;
            border-radius: 10px;

            width: 100%;
            margin: 0 auto;
            padding: 20px;
            /* Optional: Add padding to the content */
        }

        /* Media query for phone screens */
        @media only screen and (max-width: 767px) {
            .tab-content {
                width: 100%;
                /* Set a larger width on phone screens */
                margin-left: -2%;
                /* Center the element */
            }
        }






        /* Additional background colors based on form types */
        .tab-content.postal-form {
            background-color: #f0f0f0;
            /* Replace with your desired color for postal form */
        }

        .tab-content.clinic-form {
            background-color: #e0e0e0;
            /* Replace with your desired color for clinic form */
        }
    </style>

</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/components/form-toggle.blade.php ENDPATH**/ ?>
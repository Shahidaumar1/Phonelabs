<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Information</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>

<body>

    
    <?php
        $slot = '';
    ?>
    <div class="d-flex justify-content-center">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'buy'])->html();
} elseif ($_instance->childHasBeenRendered('zwoJ7A5')) {
    $componentId = $_instance->getRenderedChildComponentId('zwoJ7A5');
    $componentTag = $_instance->getRenderedChildComponentTagName('zwoJ7A5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zwoJ7A5');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'buy']);
    $html = $response->html();
    $_instance->logRenderedChild('zwoJ7A5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <div class="container mt-5">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.orders.components.top-nav', ['active' => ''])->html();
} elseif ($_instance->childHasBeenRendered('AiKVvms')) {
    $componentId = $_instance->getRenderedChildComponentId('AiKVvms');
    $componentTag = $_instance->getRenderedChildComponentTagName('AiKVvms');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AiKVvms');
} else {
    $response = \Livewire\Livewire::mount('admin.orders.components.top-nav', ['active' => '']);
    $html = $response->html();
    $_instance->logRenderedChild('AiKVvms', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Selected Option</th>
                        <th scope="col">Other Option</th>
                        <th scope="col">Message</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($contact->id); ?></th>
                            <td><?php echo e($contact->name); ?></td>
                            <td><?php echo e($contact->email); ?></td>
                            <td><?php echo e($contact->phone); ?></td>
                            <td><?php echo e($contact->selected_option); ?></td>
                            <td><?php echo e($contact->other_option); ?></td>
                            <td><?php echo e($contact->message); ?></td>
                            <td class="d-flex justify-content-center gap-2">
                                <a href="<?php echo e(route('contacts.show', $contact->id)); ?>" class="btn btn-info btn-sm"
                                    title="View"><i class="fas fa-eye"></i></a>
                                <!--<a href="<?php echo e(route('contacts.edit', $contact->id)); ?>" class="btn btn-primary btn-sm"-->
                                <!--    title="Edit"><i class="fas fa-edit"></i></a>-->
                                <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="POST"
                                    style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete"><i
                                            class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mobilebitz/public_html/resources/views/contacts/index.blade.php ENDPATH**/ ?>
<div class="">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.repair.repair-price.components.import-export', [])->html();
} elseif ($_instance->childHasBeenRendered('l2218649702-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2218649702-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2218649702-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2218649702-0');
} else {
    $response = \Livewire\Livewire::mount('admin.repair.repair-price.components.import-export', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2218649702-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <hr>
    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>

    <div>
        <div class=" align-items-center d-flex gap-3 flex-wrap">

            <div >
                <label for="master_id">Select Device</label>
                <select class="form-select" aria-label="Default select example" id="select_Cat" wire:model="selectedCatId">
                    <option selected disabled>Select Device</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </option>
                </select>
                <?php $__errorArgs = ['selectedCatId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red " class="text-xs"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="master_id">Select Brand</label>
                <select class="form-select" aria-label="Default select example" id="select_Cat"
                    wire:model="selectedDeviceId">
                    <option selected >Select Brand</option>
                    <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </option>
                </select>
                <?php $__errorArgs = ['selectedDeviceId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red " class="text-xs"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="master_id">Select Model</label>
                <select class="form-select" aria-label="Default select example" id="select_Cat"
                    wire:model="selectedModelId">
                    <option>Select Model</option>
                    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($model->id); ?>"><?php echo e($model->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </option>
                </select>
                <?php $__errorArgs = ['selectedModelId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red " class="text-xs"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="master_id">Select Repair</label>
                <select class="form-select" aria-label="Default select example" id="select_Cat"
                    wire:model="selectedRepairType">
                    <option>Select Repair</option>
                    <?php $__currentLoopData = $repair_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($repair->id); ?>"><?php echo e($repair->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </option>
                </select>
                <?php $__errorArgs = ['selectedRepairType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red " class="text-xs"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="d-flex flex-column">
                <label for="broken_screen_p">Price</label>
                <input type="text" name="price" id="price" placeholder="Price" required
                    wire:model.debounce.500="price">
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red " class="text-xs"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="button" class="bg-blue text-white mt-3" wire:click="create">
                Add Repair Price
                <span wire:loading wire:target='create'>
                    <?php if (isset($component)) { $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0 = $attributes; } ?>
<?php $component = App\View\Components\Spinner::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Spinner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0)): ?>
<?php $attributes = $__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0; ?>
<?php unset($__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0)): ?>
<?php $component = $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0; ?>
<?php unset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0); ?>
<?php endif; ?>
                </span>
            </button>
        </div>





    </div>
</div>
<?php /**PATH /Users/mubashir/Documents/scode/resources/views/livewire/admin/repair/repair-price/create.blade.php ENDPATH**/ ?>
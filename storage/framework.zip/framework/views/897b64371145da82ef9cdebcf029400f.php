<nav class=" px-3 " style=" background-color: transparent;">
    <div class="d-flex justify-content-between align-items-center ">
        <i class="fa fa-bars cursor-pointer text-black" aria-hidden="true" onclick="toggleLeftDrawer()"></i>

        <div class="d-flex  align-items-center admin-top-items">
            <div>
                <a href="<?php echo e(route('orders')); ?>" class="text-danger fw-bold p-3 <?php echo e($active == 'orders' ? 'text-danger fw-bold p-3' : ''); ?>">Orders Details</a>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.avatar', [])->html();
} elseif ($_instance->childHasBeenRendered('l3032848542-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3032848542-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3032848542-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3032848542-0');
} else {
    $response = \Livewire\Livewire::mount('components.avatar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3032848542-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

</nav><?php /**PATH /home/mobilebitz/test.mobilebitz.co.uk/resources/views/livewire/admin/orders/components/top-nav.blade.php ENDPATH**/ ?>
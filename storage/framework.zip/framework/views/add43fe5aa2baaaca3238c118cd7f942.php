<?php echo e($slot); ?>

<?php /**PATH /home/mobilebitz/public_html/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>
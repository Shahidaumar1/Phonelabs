<div class="spinner-border text-<?php echo e($color ?? 'light'); ?>  spinner-border-sm" role="status">
    <span class="visually-hidden">Loading...</span>
</div>
<?php /**PATH /Users/mubashir/Documents/vscode (2)/resources/views/components/spinner.blade.php ENDPATH**/ ?>
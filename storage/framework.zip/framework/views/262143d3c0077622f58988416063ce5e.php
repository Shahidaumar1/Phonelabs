<div>
    <?php
        $tagline = [
            'Sell' => 'How you’ll send your device',
            'Repair' => 'How would you like us to repair your device?',
            'Buy' => 'How you’ll get your device',
        ];

        $heading = [
            'Sell' => 'Selling Options',
            'Repair' => 'Repair Options',
        ];

        $postalText = [
            'Sell' => 'Post Your Device',
            'Repair' => 'Postal Repair',
            'Buy' => 'Post My Device',
        ];

        $formService = strtolower($data['service']);
    ?>
<div class="bg-white" >
    <!-- <h2 class="text-danger"><?php echo e($heading[$data['service']] ?? ''); ?></h2>
    <p><?php echo e($tagline[$data['service']] ?? ''); ?></p> -->
    <div class="grid-heading  ">
    <h3 class="text-center text-danger pt-4">What way would you like us to fix your device?</h3>
    <p class="text-center">If your iPhone 14 Plus is damaged, we understand that you would want this repaired in no time so you... <span class="text-danger">Read More</span></p>
    </div>
    <!-- Grid Container -->
    <div class="grid-container " role="grid">
        <?php if($formStatuses[0]->$formService): ?>
            <div class="grid-item">
                <a href="#" wire:click.prevent="showForm('clinic_form')">
                    <div class="icon-container text-danger">
                        <i class="fas fa-store"></i>
                    </div>
                    <div class="option-label text-dark">Store Repair</div>
                    <div class="option-description">Choose from one of our 40 nationwide locations.</div>
                </a>
            </div>
        <?php endif; ?>
        <?php if($formStatuses[1]->$formService): ?>
            <div class="grid-item">
                <a href="#" wire:click.prevent="showForm('postal_form')">
                    <div class="icon-container text-danger">
                        <i class="fas fa-mail-bulk"></i>
                    </div>
                    <div class="option-label text-dark">Postal Repair</div>
                    <div class="option-description">No stores close to you? Send your device to us!</div>
                </a>
            </div>
        <?php endif; ?>
        <?php if($formStatuses[2]->$formService && $data['service'] != 'Buy'): ?>
            <div class="grid-item mb-5">
                <a href="#" wire:click.prevent="showForm('collection_form')">
                    <div class="icon-container text-danger">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="option-label text-dark">Collect My Device</div>
                    <div class="option-description">We'll pick up your device for repair and return it to you afterward.</div>
                </a>
            </div>
        <?php endif; ?>
        <?php if($formStatuses[3]->$formService && $data['device']['name'] != 'Apple iPad' && $data['service'] == 'Repair'): ?>
            <div class="grid-item mb-5">
                <a href="#" wire:click.prevent="showForm('fix_form')">
                    <div class="icon-container text-danger">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="option-label text-dark">Fix At My Address</div>
                    <div class="option-description">Our technicians will visit your residence to repair your mobile device.</div>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Form -->
    <?php if($showForm): ?>
        <div class="tab-content">
            <div class="tab-pane <?php if($form_type === 'clinic_form'): ?> active show <?php endif; ?>" id="tab-clinic" style="display: none;">
                <?php if($data['service'] == 'Buy'): ?>
                    Buy in Store
                <?php elseif($data['service'] == 'Sell'): ?>
                    <!-- Sell In Store -->
                <?php elseif($data['service'] == 'Repair'): ?>
                    Store Repair
                <?php endif; ?>
            </div>
            <div class="tab-pane <?php if($form_type === 'postal_form'): ?> active show <?php endif; ?>" id="tab-postal" style="display: none;">
                <?php if($data['service'] != 'Buy'): ?>
                    <?php echo e($postalText[$data['service']]); ?>

                <?php endif; ?>
            </div>
            <div class="tab-pane <?php if($form_type === 'collection_form'): ?> active show <?php endif; ?>" id="tab-collection" style="display: none;">
                <?php if($data['service'] != 'Buy'): ?>
                    <?php echo e($postalText[$data['service']]); ?>

                    <!-- Collection Form Content -->
                    <!-- ... -->
                <?php endif; ?>
            </div>
            <div class="tab-pane <?php if($form_type === 'fix_form'): ?> active show <?php endif; ?>" id="tab-fix" style="display: none;">
                <?php if($data && $data['device']['name'] != 'Apple iPad' && $data['service'] == 'Repair'): ?>
                    <div class="option-label text-dark">Fix At My Address</div>
                    <!-- Fix Form Content -->
                    <!-- ... -->
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <div>
        <div>
            <div wire:loading wire:target="form_type" class="w-100">
                <div class="overlay rounded d-flex flex-column justify-content-center align-items-center bg-pink-linear text-white" style="height:400px;">
                    <?php if (isset($component)) { $__componentOriginalf26909af655deaf31c8e20175813a5a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf26909af655deaf31c8e20175813a5a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spinner','data' => ['color' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf26909af655deaf31c8e20175813a5a0)): ?>
<?php $attributes = $__attributesOriginalf26909af655deaf31c8e20175813a5a0; ?>
<?php unset($__attributesOriginalf26909af655deaf31c8e20175813a5a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf26909af655deaf31c8e20175813a5a0)): ?>
<?php $component = $__componentOriginalf26909af655deaf31c8e20175813a5a0; ?>
<?php unset($__componentOriginalf26909af655deaf31c8e20175813a5a0); ?>
<?php endif; ?>
                </div>
            </div>
            <div wire:loading.remove wire:target="form_type">
                <!-- Render form components conditionally -->
                <?php if($showForm): ?>
                    <?php if($form_type == 'postal_form'): ?>
                        <div class="bg-white">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.postal-repair-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.postal-repair-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    <?php elseif($form_type == 'clinic_form'): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.clinic-repair-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.clinic-repair-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php elseif($form_type == 'collection_form'): ?>
                        <div wire:ignore>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.collection-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.collection-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    <?php elseif($form_type == 'fix_form'): ?>
                        <div wire:ignore>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.fix-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.fix-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
    <style>
        .nav-tabs {
            display: flex;
            flex-wrap: nowrap;
            overflow-x: auto;
            border-bottom: none;
            background-color: transparent;
            scrollbar-width: none; /* Optional: hide scrollbar in case of overflow */
        }

        .nav-item {
            white-space: nowrap;
            color: green; /* Adding the color property to set text color to green */
        }

        .nav-link {
            color: #3E3E3E; /* Change to your preferred color */
        }

        .nav-link:hover {
            color: black !important; /* Change to your preferred color */
        }

        .nav-link.active {
            color: #3E3E3E; /* Change to your preferred active color */
        }

        .nav-tabs::-webkit-scrollbar {
            display: none;
        }

        .nav-tabs .nav-link.active {
            background-color: white;
            position: relative;
            z-index: 1;
        }
        .tab-content {
            background-color: #ffffff;
            border-radius: 10px;
            width: 100%;
            margin: 0 auto;
            padding: 20px; /* Optional: Add padding to the content */
        }

        @media only screen and (max-width: 767px) {
            .tab-content {
                width: 100%; /* Set a larger width on phone screens */
                margin-left: -2%; /* Center the element */
            }
        }

        .tab-content.postal-form {
            background-color: #f0f0f0; /* Replace with your desired color for postal form */
        }

        .tab-content.clinic-form {
            background-color: #e0e0e0; /* Replace with your desired color for clinic form */
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
            padding-left: 200px;
            padding-right: 200px;
            padding-top: 40px;
        }

        .grid-item {
            background-color: hsl(0, 100%, 99%);
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .grid-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }

        .icon-container {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .option-label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .option-description {
            font-size: 0.9rem;
            color: #666;
        }

        a {
            text-decoration: none;
        }
    </style>


<script>function showForm(formType) {
    // Hide the grid container
    document.querySelector('.grid-heading').style.display = 'none';

 
    // Show the corresponding form based on formType
    const formElement = document.getElementById(formType);
    if (formElement) {
        formElement.style.display = 'block';
    } else {
        console.error(`Form element with id ${formType} not found.`);
    }
}

</script>
</div><?php /**PATH /home/mobilebitz/new.mobilebitz.co.uk/resources/views/livewire/guest/components/form-toggle.blade.php ENDPATH**/ ?>
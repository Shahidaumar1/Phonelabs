
<div>
    <div>
        <div class="d-flex">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'repair'])->html();
} elseif ($_instance->childHasBeenRendered('l842388219-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l842388219-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l842388219-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l842388219-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l842388219-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.repair.components.top-nav', ['active' => 'price'])->html();
} elseif ($_instance->childHasBeenRendered('l842388219-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l842388219-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l842388219-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l842388219-1');
} else {
    $response = \Livewire\Livewire::mount('admin.repair.components.top-nav', ['active' => 'price']);
    $html = $response->html();
    $_instance->logRenderedChild('l842388219-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <div class="container">
                    <div class="text-center my-3">
                        <h3> Select categeory,device and model to seee product specifications with
                            prices.
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-6 mb-3 d-flex justify-content-center">
                            <a href="<?php echo e(route('repair-master-type')); ?>">
                                <button class="btn p-3"  style="border-radius: 20px; color: white; background-color: #20375E; padding: 10px">
                                    Master Repairs
                                </button>
                            </a>
                        </div>
                        
                        <div class="col-lg-3 col-md-6 mb-3"> <!-- Added flex-grow for responsiveness -->
                            <select class="form-select" aria-label="Default select example" wire:model="selectedCatId">
                                <option disabled>Select Category</option>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-3"> <!-- Added flex-grow for responsiveness -->
                            <select class="form-select" aria-label="Default select example" wire:model="selectedDeviceId">
                                <option disabled>Select device</option>
                                <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    
                        <div class="col-lg-3 col-md-6 mb-3 d-flex justify-content-center" onclick="showM('add-new-repair')">
                            <button class="btn p-3" onclick="showM('add-new-repair')" style="border-radius: 20px; color: white; background-color: #20375E; padding: 10px">
                                Add New Repair
                            </button>
                        </div>
                    </div>

                    
                    <div style="overflow-x: auto;">
                        <div id="wrap">
                            <div class="container">
                                <script src="https://cdn.jsdelivr.net/gh/livewire/sortable@v0.x.x/dist/livewire-sortable.js"></script>
                                <table class="table table-striped table-bordered" id="table_id">
                                    <thead>
                                        <?php if($selectedDevice): ?>
                                            <tr wire:sortable="updateTaskOrder">
                                                <th><?php echo e($selectedDevice->name); ?></th>
                                                <?php $__currentLoopData = $selectedDevice->repair_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="sticky-cell" style="cursor: move" wire:sortable.handle wire:sortable.item="<?php echo e($repair_type->id); ?>" wire:key="repair-<?php echo e($repair_type->id); ?>">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <?php echo e($repair_type->name); ?>

                                                            <span class="fas fa-arrows-alt"></span>
                                                        </div>
                                                        
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($modal->name); ?></td>
                                                <?php $__currentLoopData = $selectedDevice->repair_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repairType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($price = $modal->prices->where('repair_type_id', $repairType->id)->first()): ?>
                                                        <td>
                                                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('repair.components.price-edit', ['price' => $price])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('repair.components.price-edit', ['price' => $price]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                        </td>
                                                    <?php else: ?>
                                                        <td>....</td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>


<!----------------------------- footer-------------------------->
<style>
.button-sticky {
    height: 60px;
    color: white;
    font-family: sans-serif;
    font-size: 17px;
    line-height: 15px;
    text-align: center;
    position: fixed;
    bottom: -2px;
    z-index: 999;
    overflow-x:auto;
}

.home-btn:hover {
    color: orange;
}
.button-sticky .col-2 {
    margin-right: 10px; /* Adjust this value to set the desired gap */
}

.button-sticky .col-2:last-child {
    margin-right: 0; /* Remove margin from the last button to prevent extra space */
}

</style>

<div class="button-sticky container bg-blue d-lg-none d-md-none">
    <div class="row justify-content-center">

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('repair-categories')); ?>" class="text-white item "> Devices</a>
        </div>

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('repair-devices')); ?>" class="text-white  item "> Brands</a>
        </div>

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('repair-models')); ?>" class="text-white  item "> Models</a>
        </div>

        <div class="col-2 mt-4">
            <a href="<?php echo e(route('repair-price')); ?>"
                    class=" text-white p-3 item  ">Repair</a>
        </div>
    </div>
</div>
    </div>






        </div>
        
        <?php if($selectedDevice): ?>
            <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Add Model','id' => 'add-new-repair','size' => 'xl']); ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.repair.repair-price.create', ['device' => $selectedDevice])->html();
} elseif ($_instance->childHasBeenRendered('l842388219-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l842388219-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l842388219-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l842388219-3');
} else {
    $response = \Livewire\Livewire::mount('admin.repair.repair-price.create', ['device' => $selectedDevice]);
    $html = $response->html();
    $_instance->logRenderedChild('l842388219-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Model','id' => 'edit-repair-model']); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.repair.model.edit', [])->html();
} elseif ($_instance->childHasBeenRendered('l842388219-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l842388219-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l842388219-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l842388219-4');
} else {
    $response = \Livewire\Livewire::mount('admin.repair.model.edit', []);
    $html = $response->html();
    $_instance->logRenderedChild('l842388219-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>







</div>
<style>
    /* Add CSS for sticky elements */
    .sticky-cell {
        position: sticky;
        top: 0;
    }
</style>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/admin/repair/repair-price/index.blade.php ENDPATH**/ ?>
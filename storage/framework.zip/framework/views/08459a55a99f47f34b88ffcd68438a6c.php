<div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l3263474312-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3263474312-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3263474312-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3263474312-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3263474312-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <section class="device-type-head">
        <div class="overlay"></div>
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l3263474312-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3263474312-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3263474312-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3263474312-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3263474312-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
             <a href="<?php echo e(route('home')); ?>">
                        
                    <button class="btn btn-danger btn-sm mt-2"  ><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
</svg></button>
                    </a>
            <div class="p-3 rounded-2 mt-5 d-flex justify-content-between align-items-center"
                style="background-color: #afafaf">
                <div class="d-flex flex-column">
                    <h1 class="text-black"><?php echo $webContent->repair_page_heading_1; ?></h1>
                    <span class="tagline text-black"><?php echo $webContent->repair_page_heading_2; ?></span>
                </div>

                <div class="d-flex justify-content-end align-items-center">
                    
                    <!--<h2 class=" mt-3 ml-3 " style="color: #da0a0a"><b>Students can get 10% Off on all repairs</b></h2>-->
                </div>

            </div>
        </div>
    </section>
    <section class="device-type-section">
        <div class="container">
            <div class="phone-section">
                <div class="section-header text-center my-5 ">
                    <h1><sup></sup> <?php echo $webContent->repair_page_heading_3; ?> <sub></sub>
                    </h1>
                    <p>
                      <?php echo $webContent->repair_page_heading_4; ?>

                    </p>

                </div>
                <div class="d-flex justify-content-center gap-3 flex-wrap mb-5 ">

                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <div class="black-cards">
                            <a href="<?php echo e(route('device-types', $category->id)); ?>">
                                <?php if($category->name != 'Apple iPad'): ?>
                                    <div class="card">
                                        <div class="card-header">
                                            <img src="<?php echo e($category->file ?? ''); ?>" class="img-thumbnail border-0"
                                                style="height:150px;">
                                        </div>
                                        <div class="card-body">
                                            <h4 class="text-center">
                                                <b><?php echo e($category['name']); ?></b>
                                            </h4>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </a>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span>Not Found</span>
                    <?php endif; ?>

                </div>

            </div>


        </div>
    </section>


</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/livewire/guest/categories.blade.php ENDPATH**/ ?>
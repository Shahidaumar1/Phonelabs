










<div class="search-bar">
    <input type="text" class="form-control" placeholder="e.g iPhone 15 screen repair...." wire:model="search">

    <?php if($results): ?>
        <ul class="list-group mt-2" style="max-height: 300px; overflow-y: auto;">
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($result instanceof \App\Models\DeviceType): ?>
                    <li class="list-group-item font-weight-bold">
                        <a style="color: black" href="javascript:void(0);"
                            wire:click="navigate('deviceType', <?php echo e($result->id); ?>)">
                            <?php echo e($result->name); ?>

                        </a>
                    </li>
                    <?php $__currentLoopData = $result->modals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item ml-3">
                            <a style="color: black" href="javascript:void(0);"
                                wire:click="navigate('modal', <?php echo e($modal->id); ?>)">
                                <?php echo e($modal->name); ?>

                            </a>
                            <ul class="list-group ml-3">
                                <?php $__currentLoopData = $modal->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($price->repairType): ?>
                                        <li class="list-group-item">
                                            <a style="color: black" href="javascript:void(0);"
                                                wire:click="navigate('price', <?php echo e($price->id); ?>)">
                                                Price: £<?php echo e($price->price); ?> - Repair Type: <?php echo e($price->repairType->name); ?>

                                            </a>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($modal->prices->isEmpty()): ?>
                                    <li class="list-group-item">
                                        <span>No prices available</span>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($result instanceof \App\Models\Modal): ?>
                    <li class="list-group-item">
                        <a style="color: black; font-weight: bold;" href="javascript:void(0);"
                            wire:click="navigate('deviceType', <?php echo e($result->deviceType->id); ?>)">
                            <?php echo e($result->deviceType->name); ?>

                        </a>
                    </li>
                    <li class="list-group-item ml-3">
                        <a style="color: black" href="javascript:void(0);"
                            wire:click="navigate('modal', <?php echo e($result->id); ?>)">
                            <?php echo e($result->name); ?>

                        </a>
                        <ul class="list-group ml-3">
                            <?php $__currentLoopData = $result->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($price->repairType): ?>
                                    <li class="list-group-item">
                                        <a style="color: black" href="javascript:void(0);"
                                            wire:click="navigate('price', <?php echo e($price->id); ?>)">
                                            Price: £<?php echo e($price->price); ?> - Repair Type: <?php echo e($price->repairType->name); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($result->prices->isEmpty()): ?>
                                <li class="list-group-item">
                                    <span>No prices available</span>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php elseif($result instanceof \App\Models\Price): ?>
                    <?php if($result->modal && $result->modal->deviceType): ?>
                        <li class="list-group-item">
                            <a style="color: black" href="javascript:void(0);"
                                wire:click="navigate('price', <?php echo e($result->id); ?>)">
                                Price: £<?php echo e($result->price); ?> - 
                                Model: <?php echo e($result->modal ? $result->modal->name : 'N/A'); ?> - 
                                Device Type: <?php echo e($result->modal && $result->modal->deviceType ? $result->modal->deviceType->name : 'N/A'); ?>

                            </a>
                            <ul class="list-group ml-3">
                                <li class="list-group-item">
                                    Repair Type: <?php echo e($result->repairType ? $result->repairType->name : 'N/A'); ?>

                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php elseif($result instanceof \App\Models\RepairType): ?>
                    <?php
                        $prices = $result->prices->filter(function($price) {
                            return $price->modal && $price->modal->deviceType;
                        });
                    ?>
                    <?php if($prices->isNotEmpty()): ?>
                        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <a style="color: black" href="javascript:void(0);"
                                    wire:click="navigate('price', <?php echo e($price->id); ?>)">
                                    Repair Type: <?php echo e($result->name); ?> - 
                                    Price: £<?php echo e($price->price); ?> - 
                                    Model: <?php echo e($price->modal ? $price->modal->name : 'N/A'); ?> - 
                                    Device Type: <?php echo e($price->modal && $price->modal->deviceType ? $price->modal->deviceType->name : 'N/A'); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li class="list-group-item">
                            <span>No prices available</span>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</div>



<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/components/search-bar.blade.php ENDPATH**/ ?>
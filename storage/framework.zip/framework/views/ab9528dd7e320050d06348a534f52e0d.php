<div>
    <div>
        <!-- --------------------------top bar----------------- -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l1537855649-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1537855649-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1537855649-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1537855649-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1537855649-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <!-- --------------------navbar--------------------- -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l1537855649-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1537855649-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1537855649-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1537855649-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1537855649-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <!-- --------------search filter-------- -->

        <div>
        <!-- --------------------navbar--------------------- -->
        <!-- --------------search filter-------- -->

        <div class="container ">
             <a href="<?php echo e(route('home')); ?>">
                        
                    <button class="btn btn-danger btn-sm mt-2"  ><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
</svg> </button>
                    </a>
            
            <div class="row">
                <div class="d-flex my-3 align-items-center justify-content-center  ">

                    <div class="col-lg-6 col-md-4">
                        <form class="d-flex " role="search">
                            <div class="wrapper">
                                <div class="search_box khuram">
                                    <div class="d-flex gap-2 ">
                                        <div class="dropdown ">

                                            <select class="form-control categories-k rounded-pill " wire:model="selectedCategoryId">

                                                <option class="text-center font-weight-bold kh" value="All">All</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option value="">Not Found!</option>
                                                <?php endif; ?>


                                            </select>
                                        </div>
                                        <div class="search_field ">
                                            <input type="text" class="form-control rounded-pill" placeholder="Search" wire:model.debounce.500="search">
                                            

                                            <img class="bi" src="<?php echo e(asset('assets/kimges/icon.webp')); ?>" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        
        <div class="d-flex flex-wrap justify-content-center mb-4">
            <?php if($selectedCategoryId != 'All'): ?>
            <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bubble logo1 bg-light cursor-pointer mb-2 <?php echo e($selectedDevice && $selectedDevice->id == $device->id ? 'border border-success border-2 ' : ''); ?>" wire:click="selectDevice('<?php echo e($device->id); ?>')">
                <img src="<?php echo e($device->file ?? '#'); ?>" alt="" class="img-fluid">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div>Not Found !</div>
            <?php endif; ?>
            <?php endif; ?>
        </div>


        
        <section class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="d-flex justify-content-end">
                        <a class="text-primary cursor-pointer" wire:click="clearFilter">Clear Filter</a>
                    </div>
                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> device</h3>
                        <div class="p-2">
                            <div class="form-check">
                                <input <?php echo e($selectedCategoryId == 'All' ? 'checked' : ''); ?> class="form-check-input" type="radio" name="category" value="<?php echo e('All'); ?>" wire:model="selectedCategoryId">
                                <label class="form-check-label">
                                    All
                                </label>
                            </div>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input <?php echo e($selectedCategoryId == $category->id ? 'checked' : ''); ?> class="form-check-input" type="radio" name="category" value="<?php echo e($category->id); ?>" wire:model="selectedCategoryId">
                                <label class="form-check-label">
                                    <?php echo e($category->name); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                    <?php if($selectedCategoryId != 'All'): ?>
                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> Models</h3>
                        <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-2">
                            <div class="form-check">
                                <input <?php echo e($selectedDevice && $selectedDevice->id  == $device->id ? 'checked' : ''); ?> class="form-check-input" type="radio" name="device" value="<?php echo e($device->id); ?>" wire:click="selectDevice('<?php echo e($device->id); ?>')">
                                <label class="form-check-label">
                                    <?php echo e($device->name); ?>

                                </label>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div>Not Found !</div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> Memory Sizes</h3>
                        <div class="p-2">
                            <?php $__currentLoopData = $memory_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memory_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input <?php echo e($selectedMemorySize == $memory_size ? 'checked' : ''); ?> class="form-check-input" type="radio" name="memory_size" value="<?php echo e($memory_size); ?>" wire:click="filterByMemorySize('<?php echo e($memory_size); ?>')">
                                <label class="form-check-label">
                                    <?php echo e($memory_size); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> Grade</h3>
                        <div class="p-2">
                            <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input <?php echo e($selectedGrade == $g ? 'checked' : ''); ?> class="form-check-input" type="radio" name="grade" value="<?php echo e($g); ?>" wire:click="filterByGrade('<?php echo e($g); ?>')">
                                <label class="form-check-label">
                                    <?php echo e($g); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                    <!-- ---------------Color-------- -->

                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> Color</h3>
                        <div class="p-2">
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input <?php echo e($selectedColor == $color ? 'checked' : ''); ?> class="form-check-input" type="radio" name="color" value="<?php echo e($color); ?>" wire:click="filterByColor('<?php echo e($color); ?>')">
                                <label class="form-check-label">
                                    <?php echo e($color); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                    <!-- -------------------------price----------- -->
                    <div class="box card my-2">
                        <h3 class="bg-danger text-white  p-2"> PRICE</h3>
                        <div class="p-2">
                            <label for="customRange1" class="form-label">£0</label>
                            <input type="range" class="form-range" id="customRange1" min="0" max="12000" wire:model="price">
                            <span style="float:right;">£ <?php echo e($price ?? '12000'); ?></span>
                        </div>
                    </div>

                </div>
<div class="col-lg-9">
    <div class="row row-cols-2 row-cols-md-4 g-3 justify-content-center">
        <?php $__empty_1 = true; $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col">
            <a href="<?php echo e(route('guest-buy-product-specs', $model['id'])); ?>">
                <div class="card pt-1 text-center">
                    <div class="d-flex justify-content-center">
                        <img src="<?php echo e($model['file'] ?? '#'); ?>" class="img-fluid" style="width: 140px;height: 140px;" />
                    </div>
                    <div class="card-body">
                        <h6 style="font-size:13px;" class="card-text "><?php echo e($model['name']); ?></h6>
                        <!-- Added "d-grid" class to make the button responsive -->
                        <span style="font-size:12px;" class="btn btn-danger d-grid w-100">View Details</span>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col">
            <span>Not Found!</span>
        </div>
        <?php endif; ?>
    </div>
</div>




            </div>

        </section>




    </div>



    </div>
</div>
<style>
    .kh {
        font-weight: 900 !important;
    }
</style>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/buy/index.blade.php ENDPATH**/ ?>
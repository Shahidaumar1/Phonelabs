<div>
    






<!--<div>-->
<!--    <div class="form-group">-->
<!--        <label for="post_code">Post Code:</label>-->
<!--        <input type="text" wire:model.debounce.500ms="post_code" class="form-control" id="post_code" placeholder="Enter Post Code">-->
<!--        <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
<!--            <span class="text-danger"><?php echo e($message); ?></span>-->
<!--        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
<!--    </div>-->

<!--    <div id="resultContainer" class="mt-3">-->
<!--        <?php if(isset($responseData['knownAddresses']) && count($responseData['knownAddresses']) > 0): ?>-->
<!--            <select class="form-select">-->
<!--                <option value="" selected>Select an option</option>-->
<!--                <?php $__currentLoopData = $responseData['knownAddresses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
<!--                    <option value="<?php echo e($address); ?>"><?php echo e($address); ?></option>-->
<!--                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
<!--            </select>-->
<!--        <?php else: ?>-->
<!--            <p>No addresses found or API call failed.</p>-->
<!--        <?php endif; ?>-->
<!--    </div>-->
<!--</div>-->
<div class="row" style="display: flex; justify-content: center; align-items: center;">
    <div class="col-md-6 col-sm-12 col-12">
<div>
    <div class="form-group">
        <label for="post_code">Post Code:</label>
        <input type="text" wire:model.debounce.500ms="post_code" wire:model.lazy="collection.post_code" class="form-control" id="post_code" placeholder="Enter Post Code">
        <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div id="resultContainer" class="mt-3">
        <?php if(isset($responseData['knownAddresses']) && count($responseData['knownAddresses']) > 0): ?>
            <select wire:model="selectedAddress" class="form-select">
                <option value="" selected>Select an option</option>
                <?php $__currentLoopData = $responseData['knownAddresses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($address); ?>"><?php echo e($address); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
            <p>No addresses found or API call failed.</p>
        <?php endif; ?>
    </div>
</div>

<div class="mb-3 mt-3">
    <label for="address_line_2">Address Line 1*:</label>
    <input type="text" class="form-control form-control-sm" id="address" wire:model.lazy="collection.address_line_1" placeholder="Address Line 1" name="address_line_1" required="">
    <?php $__errorArgs = ['collection.address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>







<!--<div class="mb-3 mt-3">-->
<!--    <label for="address_line_2">Address Line 1*:</label>-->
<!--    <input type="text" class="form-control form-control-sm" id="address" wire:model.lazy="collection.address_line_1" placeholder="Address Line 1" name="address_line_1-->
<!--            " required="">-->
<!--    <?php $__errorArgs = ['collection.address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
<!--    <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>-->
<!--    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
<!--</div>-->
<div class="mb-3 mt-3">
    <label for="address_line_2">Address Line 2:</label>
    <input type="text" class="form-control form-control-sm" wire:model.lazy="collection.address_line_2" id="address_line_2" placeholder="Address Line 2" name="address_line_2">
</div>

<div class="mb-3 mt-3">
    <label for="city">Town/City*:</label>
    <input type="text" class="form-control form-control-sm" id="city" wire:model.lazy="collection.city" placeholder="Town/City" name="city" required="">
    <?php $__errorArgs = ['collection.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-3 mt-3 ">
    <label for="email">Post Code*:</label>
    <input type="text" class="form-control form-control-sm" id="post_code
        " wire:model.lazy="collection.post_code" placeholder="Post Code
                   " name="post_code
                   " required="">
    <?php $__errorArgs = ['collection.post_code
    '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>




<div class="mb-3 mt-3">
    <label for="repair_date">Date</label>
    <select class="form-control form-select form-control-sm" id="repair_date" name="repair_date" wire:model.lazy="collection.repair_date">
        <option>Select Date</option>
        <?php
        use Carbon\Carbon;
        use Carbon\CarbonInterval;
        $currentDate = Carbon::now('Europe/London');
        $workingDays = 0;

        // Fetch public holidays using API
        $year = $currentDate->year;
        $publicHolidaysURL = "https://date.nager.at/Api/v2/PublicHolidays/{$year}/GB";

        $publicHolidaysResponse = file_get_contents($publicHolidaysURL);
        $publicHolidays = json_decode($publicHolidaysResponse);

        while ($workingDays < 10) { $currentDate->addDay();

            if ($currentDate->isWeekday() && !$this->isPublicHoliday($currentDate, $publicHolidays)) {
            $workingDays++;
            echo '<option value="' . $currentDate->toDateString() . '">' . $currentDate->format('D d/m/Y') . '</option>';
            }
            }

            function isPublicHoliday($date, $publicHolidays)
            {
            foreach ($publicHolidays as $holiday) {
            if ($date->toDateString() === $holiday->date) {
            return true;
            }
            }
            return false;
            }
            ?>
    </select>
    <?php $__errorArgs = ['collection.repair_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-3 mt-3 ">
    <label for="repair_slot">Select Slot</label>
    <select class="form-control form-select form-control-sm" wire:model="collection.repair_slot" id="repair_slot">
        <option>Select Slot</option>
        <option value="11am - 2pm">11am - 2pm</option>
        <option value="2pm - 5pm">2pm - 5pm</option>
        <option value="5pm - 8pm">5pm - 8pm</option>
    </select>
    <?php $__errorArgs = ['collection.repair_slot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-2">
    <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Write Note</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" wire:model="collection.repair_note" rows="3" name="repair_note" placeholder="Please write any comment...">
                </textarea>
        <?php $__errorArgs = ['collection.repair_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>

</div></div>

 <div class="container-fluid mt-4">
    <div class="row">
        <div class="col d-flex justify-content-end">
            <button type="submit" wire:click.prevent="submitForm" class="btn p-0 border-0" style="background: none;">
                <!--<img id="next-button" src="https://ik.imagekit.io/li8bg5tjv3/1.png?updatedAt=1715028228699" style="width: 150px; height: auto;" />-->
                <button type="submit"wire:click.prevent="submitForm"   class="btn btn-danger customer-btn" style="margin-top: 20px; padding: 10px 4px; width: 10%; border-radius: 15px;">Next</button>
            </button>
        </div>
    </div>
</div>
</div><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/guest/collection-form.blade.php ENDPATH**/ ?>
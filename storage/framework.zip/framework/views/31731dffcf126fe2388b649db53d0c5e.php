<div>

    <div>
        <h3><?php echo e($model->name ?? ''); ?> (<?php echo e($product_spec->memory_size ?? ''); ?>) </h3>
        <div class="d-flex justify-content-center my-4">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link cursor-pointer  <?php echo e($editor == 'Detail' ? 'active text-success' : ''); ?>"
                        aria-current="page" wire:click="toggleEditor('Detail')">Details</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link cursor-pointer  <?php echo e($editor == 'Specification' ? 'active text-success' : ''); ?>"
                        aria-current="page" wire:click="toggleEditor('Specification')">Specification</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link cursor-pointer  <?php echo e($editor == 'Warranty' ? 'active text-success' : ''); ?>"
                        aria-current="page" wire:click="toggleEditor('Warranty')">Warranty</a>
                </li>

            </ul>
        </div>

        <div>
            <h4>Enter <?php echo e($editor); ?></h4>
            <div>


                <div wire:ignore>
                    <textarea wire:model.debounce.500="content" id="editor"></textarea>
                </div>

                <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
                <script>
                    let editorInstance = null;

                    function createEditor() {
                        if (editorInstance) {
                            editorInstance.destroy().then(() => {
                                // console.log('Editor destroyed.');
                                initializeNewEditor();
                            });
                        } else {
                            initializeNewEditor();
                        }
                    }

                    function initializeNewEditor() {

                        ClassicEditor
                            .create(document.querySelector('#editor'))
                            .then(editor => {
                                editorInstance = editor;
                                editor.model.document.on('change:data', () => {
                                    window.livewire.find('<?php echo e($_instance->id); ?>').set('content', editor.getData());
                                });
                            })
                            .catch(error => {
                                console.error(error);
                            });
                    }


                    // createEditor();
                    Livewire.on('editorTypeChanged', (content) => {
                        if (editorInstance) {
                            editorInstance.setData(window.livewire.find('<?php echo e($_instance->id); ?>').get('content'));
                        }
                        createEditor();
                    });
                </script>
            </div>

            <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-xs text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>


    <div class="float-end mt-3 ">
        <button type="button" class="bg-blue text-white" wire:click="save">
            Save Changes
            <span wire:loading wire:target='save'>
                <?php if (isset($component)) { $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0 = $component; } ?>
<?php $component = App\View\Components\Spinner::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Spinner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0)): ?>
<?php $component = $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0; ?>
<?php unset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0); ?>
<?php endif; ?>
            </span>
        </button>
    </div>



</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/livewire/admin/buy/addon/more-spec.blade.php ENDPATH**/ ?>
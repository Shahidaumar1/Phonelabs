<div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l2749009785-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2749009785-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2749009785-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2749009785-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2749009785-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <section class="head-sell">
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l2749009785-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2749009785-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2749009785-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2749009785-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2749009785-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </section>


    <section>

        <div class="container mt-5 ">
            <div class="row">
                <h6 class="text-center fs-1 fw-bold">Sell <?php echo e($model->name); ?>- Mobilebitz</h6>


                <!-- Parent View -->


                <p class="text-center text-danger">(This enables us to offer you a preliminary estimate.)</p>
                <div class="col-lg-6 p-5 mt-5">
                    <img src="<?php echo e($product_spec_image ?? $model->file); ?>" class="img-fluid" alt="Responsive Image"
                        style="max-height: 380px;">
                </div>

                
                <?php
                    $product_specs = App\Models\ProductSpec::where('model_id', $model->id)->get();
                ?>
                <div class="col-lg-6  p-5 ">
                    <div>
                        <?php if(in_array(!null, $available_memory_sizes)): ?>
                            <p class="fs-6 fw-bold">Select Memory Size:</p>
                        <?php endif; ?>

                        <?php $__empty_1 = true; $__currentLoopData = $available_memory_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memory_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($memory_size != null): ?>
                                <button type="button"
                                    class="btn btn-outline-danger <?php echo e($memory_size == $selectedMemorySize ? 'bg-danger text-white' : ''); ?>"
                                    wire:click="$set('selectedMemorySize','<?php echo e($memory_size); ?>')"><?php echo e($memory_size); ?></button>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                        <div>
                            <?php
                                // Define the custom order
                                $customOrder = ['Excellent', 'Good', 'Fair', 'Poor', 'Faulty'];
                                // Sort the grades array based on the custom order
                                usort($available_conditions, function ($a, $b) use ($customOrder) {
                                    return array_search($a, $customOrder) - array_search($b, $customOrder);
                                });
                            ?>
                            <p class="fs-6 mt-3 fw-bold">Select Condition:</p>
                            <div class="d-flex  gap-2 border-0  align-items-center" style="margin-bottom: -7px">
                                <?php $__empty_1 = true; $__currentLoopData = $available_conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <label
                                        class=" cursor-pointer px-3  py-2 rounded-top border border-2  <?php echo e($condition == $selectedCondition ? '  bg-gray text-black' : ''); ?> "
                                        wire:click="$set('selectedCondition','<?php echo e($condition); ?>')">
                                        <?php echo e($condition); ?>

                                    </label>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>



                            <?php if($selectedCondition): ?>
                                <div class="bg-gray border-0 text-black  rounded p-2 mt-1   ">
                                    <?php echo $condition_text; ?>

                                </div>
                            <?php endif; ?>

                            <div class="mt-3">

                                <?php if($mobileMode || $tabletMode): ?>
                                    <?php
                                        $network_images = [
                                            'Vodafone' =>
                                                'https://upload.wikimedia.org/wikipedia/commons/f/ff/Logo_vodafone_new.png',
                                            'o2' => 'https://cdn2.downdetector.com/static/uploads/logo/O2-logo.jpg',
                                            'Smarty' =>
                                                'https://media.product.which.co.uk/prod/images/original/gm-9642cb8d-b24b-4ce6-afd6-cfac01256877-smarty.jpg',
                                            'EE' =>
                                                'https://c8.alamy.com/comp/EFEKFE/ee-logo-or-sign-for-mobile-network-operator-and-internet-provider-EFEKFE.jpg',
                                            'Asda' =>
                                                'https://media.product.which.co.uk/prod/images/original/gm-99fb2e68-49d9-4b68-be97-57f35c5e8314-asda-mobile.jpg',
                                            'Tesco' =>
                                                'https://media.product.which.co.uk/prod/images/original/gm-989813fb-0b40-4582-a0e8-2ab7a437429e-tesco-mobile.jpg',
                                        ];
                                    ?>
                                    <div class="col-lg-12 p-5">
                                        <div>
                                            <?php if(count($network_providers) > 0): ?>
                                                <p class="fs-6 fw-bold">Select Network:</p>
                                            <?php endif; ?>

                                            <?php $__empty_1 = true; $__currentLoopData = $network_providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <!-- Adjusted to work with names -->
                                                <?php if(isset($network_images[$network_name])): ?>
                                                    <!-- Check if the network has an image -->
                                                    <button type="button"
                                                        class="btn <?php echo e($network_name == $selectedNetwork ? 'bg-danger text-white' : 'btn-outline-success'); ?>"
                                                        wire:click="selectNetwork('<?php echo e($network_name); ?>')">
                                                        <!-- Select network on click -->
                                                        <img src="<?php echo e($network_images[$network_name]); ?>"
                                                            alt="<?php echo e($network_name); ?>" style="width: 30px; height: 30px;" />
                                                        <!-- Correctly set the image source -->
                                                    </button>
                                                <?php else: ?>
                                                    <button type="button" class="btn btn-outline-primary">
                                                        <?php echo e($network_name); ?> <!-- Fallback if there's no image -->
                                                    </button>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <p>No networks available</p> <!-- Fallback message -->
                                            <?php endif; ?>
                                        </div>
                                    </div>


                                    

                                    
                                    <!--<tr>-->
                                    <!--    <th>Account/cleared</th>-->
                                    <!--    <td>-->
                                    <!--        <div class="form-check form-switch">-->
                                    <!--            <input type="checkbox" role="switch"-->
                                    <!--                class="form-check-input border border-dark"-->
                                    <!--                wire:change="toggleAccountCleared" id="<?php echo e($rand . 'ac'); ?>" />-->
                                    <!--        </div>-->
                                    <!--    </td>-->
                                    <!--</tr>-->
                                <?php endif; ?>

                                <div class="mt-3 mb-1">
                                    <div class=" mt-5 d-flex align-items-end flex-column  mb-3">
                                        <div class="text-center" id="cashText">
                                            <h2 class=" text-danger fw-bold">Cash Value: £<?php echo e($price); ?>.00</h2>
                                            <small>select device specification above to see price</small>
                                        </div>
                                        <div class="p-2 fs-3 fw-bold text-secondary ">
                                            
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </section>

    <section class="container">
        <div class="bg-gray ">
            <div class="row border border-2 border-dark rounded">

                <div class="col-12 col-lg-6 col-md-6 order-1 order-md-0 bg-pink-linear rounded p-4">
                    <div class="w-100 mx-auto mb-4">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-12 col-lg-6 col-md-6 order-0 order-md-1 bg-pink-linear rounded p-4">
                    <div class="w-100 mx-auto mb-4">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    </div>
                </div>

            </div>
        </div>
    </section>



    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.sell.booking-form', [])->html();
} elseif ($_instance->childHasBeenRendered('l2749009785-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l2749009785-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2749009785-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2749009785-4');
} else {
    $response = \Livewire\Livewire::mount('guest.sell.booking-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2749009785-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH /home/mobilebitz/test.mobilebitz.co.uk/resources/views/livewire/guest/sell/model-detail.blade.php ENDPATH**/ ?>
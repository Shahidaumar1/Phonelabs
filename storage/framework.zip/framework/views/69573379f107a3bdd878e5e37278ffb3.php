<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l871127198-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l871127198-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l871127198-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l871127198-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l871127198-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <section class="device-type-head">
        <div class="overlay"></div>
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l871127198-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l871127198-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l871127198-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l871127198-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l871127198-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <a href="<?php echo e(route('categories')); ?>">

                <button class="btn btn-danger btn-sm mt-2"><svg xmlns="http://www.w3.org/2000/svg" width="35"
                        height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
                        <path fill-rule="evenodd"
                            d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z" />
                    </svg></button>
            </a>
            <div class="p-3 rounded-2 mt-5 d-flex justify-content-between align-items-center"
                style="background-color: #afafaf">
                <div class="d-flex flex-column">
                    <h1 class="text-black">Need a Repair?</h1>
                    <span class="tagline text-black">Tell Us Which Device You Have…</span>
                </div>








                <div class="d-flex justify-content-end align-items-center">
                    
                    <!--<h2 class=" mt-3 ml-3 " style="color: #da0a0a"><b>Students can get 10% Off on all repairs</b></h2>-->
                </div>

            </div>
        </div>
    </section>
    <section class="device-type-section">
        <div class="container">
            <div class="phone-section">
                <div class="section-header text-center my-5">
                    <h2><sup></sup> Brands <sub></sub>
                    </h2>
                    <p>
                        Whether you’ve got a broken screen, a battery problem or charging problem, we fix a wide
                        range<br>
                        of devices, from your Pixel, iPhones & Samsungs, to your Xiaomis, iPads, Lenovos, Huawei<br>
                        MediaPads, HPs, Dells and even your old Nokias…
                    </p>

                </div>
                <div class="d-flex justify-content-center gap-3 flex-wrap mb-5">

                    <?php $__empty_1 = true; $__currentLoopData = $device_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <div class="black-cards">
                            <a href="<?php echo e(route('modals', $device_type->id)); ?>">
                                <?php if($device_type->name != 'Apple iPad'): ?>
                                    <div class="card">
                                        <div class="card-header">
                                            <img src="<?php echo e($device_type->file ?? ''); ?>" class="img-fluid c-img"
                                                style="height:120px; width:170px;" />
                                        </div>
                                        
                                    </div>
                                <?php endif; ?>

                            </a>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span>Not Found</span>
                    <?php endif; ?>
                    <div class="col-2">
                        <div class="card ">
                            <img style="width: 60%;" onclick="toggleVisibility()" class="img-fluid"
                                src="https://thumbs.dreamstime.com/b/d-white-man-red-questionmark-computer-generated-image-isolated-68105896.jpg"
                                alt="">

                            <p class="card-text text-center border" onclick="toggleVisibility()">Other </p>
                        </div>

                    </div>






                </div>

                <div class="hidediv">

                    <div style="position: relative;top:30px;">
                        <h1 class="fw-bold text-danger my-3 text-center">Can't Find Your Model?</h1>
                        <h2 class="fw-bold  my-3 text-center">Ask For Qoute Below</h2>
                    </div>
                    <div style="position: relative;" class="hidediv container bg-gray rounded-4 p-5 mt-5  mb-5">




                        <div>
                            <!-- Livewire form to collect customer information -->
                            <form wire:submit.prevent="sendCustomerEmail">
                                <!-- Form fields for customer information -->

                                <!-- Additional Input Boxes for Brand and Model -->
                                <div class="row">

                                    <div class="container col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="brand">Brand:</label>
                                            <input class="form-control" type="text" id="brand" wire:model="brand"
                                                placeholder="Enter brand">
                                            <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="model">Model:</label>
                                            <input class="form-control" type="text" id="model" wire:model="model"
                                                placeholder="Enter model">
                                            <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div>
                                            <label class="form-label" for="additionalDescription">Additional
                                                Information:</label>
                                            <textarea class="form-control" class="form-control" id="additionalDescription" wire:model="additionalDescription"
                                                placeholder="Enter additional information"></textarea>
                                            <?php $__errorArgs = ['additionalDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>



                                    <div class="container col-md-6">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox1">Broken Screen</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox1"
                                                    wire:model="checkboxes" value="Broken Screen">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox2">Battery
                                                    Replacement</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox2"
                                                    wire:model="checkboxes" value="Battery Replacement">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox3">Charging Port
                                                    Repair</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox3"
                                                    wire:model="checkboxes" value="Charging Port Repair">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox4">Housing Issue</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox4"
                                                    wire:model="checkboxes" value="Housing Issue">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox5">Audio Fault</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox5"
                                                    wire:model="checkboxes" value="Audio Fault">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="checkbox6">Water Damage</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="checkbox6"
                                                    wire:model="checkboxes" value="Water Damage">
                                            </div>
                                        </div>

                                        <!-- "Other" Checkbox with Conditional Text Input -->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="form-label" for="otherCheckbox">Other</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-check-input" type="checkbox" id="otherCheckbox"
                                                    wire:model="checkboxes" value="Other">
                                            </div>
                                        </div>

                                        <?php if(in_array('Other', $checkboxes)): ?>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label class="form-label" for="otherText">Please
                                                        specify:</label>
                                                    <input class="form-control" type="text" id="otherText"
                                                        wire:model="otherText" placeholder="Describe other">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>


                                </div>


                                <div class="row mt-5">

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="firstName">First Name:</label>
                                            <input class="form-control" type="text" id="firstName"
                                                wire:model="firstName" required placeholder="Enter your first name">
                                            <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="lastName">Last Name:</label>
                                            <input class="form-control" type="text" id="lastName"
                                                wire:model="lastName" required placeholder="Enter your last name">
                                            <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="email">Email:</label>
                                            <input class="form-control" type="email" id="email"
                                                wire:model="email" required placeholder="Enter your email">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="productName">Confirm Email</label>
                                            <input class="form-control" type="email" id="productName"
                                                wire:model="productName" required
                                                placeholder="Enter the product name">
                                            <?php $__errorArgs = ['productName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="phone">Phone:</label>
                                            <input class="form-control" type="text" id="phone"
                                                wire:model="phone" required placeholder="Enter your phone number">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>



                                        



                                        <div>
                                            <label class="form-label">Are you an existing customer?</label>
                                            <!-- Use Flexbox for close alignment -->
                                            <div style="width: 20%; display: flex; align-items: center; gap: 5px; ">
                                                <!-- Smaller gap -->
                                                <input class="form-check-input" type="radio"
                                                    id="existingCustomerYes" name="existingCustomer" value="yes"
                                                    wire:model="existingCustomer">
                                                <label class="form-check-label" for="existingCustomerYes">Yes</label>
                                                <!-- Label close to radio button -->

                                                <input class="form-check-input" type="radio"
                                                    id="existingCustomerNo" name="existingCustomer" value="no"
                                                    wire:model="existingCustomer">
                                                <label class="form-check-label" for="existingCustomerNo">No</label>
                                                <!-- Label close to radio button -->
                                            </div>

                                            <?php $__errorArgs = ['existingCustomer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                        <div>
                                            <label class="form-label">Are you a business?</label>
                                            <div style="width: 20%; display: flex; align-items: center; gap: 5px;">
                                                <!-- Minimal gap -->
                                                <input class="form-check-input" type="radio" id="isBusinessYes"
                                                    name="isBusiness" value="yes" wire:model="isBusiness">
                                                <label for="isBusinessYes">Yes</label>

                                                <input class="form-check-input" type="radio" id="isBusinessNo"
                                                    name="isBusiness" value="no" wire:model="isBusiness">
                                                <label for="isBusinessNo">No</label>
                                            </div>

                                            <?php $__errorArgs = ['isBusiness'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                    </div>
                                </div>
                        </div>
                        <script>
                            // Function to toggle the visibility of the target div
                            function toggleVisibility() {
                                // Select the div with class "container bg-gray rounded-4 p-5 mt-5"
                                const contentDiv = document.querySelector('.hidediv');
                                // Toggle the "d-none" class to hide/show the div
                                if (contentDiv) {
                                    // Toggle between 'none' and 'block' to show/hide
                                    contentDiv.style.display = contentDiv.style.display === 'none' ? 'block' : 'none';
                                }
                            }

                            document.addEventListener('DOMContentLoaded', () => {
                                // Hide the content div at the start of the page
                                const contentDiv = document.querySelector('.hidediv');
                                if (contentDiv) {
                                    contentDiv.style.display = 'none'; // Hide the div
                                }
                            });
                        </script>


                        <!-- Checkboxes for user selection -->



                        <!-- Submit Button -->
                        <div class="d-flex justify-content-center mt-5">
                            <button class="btn btn-danger text-white rounded-pill" type="submit">Ask For
                                Qoute</button>
                            <!-- Button to submit the form -->
                        </div>
                        </form>

                        <!-- Display success message when the email is sent -->
                        <?php if(session()->has('emailSent')): ?>
                            <div>
                                <p>Thank you! The information has been sent to your email.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>


            </div>

            
        </div>


    </section>











</div>
<style>
    @media screen and (max-width: 768px) {
        .c-img {
            height: 80px !important;
            width: 130px !important;
        }
    }

    @media screen and (max-width: 500px) {
        .c-img {
            height: 80px !important;
            width: 120px !important;
        }
    }

    @media only screen and (max-width: 767px) {

        /* Adjust max-width as per your need */
        .d-flex {
            gap: 2px;
            /* Adjust the value as per your preference */
        }
    }
</style>
<?php /**PATH /home/mobilebitz/new.mobilebitz.co.uk/resources/views/livewire/guest/device-typs.blade.php ENDPATH**/ ?>
<div class="spinner-border text-<?php echo e($color ?? 'light'); ?>  spinner-border-sm" role="status">
    <span class="visually-hidden">Loading...</span>
</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/components/spinner.blade.php ENDPATH**/ ?>
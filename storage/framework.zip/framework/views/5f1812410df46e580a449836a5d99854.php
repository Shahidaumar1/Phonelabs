<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
    <!-- Add this link in the head section of your HTML document -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.19.0/font/bootstrap-icons.css" rel="stylesheet">



    <style>
        .top-bar {
            height: 40px;
            background-color: black;
            padding: 0 10px;
            color: white;
        }

        .left-text,
        .right-text {
            display: flex;
            align-items: center;
        }

        .dropdown-menu {
            background-color: black;
            color: white;
        }


        .navbar-nav .nav-item.nav-link.active-link {
            border-bottom: 2px solid red !important;
        }


        .button-width {
            min-width: 150px;
        }

        .star-container {
            color: gold;
        }
    </style>

    <title>Responsive Bootstrap Navbar</title>
</head>

<body>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l2886384877-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2886384877-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2886384877-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2886384877-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2886384877-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l2886384877-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2886384877-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2886384877-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2886384877-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2886384877-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<br/><br/>
    <div class="container">
        <div class="row">

            <div class="col-md-6">
                <div class="card d-flex flex-column " style="justify-content: center; text-align: center;">
                        <img class="card-img-top img-fluid" src="https://ik.imagekit.io/b6iqka2sz/assets/1.jpg?updatedAt=1705411179251" alt="Card image cap">
                       
                    </div>

                <style>
                    .carousel {
                        position: relative;
                    }

                    .carousel-item img {
                        object-fit: cover;
                    }

                    #carousel-thumbs {
                        background: rgba(255, 255, 255, .3);
                        bottom: 0;
                        left: 0;
                        padding: 0 50px;
                        right: 0;
                    }

                    #carousel-thumbs img {
                        border: 5px solid transparent;
                        cursor: pointer;
                    }

                    #carousel-thumbs img:hover {
                        border-color: rgba(255, 255, 255, .3);
                    }

                    #carousel-thumbs .selected img {
                        border-color: #fff;
                    }

                    .carousel-control-prev,
                    .carousel-control-next {
                        width: 50px;
                    }

                    @media all and (max-width: 767px) {
                        .carousel-container #carousel-thumbs img {
                            border-width: 3px;
                        }
                    }

                    @media all and (min-width: 576px) {
                        .carousel-container #carousel-thumbs {
                            position: absolute;
                        }
                    }

                    @media all and (max-width: 576px) {
                        .carousel-container #carousel-thumbs {
                            background: #ccccce;
                        }
                    }
                </style>

                <script>
                    $('#myCarousel').carousel({
                        interval: false
                    });
                    $('#carousel-thumbs').carousel({
                        interval: false
                    });

                    // handles the carousel thumbnails
                    // https://stackoverflow.com/questions/25752187/bootstrap-carousel-with-thumbnails-multiple-carousel
                    $('[id^=carousel-selector-]').click(function () {
                        var id_selector=$(this).attr('id');
                        var id=parseInt(id_selector.substr(id_selector.lastIndexOf('-')+1));
                        $('#myCarousel').carousel(id);
                    });
                    // Only display 3 items in nav on mobile.
                    if ($(window).width()<575) {
                        $('#carousel-thumbs .row div:nth-child(4)').each(function () {
                            var rowBoundary=$(this);
                            $('<div class="row mx-0">').insertAfter(rowBoundary.parent()).append(rowBoundary.nextAll().addBack());
                        });
                        $('#carousel-thumbs .carousel-item .row:nth-child(even)').each(function () {
                            var boundary=$(this);
                            $('<div class="carousel-item">').insertAfter(boundary.parent()).append(boundary.nextAll().addBack());
                        });
                    }
                    // Hide slide arrows if too few items.
                    if ($('#carousel-thumbs .carousel-item').length<2) {
                        $('#carousel-thumbs [class^=carousel-control-]').remove();
                        $('.machine-carousel-container #carousel-thumbs').css('padding', '0 5px');
                    }
                    // when the carousel slides, auto update
                    $('#myCarousel').on('slide.bs.carousel', function (e) {
                        var id=parseInt($(e.relatedTarget).attr('data-slide-number'));
                        $('[id^=carousel-selector-]').removeClass('selected');
                        $('[id=carousel-selector-'+id+']').addClass('selected');
                    });
                    // when user swipes, go next or previous
                    $('#myCarousel').swipe({
                        fallbackToMouseEvents: true,
                        swipeLeft: function (e) {
                            $('#myCarousel').carousel('next');
                        },
                        swipeRight: function (e) {
                            $('#myCarousel').carousel('prev');
                        },
                        allowPageScroll: 'vertical',
                        preventDefaultEvents: false,
                        threshold: 75
                    });
                    /*
                    $(document).on('click', '[data-toggle="lightbox"]', function(event) {
                      event.preventDefault();
                      $(this).ekkoLightbox();
                    });
                    */

                    $('#myCarousel .carousel-item img').on('click', function (e) {
                        var src=$(e.target).attr('data-remote');
                        if (src) $(this).ekkoLightbox();
                    });
                </script>


            </div>


            <div class="col-md-6">
                <h2>LoveCases Cherry Blossom Case - For Samsung Galaxy S24</h2>
                
                <div>
                </div>
                <div>
                    <p>The Galaxy A23 5G features a 6.6-inch Infinity display with a resolution of 1080 x 2408 
                        pixels and a 20:9 aspect ratio 2. It is equipped with Corning Gorilla Glass 5 for protection 
                        against scratches and accidental drops. The phone is equipped with a multi-lens camera 
                        system. It has a 50MP main camera with OIS (Optical Image Stabilization) for 
                        capturing.  
                </div>
                
                
             
                   




             


                <div class="row mt-3">
                    <div class="col-3">
                        <button class="btn btn-danger btn-lg button-width" style="width: 420%; height: 6vh;">Checkout</button>
                    </div>
                    
                </div><br/>
                <p style="color: black;">More Color</p>
                <div class="card-deck">
                    <div class="card d-flex flex-column " style="justify-content: center; text-align: center;">
                        <img class="card-img-top img-fluid" src="https://ik.imagekit.io/b6iqka2sz/assets/1.jpg?updatedAt=1705411179251" alt="Card image cap">
                        <span class="mt-auto " >white</span>
                    </div>
                    
                    <div class="card d-flex flex-column " style="justify-content: center; text-align: center;">
                        <img class="card-img-top img-fluid" src="https://ik.imagekit.io/b6iqka2sz/assets/19.jpg?updatedAt=1705429904488" alt="Card image cap">
                        <span class="mt-auto " >black</span>
                    </div>
                    <div class="card d-flex flex-column " style="justify-content: center; text-align: center;">
                        <img class="card-img-top img-fluid" src="https://ik.imagekit.io/b6iqka2sz/assets/20.jpg?updatedAt=1705430076134" alt="Card image cap">
                        <span class="mt-auto " >Pink</span>
                    </div>
                    <div class="card d-flex flex-column " style="justify-content: center; text-align: center;">
                        <img class="card-img-top img-fluid" src="https://ik.imagekit.io/b6iqka2sz/assets/21.jpg?updatedAt=1705430166954" alt="Card image cap">
                        <span class="mt-auto " >blue</span>
                    </div>
                  
                    
                </div>
                <br/>
                <div class="card d-flex flex-column " style="justify-content: center; text-align: center; width: 120px;">
                    <img class="card-img-top img-fluid" src="https://ik.imagekit.io/b6iqka2sz/assets/1.jpg?updatedAt=1705411179251" width="50px" alt="Card image cap">
                    <span class="mt-auto " >white</span>
                </div><br/>
                <p style="color: rgb(42, 109, 159); font-size: 15px;">Write a review</p>
                <p class="fs-5 mb-0">Price: <span style="color: black; font-size: 20px;">£11.99</span></p>
<p>
    <img src="https://img.freepik.com/premium-vector/green-check-mark-icon-symbol-logo-circle-tick-symbol-green-color-vector-illustration_685751-503.jpg?w=360" 
         width="30" />
    10 In Stock
</p>


                  <div class="col-3 " style="margin-left: 120px; margin-top:"-30px">
                    <button class="btn btn-danger btn-lg button-width" style="width: 300%; height: 6vh;">ADD TO BASKET</button>
                </div>
                
            </div>
            
        </div>





        <nav>
            <div class="nav nav-tabs text-dark" id="nav-tab" role="tablist" >
              <button class="nav-link active text-dark" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Overview</button>
              <button class="nav-link text-dark" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Questions & Answers
            </button>
              <button class="nav-link text-dark" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false"> 
                Delivery & Returns</button>
            </div>
          </nav>
          <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active mt-3" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                <h3 class="fw-bolder">Key Features</h3>
                <ul>
                    <li>Ultra-thin, flexible and lightweight</li>
                    <li>Transparent case with a unique LoveCases design</li>
                    <li>Raised bezels</li>
                    <li>Non-slip coating</li>
                    <li>Access all your Samsung Galaxy S24's features and ports</li>
                    <li>Wireless charging compatible</li>
                </ul>
                <h3 class="fw-bolder">Description</h3>
                <p>Have your Samsung Galaxy S24 looking cute, whilst also being secure in the knowledge that your phone is protected <br/>from life's little accidents with this beautiful case from LoveCases.</p>
            </div>
            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
             <h3 class="fw-bolder">Key Features</h3>
                <ul>
                    <li>Ultra-thin, flexible and lightweight</li>
                    <li>Transparent case with a unique LoveCases design</li>
                    <li>Raised bezels</li>
                    <li>Non-slip coating</li>
                    <li>Access all your Samsung Galaxy S24's features and ports</li>
                    <li>Wireless charging compatible</li>
                </ul>
                <h3 class="fw-bolder">Description</h3>
                <p>Have your Samsung Galaxy S24 looking cute, whilst also being secure in the knowledge that your phone is protected <br/>from life's little accidents with this beautiful case from LoveCases.</p>
            </div></div>
            <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
            <h3 class="fw-bolder"> Delivery & Returns</h3>
            <p>All product stock messages are up to date and as accurate as possible, with delivery times quoted at the checkout remaining accurate also.

These estimated time of arrival dates are constantly looked at and refreshed to ensure that you can purchase with confidence.<p/>
  <h3 class="fw-bolder"> Delivery Methods</h3>
            </div>
          </div>
          <br/><br/>
    </div>







    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <script>
        // JavaScript to toggle button background color on click
        document.getElementById('button1').addEventListener('click', function () {
            this.classList.toggle('btn-light');
            this.classList.toggle('btn-danger');
        });

        document.getElementById('button2').addEventListener('click', function () {
            this.classList.toggle('btn-light');
            this.classList.toggle('btn-danger');
        });

        // JavaScript to add active-link class to the active link dynamically
        var links=document.querySelectorAll('.navbar-nav .nav-item.nav-link');
        links.forEach(function (link) {
            link.addEventListener('click', function () {
                links.forEach(function (el) {
                    el.classList.remove('active-link');
                });
                this.classList.add('active-link');
            });
        });
    </script>
</body>

</html><?php /**PATH /Users/mubashir/Downloads/MobileBitz 2/resources/views/livewire/guest/checkout.blade.php ENDPATH**/ ?>
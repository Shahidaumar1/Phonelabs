<div>
    <input type="file" class="form-control" wire:model="file" />
    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-sm text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <span wire:loading wire:target="file">Uploading....</span>
    <?php if($imageKitError): ?>
        <span class="text-sm text-danger">Error: when uploading image on ImageKit server. It can be ImageKit not
            allowing
            your
            IP to upload
            image or internet connectivity</span>
    <?php endif; ?>
</div>
<?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/livewire/components/file-upload.blade.php ENDPATH**/ ?>
<div>

    <h2 class="text-danger fs-5 fs-sm-3 fs-md-3">Customer Details</h2>

    <h4>Tell us about yourself</h4>

    <div class="mt-3">
        <label for="email" class="fw-bold">First Name </label>
        <input style="font-size:12px; font-style:italic;" type="text" class="form-control form-control-sm" placeholder="Enter your first name" wire:model.lazy="patient.first_name">
        <?php $__errorArgs = ['patient.first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <!--<span class="error"><?php echo e($message); ?></span>-->
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mt-3">
        <label for="email" class="fw-bold">Last Name </label>
        <input style="font-size:12px; font-style:italic;" type="text" class="form-control form-control-sm" placeholder="Enter your last name" wire:model.lazy="patient.last_name">
        <?php $__errorArgs = ['patient.last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
    <div class="mt-3" x-data="{
            message: '',
            copyAttempt() {
                this.message = 'Copy is not allowed'
                setTimeout(() => { this.message = '' }, 1500)
            }
        }">
        <label for="email" class="fw-bold">Email address </label><br>
        <span class="error" x-text="message"></span>
        <input style="font-size:12px; font-style:italic; type=" text" class="form-control form-control-sm" placeholder="Enter your email address" wire:model.lazy="patient.email" @copy.prevent="copyAttempt">
        <?php $__errorArgs = ['patient.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
    <div class="mt-3">
        <label for="pwd" class="fw-bold">Confirm Email </label>
        <input style="font-size:12px; font-style:italic; type=" text" class="form-control form-control-sm" placeholder="Confirm your email address" wire:model.lazy="patient.confirm_email">
        <?php $__errorArgs = ['patient.confirm_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mt-3">
        <label for="pwd" class="fw-bold">Phone Number </label>
        <input style="font-size:12px; font-style:italic;" type=" text" class="form-control form-control-sm" placeholder="Enter Phone Number" wire:model.lazy="patient.phone">
        <?php $__errorArgs = ['patient.phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mt-3">
        <label for="existing_patient" class="fw-bold">Are you an existing customer?</label>
        <div class="d-flex justify-content-around">
            <label>
                <input type="radio" value="1" wire:model.lazy="patient.existing_patient"> Yes
            </label>
            <label>
                <input type="radio" value="0" wire:model.lazy="patient.existing_patient"> No
            </label>
        </div>
        <?php $__errorArgs = ['patient.existing_patient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mt-3">
        <label class="fw-bold">Are you a bussiness?</label>
        <div class="d-flex justify-content-around">
            <label>
                <input type="radio" value="1" wire:model.lazy="patient.business_repair"> Yes
            </label>
            <label>
                <input type="radio" value="0" wire:model.lazy="patient.business_repair"> No
            </label>
        </div>
        <?php $__errorArgs = ['patient.business_repair'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if($patient['business_repair'] == '1'): ?>
    <div class="mb-2">
        <label class="text-white">Company name *</label>
        <input style="font-size:12px; font-style:italic;" type=" text" class="form-control form-control-sm" placeholder="Company name" wire:model.lazy="patient.company_name">

    </div>
    <?php endif; ?>


</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/livewire/guest/components/patient-detail-form.blade.php ENDPATH**/ ?>
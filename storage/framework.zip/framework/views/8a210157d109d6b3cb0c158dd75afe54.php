<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l3361403821-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3361403821-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3361403821-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3361403821-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3361403821-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l3361403821-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3361403821-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3361403821-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3361403821-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3361403821-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <style>
        .breadcrumb-thread {
            
            display: flex;
            flex-wrap: wrap;
            padding-top: 100px;
            padding-bottom: 50px;
            margin-bottom: 1rem;
            list-style: none;
            background-color: transparent;
            border-radius: .25rem;
        }
        .breadcrumb-thread .breadcrumb-item {
            display: flex;
            align-items: center;
            position: relative;
        }
        .breadcrumb-thread .breadcrumb-item + .breadcrumb-item::before {
            content: '';
            width: 20px;
            height: 2px;
            background-color: #6c757d;
            position: absolute;
            left: -21px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 1;
        }
        .breadcrumb-thread .breadcrumb-item a {
      color: #007bff;
      text-decoration: none;
      padding: 0.5rem 1rem;
      background-color: #f8f9fa;
      border: 1px solid #dee2e6;
       border-radius: 9999px 9999px 9999px 9999px;
      position: relative;
      z-index: 2;
      color:black;
    }
        .breadcrumb-thread .breadcrumb-item a:hover {
            color: #dc3545;
            text-decoration: none;
            border: 1px solid #dc3545;
        }
        .breadcrumb-thread .breadcrumb-item a.active {
            color: #fff;
            background-color: #dc3545;
            border-color: #dc3545;
        }
    </style>


  <div class="d-none d-md-block" style="display: flex; justify-content: center; align-items: center; margin: 0;">
    <div class="container mt-3" style="text-align: center;">
        <ul class="breadcrumb-thread d-flex justify-content-center" id="form-navigation" style="padding: 0; list-style: none;">
            <li class="breadcrumb-item" style="margin: 0 10px;">
                <a href="#" data-step="0">Product Info</a>
            </li>
            <li class="breadcrumb-item" style="margin: 0 10px;">
                <a href="#" data-step="1">Select Condition</a>
            </li>
            <li class="breadcrumb-item" style="margin: 0 10px;">
                <a href="#" data-step="2">Personal Detail</a>
            </li>
            <li class="breadcrumb-item" style="margin: 0 10px;">
                <a href="#" data-step="3">Book Repair</a>
            </li>
        </ul>
    </div>
</div>



    <section id="product-info-section" class="form-step"  >
  <div class="container mt-5">
            <div class="row">
                <div class="col-lg-6 p-5 mt-5 text-center">
                    <?php if(json_decode($product_spec_image) === null): ?>
                        <!-- Display single image -->
                        <img src="<?php echo e($product_spec_image ?? $model->file); ?>" class="img-fluid"
                            style="min-width: 75%; max-height: 480px;">
                    <?php else: ?>
                        <!-- Display image slider for multiple images -->
                        <div id="imageSlider" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php $__currentLoopData = json_decode($product_spec_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?> text-center">
                                        <img src="<?php echo e($image); ?>" class="img-fluid"
                                            style="min-width: 75%; max-height: 480px;" alt="Image <?php echo e($index + 1); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button class="carousel-control-prev text-bg-danger" type="reset"
                                data-bs-target="#imageSlider" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next text-bg-danger" type="reset"
                                data-bs-target="#imageSlider" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-lg-6">
                    <div class="mt-4 text-center">
                        <h6 class="fs-2 fw-bold">Please select specifications </h6>
                        <p class="text-danger">(This enables us to offer you a preliminary estimate.)</p>
                    </div>

                    <div class="mt-5">
                        <p class="fs-3 fw-bold"><?php echo e($model->name); ?></p>

                        <?php if(!empty($available_memory_sizes)): ?>
                            <p class="fs-6 fw-bold">Select Memory Size:</p>
                            <div class="d-flex gap-2">
                                <?php $__currentLoopData = $available_memory_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memory_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button type="reset"
                                        class="btn btn-outline-danger <?php echo e($memory_size == $selectedMemorySize ? 'bg-danger text-white' : ''); ?>"
                                        wire:click="$set('selectedMemorySize', '<?php echo e($memory_size); ?>')">
                                        <?php echo e($memory_size); ?>

                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <p class="fs-5 mt-3 fw-bold">Select Grade:</p>
                        <div class="d-flex gap-2">
                            <?php $__currentLoopData = $available_grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="reset"
                                    class="btn btn-outline-dark <?php echo e($grade == $selectedGrade ? 'bg-danger text-white' : ''); ?>"
                                    wire:click="$set('selectedGrade', '<?php echo e($grade); ?>')">
                                    <?php echo e($grade); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <?php if(!empty($available_colors)): ?>
                            <p class="fs-5 mt-3 fw-bold">Color:</p>
                            <div class="d-flex gap-2">
                                <?php $__currentLoopData = $available_colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button type="reset"
                                        class="btn btn-outline-dark <?php echo e($color == $selectedColor ? 'bg-danger text-white' : ''); ?>"
                                        wire:click="$set('selectedColor', '<?php echo e($color); ?>')">
                                        <?php echo e($color); ?>

                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <div class="mt-3">
                            <label for="quantity">Quantity: only <?php echo e($available_quantity); ?> Available</label>
                            <div class="input-group mt-2" style="max-width: max-content;">
                                <div class="input-group-prepend">
                                    <button type="button" class="btn btn-danger"
                                        wire:click="decreaseQuantity">-</button>
                                </div>
                                <input type="number" class="form-control border-0 text-center"
                                    wire:model="quantity" min="1" max="<?php echo e($available_quantity); ?>" step="1"
                                    wire:change="quantityChanged">
                                <div class="input-group-append">
                                    <button type="reset" class="btn btn-success"
                                        wire:click="increaseQuantity">+</button>
                                </div>
                            </div>
                        </div>

                        <div class="accordion mt-4">
                            <div class="accordion-item" x-data="{ openTab: 1 }">
                                <div class="accordion-header bg-gray p-2 cursor-pointer"
                                    x-on:click="openTab === 1 ? openTab = 0 : openTab = 1">
                                    <span class="fw-bold">Details</span>
                                    <i x-show="openTab !== 1" class="fa fa-plus"></i>
                                    <i x-show="openTab === 1" class="fa fa-minus"></i>
                                </div>
                                <div class="accordion-content" x-show="openTab === 1">
                                    <?php echo $detail ?? ''; ?>

                                </div>
                            </div>

                            <div class="accordion-item" x-data="{ openTab: 2 }">
                                <div class="accordion-header bg-gray p-2 cursor-pointer"
                                    x-on:click="openTab === 2 ? openTab = 0 : openTab = 2">
                                    <span class="fw-bold">Specification</span>
                                    <i x-show="openTab !== 2" class="fa fa-plus"></i>
                                    <i x-show="openTab === 2" class="fa fa-minus"></i>
                                </div>
                                <div class="accordion-content" x-show="openTab === 2">
                                    <?php echo $specification ?? ''; ?>

                                </div>
                            </div>

                            <div class="accordion-item" x-data="{ openTab: 3 }">
                                <div class="accordion-header bg-gray p-2 cursor-pointer"
                                    x-on:click="openTab === 3 ? openTab = 0 : openTab = 3">
                                    <span class="fw-bold">Warranty</span>
                                    <i x-show="openTab !== 3" class="fa fa-plus"></i>
                                    <i x-show="openTab === 3" class="fa fa-minus"></i>
                                </div>
                                <div class="accordion-content" x-show="openTab === 3">
                                    <?php echo $warranty ?? ''; ?>

                                </div>
                            </div>
                        </div>


                        <div class="p-2 fs-5 text-danger fw-bold mt-4" id="cashText">
                            <h2 style="white-space: nowrap;">Cash Value: £ <?php echo e($price ?? 0); ?>.00</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="form-toggle-section" class="form-step pt-5" style="display: none;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rounded p-4" style="background-color:white; border: 3px solid black;">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="patient-detail-section" class="form-step" style="display: none;">
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </section>

    <section id="booking-section" class="form-step" style="display: none;">
        <div class="container" wire:ignore>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.buy.book-repair', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.buy.book-repair', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </section>

   
       
             <div class="container-fluid mt-4">
            <div class="row justify-content-between">
                <div class="col-auto">
                    <span id="back-button" ><img src="https://ik.imagekit.io/b6iqka2sz/prev.png?updatedAt=1719938010352" style="width: 150px; height: auto; margin-left: auto;"></span>
                </div>
                <div class="col-auto">
                    <img id="next-button" src="https://ik.imagekit.io/li8bg5tjv3/1.png?updatedAt=1715028228699" style="width: 150px; height: auto;" />
                </div>
            </div>
        </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
$(document).ready(function () {
    const steps = ['#product-info-section', '#form-toggle-section', '#patient-detail-section', '#booking-section'];
    let currentStep = 0;
    let formCompleted = [true, false, false, true];

    function showStep(stepIndex) {
        steps.forEach((step, index) => {
            $(step).toggle(index === stepIndex);
        });

        // Show or hide navigation buttons based on step index
        $('#back-button').toggle(stepIndex === steps.length - 1); // Show only on the last step
        $('#next-button').toggle(stepIndex === 0 || stepIndex === 2); // Show only on steps 0 and 2

        // Update breadcrumb navigation
        $('#form-navigation .breadcrumb-item a').removeClass('active');
        $('#form-navigation .breadcrumb-item a[data-step="' + stepIndex + '"]').addClass('active');
    }

    function moveToNextStep() {
        if (currentStep < steps.length - 1) {
            currentStep++;
            showStep(currentStep);
        }
    }

    $('#back-button').click(function () {
        if (currentStep > 0) {
            currentStep--;
            showStep(currentStep);
        }
    });

    $('#next-button').click(function () {
        if (formCompleted[currentStep]) {
            Livewire.emit('formSubmitted', currentStep);
        } else {
            alert('Please complete the current step.');
        }
    });

    Livewire.on('formSubmitted', function (stepIndex) {
        formCompleted[stepIndex] = true;
        moveToNextStep();
    });

    Livewire.on('formInvalid', function (stepIndex) {
        formCompleted[stepIndex] = false;
        showStep(currentStep);
    });

    // Handle breadcrumb clicks
    $('#form-navigation .breadcrumb-item a').click(function (e) {
        e.preventDefault();
        const stepIndex = $(this).data('step');
        if (stepIndex !== currentStep) {
            currentStep = stepIndex;
            showStep(currentStep);
        }
    });

    showStep(currentStep);
});


    </script>

</div>


      <?php /**PATH /Users/mubashir/Downloads/MobileBitz 2/resources/views/livewire/guest/buy/product-specs.blade.php ENDPATH**/ ?>
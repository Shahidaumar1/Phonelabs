<div class="container mt-3   pb-5 ">
    <?php if($mainBranch): ?>
        <div class=" p-4 ">
            <h2 class="card-title">&#128205; <?php echo e($siteBranch->name); ?></h2>
            <p class="card-text"><?php echo e($siteBranch->address_line_1); ?>,
                <?php echo e($siteBranch->address_line_2); ?><?php echo e($siteBranch->address_line_2 != '' ? ', ' : ''); ?><?php echo e($siteBranch->town_city); ?>,
                <?php echo e($siteBranch->post_code); ?>, UK
            </p>
            <p class="card-text">&#128235; <?php echo e($siteBranch->email); ?></p>
            <p class="card-text">&#9742; <?php echo e($siteBranch->landline_number); ?></p>
            <p class="card-text">&#128222; <?php echo e($siteBranch->mobile_number); ?></p>
        </div>
    <?php else: ?>
        <div x-data="{ currentStep: 0 }" class=" p-4">
            <section id="section-1" x-show="currentStep === 0" x-cloak class="row">
                <div class=" mt-4 gap-5 col-md-6 ">
                       
                            <div>
                                <?php if($map_link): ?>
                                    <?php echo $map_link; ?>

                                <?php else: ?>
                                    <iframe
                                        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                                        width="100%" height="550" style="border: 0" allowfullscreen="" loading="lazy"
                                        referrerpolicy="no-referrer-when-downgrade"></iframe>
                                <?php endif; ?>
                            </div>
                        
                    </div>
                    <div class="col-md-1"></div>
                <div class="col-md-5">
                <legend class="mb-3">
                    <h2 class="fw-bold text-danger">Find a Store</h2>
                </legend>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Enter Postal Code" wire:model.defer="postalCode"
                        required>
                    <button class="btn btn-danger" type="button" wire:click="getLatLong">Search</button>
                </div>

                <?php if(!empty($nearestBranches)): ?>
                    <label class="text-danger">
                        <h3>CHOOSE YOUR NEAREST STORE</h3>
                    </label>
                    <select class="form-select form-select-sm mb-3" wire:model="selectedBranchId">
                        <option>Select Store</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <label class="text-danger">
                        <h2>CHOOSE YOUR NEAREST STORE</h2>
                    </label>
                    <select class="form-select form-select-sm mb-3" wire:model="selectedBranchId">
                        <option>Select Store</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php endif; ?>

                <?php if($clinic['name']): ?>
                    <div class="my-3">
                        <label>Selected Store by you in previous session</label>
                        <h3 class="text-success ms-3 fw-bold"><?php echo e($clinic['name']); ?></h3>
                    </div>
                <?php endif; ?>
                <div class="col-lg-12  p-3" style="margin-left:10px;">
                            <?php if(!empty($selectedBranch['address_line_1'])): ?>
                                <div class="mb-3">
                                    <h3 class="fw-bold">Address:</h3>
                                    <p><?php echo e($selectedBranch['address_line_1']); ?>, <?php echo e($selectedBranch['address_line_2'] ?: ''); ?>,
                                        <?php echo e($selectedBranch['town_city']); ?>, <?php echo e($selectedBranch['post_code']); ?>, UK
                                    </p>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty($selectedBranch['email'])): ?>
                                <div class="mb-3">
                                    <h3>Email:</h3>
                                    <p><?php echo e($selectedBranch['email']); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty($selectedBranch['mobile_number'])): ?>
                                <div class="mb-3">
                                    <h3>Call us:</h3>
                                    <p><?php echo e($selectedBranch['mobile_number']); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
</div>
                <!--<?php if(!empty($selectedBranch)): ?>-->
                    
                <!--<?php endif; ?>-->
            </section>
            <section class="w-75" id="section-2" x-show="currentStep === 1" style="display: none;" x-cloak>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="appointment_date">Appointment Date</label>
                    <input type="date" class="form-control" id="appointment_date" name="appointment_date"
                        wire:model.lazy="clinic.appointment_date">
                    <?php $__errorArgs = ['clinic.appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="appointment_time">Appointment Time</label>
                    <select class="form-select form-select-sm" id="appointment_time" name="appointment_time"
                        wire:model="clinic.appointment_time">
                        <option value="">Select a time</option>
                        <?php if($selectedDate): ?>
                            <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($timeSlot); ?>"><?php echo e($timeSlot); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="exampleFormControlTextarea1">Write Note</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1"
                        wire:model.debounce.500="clinic.repair_note" placeholder="Please write any comment..."
                        rows="3"></textarea>
                    <?php $__errorArgs = ['clinic.repair_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </section>
            <button id="continue-button" class="btn btn-danger mt-3"
                @click="currentStep = (currentStep === 0 ? 1 : currentStep)"> Countinue
            </button>
        </div>
    <?php endif; ?>
</div><?php /**PATH /home/mobilebitz/new.mobilebitz.co.uk/resources/views/livewire/guest/components/clinic-repair-form.blade.php ENDPATH**/ ?>
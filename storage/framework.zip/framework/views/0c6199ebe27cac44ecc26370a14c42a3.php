<div>
    


    <?php if($mainBranch): ?>
    <p>&#128205:<?php echo e($siteBranch->name); ?> , <?php echo e($siteBranch->address_line_1); ?> , <?php echo e($siteBranch->address_line_2); ?> <?php echo e($siteBranch->address_line_2!=''?', ':''); ?> <?php echo e($siteBranch->town_city); ?> , <?php echo e($siteBranch->post_code); ?>,UK</p>
    <p>&#128235: <?php echo e($siteBranch->email); ?></p>
    <p>&#9742: <?php echo e($siteBranch->landline_number); ?> </p>
    <p>&#128222: <?php echo e($siteBranch->mobile_number); ?></p>
    <?php else: ?>
    <div class="mb-3 mt-3 ">
        <!--<legend for="postalCode">-->
        <!--    <h4 class="fw-bold">Find a Store</h4>-->
        <!--</legend>-->
        <!--<div class="input-group mb-3">-->
        <!--    <input type="text" id="postalCode" required class="form-control" placeholder="Enter Postal Code">-->
        <!--    <button class="btn btn-outline-danger bg-danger text-white" type="button" id="button-addon2" onclick="getLatLong()">Search</button>-->
        <!--</div>-->
        <div id="resultContainer"></div>

        <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('livewire:load', function() {
                const resultContainer = document.getElementById("resultContainer");

                Livewire.on('getLatLong', function() {
                    // Call the JavaScript function when the Livewire event is triggered

                    getLatLong();
                });
                async function getLatLong() {
                    const postalCode = document.getElementById("postalCode").value;

                    try {
                        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                        const data = await response.json();

                        if (data.length > 0) {
                            const result = data[0];
                            resultContainer.innerHTML = `<p>${result.display_name}</p>`;

                            Livewire.emit('updateLocation', {
                                latitude: result.lat,
                                longitude: result.lon
                            });
                        } else {
                            resultContainer.innerHTML = "<p>No results found for the provided postal code.</p>";
                        }
                    } catch (error) {
                        console.error("Error fetching data:", error);
                    }
                }

                // Add Livewire listener for location update
                Livewire.on('updateLocation', (location) => {
                    // Handle location update if needed
                    console.log('Received location update:', location);
                });

                // Your existing function call
                window.getLatLong = getLatLong;
            });
        </script>
        <?php $__env->stopPush(); ?>
        <?php if($nearestBraches): ?>

        <!--<label for="email">Choose Store near you </label>-->
        <!--<select class="form-control form-select form-control-sm" wire:model.lazy="postal.name">-->
        <!--    <option>Select Store</option>-->

        <!--    <?php $__empty_1 = true; $__currentLoopData = $nearestBraches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>-->
        <!--    <option value="<?php echo e($branch['branch']['name']); ?>"><?php echo e($branch['branch']['name']); ?>, Distance: <?php echo e(number_format($branch['distance'],2) != 0.00 ? number_format($branch['distance'],2) : 0); ?> Mile</option>-->
        <!--    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>-->

        <!--    <option value="">Sorry we can not find</option>-->
        <!--    <?php endif; ?>-->
        <!--</select>-->
        <?php else: ?>
        <!--<label for="email">Choose Store</label>-->
        <!--<select class="form-control form-select form-control-sm" wire:model.lazy="postal.name">-->
        <!--    <option>Select Store</option>-->

        <!--    <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>-->
        <!--    <option value="<?php echo e($branch['name']); ?>"><?php echo e($branch['name']); ?></option>-->
        <!--    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>-->

        <!--    <option value="">Sorry we can not find</option>-->
        <!--    <?php endif; ?>-->
        <!--</select>-->

        <?php endif; ?>
        <?php $__errorArgs = ['postal.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <!--<span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>-->
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
    <?php if($postal['name']): ?>
    <!--<div class="my-3">-->
    <!--    <label> Selected Store by you in previous session </label>-->
    <!--    <h3 class="text-success ms-3 fw-bold"><?php echo e($postal['name']); ?></h3>-->

    <!--    <p>&#128205:<?php echo e($selectedBranch->name); ?> , <?php echo e($selectedBranch->address_line_1); ?> , <?php echo e($selectedBranch->address_line_2); ?> <?php echo e($selectedBranch->address_line_2!=''?', ':''); ?> <?php echo e($selectedBranch->town_city); ?> , <?php echo e($selectedBranch->post_code); ?>,UK</p>-->
    <!--    <p>&#128235: <?php echo e($selectedBranch->email); ?></p>-->
    <!--    <p>&#9742: <?php echo e($selectedBranch->landline_number); ?> </p>-->
    <!--    <p>&#128222: <?php echo e($selectedBranch->mobile_number); ?></p>-->
    <!--</div>-->
    <?php endif; ?>
    <?php endif; ?>
    <div class="<?php echo e($writeYourSelf ? '':'d-none'); ?>" >
        <div class="mb-3 mt-3">
            <label for="email">Address Line 1*:</label>
            <input type="text" class="form-control form-control-sm" id="name" wire:model.lazy="postal.address_line_1" placeholder="Address Line 1" name="postal.address_line_1" required="">
            <?php $__errorArgs = ['postal.address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 mt-3">
            <label for="email">Address Line 2:</label>
            <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.address_line_2" id="name" placeholder="Address Line 2" name="postal.address_line_2">
        </div>
        <div class="mb-3 mt-3">
            <label for="email">Town/City*:</label>
            <input type="text" class="form-control form-control-sm" id="name" wire:model.lazy="postal.city" placeholder="Town/City" name="postal.city" required="">
            <?php $__errorArgs = ['postal.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div> 
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.address-common' , ['writeYourSelf' => $writeYourSelf ])->html();
} elseif ($_instance->childHasBeenRendered('l3110436918-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3110436918-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3110436918-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3110436918-0');
} else {
    $response = \Livewire\Livewire::mount('components.address-common' , ['writeYourSelf' => $writeYourSelf ]);
    $html = $response->html();
    $_instance->logRenderedChild('l3110436918-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!--<div class="mb-3 mt-3 ">-->
    <!--    <label for="email">Post Code*:</label>-->
    <!--    <input type="text" class="form-control form-control-sm" id="name" wire:model.lazy="postal.code" placeholder="Post Code" name="postal.code" required="">-->
    <!--    <?php $__errorArgs = ['postal.code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
    <!--    <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>-->
    <!--    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
    <!--</div>-->
    <div class="mb-2">
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Write Notes</label>
            <textarea class="form-control" id="postal.repair_note" wire:model="postal.repair_note" rows="3" name="postal.repair_note" placeholder="Please write any comment...">
                </textarea>
            <?php $__errorArgs = ['postal.repair_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>
</div><?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/livewire/guest/components/postal-repair-form.blade.php ENDPATH**/ ?>
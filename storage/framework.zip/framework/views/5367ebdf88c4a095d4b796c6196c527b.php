<div>
    <div>
        <!-- Top Bar Component -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l4005956931-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4005956931-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4005956931-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4005956931-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4005956931-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Mega Navigation Component with white theme -->
        <section class="head-sell">
            <div class="container">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white'])->html();
} elseif ($_instance->childHasBeenRendered('l4005956931-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l4005956931-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4005956931-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4005956931-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white']);
    $html = $response->html();
    $_instance->logRenderedChild('l4005956931-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </section>

        <!-- Multi-step Form Sections -->
        <div class="container mt-5" id="multi-step-form">
            <!-- Product Info Section -->
            <section id="product-info-section" class="form-step">
                <div class="container mt-5 ">
                    <div class="row">
                        <h6 class="text-center fs-1 fw-bold">Sell <?php echo e($model->name); ?>- Mobilebitz</h6>


                        <!-- Parent View -->


                        <p class="text-center text-danger">(This enables us to offer you a preliminary estimate.)</p>
                        <div class="col-lg-6 p-5 mt-5">
                            <img src="<?php echo e($product_spec_image ?? $model->file); ?>" class="img-fluid"
                                alt="Responsive Image" style="max-height: 380px;">
                        </div>

                        
                        <?php
                            $product_specs = App\Models\ProductSpec::where('model_id', $model->id)->get();
                        ?>
                        <div class="col-lg-6  p-5 ">
                            <div>
                                <?php if(in_array(!null, $available_memory_sizes)): ?>
                                    <p class="fs-6 fw-bold">Select Memory Size:</p>
                                <?php endif; ?>

                                <?php $__empty_1 = true; $__currentLoopData = $available_memory_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memory_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($memory_size != null): ?>
                                        <button type="button"
                                            class="btn btn-outline-danger <?php echo e($memory_size == $selectedMemorySize ? 'bg-danger text-white' : ''); ?>"
                                            wire:click="$set('selectedMemorySize','<?php echo e($memory_size); ?>')"><?php echo e($memory_size); ?></button>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>

                                <div>
                                    <?php
                                        // Define the custom order
                                        $customOrder = ['Excellent', 'Good', 'Fair', 'Poor', 'Faulty'];
                                        // Sort the grades array based on the custom order
                                        usort($available_conditions, function ($a, $b) use ($customOrder) {
                                            return array_search($a, $customOrder) - array_search($b, $customOrder);
                                        });
                                    ?>
                                    <p class="fs-6 mt-3 fw-bold">Select Condition:</p>
                                    <div class="d-flex  gap-2 border-0  align-items-center" style="margin-bottom: -7px">
                                        <?php $__empty_1 = true; $__currentLoopData = $available_conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <label
                                                class=" cursor-pointer px-3  py-2 rounded-top border border-2  <?php echo e($condition == $selectedCondition ? '  bg-gray text-black' : ''); ?> "
                                                wire:click="$set('selectedCondition','<?php echo e($condition); ?>')">
                                                <?php echo e($condition); ?>

                                            </label>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                    </div>



                                    <?php if($selectedCondition): ?>
                                        <div class="bg-gray border-0 text-black  rounded p-2 mt-1   ">
                                            <?php echo $condition_text; ?>

                                        </div>
                                    <?php endif; ?>

                                    <div class="mt-3">

                                        <?php if($mobileMode || $tabletMode): ?>
                                                                                <?php
                                                                                    $network_images = [
                                                                                        'Vodafone' =>
                                                                                            'https://upload.wikimedia.org/wikipedia/commons/f/ff/Logo_vodafone_new.png',
                                                                                        'o2' => 'https://cdn2.downdetector.com/static/uploads/logo/O2-logo.jpg',
                                                                                        'Smarty' =>
                                                                                            'https://media.product.which.co.uk/prod/images/original/gm-9642cb8d-b24b-4ce6-afd6-cfac01256877-smarty.jpg',
                                                                                        'EE' =>
                                                                                            'https://c8.alamy.com/comp/EFEKFE/ee-logo-or-sign-for-mobile-network-operator-and-internet-provider-EFEKFE.jpg',
                                                                                        'Asda' =>
                                                                                            'https://media.product.which.co.uk/prod/images/original/gm-99fb2e68-49d9-4b68-be97-57f35c5e8314-asda-mobile.jpg',
                                                                                        'Tesco' =>
                                                                                            'https://media.product.which.co.uk/prod/images/original/gm-989813fb-0b40-4582-a0e8-2ab7a437429e-tesco-mobile.jpg',
                                                                                    ];
                                                                                ?>
                                                                                <div class="col-lg-12 p-5">
                                                                                    <div>
                                                                                        <?php if(count($network_providers) > 0): ?>
                                                                                            <p class="fs-6 fw-bold">Select Network:</p>
                                                                                        <?php endif; ?>

                                                                                        <?php $__empty_1 = true; $__currentLoopData = $network_providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                                            <!-- Adjusted to work with names -->
                                                                                            <?php if(isset($network_images[$network_name])): ?>
                                                                                                <!-- Check if the network has an image -->
                                                                                                <button type="button"
                                                                                                    class="btn <?php echo e($network_name == $selectedNetwork ? 'bg-danger text-white' : 'btn-outline-success'); ?>"
                                                                                                    wire:click="selectNetwork('<?php echo e($network_name); ?>')">
                                                                                                    <!-- Select network on click -->
                                                                                                    <img src="<?php echo e($network_images[$network_name]); ?>"
                                                                                                        alt="<?php echo e($network_name); ?>" style="width: 30px; height: 30px;" />
                                                                                                    <!-- Correctly set the image source -->
                                                                                                </button>
                                                                                            <?php else: ?>
                                                                                                <button type="button" class="btn btn-outline-primary">
                                                                                                    <?php echo e($network_name); ?> <!-- Fallback if there's no image -->
                                                                                                </button>
                                                                                            <?php endif; ?>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                                            <p>No networks available</p> <!-- Fallback message -->
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>


                                                                                

                                                                                
                                                                                <!--<tr>-->
                                                                                <!--    <th>Account/cleared</th>-->
                                                                                <!--    <td>-->
                                                                                <!--        <div class="form-check form-switch">-->
                                                                                <!--            <input type="checkbox" role="switch"-->
                                                                                <!--                class="form-check-input border border-dark"-->
                                                                                <!--                wire:change="toggleAccountCleared" id="<?php echo e($rand . 'ac'); ?>" />-->
                                                                                <!--        </div>-->
                                                                                <!--    </td>-->
                                                                                <!--</tr>-->
                                        <?php endif; ?>

                                        <div class="mt-3 mb-1">
                                            <div class=" mt-5 d-flex align-items-end flex-column  mb-3">
                                                <div class="text-center" id="cashText">
                                                    <h2 class=" text-danger fw-bold">Cash Value: £ <?php echo e($price); ?>.00</h2>
                                                    <small>select device specification above to see price</small>
                                                </div>
                                                <div class="p-2 fs-3 fw-bold text-secondary ">
                                                    
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
            </section>

            <!-- Form Toggle Section -->
            <section id="form-toggle-section" class="form-step" style="display: none;">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </section>

            <!-- Patient Detail Section -->
            <section id="patient-detail-section" class="form-step" style="display: none;">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </section>

            <!-- Booking Section -->
            <section id="booking-section" class="form-step" style="display: none;">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.sell.booking-form', [])->html();
} elseif ($_instance->childHasBeenRendered('l4005956931-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l4005956931-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4005956931-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4005956931-4');
} else {
    $response = \Livewire\Livewire::mount('guest.sell.booking-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4005956931-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </section>
        </div>

        <!-- Next and Back Buttons -->
        <section class="container mt-3">
            <div class="d-flex justify-content-between">
                <button type="button" id="back-button" class="btn btn-secondary" style="display: none;">Back</button>
                <button type="button" id="next-button" class="btn btn-primary">Next</button>
            </div>
        </section>
    </div>

    <!-- JavaScript for Form Navigation -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            const steps = ['#product-info-section', '#form-toggle-section', '#patient-detail-section', '#booking-section'];
            let currentStep = 0;
            let formCompleted = [true, false, false, true]; // Initialize with `false` for all steps

            function showStep(stepIndex) {
                $('.form-step').hide(); // Hide all form steps
                $(steps[stepIndex]).show(); // Show the current step

                // Show "Next" button only in the first section
                $('#next-button').toggle(stepIndex === 0);

                // Show "Back" button in the second-to-last and last sections
                $('#back-button').toggle(stepIndex === steps.length - 1 || stepIndex === steps.length - 2);
            }

            function moveToNextStep() {
                if (currentStep < steps.length - 1) {
                    currentStep++;
                    showStep(currentStep);
                }
            }

            $('#back-button').click(function () {
                if (currentStep > 0) {
                    currentStep--;
                    showStep(currentStep);
                }
            });

            $('#next-button').click(function () {
                // Check if form is completed for the current step
                if (formCompleted[currentStep]) {
                    moveToNextStep(); // Move to the next step
                } else {
                    alert('Please complete the current step.'); // Display validation message
                }
            });

            // Livewire event: Form submission completed successfully
            Livewire.on('formSubmitted', function () {
                formCompleted[currentStep] = true;
                moveToNextStep();
            });

            // Livewire event: Form submission failed validation
            Livewire.on('formInvalid', function () {
                formCompleted[currentStep] = false;
                showStep(currentStep); // Show current step again on validation failure
            });

            // Initial display setup
            showStep(currentStep);
        });
    </script>

    </script>
    <!-- Livewire Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/livewire/2.x/livewire.js"></script>
    <script src="https://kit.fontawesome.com/09d3c3a997.js" crossorigin="anonymous"></script>

    <!-- Livewire Scripts -->

</div><?php /**PATH /Users/mubashir/Documents/vscode (2)/resources/views/livewire/guest/sell/model-detail.blade.php ENDPATH**/ ?>
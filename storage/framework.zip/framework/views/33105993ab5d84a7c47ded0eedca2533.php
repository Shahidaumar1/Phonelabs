     <p >Stripe keys will work for Klarna also.</p>
<div class = "card p-3" >
   

        <label class = "pb-2 mt-3"><b>Private Key</b> </label>
        <input type="text" class="form-control input_form w-75 mp-3" placeholder="Secret Key" aria-label="" wire:model.debounde.500="secret" />
        <?php $__errorArgs = ['secret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger pb-3"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class = "pb-2 mt-3"> <b>Public Key</b></label>
        <input type="text" class="form-control input_form w-75 mp-3" placeholder="Public Key" aria-label="" wire:model.debounde.500="public_key" />
        <?php $__errorArgs = ['public_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class=""><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="d-flex justify-content-end align-items-center pt-2 mb-3">
        <button type="button" class="<?php echo e($dirty ? 'selected-button' : 'unselected-button'); ?> " wire:click="connect" <?php echo e($dirty ? '' : 'disabled'); ?>>Connect</button>
        <span wire:loading wire:target="connect">connecting....</span>
        <?php if(session()->has('message')): ?>
        <span class=" text-success"><?php echo e(session('message')); ?></h3>
          <?php endif; ?>

</div>
<style>
.card{
       min-width: 200px;
    border-radius: 20px;
    border: 1px solid gray;
    background: whitesmoke;
}

     
</style><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/settings/components/stripe.blade.php ENDPATH**/ ?>
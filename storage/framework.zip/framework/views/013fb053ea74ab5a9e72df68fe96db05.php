
<div class = "card p-3" >
    
        <label class = "pb-2"><b>Client ID</b></label>
        <input type="text" class="form-control input_form mb-2 w-75" placeholder="Client ID" aria-label="" wire:model.debounde.500="client_id" />
        <?php $__errorArgs = ['client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
        <label class = "pb-2"><b>Secret</b></label>
        <input type="text" class="form-control input_form mb-2 w-75" placeholder="Secret" aria-label="" wire:model.debounde.500="secret" />
        <?php $__errorArgs = ['secret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


  
</div>
<div class="d-flex justify-content-end align-items-center pt-2">
    
        <button type="button" class="<?php echo e($dirty ? 'selected-button' : 'unselected-button'); ?> " wire:click="connect" <?php echo e($dirty ? '' : 'disabled'); ?>>Connect</button>
        <span wire:loading wire:target="connect">connecting....</span>
        <?php if(session()->has('message')): ?>
        <span class=" text-success"><?php echo e(session('message')); ?></h3>
          <?php endif; ?>
        
</div>

<style>
.card{
       min-width: 200px;
    border-radius: 20px;
    border: 1px solid gray;
    background: whitesmoke;
}

     
</style><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/settings/components/paypal.blade.php ENDPATH**/ ?>
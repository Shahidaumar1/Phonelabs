<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" />
    <title>Store Repair: <?php echo e($data['form']['name'] ?? ""); ?></title>
    <link rel="stylesheet" href="Clinic-Repair-LB.css" />
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <p class="m-0 fs-5"> Hi <span style=" font-weight: 600"><?php echo e($data['patient']['name']); ?>,</span>
                </p>
                <p class="fs-5">
                    I hope you're well and thanks for booking your
                       <?php echo e($data['repair_detail']['model']); ?>

                    <span style=" font-weight: 600">
                        
                    repair. Here’s the details you need:
                </p>
            </div>

            <div class="mb-3 col-12">
                <h5 class="m-0"><b>Customer Details:</b></h5>
                <table class="table table-bordered table-sm border-dark" style="font-size: 1.2rem;">
                    <tbody>
                        <tr>
                            <td style="width: 180px;">Name:</td>
                            <td style="font-weight: 600">
                                <?php echo e($data['patient']['name']); ?> 
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 180px;">Email:</td>
                            <td style=" font-weight: 600">
                                <?php echo e($data['patient']['email']); ?>

                            </td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 180px;">Contact number:</td>
                            <td style=" font-weight: 600">
                                <?php echo e($data['patient']['phone']); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="mb-3 col-12">
                <h5 class="m-0"><b>Repair Details:</b></h5>
                <table class="table table-bordered table-sm border-dark" style="font-size: 1.2rem;">
                    <tbody>
                        <tr>
                            <td scope="col" style="width: 180px;">Booking Reference:</td>
                            <td scope="col">
                                This will follow in the acknowledgement email to be sent by
                                our Lab Team
                            </td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Device:</td>
                            <td style=" font-weight: 600"><?php echo e($data['repair_detail']['device']); ?>\
                            <?php echo e($data['repair_detail']['model']); ?>

                             
                       
                                <?php echo e(array_key_exists('emc', $data) ? $data['emc'] : ''); ?>

                            </td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Fault:</td>
                            <td style=" font-weight: 600">
                                <?php if(array_key_exists('faults', $data['repair_detail'])): ?>
                                <?php $__currentLoopData = $data['repair_detail']['faults']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($value != 'Other Fault (Please Specify)'): ?>
                                <span style=" font-weight: 600"><?php echo e($value); ?></span><br>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php echo e($data['repair_detail']['fault']); ?>

                            </td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Turnaround Time:</td>
                            <td style=" font-weight: 600"><?php echo e($data['repair_detail']['How_long']); ?>

                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Part Used:</td>
                            <td style=" font-weight: 600"><?php echo e($data['repair_detail']['part_used']); ?></td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Warranty:</td>
                            <td style=" font-weight: 600"><?php echo e($data['repair_detail']['warranty']); ?></td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Provisional Quote:</td>
                            <td style=" font-weight: 600"> £ <?php echo e($data['repair_detail']['quotePrice']); ?></td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Additional Costs:</td>
                            <td style=" font-weight: 600">
                                <?php echo e($data['repair_detail']['screen_protector']); ?><br>
                                <?php echo e($data['repair_detail']['protective_case']); ?><br>
                                <?php echo e($data['repair_detail']['postal_price']); ?><br>
                                <?php echo e($data['repair_detail']['fix_form_price']); ?><br>
                                <?php echo e($data['repair_detail']['collection_form_price']); ?><br>
                            </td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">appointment at</td>
                            <td>
                                <span style="color: red"><strong><?php if(session()->has('clinic_name')): ?>
    <p><?php echo e(session('clinic_name')); ?></p>
<?php else: ?>
    <p>Branch name not available</p>
<?php endif; ?>
</strong></span>
                            </td>
                        </tr>
                           <tr>
                            <td scope="row" style="width: 170px;"> Payment Method</td>
                            <td>
                                <span style="color: red"><strong><?php if(session()->has('payment-method')): ?>
    <p><?php echo e(session('payment-method')); ?></p>
<?php else: ?>
    <p>Payment Method NOT aVAILABLE  not available</p>
<?php endif; ?>
</strong></span>
                            </td>
                        </tr>
                                                <tr>
                  <table>
    <tr>
        <td scope="row" style="width: 170px;">Location</td>
        <td>
            <?php if(session()->has('map_link')): ?>
                <a href="<?php echo e(session('map_link')); ?>" target="_blank">
                    <img src="https://staticmap.openstreetmap.de/staticmap.php?center=51.515373671697525,0.05569271195689881&zoom=15&size=600x400&maptype=mapnik&markers=51.515373671697525,0.05569271195689881,red-pushpin" alt="Map location" style="border: 0;">
                </a>
            <?php else: ?>
                Map link not available
            <?php endif; ?>
        </td>
    </tr>
</table>


                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Date - Time</td>
                            <td>
                                <?php echo e($data['form']['appointment_date'] ?? ""); ?> - <?php echo e($data['form']['appointment_time'] ?? ""); ?>

                            </td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Repair Note</td>
                            <td>
                                <?php echo e($data['form']['repair_note'] ?? ""); ?>

                            </td>
                        </tr>
                        <tr>
                            <td scope="row" style="width: 170px;">Info:</td>
                            <td>
                                If we can’t repair your device, then under our
                                <span style="color: red"><strong>No-Fix, No-Fee </strong></span>promise, there’s nothing
                                to pay for the work undertaken.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>


        </div>
    </div>
</body>

</html><?php /**PATH /home/mobilebitz/public_html/resources/views/emails/clinic_repair_lb_temp.blade.php ENDPATH**/ ?>
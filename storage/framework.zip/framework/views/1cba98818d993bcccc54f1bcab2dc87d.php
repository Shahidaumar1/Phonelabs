<div>
    <div class="d-flex">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'orders'])->html();
} elseif ($_instance->childHasBeenRendered('l2350644404-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2350644404-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2350644404-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2350644404-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'orders']);
    $html = $response->html();
    $_instance->logRenderedChild('l2350644404-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald033566f468fc7bb3a8d0f946fdab616 = $attributes; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.orders.components.top-nav', ['active' => ''])->html();
} elseif ($_instance->childHasBeenRendered('l2350644404-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2350644404-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2350644404-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2350644404-1');
} else {
    $response = \Livewire\Livewire::mount('admin.orders.components.top-nav', ['active' => '']);
    $html = $response->html();
    $_instance->logRenderedChild('l2350644404-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <div class="container my-5">
                <div>


                    <div class="card">
                        <div class="card-header">
                            <h2 class="text-primary">
                                Orders Details
                            </h2>
                        </div>
                        <div class="card-body">
                            
                        <div class="container">
                            <div class="row">


                                <div class="mb-3 col-12">
                                    <h3 class="text-primary text-center"><b>Customer Details</b></h3>
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td>Name:</td>
                                                <td style="font-weight: 600">
    <?php if(!empty($data['patient']['first_name']) && !empty($data['patient']['last_name'])): ?>
        <?php echo e($data['patient']['first_name'] . ' ' . $data['patient']['last_name']); ?>

    <?php else: ?>
        <?php echo e($data['patient']['name']); ?>

    <?php endif; ?>                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Email:</td>
                                                <td style=" font-weight: 600">
                                                    <?php echo e($data['patient']['email']); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row">Contact number:</td>
                                                <td style=" font-weight: 600">
                                                    <?php echo e($data['patient']['phone']); ?>

                                                </td>
                                            </tr>


                                            <tr>
                                                <td scope="row">Payment Method:</td>
                                                <td style="font-weight: 600">
                                                    <?php echo e($data['payment_method'] ?? 'N/A'); ?>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="mb-3 col-12">
                                    <h3 class="text-primary text-center"><b><?php echo e($data['Service']); ?> Details</b></h3>
                                    <?php if($data['Service']==='Repairing'): ?>
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td scope="col">Booking Reference:</td>
                                                <td scope="col">
                                                    This will follow in the acknowledgement email to be sent by
                                                    our Lab Team
                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Device:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['device']); ?>

                                                    <?php echo e($data['repair_detail']['model']); ?>

                                                    <?php echo e(array_key_exists('emc', $data) ? $data['emc'] : ''); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Fault:</td>
                                                <td style=" font-weight: 600">
                                                    <?php if(array_key_exists('faults', $data['repair_detail'])): ?>
                                                    <?php $__currentLoopData = $data['repair_detail']['faults']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($value != 'Other Fault (Please Specify)'): ?>
                                                    <span style=" font-weight: 600"><?php echo e($value); ?></span><br>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    <?php echo e($data['repair_detail']['fault']); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Turnaround Time:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['How_long']); ?>

                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Part Used:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['part_used']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Warranty:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['warranty']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Provisional Quote:</td>
                                                <td style=" font-weight: 600"> £ <?php echo e($data['repair_detail']['quotePrice']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Additional Costs:</td>
                                                <td style=" font-weight: 600">
                                                    <?php echo e($data['repair_detail']['screen_protector']); ?>

                                                    <?php echo e($data['repair_detail']['protective_case']); ?>

                                                    <?php echo e($data['repair_detail']['postal_price']); ?>

                                                    <?php echo e($data['repair_detail']['fix_form_price']); ?>

                                                    <?php echo e($data['repair_detail']['collection_form_price']); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">appointment at</td>
                                                <td>
                                                    <span style="color: red"><strong><?php echo e(session('clinic_name')); ?></strong></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Date - Time</td>
                                                <td class="text-info" style="font-weight: 600;">
                                                    <?php echo e($data['form']['appointment_date'] ?? ""); ?> - <?php echo e($data['form']['appointment_time'] ?? ""); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Repair Note</td>
                                                <td>
                                                    <?php echo e($data['form']['repair_note'] ?? ""); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Info:</td>
                                                <td>
                                                    If we can’t repair your device, then under our
                                                    <span style="color: red"><strong>No-Fix, No-Fee </strong></span>promise, there’s nothing
                                                    to pay for the work undertaken.
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <?php elseif($data['Service']==='Buy'): ?>
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td scope="col" style="width: 180px;">Booking Reference:</td>
                                                <td scope="col">
                                                    This will follow in the acknowledgement email to be sent by
                                                    our Lab Team
                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Device:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['device']['name']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Model:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['modal']['name']); ?></td>
                                            </tr>

                                            <tr>
                                                <td scope="row" style="width: 170px;">Memory Size:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['memory_size']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Color:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['color']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Grade:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['grade']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Detail:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['detail']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Specification:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['specification']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Warranty:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['warranty']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Quantity:</td>
                                                <td style=" font-weight: 600"> <?php echo e($data['repair_detail']['quantity']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Provisional Quote:</td>
                                                <td style=" font-weight: 600"> £ <?php echo e($data['repair_detail']['price']); ?></td>
                                            </tr>

                                            <tr>
                                                <td scope="row" style="width: 170px;">Note</td>
                                                <td>
                                                    <?php echo e($data['form']['repair_note']); ?>

                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>

                                    <h3 class="text-primary text-center"><b>Appointment Options</b></h3>
                                    <table class="table">
                                        <tbody>

                                            <tr>
                                                <td scope="row" style="width: 170px;">appointment at</td>
                                                <td>
                                                    <span style="color: red"><strong><?php echo e($data['form']['name'] ?? ""); ?></strong></span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td scope="row" style="width: 170px;">Date - Time</td>
                                                <td class="text-info" style="font-weight: 600;">
                                                    <?php echo e($data['form']['appointment_date'] ?? ""); ?> - <?php echo e($data['form']['appointment_time'] ?? ""); ?>


                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 180px;">Directions:</td>
                                                <td>
                                                    The entrance to the alleyway is next to Holland & Barrett
                                                    (opposite Borough Market) and we’re in the same building as the
                                                    Vape Store. If you're travelling by Underground, please exit
                                                    London Bridge Station from the
                                                    <b>Borough High Street (East)</b> exit. It’s a 30-second walk
                                                    from here, but up to 10 minutes from other exits.
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <?php elseif($data['Service']==='Sell'): ?>

                                    <?php if(isset($data['selectedBranch']['name'])): ?>

                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td style="width: 180px;">Adress :</td>
                                                <td>
                                                    <span> <?php echo e($data['selectedBranch']['name']); ?> , <?php echo e($data['selectedBranch']['address_line_1']); ?> , <?php echo e($data['selectedBranch']['address_line_2']); ?> <?php echo e($data['selectedBranch']['address_line_2']!=''?', ':''); ?> <?php echo e($data['selectedBranch']['town_city']); ?> , <?php echo e($data['selectedBranch']['post_code']); ?>,UK</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 180px;">Email :</td>
                                                <td>

                                                    <span> <?php echo e($data['selectedBranch']['email']); ?></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 180px;">Landline Number :</td>
                                                <td>

                                                    <span><?php echo e($data['selectedBranch']['landline_number']); ?> </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 180px;">Mobile Number :</td>
                                                <td>

                                                    <span> <?php echo e($data['selectedBranch']['mobile_number']); ?></span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <?php endif; ?>
                                    <h3 class="text-primary text-center"><b>Device Details</b></h3>
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td scope="col" style="width: 180px;">Sell Device Reference:</td>
                                                <td scope="col">
                                                    This will follow in the acknowledgement email to be sent by
                                                    our Lab Team
                                                </td>
                                            </tr>
                                            <tr>

                                                <td scope="row" style="width: 170px;">Device:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['specs']['device']['name']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Model:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['specs']['modal']['name']); ?></td>
                                            </tr>

                                            <tr>
                                                <td scope="row" style="width: 170px;"></td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['specs']['memory_size']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Color:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['specs']['color']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Condition:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['specs']['condition']); ?></td>
                                            </tr>

                                            <tr>
                                                <td scope="row" style="width: 170px;">Provisional Quote:</td>
                                                <td style=" font-weight: 600"> £ <?php echo e($data['repair_detail']['specs']['price']); ?></td>
                                            </tr>

                                            <tr>
                                                <td scope="row" style="width: 170px;">appointment at</td>
                                                <td>
                                                    <span style="color: red"><strong><?php echo e($data['form']['name'] ?? ""); ?></strong></span>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td scope="row" style="width: 170px;">Date - Time</td>
                                                <td class="text-info" style="font-weight: 600;">
                                                    <?php echo e($data['form']['appointment_date'] ?? ""); ?> - <?php echo e($data['form']['appointment_time'] ?? ""); ?>


                                                </td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Note</td>
                                                <td>
                                                    <?php echo e($data['form']['repair_note']); ?>

                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>

                                    <h3 class="text-primary text-center"><b>Payment Option Details</b></h3>
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td scope="col" style="width: 180px;">Sell Device Reference:</td>
                                                <td scope="col">
                                                    This will follow in the acknowledgement email to be sent by
                                                    our Lab Team
                                                </td>
                                            </tr>
                                            <?php if($data['repair_detail']['paypal']): ?>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Paypal:</td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Paypal Account Name:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['paypal']['account_name']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Paypal Account Email:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['paypal']['email']); ?></td>
                                            </tr>
                                            <?php elseif($data['repair_detail']['bank']): ?>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Bank :</td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Bank Name:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['bank']['name']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Bank Account Number:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['bank']['account_number']); ?></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" style="width: 170px;">Sort Code:</td>
                                                <td style=" font-weight: 600"><?php echo e($data['repair_detail']['bank']['sort_code']); ?></td>
                                            </tr>
                                            <?php else: ?>
                                            <?php endif; ?>





                                        </tbody>
                                    </table>
                                    <?php endif; ?>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>

            </div>
    </div>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $attributes = $__attributesOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__attributesOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>


</div>
</div><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/orders/view.blade.php ENDPATH**/ ?>
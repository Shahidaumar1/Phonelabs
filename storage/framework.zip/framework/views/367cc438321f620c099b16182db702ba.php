<div class="container justify-content-end align-items-center"
    style="">

    <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Payment failed!</strong> <?php echo e($message); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   
    <div>
        <!--<img src="https://cdn.worldvectorlogo.com/logos/klarna.svg" width="200px" height="150px"/>-->
    </div>

    <form class='w-100 '>

        <div style="position:relative;top:2px;" class="d-flex gap-2 flex-column">


            <button style="margin-left:10px; background-color:pink" type="button" wire:click="sendEmailBeforePay"
                class="btn " <?php if($loading || $price == 0): ?> disabled <?php endif; ?>>
                <div class="d-flex gap-3 justify-content-center align-itemes-center ">
                    Pay With Klarna
                    <?php if($loading): ?>
                        <span>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spinner','data' => ['color' => 'white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </span>
                    <?php endif; ?>
                </div>
            </button>
        </div>

    </form>
    <div class="form-check m-2">
        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked>

        <label style="font-size:0.9vw;"  class="form-check-label" for="flexCheckChecked"><a href="<?php echo e(route('privacy-and-policy')); ?>">I Agree
                to
                Privacy Policy</a> And <a href="<?php echo e(route('terms-and-conditions')); ?>">Terms & Conditions</a></label>
    </div>
</div>
<style>
    .hhh{
        min-height:300px; max-width:550px; background: #ffffff 0% 0% no-repeat padding-box;box-shadow: 0px 3px 6px #ff070729;border: 1px solid #cecece;border-radius: 15px;
    }
     
    }
</style><?php /**PATH /home/mobilebitz/test.mobilebitz.co.uk/resources/views/livewire/payment-methods/klarna.blade.php ENDPATH**/ ?>
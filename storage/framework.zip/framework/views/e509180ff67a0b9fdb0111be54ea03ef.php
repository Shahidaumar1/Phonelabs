  <a href="javascript:void(0)" class="d-flex align-items-center gap-2 text-black ">
      <img src="<?php echo e($user->avater ?? 'https://mdbcdn.b-cdn.net/img/new/avatars/2.webp'); ?>" alt="hugenerd" width="40"
          height="40" class="rounded-circle" />
      <span class="fw-bold"><?php echo e($user->name ?? 'John Doe'); ?></span>
  </a>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/components/avatar.blade.php ENDPATH**/ ?>
<div class="p-10">
    <div class="form-group">
        <label for="post_code">Post Code:</label>
        <input type="text" wire:model="post_code" class="form-control" id="post_code" placeholder="Enter Post Code">
        <div id="resultContainer">
            <p><?php echo e($addressName); ?></p>
        </div>
        <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    <button wire:click.prevent="changeApiData" class="mb-2">Search</button>
    <?php if($responseData): ?>
        
        

        
        <select wire:model="selectedOption"  class="form-select" wire:change.prevent="addAddressData">
            <option value="" selected >Select an option</option>
            <?php $__currentLoopData = $responseData['knownAddresses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option key="<?php echo e($key); ?>" value="<?php echo e($address); ?>"><?php echo e($address); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <a class="text-primary" href="#" wire:click.prevent="toggleAddressFields" >or you can write your own </a>
        
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/livewire/components/address-common.blade.php ENDPATH**/ ?>
<div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l1467137632-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1467137632-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1467137632-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1467137632-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1467137632-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <section class="modals-head">
        <div class="overlay"></div>
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l1467137632-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1467137632-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1467137632-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1467137632-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1467137632-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          
            <div class="p-3 rounded-2 mt-5 d-flex justify-content-between align-items-center"
                style="background-color: #afafaf">
                <div class="d-flex flex-column col-7">
                    <h1 class="">Broken <span class="text-danger"><?php echo e($device->name ?? 'Apple iPhone'); ?>? </span>
                    </h1>
                    <p class="tagline ">
                        Whether you’ve got a broken screen or back glass, a battery problem, water damage, a charging
                        problem, faulty camera, or however else you’ve broken it, we should be able to repair it for
                        you…
                        But first, we need to know which <?php echo e($device->name ?? ''); ?> you’re fixing!
                    </p>
                </div>

                <div class="d-flex justify-content-end align-items-center col-4">
                    
                    <!--<h2 class=" mt-3 ml-3 text-end " style="color: #da0a0a"><b>Students can get 10% Off on all-->
                    <!--        repairs</b></h2>-->
                </div>

            </div>

        </div>
    </section>

<section>
    
    <div class="container d-flex justify-content-center align-items-center mt-5">
    <div class="input-group mb-3" style="max-width: 400px;">
        <input type="text" id="modalSearch" class="rounded-pill" placeholder="Search by Modal Name">
        <i style="position:absolute;right:20px" class="fa fa-search mt-2"></i>
    </div>
</div>
    
    <div class="container ">

        <div class="section-header text-center my-5">
            <h2><sup></sup> <?php echo e($device->name ?? 'Apple Iphone'); ?>

                <sub></sub>
            </h2>
        </div>

        <div class="row justify-content-center">
            <?php $__empty_1 = true; $__currentLoopData = $modals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key  => $modal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
            <div class="col-lg-2 col-md-4 mb-4 col-sm-6 col-6"> <!-- Adjust column sizes for responsiveness -->
                <div class="black-cards">
                    <a href="<?php echo e(route('repair-types', ['device' => $device->id, 'modal' => $modal->id])); ?>">
                        <div class="card text-center">
                            <div class="card-header">
                                <img src="<?php echo e($modal->file ?? ''); ?>" class="img-fluid  mx-auto" style="max-height:150px; max-width:150px;">
                            </div>
                            <div class="card-text">
                                <?php echo e($modal->name); ?>

                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span>Not Found</span>
            <?php endif; ?>
        </div>
    </div>
</section>



<!-- JavaScript for Search Functionality -->
<script>
    // Function to handle modal search
    function searchModals() {
        // Declare variables
        var input, filter, modals, modalCards, modalName, i;
        input = document.getElementById('modalSearch');
        filter = input.value.toUpperCase();
        modals = document.getElementsByClassName('row justify-content-center')[0];
        modalCards = modals.getElementsByClassName('card');

        // Loop through all modal cards, and hide those that don't match the search query
        for (i = 0; i < modalCards.length; i++) {
            modalName = modalCards[i].getElementsByClassName("card-text")[0];
            if (modalName.innerText.toUpperCase().indexOf(filter) > -1) {
                modalCards[i].style.display = "";
            } else {
                modalCards[i].style.display = "none";
            }
        }
    }

    // Attach event listener to the search input
    document.getElementById('modalSearch').addEventListener('keyup', searchModals);
</script>



</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/modals.blade.php ENDPATH**/ ?>
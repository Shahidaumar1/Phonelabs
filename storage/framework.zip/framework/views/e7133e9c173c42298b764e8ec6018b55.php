<div>
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset($siteSettings->logo ?? 'logo/logo.png')); ?>"
        class="img-fluid " style="height:50px; width:135px; margin-bottom:10px;"></a>

</div>
<?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/livewire/components/logo.blade.php ENDPATH**/ ?>
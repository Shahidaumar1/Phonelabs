<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l1425277616-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1425277616-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1425277616-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1425277616-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1425277616-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l1425277616-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1425277616-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1425277616-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1425277616-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1425277616-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div class="col-md-8 mx-auto my-5">
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Payment Successfully Sent.</h4>
                <p>Admin will contact you soon</p>
                <hr>
                <p class="mb-0">Whenever you need to, you can contact with us.</p>
                <a href="<?php echo e(route('home')); ?>">Go To Home</a>
            </div>
        </div>
    </div>

</div>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/payment-methods/klarna-success.blade.php ENDPATH**/ ?>
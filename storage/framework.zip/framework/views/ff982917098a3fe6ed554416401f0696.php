<div>
    <div class="mb-3">
        <label for="key" class="form-label">Key: <sub>no space</sub> </label>
        <input type="text" wire:model="key" name="key" class="form-control" />
        <?php $__errorArgs = ['key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3" wire:ignore>
        <label for="content" class="form-label">Content: <sub>*required</sub></label>
        <textarea wire:model.debounce.500="content" id="editor" class="form-control"></textarea>
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Description: <sub>optional</sub></label>
        <input type="text" wire:model="description" class="form-control" />
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="float-end mt-3">
        <button type="submit" class="btn btn-primary" wire:click="save">
            <?php echo e($editing ? 'Update' : 'Save'); ?>

            <span wire:loading wire:target='save'>
                <?php if (isset($component)) { $__componentOriginalf26909af655deaf31c8e20175813a5a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf26909af655deaf31c8e20175813a5a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spinner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf26909af655deaf31c8e20175813a5a0)): ?>
<?php $attributes = $__attributesOriginalf26909af655deaf31c8e20175813a5a0; ?>
<?php unset($__attributesOriginalf26909af655deaf31c8e20175813a5a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf26909af655deaf31c8e20175813a5a0)): ?>
<?php $component = $__componentOriginalf26909af655deaf31c8e20175813a5a0; ?>
<?php unset($__componentOriginalf26909af655deaf31c8e20175813a5a0); ?>
<?php endif; ?>
            </span>
        </button>
    </div>
</div>
<script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
<script>
    let editorInstance = null;

    function createEditor() {
        if (editorInstance) {
            editorInstance.destroy().then(() => {
                // console.log('Editor destroyed.');
                initializeNewEditor();
            });
        } else {
            initializeNewEditor();
        }
    }

    function initializeNewEditor() {

        ClassicEditor
            .create(document.querySelector('#editor'))
            .then(editor => {
                editorInstance = editor;
                editor.model.document.on('change:data', () => {
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('content', editor.getData());
                });
            })
            .catch(error => {
                console.error(error);
            });
    }


    // createEditor();
    Livewire.on('AddContent', (content) => {
        if (editorInstance) {
            editorInstance.setData(window.livewire.find('<?php echo e($_instance->id); ?>').get('content'));
        }
        createEditor();
    });
</script><?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/livewire/admin/website-contents/add-web-content.blade.php ENDPATH**/ ?>
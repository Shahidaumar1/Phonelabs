<!-- -------change radio forms------ -->
<div class="d-flex  align-items-center">
    <style>
      .col-7 {
    width: 100%;
    height: 100%;
    background: #ffffff 0% 0% no-repeat padding-box;

    border-radius: 15px;
    margin-left: auto;
    margin-right: auto;
}

@media (max-width: 767px) {
    .col-7 {
        width: 100%;
           /* Limit maximum width */
    }
    .btn-success{
        margin-top:-20px;
    }
    
}

    </style>
    <div class="my-4 col-7" style="
          
          ">
        <div id="paymentForm">
            <!--<h2 class="text-center p-2 fw-bold">Bank Transfer</h2>-->
 
            <div class="px-1 ">
                <!--<label for="disabledSelect" class="form-label">Account Title</label>-->
                <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Title" wire:model.debounce.500="bank.account_title">-->
            
            <div class="row mb-2">
    <label for="exampleFormControlInput1" style="font-size:1vw;"  class="col-sm-2 col-form-label">Title</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="exampleFormControlInput1" style="font-size:12px;" placeholder="Enter Account Title" wire:model.debounce.500="bank.account_title">
    </div>
</div>

            
            
            
                <?php $__errorArgs = ['bank.account_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="px-1 ">
                <!--<label for="disabledSelect" class="form-label">Account Number</label>-->
                <!--<input type="number" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Number" wire:model.debounce.500="bank.account_number">-->
                <div class="row mb-2">
    <label for="exampleFormControlInput1" style="font-size:1vw;"  class="col-sm-2 col-form-label">Account</label>
    <div class="col-sm-10">
        <input type="number" class="form-control" id="exampleFormControlInput1" style="font-size:11px;" placeholder="Enter Account Number" wire:model.debounce.500="bank.account_number">
    </div>
</div>

                
                <?php $__errorArgs = ['bank.account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-1 ">
                <!--<label for="disabledSelect" class="form-label">Bank Name</label>-->
                <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Bank Name" wire:model.debounce.500="bank.name">-->
               <div class="row mb-2">
    <label for="exampleFormControlInput1" style="font-size:1vw;" class="col-sm-2 col-form-label">Bank</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="exampleFormControlInput1"  style="font-size:11px;"  placeholder="Enter Bank Name" wire:model.debounce.500="bank.name">
    </div>
</div>

               
               
                <?php $__errorArgs = ['bank.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="px-1 ">
                <!--<label for="disabledSelect" class="form-label">Sort Code</label>-->
                <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Sort Code" wire:model.debounce.500="bank.sort_code">-->
               <div class="row mb-2">
    <label for="exampleFormControlInput1" style="font-size:1vw;" class="col-sm-2 col-form-label">S.code</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="exampleFormControlInput1" style="font-size:11px;" placeholder="Enter Sort Code" wire:model.debounce.500="bank.sort_code">
    </div>
</div>

               
               
                <?php $__errorArgs = ['bank.sort_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-2 py-2">
                <div class="form-check">
                    <input style="transform: scale(0.8);" class="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                    <label style="font-size:0.9vw;" class="form-check-label" for="flexCheckDefault">
                        Agree with Privacy Policy Terms & Conditions
                    </label>
                </div>
            </div>

            <div class="cursor-point align-items-center d-grid gap-2 col-12 justify-content-center">

                <button class="btn btn-danger text-white" wire:click="submit">Submit</button>
                <?php if($loading): ?>
                <span>Submiting...</span>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/sell/components/bank.blade.php ENDPATH**/ ?>
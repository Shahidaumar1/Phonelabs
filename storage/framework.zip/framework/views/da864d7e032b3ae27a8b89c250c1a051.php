<div>
    <?php if(Session::get('serviceType') == 'Repair'): ?>
<div>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>


    <div class="container mt-3" style="background-color:white">
        <!-- Display branch selection and appointment form -->
        <form x-data="{ step: 0 }" class="p-4 submit-form" wire:submit.prevent="submitForm">
            <!-- Step 1: Select nearest branch -->
            <section id="section-1" x-show="step === 0" x-cloak class="row map-select">
                <legend class="mb-3">
                    <h2 class="find">Find a Nearest Store To Post Your Device</h2>
                    <p class="text-center"><em>To calculate the real-time distance of stores from your location, please
                            enter your postal code</em></p>
                </legend>
                <!--  on phone screen-->
                <div class="col-md-6 mt-4   d-lg-none d-md-none" style=" width:840% !important;">
                    <div class="input-group  " style="display: flex; ">
                        <input type="text" class="form-control " wire:model.defer="post_code" required
                            style="margin-left:-25%" placeholder="Enter Your Post Code">
                        <button type="button" class="btn btn-danger " wire:click="getLatLong"
                            style="margin-top:-34%;height:44px;margin-left:100%">Search</button>
                    </div>

                    <div style="margin-left:-20%; width="120%!important" height="530px"; border: 0;">
                        <!-- Display map or iframe -->
                        <?php if(!empty($mapLink)): ?>
                        <?php echo $mapLink; ?>

                        <?php else: ?>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                            width="120%" height="530px" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php endif; ?>
                    </div>
                </div>
                <!--Show on desktop screen-->
                <div class="col-md-4 mt-4 fpostcode-map d-none d-lg-block d-md-block">
                        <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control search search_input" wire:model.defer="post_code"
                            required placeholder="Enter Your Post Code">
                        <button type="button" class="btn btn-danger search-btn" wire:click="getLatLong">Search</button>
                    </div>
                    <div class="map-setting" style="width: 100%; height: 570px; border: 0;">
                        <!-- Display map or iframe -->
                        <?php if(!empty($mapLink)): ?>
                        <?php echo $mapLink; ?>

                        <?php else: ?>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                            width="100%" height="530px" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php endif; ?>
                    </div>
                </div>
                <!---------------------------------on phone screen-------------->
                <div class="col-md-3   d-lg-none d-md-none">
                    <div class="col-lg-12 px-3 boxes" style="width:370px;margin-left:-40%">
                        <!-- Display nearest branches -->
                        <?php if(!empty($nearestBranches)): ?>
                        <?php $__currentLoopData = $nearestBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <p class="fw-bold branch-name" style="font-size:5px"><?php echo e($branch['name']); ?>, <span
                                    class="distance_color"><?php echo e(number_format($branch['distance'], 2)); ?> miles</span></p>
                            <p class="address-town-post-code" style="font-size:7px;margin-top:-10px"><?php echo e($branch['address_line_1']); ?>, <?php echo e($branch['address_line_2'] ?: ''); ?>, <?php echo e($branch['town_city']); ?>, <?php echo e($branch['post_code']); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch['landline_number'])): ?>
                                    <option value="1">Landline: <?php echo e($branch['landline_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['mobile_number'])): ?>
                                    <option value="2">Mobile: <?php echo e($branch['mobile_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['email'])): ?>
                                    <option value="3" selected>Email: <?php echo e($branch['email']); ?></option>
                                    <?php endif; ?>


                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch['id']); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(!empty($branches)): ?>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <p class="fw-bold branch-name"><?php echo e($branch->name); ?></p>
                            <p class="address-town-post-code" style="margin-top:-10px"><?php echo e($branch->address_line_1); ?>, <?php echo e($branch->address_line_2 ?: ''); ?>, <?php echo e($branch->town_city); ?>, <?php echo e($branch->post_code); ?>, UK
                            </p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch->email)): ?>
                                    <option value="3" selected>Email: <?php echo e($branch->email); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->landline_number)): ?>
                                    <option value="1">Landline: <?php echo e($branch->landline_number); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->mobile_number)): ?>
                                    <option value="2">Mobile: <?php echo e($branch->mobile_number); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch->id); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <!---------------------------------desktop screen-------------->
                <div class="col-md-5 d-none d-lg-block d-md-block selection-area">
                    <div class="col-lg-12 px-3 boxes" style="height: 580px;">
                        <!-- Display nearest branches -->
                        <?php if(!empty($nearestBranches)): ?>
                        <?php $__currentLoopData = $nearestBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <h3 class="fw-bold branch-name"><?php echo e($branch['name']); ?>, <span class="distance_color"><?php echo e(number_format($branch['distance'], 2)); ?> miles</span></h3>
                            <p class="address-town-post-code"><?php echo e($branch['address_line_1']); ?>, <?php echo e($branch['address_line_2'] ?: ''); ?>, <?php echo e($branch['town_city']); ?>, <?php echo e($branch['post_code']); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch['email'])): ?>
                                    <option value="1" selected>Email: <?php echo e($branch['email']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['landline_number'])): ?>
                                    <option value="2">Landline: <?php echo e($branch['landline_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['mobile_number'])): ?>
                                    <option value="3">Mobile: <?php echo e($branch['mobile_number']); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch['id']); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(!empty($branches)): ?>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <h3 class="fw-bold branch-name"><?php echo e($branch->name); ?></h3>
                            <p class="address-town-post-code"><?php echo e($branch->address_line_1); ?>, <?php echo e($branch->address_line_2
                                ?: ''); ?>, <?php echo e($branch->town_city); ?>, <?php echo e($branch->post_code); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch->email)): ?>
                                    <option value="1" selected>Email: <?php echo e($branch->email); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->landline_number)): ?>
                                    <option value="2">Landline: <?php echo e($branch->landline_number); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->mobile_number)): ?>
                                    <option value="3">Mobile: <?php echo e($branch->mobile_number); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch->id); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

            </section>
            <section id="section-2" x-show="step === 1" x-cloak>
            <div  style="    background-color: #ffffff;
    border-radius: 10px;
    width: 100%;
    margin: 0 auto;
    padding: 20px;"  >


        <h5 class="fw-bold mt-3 mb-3">Please post your device to this address</h5>


        <div class="p-10">
            <div class="form-group">
                <label for="post_code">Post Code:</label>
                <input type="text" wire:model="post_code" class="form-control" id="post_code"
                    placeholder="Enter Post Code">
                <div id="resultContainer">
                    <p><?php echo e($addressName); ?></p>
                </div>
                <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button wire:click.prevent="changeApiData" class="mb-2">Search</button>
            <?php if($responseData): ?>


                
                <select wire:model="selectedOption" class="form-select" wire:change.prevent="updateAddressFields">
                    <option value="" selected>Select an option</option>
                    <?php $__currentLoopData = $responseData['knownAddresses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option key="<?php echo e($key); ?>" value="<?php echo e($address); ?>"><?php echo e($address); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>


                <!-- Display the error message if set -->
                <?php if($errorMessage): ?>
                    <div class="text-danger"><?php echo e($errorMessage); ?></div>
                <?php endif; ?>

            <?php endif; ?>


            <?php if($responseData): ?>
                <button class=" text-danger bg-white border-radius rounded-pill mt-3"
                    wire:click.prevent="toggleInputFields">I can't find my address..</button>

                <!-- Conditional rendering for input fields -->
                <?php if($showInputFields): ?>
                    <div class="mb-3 mt-3">
                        <label for="address_line_1">Address Line 1*:</label>
                        <input type="text" class="form-control form-control-sm"
                            wire:model.lazy="postal.address_line_1" placeholder="Address Line 1"
                            name="postal.address_line_1" required="">
                        <?php $__errorArgs = ['postal.address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3 mt-3">
                        <label for="address_line_2">Address Line 2:</label>
                        <input type="text" class="form-control form-control-sm"
                            wire:model.lazy="postal.address_line_2" placeholder="Address Line 2"
                            name="postal.address_line_2">
                    </div>

                    <div class="mb-3 mt-3">
                        <label for="city">Town/City*:</label>
                        <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.city"
                            placeholder="Town/City" name="postal.city" required="">
                        <?php $__errorArgs = ['postal.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>




                    <div class="mb-3 mt-3">
                        <label for="postal_code">Post Code*:</label>
                        <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.code"
                            placeholder="Post Code" name="postal.code" required="">
                        <?php $__errorArgs = ['postal.code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>


        <!-- Include this script in your Livewire component or wherever necessary -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Listen for the Livewire event indicating data update
                Livewire.on('addressFieldsUpdated', function() {
                    // Find the relevant input fields by name attribute
                    var address1 = document.querySelector("input[name='postal.address_line_1']");
                    var address2 = document.querySelector("input[name='postal.address_line_2']");
                    var city = document.querySelector("input[name='postal.city']");
                    var post_code = document.querySelector("input[name='postal.code']");

                    // Append five dots to each field if they exist
                    if (address1) {
                        address1.value += '.....';
                        // Trigger input event to simulate user interaction
                        var event = new Event('input', {
                            bubbles: true
                        });
                        address1.dispatchEvent(event);
                    }

                    if (address2) {
                        address2.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        address2.dispatchEvent(event);
                    }

                    if (city) {
                        city.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        city.dispatchEvent(event);
                    }

                    if (post_code) {
                        post_code.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        post_code.dispatchEvent(event);
                    }
                });
            });
        </script>




    </div>
             </section>
      

            <!-- Submit button  desktop-->
            <div class="d-none d-lg-block d-md-block">
                <div class="btn-style ">

                    <button class="button-20 " role="button" type="submit" x-show="step === 1">Next</button>

                    <button class="button-20" role="button" type="button" @click="step = 0" x-show="step === 1"  wire:click="goBack">Go
                        Back</button>
                </div>
            </div>
            <!--------------------phone screen-------------->
            <div class=" d-lg-none d-md-none " style="margin-top:-20%">
                <div class="btn-style ">

                    <button class="button-20" style="margin-right:-23%" role="button" type="submit"
                        x-show="step === 1">Next</button>

                    <button class="button-20" style="margin-left:-20%; role="button" type="button"
                        @click="step = 0" x-show="step === 1"  wire:click="goBack">GoBack</button>
                </div>
            </div>

    </div>
    </form>
</div>

<style>
    .submit-form {
        position: relative;
    }

    .button-20 {
        appearance: button;
        /*width: 11%;*/
        background-color: #dc3545;
        background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
        border: 1px solid #dc3545;
        border-radius: 1rem;
        box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px;
        box-sizing: border-box;
        color: #FFFFFF;
        cursor: pointer;
        display: inline-block;
        font-family: Inter, sans-serif;
        font-size: 1rem;
        font-weight: 500;
        line-height: 1.7;
        margin: 0;
        padding: 6px 50px;
        text-align: center;
        text-transform: none;
        transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
        vertical-align: middle;
    }

    .button-20:focus:not(:focus-visible),
    .button-20:focus {
        outline: 0;
    }

    .button-20:hover {
        background-color: #dc3545;
        border-color: #dc3545;
    }

    .button-20:focus {
        background-color: #dc3545;
        border-color: #dc3545;
        box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
    }

    .button-20:active {
        background-color: #dc3545;
        background-image: none;
        border-color: #dc3545;
        box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
    }

    .button-20:active:focus {
        box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
    }

    .button-20:disabled {
        background-image: none;
        box-shadow: none;
        opacity: .65;
        pointer-events: none;
    }

    .calendar-container {
        border: 1px solid #dee2e6;
        border-radius: 10px;
        box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
        padding: 1rem;
        width: max-content;
    }

    .calendar-table {
        margin-bottom: 1rem;
    }

    .calendar-table th,
    .calendar-table td {
        text-align: center;
        vertical-align: middle;
        padding: 0.5rem;
    }

    .calendar-table td {
        cursor: pointer;
    }

    .calendar-table td.today {
        background-color: #f8f9fa;
    }

    .calendar-table td.selected {
        background-color: #dc3545;
        color: white;
    }

    .calendar-table td.disabled {
        color: #dee2e6;
        cursor: not-allowed;
    }

    .time-slots-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 10px;
    }

    .time-slot-btn {
        padding: 10px;
        text-align: center;
    }

    .time-slot-btn.active {
        background-color: #dc3545;
        color: white;
        border-color: #dc3545;
    }

    .selected-datetime {
        font-weight: bold;
    }

    .search {
        width: 70px;
    }

    .map-setting {
        background-color: #fff;
        border-radius: 15px;
        box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);
        padding: 17px 14px 14px;
    }

    .fpostcode-map {
        width: 40%;
        background-color: #fff;
        border-radius: 15px;
        /*box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);*/
        /*padding: 17px 14px 14px 14px;*/
    }

    .input-group {
        display: flex;
        gap: 20px;
    }

    .form-select-btn {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .distance_color {
        color: #dc3545;
    }

    .search_input {
        border-radius: 20px;
        border-top-right-radius: 20px !important;
        border-bottom-right-radius: 20px !important;
        /*box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;*/
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
    }

    .search-btn {
        border-radius: 20px;
        border-top-left-radius: 20px !important;
        border-bottom-left-radius: 20px !important;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

    }

    .address-town-post-code {
        padding-bottom: 6px;
    }

    .boxes {
        width: 700px;
        margin-top: 25px;
        height: 920px;
        overflow-y: scroll;
        /*scrollbar-color: rgb(233, 163, 163) transparent;*/
        scroll-behavior: smooth;
        /*scroll-padding: 50px;*/
    }

    .boxes div {
        border-radius: 20px;
    }

    .boxes div:nth-child(1) {
        margin-top: 0px !important;
    }

    .boxes::-webkit-scrollbar {
        width: 20px;
        height: 100px;
    }

    .btn-style {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-direction: row-reverse;
        margin-top: 50px;
    }

    .boxes::-webkit-scrollbar-track {
        background: #d1d1d1;
        border-radius: 40px;
    }

    .boxes::-webkit-scrollbar-thumb {
        background-color: #dc3545;
        border-radius: 40px;
        border: 3px solid transparent;
    }

    .find {
        color: rgb(240, 88, 88);
        font-size: 44px;
        font-weight: 900;
        text-align: center;
    }

    .search-btn {
        background-color: #da3847;
        color: white;
    }

    .s-card {
        height: 120px;
    }

    .left-side {
        width: 30%;
    }

    @media (max-width: 576px) {

        h2.find,
        p.text-center {
            margin-left: -20px;
            font-size: 15px;
        }

        .input-group {
            flex-wrap: wrap;
        }

        .input-group .form-control {
            flex: 1 1 100%;
            width: 100%;
            margin-right: 0;
            margin-bottom: 10px;
        }

        .input-group .search-btn {
            flex: 1 1 100%;
            width: 100%;
        }

        /* width: 133%;
        height: 850px;
        border: 0; */
    }

    .slot-container {
        justify-content: center;
    }

    /*///////////// Slot Responsive /////////////*/
    @media (max-width: 1400px) {
        .left-side {
            width: 35%;
        }
    }

    @media (max-width: 1400px) {
        .left-side {
            width: 40%;
        }
    }

    @media (max-width: 1024px) {
        .map-select {
            flex-direction: column;
        }

        .fpostcode-map {
            width: 100%;
        }

        .selection-area {
            width: 100%;
        }

        .boxes {
            width: 100%;
        }
    }

    @media (max-width: 900px) {
        .slot-container {
            flex-direction: column;
        }

        .select-slot-div {
            width: 100%;
        }

        .left-side {
            width: 100%;
        }

    }

    /*///////////// Slot Responsive /////////////*/
    /*-------------------------------------phone reponsive--- start-----------------*/
    @media (max-width: 320px) {

        .col-md-6 {
            flex: 0 0 auto;
            width: 300% !important;
        }
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        flatpickr("#appointment_date", {
            dateFormat: "Y-m-d",
            minDate: "today"
        });
    });
</script>


</div>


<div  style="    background-color: #ffffff;
    border-radius: 10px;
    width: 100%;
    margin: 0 auto;
    padding: 20px;"  >

    <?php elseif(Session::get('serviceType') == 'Buy'): ?>

        <h5 class="fw-bold mt-3 mb-3">Please post your device to this address</h5>


        <div class="p-10">
            <div class="form-group">
                <label for="post_code">Post Code:</label>
                <input type="text" wire:model="post_code" class="form-control" id="post_code"
                    placeholder="Enter Post Code">
                <div id="resultContainer">
                    <p><?php echo e($addressName); ?></p>
                </div>
                <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button wire:click.prevent="changeApiData" class="mb-2">Search</button>
            <?php if($responseData): ?>


                
                <select wire:model="selectedOption" class="form-select" wire:change.prevent="updateAddressFields">
                    <option value="" selected>Select an option</option>
                    <?php $__currentLoopData = $responseData['knownAddresses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option key="<?php echo e($key); ?>" value="<?php echo e($address); ?>"><?php echo e($address); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>


                <!-- Display the error message if set -->
                <?php if($errorMessage): ?>
                    <div class="text-danger"><?php echo e($errorMessage); ?></div>
                <?php endif; ?>

            <?php endif; ?>


            <?php if($responseData): ?>
                <button class=" text-danger bg-white border-radius rounded-pill mt-3"
                    wire:click.prevent="toggleInputFields">I can't find my address..</button>

                <!-- Conditional rendering for input fields -->
                <?php if($showInputFields): ?>
                    <div class="mb-3 mt-3">
                        <label for="address_line_1">Address Line 1*:</label>
                        <input type="text" class="form-control form-control-sm"
                            wire:model.lazy="postal.address_line_1" placeholder="Address Line 1"
                            name="postal.address_line_1" required="">
                        <?php $__errorArgs = ['postal.address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3 mt-3">
                        <label for="address_line_2">Address Line 2:</label>
                        <input type="text" class="form-control form-control-sm"
                            wire:model.lazy="postal.address_line_2" placeholder="Address Line 2"
                            name="postal.address_line_2">
                    </div>

                    <div class="mb-3 mt-3">
                        <label for="city">Town/City*:</label>
                        <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.city"
                            placeholder="Town/City" name="postal.city" required="">
                        <?php $__errorArgs = ['postal.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>




                    <div class="mb-3 mt-3">
                        <label for="postal_code">Post Code*:</label>
                        <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.code"
                            placeholder="Post Code" name="postal.code" required="">
                        <?php $__errorArgs = ['postal.code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <!-- Include this script in your Livewire component or wherever necessary -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Listen for the Livewire event indicating data update
                Livewire.on('addressFieldsUpdated', function() {
                    // Find the relevant input fields by name attribute
                    var address1 = document.querySelector("input[name='postal.address_line_1']");
                    var address2 = document.querySelector("input[name='postal.address_line_2']");
                    var city = document.querySelector("input[name='postal.city']");
                    var post_code = document.querySelector("input[name='postal.code']");

                    // Append five dots to each field if they exist
                    if (address1) {
                        address1.value += '.....';
                        // Trigger input event to simulate user interaction
                        var event = new Event('input', {
                            bubbles: true
                        });
                        address1.dispatchEvent(event);
                    }

                    if (address2) {
                        address2.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        address2.dispatchEvent(event);
                    }

                    if (city) {
                        city.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        city.dispatchEvent(event);
                    }

                    if (post_code) {
                        post_code.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        post_code.dispatchEvent(event);
                    }
                });
            });
        </script>
                        <button  wire:click.prevent="submitForm" class="btn btn-danger customer-btn" style="margin-top: 20px; padding: 10px 4px; width: 10%; border-radius: 15px;">Next</button>

<?php elseif(Session::get('serviceType') == 'Sell'): ?>
<div class="container mt-3" style="background-color:white">
        <!-- Display branch selection and appointment form -->
        <form x-data="{ step: 0 }" class="p-4 submit-form" wire:submit.prevent="submitForm">
            <!-- Step 1: Select nearest branch -->
            <section id="section-1" x-show="step === 0" x-cloak class="row map-select">
                <legend class="mb-3">
                    <h2 class="find">Find a Nearest Store To Post Your Device</h2>
                    <p class="text-center"><em>To calculate the real-time distance of stores from your location, please
                            enter your postal code</em></p>
                </legend>
                <!--  on phone screen-->
                <div class="col-md-6 mt-4   d-lg-none d-md-none" style=" width:840% !important;">
                    <div class="input-group  " style="display: flex; ">
                        <input type="text" class="form-control " wire:model.defer="post_code" required
                            style="margin-left:-25%" placeholder="Enter Your Post Code">
                        <button type="button" class="btn btn-danger " wire:click="getLatLong"
                            style="margin-top:-34%;height:44px;margin-left:100%">Search</button>
                    </div>

                    <div style="margin-left:-20%; width="120%!important" height="530px"; border: 0;">
                        <!-- Display map or iframe -->
                        <?php if(!empty($mapLink)): ?>
                        <?php echo $mapLink; ?>

                        <?php else: ?>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                            width="120%" height="530px" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php endif; ?>
                    </div>
                </div>
                <!--Show on desktop screen-->
                <div class="col-md-6 mt-4 fpostcode-map d-none d-lg-block d-md-block">
                        <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control search search_input" wire:model.defer="post_code"
                            required placeholder="Enter Your Post Code">
                        <button type="button" class="btn btn-danger search-btn" wire:click="getLatLong">Search</button>
                    </div>
                    <div class="map-setting" style="width: 100%; height: 570px; border: 0;">
                        <!-- Display map or iframe -->
                        <?php if(!empty($mapLink)): ?>
                        <?php echo $mapLink; ?>

                        <?php else: ?>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                            width="100%" height="530px" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php endif; ?>
                    </div>
                </div>
                <!---------------------------------on phone screen-------------->
                <div class="col-md-3   d-lg-none d-md-none">
                    <div class="col-lg-12 px-3 boxes" style="width:370px;margin-left:-40%">
                        <!-- Display nearest branches -->
                        <?php if(!empty($nearestBranches)): ?>
                        <?php $__currentLoopData = $nearestBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <p class="fw-bold branch-name" style="font-size:5px"><?php echo e($branch['name']); ?>, <span
                                    class="distance_color"><?php echo e(number_format($branch['distance'], 2)); ?> miles</span></p>
                            <p class="address-town-post-code" style="font-size:7px;margin-top:-10px"><?php echo e($branch['address_line_1']); ?>, <?php echo e($branch['address_line_2'] ?: ''); ?>, <?php echo e($branch['town_city']); ?>, <?php echo e($branch['post_code']); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch['landline_number'])): ?>
                                    <option value="1">Landline: <?php echo e($branch['landline_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['mobile_number'])): ?>
                                    <option value="2">Mobile: <?php echo e($branch['mobile_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['email'])): ?>
                                    <option value="3" selected>Email: <?php echo e($branch['email']); ?></option>
                                    <?php endif; ?>


                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch['id']); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(!empty($branches)): ?>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <p class="fw-bold branch-name"><?php echo e($branch->name); ?></p>
                            <p class="address-town-post-code" style="margin-top:-10px"><?php echo e($branch->address_line_1); ?>, <?php echo e($branch->address_line_2 ?: ''); ?>, <?php echo e($branch->town_city); ?>, <?php echo e($branch->post_code); ?>, UK
                            </p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch->email)): ?>
                                    <option value="3" selected>Email: <?php echo e($branch->email); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->landline_number)): ?>
                                    <option value="1">Landline: <?php echo e($branch->landline_number); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->mobile_number)): ?>
                                    <option value="2">Mobile: <?php echo e($branch->mobile_number); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch->id); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <!---------------------------------desktop screen-------------->
                <div class="col-md-3 d-none d-lg-block d-md-block selection-area">
                    <div class="col-lg-12 px-3 boxes" style="height: 580px;">
                        <!-- Display nearest branches -->
                        <?php if(!empty($nearestBranches)): ?>
                        <?php $__currentLoopData = $nearestBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <h3 class="fw-bold branch-name"><?php echo e($branch['name']); ?>, <span class="distance_color"><?php echo e(number_format($branch['distance'], 2)); ?> miles</span></h3>
                            <p class="address-town-post-code"><?php echo e($branch['address_line_1']); ?>, <?php echo e($branch['address_line_2'] ?: ''); ?>, <?php echo e($branch['town_city']); ?>, <?php echo e($branch['post_code']); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch['email'])): ?>
                                    <option value="1" selected>Email: <?php echo e($branch['email']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['landline_number'])): ?>
                                    <option value="2">Landline: <?php echo e($branch['landline_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['mobile_number'])): ?>
                                    <option value="3">Mobile: <?php echo e($branch['mobile_number']); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch['id']); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(!empty($branches)): ?>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <h3 class="fw-bold branch-name"><?php echo e($branch->name); ?></h3>
                            <p class="address-town-post-code"><?php echo e($branch->address_line_1); ?>, <?php echo e($branch->address_line_2
                                ?: ''); ?>, <?php echo e($branch->town_city); ?>, <?php echo e($branch->post_code); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch->email)): ?>
                                    <option value="1" selected>Email: <?php echo e($branch->email); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->landline_number)): ?>
                                    <option value="2">Landline: <?php echo e($branch->landline_number); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->mobile_number)): ?>
                                    <option value="3">Mobile: <?php echo e($branch->mobile_number); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch->id); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

            </section>
<!-- Step 2: Display Selected Branch Details -->
<legend class="mb-3">
    <h2 class="branch-details-title display-5 text-danger text-center" >Your Selected Branch Address</h2>
</legend>

<!-- Display Branch Details -->
    <?php if($selectedBranch): ?>
    <div class="container overflow-hidden">
<div class="row shadow-lg gy-5 ">
    <!-- Left Column for Branch Details and Image -->
    <div class="col-md-6 mt-5 border border-1 shadow-lg ">
        <h3 class="branch-name display-6 text-danger" ><?php echo e($selectedBranch->name); ?></h3>
        <p class="branch-address lead">
            <?php echo e($selectedBranch->address_line_1); ?>, <?php echo e($selectedBranch->address_line_2 ?: ''); ?>, <?php echo e($selectedBranch->town_city); ?>, <?php echo e($selectedBranch->post_code); ?>, UK
        </p>
        <p class="branch-description"><?php echo e($selectedBranch->description); ?></p>
        <p class="branch-contact">
            <?php if($selectedBranch->email): ?>
            <p><span style="font-size:1em; font-weight:bold;">Email: </span><br><?php echo e($selectedBranch->email); ?></p>
            <?php endif; ?>
            <?php if($selectedBranch->landline_number): ?>
            <p><span style="font-size:1em; font-weight:bold; margin-top:0;">Landline:</span><br> <?php echo e($selectedBranch->landline_number); ?></p>
            <?php endif; ?>
            <?php if($selectedBranch->mobile_number): ?>
            <p><span style="font-size:1em; font-weight:bold; margin-top:0;">Mobile:</span><br><?php echo e($selectedBranch->mobile_number); ?></p>
            <?php endif; ?>
        </p>

        <?php if($selectedBranch->image): ?>
        <div class="branch-image mb-3 " style="height: 800%;"   >
            <img src="<?php echo e($selectedBranch->image); ?>" class="img-fluid h-75" style="width: 100%;" alt="Branch Image"/>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Right Column for Map -->
    <div class="col-md-6 mt-5 border border-1 shadow-lg gy-5" >
        <?php if($selectedBranch->map_link): ?>
        <div class="branch-map mb-3 h-75 w-50" style="width: 100%;">
            <?php echo $selectedBranch->map_link; ?>

        </div>
        <?php endif; ?>
    </div>
</div>
</div>
<?php else: ?>
<p>No branch selected.</p>
<?php endif; ?>




            <!-- Submit button  desktop-->
            <div class="d-none d-lg-block d-md-block">
                <div class="btn-style ">

                    <button class="button-20 " role="button" type="submit" x-show="step === 1">Next</button>

                    <button class="button-20" role="button" type="button" @click="step = 0" x-show="step === 1"  wire:click="goBack">Go
                        Back</button>
                </div>
            </div>
            <!--------------------phone screen-------------->
            <div class=" d-lg-none d-md-none " style="margin-top:-20%">
                <div class="btn-style ">

                    <button class="button-20" style="margin-right:-23%" role="button" type="submit"
                        x-show="step === 1">Next</button>

                    <button class="button-20" style="margin-left:-20%; role="button" type="button"
             @click="step = 0" x-show="step === 1"  wire:click="goBack">GoBack</button>
                </div>
            </div>

    </div>
    </form>
</div>
<!--my media query-->
<style>
<!--branch details media query-->
  <!--.branch-name {-->
  <!--  color: red;-->
  <!--  font-weight: bold;-->
  <!--  margin-top: 100px;-->
  <!--  font-size: 45px;-->
  <!--}-->

  <!--.branch-address,-->
  <!--.branch-description,-->
  <!--.branch-contact {-->
  <!--  font-size: 1em;-->
  <!--}-->



  /* Tablet styles */
  @media only screen and (max-width: 768px) {
    .branch-name {
      font-size: 60px;
      margin-top: 50px;
    }

    .branch-address,
    .branch-description,
    .branch-contact {
      font-size: 0.95em;
    }

    .col-md-6 {
      width: 100%;
    }
  }
  
    /* mobile425 styles */
  @media only screen and (max-width: 425px) {
      .branch-name {
      font-size: 50px;
      margin-top: 25px;
    }

    .branch-address,
    .branch-description,
    .branch-contact {
      font-size: 50px;
    }
    <!--.col-md-6 {-->
    <!--  width: 50%;-->
    <!--}-->
  }
  
    /* mobile320 styles */
  @media only screen and (max-width: 320px) {
    .branch-name {
      font-size: 40px;
      margin-top: 20px;
    }

    .branch-address,
    .branch-description,
    .branch-contact {
      font-size: 40px;
    }

    <!--.col-md-6 {-->
    <!--  width: 100%;-->
    <!--}-->
  }

<!--image media query-->
<!--.branch-image {-->
<!--    width: 100%;-->
<!--    max-width: 480px;-->
<!--}-->

<!--.branch-image img {-->
<!--    width: 100%;-->
<!--    height: auto;-->
<!--}-->
/* Tablet styles */
@media only screen and (max-width: 768px) {
    .branch-image {
        max-width: 100%;
    }

    .branch-image img {
        height: 150px; /* Adjust height for medium screens */
    }
}

/* mobile425 styles */
@media only screen and (max-width: 425px) {
    .branch-image {
        max-width: 100%;
    }

    .branch-image img {
        height: 120px; 
    }
}
/* mobile320 styles */
@media only screen and (max-width: 320px) {
    .branch-image {
        max-width: 100%;
    }

    .branch-image img {
        height: 100px; /* Adjust height for extra small screens */
    }
}
<!--map media query-->
<!--.col-md-6 {-->
<!--            margin-top: 87px;-->
<!--            width: 50%; /* Default for medium screens and up */-->
<!--        }-->

<!--        .branch-map {-->
<!--            width: 100%;-->
<!--        }-->
/* Tablet styles */
        @media only screen and (max-width: 768px) {
            .branch-map  {
                width: 30px;
                margin-top: 10px; 
            }
        }
        /* mobile425 styles */
                @media only screen and (max-width: 425px) {
            .branch-map  {
                width: 60px; 
                margin-top: 10px; 
            }
        }
        /* mobile320 styles */
                @media only screen and (max-width: 320px) {
            .branch-map  {
                width: 40px; 
                margin-top: 5px; 
            }
        }
</style>

<style>
    .submit-form {
        position: relative;
    }

    .button-20 {
        appearance: button;
        /*width: 11%;*/
        background-color: #dc3545;
        background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
        border: 1px solid #dc3545;
        border-radius: 1rem;
        box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px;
        box-sizing: border-box;
        color: #FFFFFF;
        cursor: pointer;
        display: inline-block;
        font-family: Inter, sans-serif;
        font-size: 1rem;
        font-weight: 500;
        line-height: 1.7;
        margin: 0;
        padding: 6px 50px;
        text-align: center;
        text-transform: none;
        transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
        vertical-align: middle;
    }

    .button-20:focus:not(:focus-visible),
    .button-20:focus {
        outline: 0;
    }

    .button-20:hover {
        background-color: #dc3545;
        border-color: #dc3545;
    }

    .button-20:focus {
        background-color: #dc3545;
        border-color: #dc3545;
        box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
    }

    .button-20:active {
        background-color: #dc3545;
        background-image: none;
        border-color: #dc3545;
        box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
    }

    .button-20:active:focus {
        box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
    }

    .button-20:disabled {
        background-image: none;
        box-shadow: none;
        opacity: .65;
        pointer-events: none;
    }

    .calendar-container {
        border: 1px solid #dee2e6;
        border-radius: 10px;
        box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
        padding: 1rem;
        width: max-content;
    }

    .calendar-table {
        margin-bottom: 1rem;
    }

    .calendar-table th,
    .calendar-table td {
        text-align: center;
        vertical-align: middle;
        padding: 0.5rem;
    }

    .calendar-table td {
        cursor: pointer;
    }

    .calendar-table td.today {
        background-color: #f8f9fa;
    }

    .calendar-table td.selected {
        background-color: #dc3545;
        color: white;
    }

    .calendar-table td.disabled {
        color: #dee2e6;
        cursor: not-allowed;
    }

    .time-slots-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 10px;
    }

    .time-slot-btn {
        padding: 10px;
        text-align: center;
    }

    .time-slot-btn.active {
        background-color: #dc3545;
        color: white;
        border-color: #dc3545;
    }

    .selected-datetime {
        font-weight: bold;
    }

    .search {
        width: 70px;
    }

    .map-setting {
        background-color: #fff;
        border-radius: 15px;
        box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);
        padding: 17px 14px 14px;
    }

    .fpostcode-map {
        width: 40%;
        background-color: #fff;
        border-radius: 15px;
        /*box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);*/
        /*padding: 17px 14px 14px 14px;*/
    }

    .input-group {
        display: flex;
        gap: 20px;
    }

    .form-select-btn {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .distance_color {
        color: #dc3545;
    }

    .search_input {
        border-radius: 20px;
        border-top-right-radius: 20px !important;
        border-bottom-right-radius: 20px !important;
        /*box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;*/
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
    }

    .search-btn {
        border-radius: 20px;
        border-top-left-radius: 20px !important;
        border-bottom-left-radius: 20px !important;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

    }

    .address-town-post-code {
        padding-bottom: 6px;
    }

    .boxes {
        width: 700px;
        margin-top: 25px;
        height: 920px;
        overflow-y: scroll;
        /*scrollbar-color: rgb(233, 163, 163) transparent;*/
        scroll-behavior: smooth;
        /*scroll-padding: 50px;*/
    }

    .boxes div {
        border-radius: 20px;
    }

    .boxes div:nth-child(1) {
        margin-top: 0px !important;
    }

    .boxes::-webkit-scrollbar {
        width: 20px;
        height: 100px;
    }

    .btn-style {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-direction: row-reverse;
        margin-top: 50px;
    }

    .boxes::-webkit-scrollbar-track {
        background: #d1d1d1;
        border-radius: 40px;
    }

    .boxes::-webkit-scrollbar-thumb {
        background-color: #dc3545;
        border-radius: 40px;
        border: 3px solid transparent;
    }

    .find {
        color: rgb(240, 88, 88);
        font-size: 44px;
        font-weight: 900;
        text-align: center;
    }

    .search-btn {
        background-color: #da3847;
        color: white;
    }

    .s-card {
        height: 120px;
    }

    .left-side {
        width: 30%;
    }

    @media (max-width: 576px) {

        h2.find,
        p.text-center {
            margin-left: -20px;
            font-size: 15px;
        }

        .input-group {
            flex-wrap: wrap;
        }

        .input-group .form-control {
            flex: 1 1 100%;
            width: 100%;
            margin-right: 0;
            margin-bottom: 10px;
        }

        .input-group .search-btn {
            flex: 1 1 100%;
            width: 100%;
        }

        /* width: 133%;
        height: 850px;
        border: 0; */
    }

    .slot-container {
        justify-content: center;
    }

    /*///////////// Slot Responsive /////////////*/
    @media (max-width: 1400px) {
        .left-side {
            width: 35%;
        }
    }

    @media (max-width: 1400px) {
        .left-side {
            width: 40%;
        }
    }

    @media (max-width: 1024px) {
        .map-select {
            flex-direction: column;
        }

        .fpostcode-map {
            width: 100%;
        }

        .selection-area {
            width: 100%;
        }

        .boxes {
            width: 100%;
        }
    }

    @media (max-width: 900px) {
        .slot-container {
            flex-direction: column;
        }

        .select-slot-div {
            width: 100%;
        }

        .left-side {
            width: 100%;
        }

    }

    /*///////////// Slot Responsive /////////////*/
    /*-------------------------------------phone reponsive--- start-----------------*/
    @media (max-width: 320px) {

        .col-md-6 {
            flex: 0 0 auto;
            width: 300% !important;
        }
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        flatpickr("#appointment_date", {
            dateFormat: "Y-m-d",
            minDate: "today"
        });
    });
</script>


</div>

<?php endif; ?> 
    </div>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/guest/components/postal-repair-form.blade.php ENDPATH**/ ?>
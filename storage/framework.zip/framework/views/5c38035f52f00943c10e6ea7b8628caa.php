<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Repair Service Page</title>
    <!-- Include necessary CSS and JS files here -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>

<body>

    <!-- Top Bar Component -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l3790216916-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3790216916-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3790216916-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3790216916-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3790216916-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Mega Navigation Component with white theme -->
    <section class="bg-pink-linear">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white'])->html();
} elseif ($_instance->childHasBeenRendered('l3790216916-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3790216916-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3790216916-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3790216916-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white']);
    $html = $response->html();
    $_instance->logRenderedChild('l3790216916-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Introduction Section -->
        <div class="container">
            <div class="text-center my-4 p-3 rounded-3" style="background-color: #afafaf">
                <h2><?php echo e($data['repair_type']->name); ?> on your <br>
                    <span class="text-danger"><?php echo e($data['modal']->name); ?>?</span>
                </h2>
                <span class="tagline"><?php echo $webContent->repair_page5_heading1; ?></span>
            </div>
        </div>
    </section>
    
    <!-- Main Content Section -->
    <div class="container">
        <!-- Pre-Repair Checklist and Service Information -->
        <section id="repair-info-section">
            <div class="my-5 p-3">
                <div class="row text-center">
                    <!-- Checklist Column -->
                    <div class="col-lg-4 text-start">
                        <h3>Pre-Repair Checklist</h3>
                        <p>(Stuff to know before your repair)</p>
                        <h4><b class="text-danger">&#10003; How long?</b> <?php echo e($data['repair_type']->duration ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger">&#10003; Part Used?</b> <?php echo e($data['repair_type']->part_used ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger">&#10003; Warranty?</b> <?php echo e($data['repair_type']->warranty ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger">&#10003; Will my data be lost?</b>
                            <?php echo e($data['repair_type']->data_loss ?? ''); ?></h4>
                        <h4><b class="text-danger">&#10003; Post Repair Advice?</b> <?php echo $data['repair_type']->advice ??
                            ''; ?></h4>
                        <h4><b class="text-danger">&#10003; What if you can’t fix my device?</b> <?php echo $data['repair_type']->no_fix_no_fee ?? ''; ?></h4>
                    </div>

                    <!-- Device Image Column -->
                    <div class="col-lg-4 mt-5">
                        <img src="<?php echo e(asset($data['modal']->file) ?? 'https://ik.imagekit.io/qml3d7tgz/iphone1_9JHn-8RLU.jpg'); ?>"
                            style="height:400px; width:281px" />
                    </div>

                    <!-- Service Explanation Column -->
                    <div class="col-lg-4 mt-5">
                        <p class="text-start">At The <?php echo e($siteSettings->buisness_name ?? ''); ?> we strive to provide
                            top-notch mobile repair services, offering four convenient repair options: in-store repair,
                            post your device, collect and return device, and fix at my address. For all repair types,
                            except in-store repair, online payment is required to ensure a smooth and secure transaction
                            process.

                            Our commitment to transparency and your satisfaction is paramount. As part of our Terms of
                            Service and Conditions, we specify the repair time and the parts used for your device, and
                            outline the conditions related to data loss and provide repair advice. In the rare event
                            that we can't fix your device, rest assured that we have a clear response in place to
                            address this situation.

                            For in-store repair, we offer the flexibility of payment methods, allowing you to choose
                            between paying in-store or online, catering to your preferences. Your trust in "The Phone
                            Lab" is greatly valued, and we look forward to providing you with efficient and reliable
                            mobile repair services.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Form Section Part 1 (Initial Hidden) -->
        <section id="form-section-1" class="bg-gray" style="display:none;">
            <div>
                <div class="row">
                    <!-- Patient Detail Form Column -->
                    <div class="col-12 col-lg-5 col-md-5 bg-pink-linear rounded p-4">
                        <div style="font-style:italic; max-width: 350px;">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Form Section Part 2 (Initial Hidden) -->
        <section id="form-section-2" class="bg-gray" style="display:none;">
            <div class="container">
                <div class="row">
                    <!-- Form Toggle Column -->
                    <div class="col-lg-6">
                        <div class="bg-pink-linear rounded p-4">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                            width="100%" height="550" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php $__env->startPush('scripts'); ?>
                        <script>
                            document.addEventListener('livewire:load', function () {
                                const postalCodeInput = document.getElementById("postalCode");
                                const mapIframe = document.getElementById("mapIframe");

                                postalCodeInput.addEventListener('change', function () {
                                    getLatLong();
                                });

                                async function getLatLong() {
                                    const postalCode = postalCodeInput.value;

                                    try {
                                        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                                        const data = await response.json();

                                        if (data.length > 0) {
                                            const result = data[0];
                                            const latitude = result.lat;
                                            const longitude = result.lon;

                                            // Update the iframe src with the new latitude and longitude
                                            mapIframe.src = `https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d${longitude}!3d${latitude}!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus`;
                                        } else {
                                            // Handle case when no results are found
                                            console.log("No results found for the provided postal code.");
                                        }
                                    } catch (error) {
                                        console.error("Error fetching data:", error);
                                    }
                                }

                                // Initial call to getLatLong function
                                getLatLong();
                            });
                        </script>
                        <?php $__env->stopPush(); ?>

                    </div>
                </div>
            </div>
        </section>



        <!-- Book Repair Component (Initial Hidden) -->
        <section id="book-repair-section" style="display:none;">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </section>

        <!-- Next Button -->
        <div class="text-center my-5">
            <button id="next-button" class="btn btn-danger">next</button>
        </div>
    </div>

    <!-- JavaScript to Handle the Next Button Click and Load Content -->

    <!-- Main Content Section -->
    
 




    <!-- JavaScript to Handle the Next Button Click and Load Content -->
    <script>
        let currentStep = 0;
        const steps = [
            'repair-info-section',
            'form-section-2',
            'form-section-1',
            'book-repair-section'
        ];

        document.getElementById('next-button').addEventListener('click', function () {
            if (currentStep < steps.length) {
                document.getElementById(steps[currentStep]).style.display = 'block';
                if (currentStep > 0) {
                    document.getElementById(steps[currentStep - 1]).style.display = 'none';
                }
                currentStep++;
            }
        });

    </script>

    <!-- Include necessary JavaScript files here -->
</body>

</html><?php /**PATH /Users/mubashir/Downloads/vscode/resources/views/livewire/guest/repair-detail.blade.php ENDPATH**/ ?>
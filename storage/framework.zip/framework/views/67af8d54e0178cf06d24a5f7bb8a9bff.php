<!DOCTYPE html>
<html lang="en">

<head>

    <?php echo $__env->make('frontend.sections.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TQHMKBMJ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    
    
    
    
    <?php echo $__env->yieldContent('content'); ?>
    <?php if(isset($slot)): ?>
    <?php echo e($slot); ?>

    <?php endif; ?>

    <?php echo $__env->make('frontend.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>



<?php echo $__env->make('frontend.sections.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH /Users/mubashir/Documents/vscode (2)/resources/views/frontend/layouts/app.blade.php ENDPATH**/ ?>
 <div id="content" style="width:100%">
     <?php echo e($slot); ?>

 </div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/components/content.blade.php ENDPATH**/ ?>
<div>
    <div class="d-flex flex-column gap-3">
        <div>
            <input placeholder="Enter name" type="text" required wire:model.debounce.500="device.name" /><br>
            <?php $__errorArgs = ['device.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-xs text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <input type="file" accept="*" wire:model="file" id=<?php echo e($rand); ?> /><br>
            <span wire:loading wire:target="file">loading...</span>
        </div>

    </div>
    <div class="float-end mt-3 ">
        <button type="button" class="bg-blue text-white" wire:click="update">
            Save Changes
            <span wire:loading wire:target='update'>
                <?php if (isset($component)) { $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0 = $attributes; } ?>
<?php $component = App\View\Components\Spinner::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Spinner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0)): ?>
<?php $attributes = $__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0; ?>
<?php unset($__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0)): ?>
<?php $component = $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0; ?>
<?php unset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0); ?>
<?php endif; ?>
            </span>
        </button>
    </div>
</div>
<?php /**PATH /Users/mubashir/Documents/scode/resources/views/livewire/admin/buy/device/edit.blade.php ENDPATH**/ ?>
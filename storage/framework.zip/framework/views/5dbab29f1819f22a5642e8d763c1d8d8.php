
<div  style="    background-color: #ffffff;
    border-radius: 10px;
    width: 100%;
    margin: 0 auto;
    padding: 20px;" wire:submit.prevent="submitForm" >

    <?php if(Session::get('serviceType') == 'Buy'): ?>

        <h5 class="fw-bold mt-3 mb-3">Please post your device to this address</h5>


        <div class="p-10">
            <div class="form-group">
                <label for="post_code">Post Code:</label>
                <input type="text" wire:model="post_code" class="form-control" id="post_code"
                    placeholder="Enter Post Code">
                <div id="resultContainer">
                    <p><?php echo e($addressName); ?></p>
                </div>
                <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button wire:click.prevent="changeApiData" class="mb-2">Search</button>
            <?php if($responseData): ?>


                
                <select wire:model="selectedOption" class="form-select" wire:change.prevent="updateAddressFields">
                    <option value="" selected>Select an option</option>
                    <?php $__currentLoopData = $responseData['knownAddresses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option key="<?php echo e($key); ?>" value="<?php echo e($address); ?>"><?php echo e($address); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>


                <!-- Display the error message if set -->
                <?php if($errorMessage): ?>
                    <div class="text-danger"><?php echo e($errorMessage); ?></div>
                <?php endif; ?>

            <?php endif; ?>


            <?php if($responseData): ?>
                <button class=" text-danger bg-white border-radius rounded-pill mt-3"
                    wire:click.prevent="toggleInputFields">I can't find my address..</button>

                <!-- Conditional rendering for input fields -->
                <?php if($showInputFields): ?>
                    <div class="mb-3 mt-3">
                        <label for="address_line_1">Address Line 1*:</label>
                        <input type="text" class="form-control form-control-sm"
                            wire:model.lazy="postal.address_line_1" placeholder="Address Line 1"
                            name="postal.address_line_1" required="">
                        <?php $__errorArgs = ['postal.address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3 mt-3">
                        <label for="address_line_2">Address Line 2:</label>
                        <input type="text" class="form-control form-control-sm"
                            wire:model.lazy="postal.address_line_2" placeholder="Address Line 2"
                            name="postal.address_line_2">
                    </div>

                    <div class="mb-3 mt-3">
                        <label for="city">Town/City*:</label>
                        <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.city"
                            placeholder="Town/City" name="postal.city" required="">
                        <?php $__errorArgs = ['postal.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>




                    <div class="mb-3 mt-3">
                        <label for="postal_code">Post Code*:</label>
                        <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.code"
                            placeholder="Post Code" name="postal.code" required="">
                        <?php $__errorArgs = ['postal.code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>


        <!-- Include this script in your Livewire component or wherever necessary -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Listen for the Livewire event indicating data update
                Livewire.on('addressFieldsUpdated', function() {
                    // Find the relevant input fields by name attribute
                    var address1 = document.querySelector("input[name='postal.address_line_1']");
                    var address2 = document.querySelector("input[name='postal.address_line_2']");
                    var city = document.querySelector("input[name='postal.city']");
                    var postalCode = document.querySelector("input[name='postal.code']");

                    // Append five dots to each field if they exist
                    if (address1) {
                        address1.value += '.....';
                        // Trigger input event to simulate user interaction
                        var event = new Event('input', {
                            bubbles: true
                        });
                        address1.dispatchEvent(event);
                    }

                    if (address2) {
                        address2.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        address2.dispatchEvent(event);
                    }

                    if (city) {
                        city.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        city.dispatchEvent(event);
                    }

                    if (postalCode) {
                        postalCode.value += '.....';
                        var event = new Event('input', {
                            bubbles: true
                        });
                        postalCode.dispatchEvent(event);
                    }
                });
            });
        </script>



    <?php endif; ?>
    <?php if($mainBranch): ?>
        <p>&#128205:<?php echo e($siteBranch->name); ?> , <?php echo e($siteBranch->address_line_1); ?> , <?php echo e($siteBranch->address_line_2); ?>

            <?php echo e($siteBranch->address_line_2 != '' ? ', ' : ''); ?> <?php echo e($siteBranch->town_city); ?> ,
            <?php echo e($siteBranch->post_code); ?>,UK
        </p>
        <p>&#128235: <?php echo e($siteBranch->email); ?></p>
        <p>&#9742: <?php echo e($siteBranch->landline_number); ?> </p>
        <p>&#128222: <?php echo e($siteBranch->mobile_number); ?></p>
    <?php else: ?>
        <?php if(Session::get('serviceType') !== 'Buy'): ?>

            <div class="mb-3 mt-3">
                <legend for="postalCode">
                    <h4 class="fw-bold">Find a Store</h4>
                </legend>
                <div class="input-group mb-3">
                    <input type="text" id="postalCode" required class="form-control" placeholder="Enter Postal Code">
                    <button class="btn btn-outline-danger bg-danger text-white" type="button" id="button-addon2"
                        onclick="getLatLong()">Search</button>
                </div>
                <div id="resultContainer"></div>

                <?php $__env->startPush('scripts'); ?>
                    <script>
                        document.addEventListener('livewire:load', function() {
                            const resultContainer = document.getElementById("resultContainer");

                            Livewire.on('getLatLong', function() {
                                // Call the JavaScript function when the Livewire event is triggered

                                getLatLong();
                            });
                            async function getLatLong() {
                                const postalCode = document.getElementById("postalCode").value;

                                try {
                                    const response = await fetch(
                                        `https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                                    const data = await response.json();

                                    if (data.length > 0) {
                                        const result = data[0];
                                        resultContainer.innerHTML = `<p>${result.display_name}</p>`;

                                        Livewire.emit('updateLocation', {
                                            latitude: result.lat,
                                            longitude: result.lon
                                        });
                                    } else {
                                        resultContainer.innerHTML = "<p>No results found for the provided postal code.</p>";
                                    }
                                } catch (error) {
                                    console.error("Error fetching data:", error);
                                }
                            }

                            // Add Livewire listener for location update
                            Livewire.on('updateLocation', (location) => {
                                // Handle location update if needed
                                console.log('Received location update:', location);
                            });

                            // Your existing function call
                            window.getLatLong = getLatLong;
                        });
                    </script>
                <?php $__env->stopPush(); ?>
                <?php if($nearestBranches): ?>

                    <label for="email" class="mt-3 text-danger">
                        <h2>CHOOSE YOUR NEAREST STORE</h2>
                    </label>
                    <select class="form-control form-select form-control-sm" wire:model.lazy="postal.name">
                        <option>Select Store</option>

                        <?php $__empty_1 = true; $__currentLoopData = $nearestBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($branch['branch']['name']); ?>"><?php echo e($branch['branch']['name']); ?>, Distance:
                                <?php echo e(number_format($branch['distance'], 2) != 0.0 ? number_format($branch['distance'], 2) : 0); ?>

                                Mile</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <option value="">Sorry we can not find</option>
                        <?php endif; ?>
                    </select>
                <?php else: ?>
                    <label for="email" class="text-danger mt-3">
                        <h3>CHOOSE YOUR NEAREST STORE</h3>
                    </label>
                    <select class="form-control form-select form-control-sm" wire:model.lazy="postal.name">
                        <option>Select Store</option>

                        <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($branch['name']); ?>"><?php echo e($branch['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <option value="">Sorry we can not find</option>
                        <?php endif; ?>
                    </select>

                <?php endif; ?>
                <?php $__errorArgs = ['postal.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
        <?php endif; ?>


        <?php if($postal['name']): ?>

            <?php if(Session::get('serviceType') !== 'Buy'): ?>
                <div class="my-3">
                    <label> Selected Store by you in previous session </label>
                    <h3 class="text-success ms-3 fw-bold"><?php echo e($postal['name']); ?></h3>



                    <p>&#128205:<?php echo e($selectedBranch->name); ?> , <?php echo e($selectedBranch->address_line_1); ?> ,
                        <?php echo e($selectedBranch->address_line_2); ?> <?php echo e($selectedBranch->address_line_2 != '' ? ', ' : ''); ?>

                        <?php echo e($selectedBranch->town_city); ?> , <?php echo e($selectedBranch->post_code); ?>,UK</p>
                    <p>&#128235: <?php echo e($selectedBranch->email); ?></p>
                    <p>&#9742: <?php echo e($selectedBranch->landline_number); ?> </p>
                    <p>&#128222: <?php echo e($selectedBranch->mobile_number); ?></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(Session::get('serviceType') !== 'Sell' && Session::get('serviceType') !== 'Buy'): ?>
        <div class="mb-3 mt-3">
            <label for="email">Address Line 1*:</label>
            <input type="text" class="form-control form-control-sm" id="name"
                wire:model.lazy="postal.address_line_1" placeholder="Address Line 1" name="postal.address_line_1"
                required="">
            <?php $__errorArgs = ['postal.address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endif; ?>
</div>

<?php if(Session::get('serviceType') !== 'Sell' && Session::get('serviceType') !== 'Buy'): ?>
    <div class="mb-3 mt-3">
        <label for="email">Address Line 2:</label>
        <input type="text" class="form-control form-control-sm" wire:model.lazy="postal.address_line_2"
            id="name" placeholder="Address Line 2" name="postal.address_line_2">
    </div>
<?php endif; ?>
<?php if(Session::get('serviceType') !== 'Sell' && Session::get('serviceType') !== 'Buy'): ?>
    <div class="mb-3 mt-3">
        <label for="email">Town/City*:</label>
        <input type="text" class="form-control form-control-sm" id="name" wire:model.lazy="postal.city"
            placeholder="Town/City" name="postal.city" required="">
        <?php $__errorArgs = ['postal.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<?php endif; ?>

<?php if(Session::get('serviceType') !== 'Sell' && Session::get('serviceType') !== 'Buy'): ?>
    <div class="mb-3 mt-3 ">
        <label for="email">Post Code*:</label>
        <input type="text" class="form-control form-control-sm" id="name" wire:model.lazy="postal.code"
            placeholder="Post Code" name="postal.code" required="">
        <?php $__errorArgs = ['postal.code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<?php endif; ?>


<?php if(Session::get('serviceType') == 'Sell' && Session::get('serviceType') == 'Buy'): ?>
    <label for="exampleFormControlTextarea1" class="form-label">Write Notes</label>
    <textarea class="form-control" rows="3" placeholder="Please write any comment...">
                  </textarea>
<?php endif; ?>
<?php if(Session::get('serviceType') !== 'Sell' && Session::get('serviceType') !== 'Buy'): ?>
    <div class="mb-2">
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Write Notes</label>
            <textarea class="form-control" id="postal.repair_note" wire:model="postal.repair_note" rows="3"
                name="postal.repair_note" placeholder="Please write any comment...">
                  </textarea>
            <?php $__errorArgs = ['postal.repair_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
<?php endif; ?>
</div>
 <div class="container-fluid ">
    <div class="row">
        <div class="col d-flex justify-content-end">
            <button type="submit" wire:click.prevent="submitForm" class="btn p-0 border-0" style="background: none;">
                <!--<img id="next-button" src="https://ik.imagekit.io/li8bg5tjv3/1.png?updatedAt=1715028228699" style="width: 150px; height: auto;" />-->
                <button type="submit" class="btn btn-danger customer-btn" style="margin-top: 20px; padding: 10px 4px; width: 10%; border-radius: 15px;">Next</button>
            </button>
        </div>
    </div>
</div>

 
</div>
<?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/livewire/guest/components/postal-repair-form.blade.php ENDPATH**/ ?>
<div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://kit.fontawesome.com/09d3c3a997.js" crossorigin="anonymous"></script>

    <!-- Top Bar Component -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l2703685819-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2703685819-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2703685819-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2703685819-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2703685819-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Mega Navigation Component with white theme -->
    <section class="bg-pink-linear">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white'])->html();
} elseif ($_instance->childHasBeenRendered('l2703685819-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2703685819-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2703685819-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2703685819-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white']);
    $html = $response->html();
    $_instance->logRenderedChild('l2703685819-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Introduction Section -->
        <div class="container">
            <div class="text-center my-4 p-3 rounded-3">
                <h2><?php echo e($data['repair_type']->name); ?> on your <br>
                    <span class="text-danger"><?php echo e($data['modal']->name); ?></span>
                </h2>
                <span class="tagline"><?php echo $webContent->repair_page5_heading1; ?></span>
            </div>
        </div>
    </section>

    <!-- Main Content Section -->
    <div x-data="{ 
        currentStep: 0, 
        steps: ['repair-info-section', 'form-section-2', 'form-section-1', 'book-repair-section'],
        formCompleted: [true, true, false, false] // Initialize with `true` for intro section
    }">
        <div class="container">
            <!-- Pre-Repair Checklist and Service Information -->
            <section id="repair-info-section" x-show="currentStep === 0">
                <div class="my-5 p-3">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="my-4 p-3 rounded-3">
                                <h2><span class="text-danger"><?php echo e($data['modal']->name); ?> Repairs </span></h2>
                                <p><span class="text-danger">What if you can't fix my device?</span> No charge if we
                                    can't repair your device. <br>We'll provide details on the issue and offer
                                    alternatives, <br> including returning your device as is.</p>
                                <h1 class="text-danger"><?php echo e($data['modal']->name); ?> <br> <?php echo e($data['repair_type']->name); ?>

                                </h1>
                            </div>
                        </div>
                        <!-- Checklist Column -->
                        <div class="col-lg-4 text-start">
                            <h3 class="text-danger"><?php echo e($data['modal']->name); ?> <?php echo e($data['repair_type']->name); ?></h3>
                            <div><br></div>
                            <h4><b class="text-danger">&#10003; How long?</b> <?php echo e($data['repair_type']->duration ?? ''); ?>

                            </h4>
                            <h4><b class="text-danger">&#10003; Part Used?</b>
                                <?php echo e($data['repair_type']->part_used ?? ''); ?>

                            </h4>
                            <h4><b class="text-danger">&#10003; Warranty?</b> <?php echo e($data['repair_type']->warranty ?? ''); ?>

                            </h4>
                            <h4><b class="text-danger">&#10003; Will my data be lost?</b>
                                <?php echo e($data['repair_type']->data_loss ?? ''); ?></h4>
                            <h4><b class="text-danger">&#10003; Post Repair Advice?</b> <?php echo $data['repair_type']->advice ??
    ''; ?></h4>
                            <h4><b class="text-danger">&#10003; What if you can’t fix my device?</b> <?php echo $data['repair_type']->no_fix_no_fee ?? ''; ?></h4>
                        </div>

                        <!-- Device Image Column -->
                        <div class="col-lg-2 mt-5">
                            <img src="<?php echo e(asset($data['modal']->file) ?? 'https://ik.imagekit.io/qml3d7tgz/iphone1_9JHn-8RLU.jpg'); ?>"
                                style="height:400px; width:281px" />
                        </div>

                        <!-- Service Explanation Column -->
                    </div>
                </div>
            </section>

            <!-- Form Section Part 1 (Initial Hidden) -->
            <section id="form-section-1" x-show="currentStep === 2" style="display:none;">
                <div>
                    <div class="row justify-content-center">
                        <!-- Patient Detail Form Column -->
                        <div class="col-12 col-lg-12  rounded p-4">
                            <div>
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', ['@formValidated' => 'formCompleted[currentStep] = $event'])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', ['@formValidated' => 'formCompleted[currentStep] = $event']);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Form Section Part 2 (Initial Hidden) -->
            <section id="form-section-2" class="bg-white" x-show="currentStep === 1" style="display:none;">
                <div class="container">
                    <div class="row">
                        <!-- Form Toggle Column -->
                        <div class="col-lg-12">
                            <div class="bg-pink-linear rounded p-4">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Book Repair Component (Initial Hidden) -->
            <section id="book-repair-section" x-show="currentStep === 3" style="display:none;">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data,'@formValidated' => 'formCompleted[currentStep] = $event'])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data,'@formValidated' => 'formCompleted[currentStep] = $event']);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </section>

            <!-- Back and Next Buttons -->
            <div class="container-fluid mt-4">
                <div class="row justify-content-between">
                    <div class="col-auto">
                        <button x-show="currentStep > 0" @click="currentStep--" class="btn btn-danger m-5">Back</button>
                    </div>
                    <div class="col-auto">
                        <button x-show="currentStep < steps.length - 1" @click="currentStep++"
                            :disabled="currentStep === 0 ? false : !formCompleted[currentStep]"
                            class="btn btn-danger m-5">
                            Next
                        </button>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- JavaScript to Handle Livewire and Alpine.js Integration -->
    <script>
        document.addEventListener('livewire:load', function () {
            Livewire.on('formShown', function () {
                // Hide the grid container when a form is shown
                document.querySelector('.grid-container').style.display = 'none';
            });
        });
        
    </script>
</div><?php /**PATH /Users/mubashir/Documents/vscode/resources/views/livewire/guest/repair-detail.blade.php ENDPATH**/ ?>
<div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://kit.fontawesome.com/09d3c3a997.js" crossorigin="anonymous"></script>

    <!-- Top Bar Component -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l1700223798-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1700223798-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1700223798-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1700223798-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1700223798-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Mega Navigation Component with white theme -->
    <section class="bg-pink-linear">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white'])->html();
} elseif ($_instance->childHasBeenRendered('l1700223798-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1700223798-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1700223798-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1700223798-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white']);
    $html = $response->html();
    $_instance->logRenderedChild('l1700223798-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Introduction Section -->
        <div class="container">
            <div class="text-center my-4 p-3 rounded-3">
                <h2><?php echo e($data['repair_type']['name']); ?> on your <br>
                    <span class="text-danger"><?php echo e($data['modal']['name']); ?></span>
                </h2>
                <span class="tagline"><?php echo $webContent->repair_page5_heading1; ?></span>
            </div>
        </div>
    </section>

    <!-- Main Content Section -->
    <div class="container" id="multi-step-form">
        <!-- Pre-Repair Checklist and Service Information -->
        <section id="repair-info-section" class="form-step">
            <div class="my-5 p-3">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="my-4 p-3 rounded-3">
                            <h2><span class="text-danger"><?php echo e($data['modal']['name']); ?> Repairs </span></h2>
                            <p><span class="text-danger">What if you can't fix my device?</span> No charge if we
                                can't repair your device. <br>We'll provide details on the issue and offer
                                alternatives, <br> including returning your device as is.</p>
                            <h1 class="text-danger"><?php echo e($data['modal']['name']); ?> <br> <?php echo e($data['repair_type']['name']); ?>

                            </h1>
                        </div>
                    </div>
                    <!-- Checklist Column -->
                    <div class="col-lg-4 text-start">
                        <h3 class="text-danger"><?php echo e($data['modal']['name']); ?> <?php echo e($data['repair_type']['name']); ?></h3>
                        <div><br></div>
                        <h4><b class="text-danger">&#10003; How long?</b> <?php echo e($data['repair_type']['duration'] ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger">&#10003; Part Used?</b> <?php echo e($data['repair_type']['part_used'] ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger">&#10003; Warranty?</b> <?php echo e($data['repair_type']['warranty'] ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger">&#10003; Will my data be lost?</b>
                            <?php echo e($data['repair_type']['data_loss'] ?? ''); ?></h4>
                        <h4><b class="text-danger">&#10003; Post Repair Advice?</b>
                            <?php echo $data['repair_type']['advice'] ?? ''; ?></h4>
                        <h4><b class="text-danger">&#10003; What if you can’t fix my device?</b>
                            <?php echo $data['repair_type']['no_fix_no_fee'] ?? ''; ?></h4>
                    </div>

                    <!-- Device Image Column -->
                    <div class="col-lg-2 mt-5">
                        <img src="<?php echo e(asset($data['modal']['file']) ?? 'https://ik.imagekit.io/qml3d7tgz/iphone1_9JHn-8RLU.jpg'); ?>"
                            style="height:400px; width:281px" />
                    </div>

                    <!-- Service Explanation Column -->
                </div>
            </div>
        </section>

        <!-- Form Section Part 1 (Initial Hidden) -->
        <section id="form-section-1" class="form-step" style="display:none;">
            <div>
                <div class="row justify-content-center">
                    <!-- Patient Detail Form Column -->
                    <div class="col-12 col-lg-12 rounded p-4">
                        <div>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Form Section Part 2 (Initial Hidden) -->
        <section id="form-section-2" class="form-step bg-white" style="display:none;">
            <div class="container">
                <div class="row">
                    <!-- Form Toggle Column -->
                    <div class="col-lg-12">
                       <div class="rounded p-4" style="background-color:white; border: 3px solid black;">
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

                    </div>
                </div>
            </div>
        </section>

        <!-- Book Repair Component (Initial Hidden) -->
        <section id="book-repair-section" class="form-step" style="display:none;">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </section>

        <!-- Back and Next Buttons -->
        <div class="container-fluid mt-4">
            <div class="row justify-content-between">
                <div class="col-auto">
                    <button id="back-button" class="btn btn-danger m-5" style="display:none;">Back</button>
                </div>
                <div class="col-auto">
                    <button id="next-button" class="btn btn-danger m-5">Next</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            const steps = ['repair-info-section', 'form-section-2', 'form-section-1', 'book-repair-section'];
            let currentStep = <?php echo e($currentStep); ?>;
            let formCompleted = [true, false, false, false]; // Initialize with `true` for intro section and `false` for others

            function showStep(stepIndex) {
                $('.form-step').hide();
                $('#' + steps[stepIndex]).show();

                if (stepIndex === 0 || stepIndex === 1) {
                    $('#back-button').hide();
                } else {
                    $('#back-button').show();
                }

                if (stepIndex === 1 || stepIndex === 2 || stepIndex === 3) {
                    $('#next-button').hide();
                } else {
                    $('#next-button').show();
                    $('#next-button').prop('disabled', !formCompleted[stepIndex]);
                    if (!formCompleted[stepIndex]) {
                        $('#next-button').hide(); // Hide the Next button if the form is not validated
                    } else {
                        $('#next-button').show(); // Show the Next button if the form is validated
                    }
                }
            }

            function moveToNextStep() {
                if (currentStep < steps.length - 1) {
                    currentStep++;
                    showStep(currentStep);
                }
            }

            $('#back-button').click(function () {
                if (currentStep > 0) {
                    currentStep--;
                    showStep(currentStep);
                }
            });

            $('#next-button').click(function () {
                moveToNextStep();
            });

            Livewire.on('formSubmitted', function () {
                formCompleted[currentStep] = true;
                moveToNextStep();
            });

            Livewire.on('formInvalid', function () {
                formCompleted[currentStep] = false;
                showStep(currentStep);
            });

            // Initial display setup
            showStep(currentStep);
        });

        document.addEventListener('livewire:load', function () {
            Livewire.on('formShown', function () {
                // Hide the grid container when a form is shown
                document.querySelector('.grid-container').style.display = 'none';
            });
        });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/livewire/2.x/livewire.js"></script>
</div><?php /**PATH /Users/mubashir/Documents/vscode (2)/resources/views/livewire/guest/repair-detail.blade.php ENDPATH**/ ?>
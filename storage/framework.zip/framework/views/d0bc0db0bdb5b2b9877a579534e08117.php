<div>
    <section class="top-sec bg-black text-white">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner text-center py-1">
                <div class="carousel-item active text-center py-1">
                    <p class="d-block w-100 m-0 fs-6">Your Destination for Buying, Selling, and Repair.</p>
                </div>
                <div class="carousel-item text-center py-1">
                    <p class="d-block w-100 m-0 fs-6">Buy, Sell, Repair: Your Trusted Marketplace.</p>
                </div>
                <div class="carousel-item text-center py-1">
                    <p class="d-block w-100 m-0 fs-6">Buy It, Sell It, Fix It - Right Here</p>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/components/top-bar.blade.php ENDPATH**/ ?>
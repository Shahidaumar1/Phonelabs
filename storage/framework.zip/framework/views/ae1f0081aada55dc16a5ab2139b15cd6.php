<div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l2465203789-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2465203789-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2465203789-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2465203789-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2465203789-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <section class="device-type-head">
        <div class="overlay"></div>
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l2465203789-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2465203789-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2465203789-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2465203789-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2465203789-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
             <a href="<?php echo e(route('categories')); ?>">
                        
                    <button class="btn btn-danger btn-sm mt-2"  ><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
</svg></button>
                    </a>
            <div class="p-3 rounded-2 mt-5 d-flex justify-content-between align-items-center"
                style="background-color: #afafaf">
                <div class="d-flex flex-column">
                    <h1 class="text-black">Need a Repair?</h1>
                    <span class="tagline text-black">Tell Us Which Device You Have…</span>
                </div>

                <div class="d-flex justify-content-end align-items-center">
                    
                    <!--<h2 class=" mt-3 ml-3 " style="color: #da0a0a"><b>Students can get 10% Off on all repairs</b></h2>-->
                </div>

            </div>
        </div>
    </section>
    <section class="device-type-section">
        <div class="container">
            <div class="phone-section">
                <div class="section-header text-center my-5">
                    <h2><sup></sup> Brands <sub></sub>
                    </h2>
                    <p>
                        Whether you’ve got a broken screen, a battery problem or charging problem, we fix a wide
                        range<br>
                        of devices, from your Pixel, iPhones & Samsungs, to your Xiaomis, iPads, Lenovos, Huawei<br>
                        MediaPads, HPs, Dells and even your old Nokias…
                    </p>

                </div>
                         <div class="d-flex justify-content-center gap-3 flex-wrap mb-5">

                    <?php $__empty_1 = true; $__currentLoopData = $device_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <div class="black-cards">
                            <a href="<?php echo e(route('modals', $device_type->id)); ?>">
                                <?php if($device_type->name != 'Apple iPad'): ?>
                                    <div class="card">
                                        <div class="card-header">
                                            <img src="<?php echo e($device_type->file ?? ''); ?>" class="img-fluid c-img" 
                                                 style="height:120px; width:170px;" />
                                        </div>
                                        
                                    </div>
                                <?php endif; ?>
                            </a>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span>Not Found</span>
                    <?php endif; ?>

                </div>



            </div>

            
        </div>
    </section>


</div>
<style>
@media screen and (max-width: 768px) {
    .c-img{
        height:80px !important; 
        width:130px !important;
    }
    }
@media screen and (max-width: 500px) {
    .c-img{
        height:80px !important; 
        width:120px !important;
    }
    }
@media only screen and (max-width: 767px) { /* Adjust max-width as per your need */
    .d-flex {
        gap: 2px; /* Adjust the value as per your preference */
    }
}

  
</style>
 <?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/livewire/guest/device-typs.blade.php ENDPATH**/ ?>
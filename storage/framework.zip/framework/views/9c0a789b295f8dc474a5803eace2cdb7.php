<div class="container mt-5 rounded"  style="background-color:#bfb9b9"  >

  <h2 class="text-danger text-center mb-4 pt-4">Customer Details</h2>
  <h4 class="text-danger text-center mb-4">Tell us about yourself</h4>
  <form wire:submit.prevent="submitForm">
  <div class="row g-3">
    <div class="col-md-6">
      <label for="first_name" class="form-label fw-bold">First Name</label>
      <input type="text" class="form-control" id="first_name" placeholder="Enter your first name"
        wire:model.lazy="patient.first_name">
      <?php $__errorArgs = ['patient.first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger" style="font-size: 12px;"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6">
      <label for="last_name" class="form-label fw-bold">Last Name</label>
      <input type="text" class="form-control" id="last_name" placeholder="Enter your last name"
        wire:model.lazy="patient.last_name">
      <?php $__errorArgs = ['patient.last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger" style="font-size: 12px;"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6">
      <label for="email" class="form-label fw-bold">Email address</label>
      <input type="email" class="form-control" id="email" placeholder="Enter your email address"
        wire:model.lazy="patient.email">
      <?php $__errorArgs = ['patient.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger" style="font-size: 12px;"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6">
      <label for="confirm_email" class="form-label fw-bold">Confirm Email</label>
      <input type="email" class="form-control" id="confirm_email" placeholder="Confirm your email address"
        wire:model.lazy="patient.confirm_email">
      <?php $__errorArgs = ['patient.confirm_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger" style="font-size: 12px;"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6">
      <label for="phone" class="form-label fw-bold">Phone Number</label>
      <input type="tel" class="form-control" id="phone" placeholder="Enter Phone Number"
        wire:model.lazy="patient.phone">
      <?php $__errorArgs = ['patient.phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger" style="font-size: 12px;"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-3 mt-4">
      <label class="form-label fw-bold d-block">Are you an exsiting customer?</label>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="existing_customer_yes" value="1"
          wire:model.lazy="patient.existing_patient">
        <label class="form-check-label" for="existing_customer_yes">Yes</label>
      </div>
      <div class="form-check form-check-inline ml-5">
        <input class="form-check-input" type="radio" id="existing_customer_no" value="0"
          wire:model.lazy="patient.existing_patient">
        <label class="form-check-label" for="existing_customer_no">No</label>
      </div>
      <?php $__errorArgs = ['patient.existing_patient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger" style="font-size: 12px;"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-3 mt-4">
      <label class="form-label fw-bold d-block">Are you a business?</label>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="existing_business_yes" value="1"
          wire:model.lazy="patient.business_repair">
        <label class="form-check-label" for="existing_business_yes">Yes</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="existing_business_no" value="0"
          wire:model.lazy="patient.business_repair">
        <label class="form-check-label" for="existing_business_no">No</label>
      </div>
      <?php $__errorArgs = ['patient.business_repair'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger" style="font-size: 12px;"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6">
      <?php if($patient['business_repair'] == '1'): ?>
      <label for="company_name" class="form-label fw-bold">Company Name *</label>
      <input type="text" class="form-control" id="company_name" placeholder="Enter company name"
      wire:model.lazy="patient.company_name">
    <?php endif; ?>
    </div>
    

  </div>
        <button type="submit" class="btn btn-danger">Next</button>
  </form>
  <!-- <script>
    document.addEventListener('livewire:load', function () {
      Livewire.on('formValidated', () => {
        // Handle form validation success here
        console.log('Form validated successfully');
      });
    });
    

  </script> -->
</div><?php /**PATH /Users/mubashir/Documents/vscode (2)/resources/views/livewire/guest/components/patient-detail-form.blade.php ENDPATH**/ ?>
<div class=" search-form d-flex flex-column flex-lg-row gap-2 align-items-center">

    <li class="m-1 nav-item dropdown select-device-dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">

            <?php echo e($selectedDeviceType ? $device_type->name : 'Select Device'); ?>

        </a>
        <ul class="dropdown-menu">
            <?php $__currentLoopData = $device_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a class="dropdown-item" href="javascript:void(0)"
                        wire:click="selectDeviceType('<?php echo e($device_type->id); ?>')"><?php echo e($device_type->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a class="dropdown-item" href="<?php echo e(route('other-device-booking', ['type' => 'samsung-glaxy-tab'])); ?>">
                Samsung Galaxy Tab
            </a>
            <a class="dropdown-item" href="<?php echo e(route('other-device-booking', ['type' => 'apple-macbook'])); ?>">
                Apple Macbook
            </a>
            <a class="dropdown-item" href="<?php echo e(route('other-device-booking', ['type' => 'microsoft-surface'])); ?>">
                Microsoft Surface
            </a>

            <a class="dropdown-item" href="<?php echo e(route('other-device-booking', ['type' => 'other-mobiles'])); ?>">
                Other Mobiles
            </a>
            <a class="dropdown-item" href="<?php echo e(route('other-device-booking', ['type' => 'other-tablets'])); ?>">
                Other Tablets
            </a>
            <a class="dropdown-item" href="<?php echo e(route('other-device-booking', ['type' => 'other-laptops'])); ?>">
                Other Laptops
            </a>


        </ul>
    </li>
    <li class="m-1 nav-item dropdown select-modal-dropdown ">
        <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo e($selectedModal ? $modal->name : 'Select Model'); ?>

        </a>
        <ul class="dropdown-menu">
            <?php $__currentLoopData = $modals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a wire:click="selectModal('<?php echo e($modal->id); ?>')" class="dropdown-item"
                        href="javascript:void(0)"><?php echo e($modal->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
    <button type="button" wire:click="Go" class="mx-1 btn btn-light "
        <?php echo e($selectedDeviceType && $selectedModal ? '' : 'disabled'); ?>>
        <div>
            <span wire:loading.remove wire:target='Go'>GO</span>
            <span wire:loading wire:target='Go' class="text-white">loading.....</span>
        </div>
    </button>
</div>
</div>
<?php /**PATH /Users/mubashir/Documents/scode/resources/views/livewire/components/slider/search-form.blade.php ENDPATH**/ ?>
<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l1819702083-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1819702083-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1819702083-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1819702083-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1819702083-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <section class="repair-types ">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white'])->html();
} elseif ($_instance->childHasBeenRendered('l1819702083-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1819702083-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1819702083-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1819702083-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white']);
    $html = $response->html();
    $_instance->logRenderedChild('l1819702083-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div class="container p-3 rounded-2 mt-5 d-flex justify-content-between align-items-center"
            style="background-color: #afafaf">
            <div class="d-flex flex-column">
                <h1 class="text-black">Need a Repair?</h1>
                <span class="tagline text-black">Tell Us Which Device You Have…</span>
            </div>

            <div class="d-flex justify-content-end align-items-center">
                
                <!--<h2 class="text-danger mt-3 ml-3 "><b>Students can get 10% Off on all repairs</b></h2>-->
            </div>

        </div>
        <div class="text-center my-4">
            <h2 class="text-danger">Broken <?php echo e($modal->name ?? ''); ?></h2>
            <span class="tagline text-black">We can fix that!</span>
        </div>
    </section>
    <?php if($device): ?>



        <section>
            <div class="container my-5">
                <div class=" d-flex align-items-center justify-content-center text-center">
                    <div class="d-flex gap-5 flex-wrap justify-content-center ">

                        <?php $__empty_1 = true; $__currentLoopData = $device->repair_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $price = App\Models\Price::where('modal_id', $modal->id)
                                    ->where('repair_type_id', $repair_type->id)
                                    ->first();
                                // $d = App\Helpers\SeoUrl::encodeUrl($device->name);
                                // $m = App\Helpers\SeoUrl::encodeUrl($modal->name);
                                // $r = App\Helpers\SeoUrl::encodeUrl($repair_type->name);
                            ?>

                            <?php if($price && $price->price > 0): ?>
                                <div class="card p-3 d-flex justify-content-center align-items-center "
                                    >
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.components.klarna-installments-badge', ['price' => $price->price])->html();
} elseif ($_instance->childHasBeenRendered('l1819702083-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l1819702083-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1819702083-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1819702083-2');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.components.klarna-installments-badge', ['price' => $price->price]);
    $html = $response->html();
    $_instance->logRenderedChild('l1819702083-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    <a href="<?php echo e(route('repair-detail', ['device' => $device->id, 'modal' => $modal->id, 'repair' => $repair_type->id])); ?>">
                                        
                                    <img src="<?php echo e(asset($repair_type->image) ?? ''); ?>" class="img-fluid p-3"
                                        style="height:150px; ">
                                    </a>
                                        <a href="<?php echo e(route('repair-detail', ['device' => $device->id, 'modal' => $modal->id, 'repair' => $repair_type->id])); ?>">
                                            
                                    <h4 class="text-center text-wrap"><?php echo e($repair_type->name); ?></h4>
                                        </a>

                                    <h3>£ <?php echo e($price->price); ?></h3>
                                    <a style="text-decoration: none;"
                                        href="<?php echo e(route('repair-detail', ['device' => $device->id, 'modal' => $modal->id, 'repair' => $repair_type->id])); ?>">
                                        <button class="btn btn-danger" type="button">Repair</button>
                                    </a>

                                </div>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No repair types found.</p>
                        <?php endif; ?>

                        
                    </div>

                    
                    


                </div>

            </div>
        </section>
    <?php endif; ?>
</div>
<?php /**PATH /Users/mubashir/Downloads/vscode/resources/views/livewire/guest/repair-types.blade.php ENDPATH**/ ?>
<div>
    <div class="container mt-3 pb-5" style="background-color:white">
        <!-- Display branch selection and appointment form -->
        <form x-data="{ step: 0 }" class="p-4" wire:submit.prevent="submitForm">
            <!-- Step 1: Select nearest branch -->
            <section id="section-1" x-show="step === 0" x-cloak class="row">
                <legend class="mb-3">
                    <h2 class="find" style="text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);">Find a Store</h2>
                </legend>

                <!-- Display map or default map if no map link -->
                <div class="mt-4 col-md-6 fpostcode-map">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control search" wire:model.defer="postalCode" required>
                        <button type="button" class="btn btn-danger search-btn" wire:click="getLatLong">Search</button>
                    </div>
                    <div style="width: 100%; height: 550px; border: 0;">
                        <?php if(!empty($mapLink)): ?>
                            <?php echo $mapLink; ?>

                        <?php else: ?> 
                            <!-- <iframe
                                        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                                        width="100%" height="550" style="border: 0" allowfullscreen="" loading="lazy"
                                        referrerpolicy="no-referrer-when-downgrade"></iframe> -->
                         <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('branches-map')->html();
} elseif ($_instance->childHasBeenRendered('l269312319-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l269312319-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l269312319-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l269312319-0');
} else {
    $response = \Livewire\Livewire::mount('branches-map');
    $html = $response->html();
    $_instance->logRenderedChild('l269312319-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-1"></div>

                <div class="col-md-5">
                    <div class="col-lg-12 p-3 boxes" id="branch-list">
                        <?php if(!empty($nearestBranches)): ?>
                            <?php $__currentLoopData = $nearestBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-4 border p-3" style="border: 2px solid black;">
                                    <h3 class="fw-bold"><?php echo e($branch['name']); ?>, (distance
                                        <?php echo e(number_format($branch['distance'], 2) != 0.00 ? number_format($branch['distance'], 2) : 0); ?>

                                        miles)
                                    </h3>
                                    <p style="white-space: normal; word-wrap: break-word; margin: 0;">
                                        <?php echo e($branch['address_line_1']); ?>,
                                        <?php echo e($branch['address_line_2'] ?: ''); ?>,
                                        <?php echo e($branch['town_city']); ?>,
                                        <?php echo e($branch['post_code']); ?>, UK
                                    </p>
                                    <select class="form-select" aria-label="Contact Options">
                                        <?php if(!empty($branch['email'])): ?>
                                            <option value="1" selected>Email: <?php echo e($branch['email']); ?></option>
                                        <?php endif; ?>
                                        <?php if(!empty($branch['landline_number'])): ?>
                                            <option value="2">Landline: <?php echo e($branch['landline_number']); ?></option>
                                        <?php endif; ?>
                                        <?php if(!empty($branch['mobile_number'])): ?>
                                            <option value="3">Mobile: <?php echo e($branch['mobile_number']); ?></option>
                                        <?php endif; ?>
                                    </select>
                                    <button type="reset" class="btn btn-danger mt-2"
                                        wire:click="selectBranch(<?php echo e($branch['id']); ?>)">Select</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(!empty($branches)): ?>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-4 border p-3" style="border: 2px solid black;">
                                    <h3 class="fw-bold"><?php echo e($branch->name); ?></h3>
                                    <p style="white-space: normal; word-wrap: break-word; margin: 0;">
                                        <?php echo e($branch->address_line_1); ?>,
                                        <?php echo e($branch->address_line_2 ?: ''); ?>,
                                        <?php echo e($branch->town_city); ?>,
                                        <?php echo e($branch->post_code); ?>, UK
                                    </p>
                                    <select class="form-select" aria-label="Contact Options">
                                        <?php if(!empty($branch->email)): ?>
                                            <option value="1" selected>Email: <?php echo e($branch->email); ?></option>
                                        <?php endif; ?>
                                        <?php if(!empty($branch->landline_number)): ?>
                                            <option value="2">Landline: <?php echo e($branch->landline_number); ?></option>
                                        <?php endif; ?>
                                        <?php if(!empty($branch->mobile_number)): ?>
                                            <option value="3">Mobile: <?php echo e($branch->mobile_number); ?></option>
                                        <?php endif; ?>
                                    </select>
                                    <button type="reset" class="btn btn-danger mt-2"
                                        wire:click="selectBranch(<?php echo e($branch->id); ?>)">Select</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <!-- Step 2: Appointment Form -->
            <section id="section-2" x-show="step === 1" x-cloak class="w-75">
                <div class="mb-3">
                    <label class="form-label fw-bold" for="appointment_date">Appointment Date</label>
                    <input type="date" class="form-control" id="appointment_date" name="appointment_date"
                        wire:model.lazy="clinic.appointment_date">
                    <?php $__errorArgs = ['clinic.appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="appointment_time">Appointment Time</label>
                    <select class="form-select form-select-sm" id="appointment_time" name="appointment_time"
                        wire:model="clinic.appointment_time">
                        <option value="">Select a time</option>
                        <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($timeSlot); ?>"><?php echo e($timeSlot); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['clinic.appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="repair_note">Repair Note</label>
                    <textarea class="form-control" id="repair_note" wire:model.debounce.500ms="clinic.repair_note"
                        placeholder="Please write any comment..." rows="3"></textarea>
                    <?php $__errorArgs = ['clinic.repair_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Submit button -->
                <button type="submit" class="btn btn-danger mt-3">Next</button>
            </section>

            <!-- Navigation button -->
            <button type="button" class="btn btn-danger mt-3" @click="step = 1" x-show="step === 0">Next</button>
        </form>
    </div>

    <style>
        .search {
            width: 70px !important;
        }

        .fpostcode-map {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);
            padding: 17px 14px 14px 14px;
        }

        .boxes {
            margin-top: 12px;
            height: 650px;
            overflow-y: scroll;
            scrollbar-color: rgb(233, 163, 163) transparent;
            scrollbar-width: thin;
            scroll-behavior: smooth;
            scroll-padding: 50px;
        }

        .boxes::-webkit-scrollbar {
            width: 40px;
        }

        .boxes::-webkit-scrollbar-track {
            background: transparent;
        }

        .boxes::-webkit-scrollbar-thumb {
            background-color: rgb(233, 163, 163);
            border-radius: 40px;
            border: 3px solid transparent;
        }

        .find {
            color: rgb(240, 88, 88);
            font-size: 44px;
            font-weight: 900;
            text-align: center;
        }

        .search-btn {
            background-color: #da3847;
            color: white;
        }

        .s-card {
            height: 120px;
        }
    </style>
    <script>
        document.addEventListener('livewire:load', function () {
            let branchList = document.getElementById('branch-list');

            Livewire.hook('message.processed', (message, component) => {
                // Scroll to the current position instead of jumping to the top
                branchList.scrollTop = branchList.scrollHeight;
            });
        });
    </script>

</div><?php /**PATH /Users/mubashir/Documents/vscode (2)/resources/views/livewire/guest/components/clinic-repair-form.blade.php ENDPATH**/ ?>
<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l1321710840-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1321710840-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1321710840-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1321710840-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1321710840-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l1321710840-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1321710840-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1321710840-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1321710840-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1321710840-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <section>

        <div class="container mt-5 ">
            
            <div class="row">
                <h6 class="text-center fs-2 fw-bold">Please select specifications for your <?php echo e($model->name); ?></h6>
                <p class="text-center text-danger">(This enables us to offer you a preliminary estimate.) </p>


                <div class="col-lg-6 p-5 mt-5 text-center">
                    <?php if(json_decode($product_spec_image) === null): ?>
                        <!-- Display single image -->
                        <img src="<?php echo e($product_spec_image ?? $model->file); ?>" class="img-fluid"
                            style="min-width: 75%; max-height: 480px;">
                    <?php else: ?>
                        <!-- Display image slider for multiple images -->
                        <div id="imageSlider" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php $__currentLoopData = json_decode($product_spec_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?> text-center">
                                        <img src="<?php echo e($image); ?>" class="img-fluid"
                                            style="min-width: 75%; max-height: 480px;" alt="Image <?php echo e($index + 1); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button class="carousel-control-prev text-bg-danger" type="button"
                                data-bs-target="#imageSlider" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next text-bg-danger" type="button"
                                data-bs-target="#imageSlider" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>

                <?php
                    $product_specs = App\Models\ProductSpec::where('model_id', $model->id)->get();
                ?>
                <!-- ----details--- -->
                <div class="col-lg-6  ">


                    <div class="">
                        <p class="fs-3 mt-4  fw-bold"><?php echo e($model->name); ?></p>

                        <?php if(in_array(!null, $available_memory_sizes)): ?>
                            <p class="fs-6 fw-bold">Select Memory Size:</p>
                        <?php endif; ?>

                        <?php $__empty_1 = true; $__currentLoopData = $available_memory_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memory_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($memory_size != null): ?>
                                <button type="button"
                                    class="btn btn-outline-danger <?php echo e($memory_size == $selectedMemorySize ? 'bg-danger text-white' : ''); ?>"
                                    wire:click="$set('selectedMemorySize','<?php echo e($memory_size); ?>')"><?php echo e($memory_size); ?></button>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                        <p class="fs-5 mt-3 fw-bold">Select Grade:</p>
                        <div>
                            <?php
                                // Define the custom order
                                $customOrder = ['A', 'B', 'C'];
                                // Sort the grades array based on the custom order
                                usort($available_grades, function ($a, $b) use ($customOrder) {
                                    return array_search($a, $customOrder) - array_search($b, $customOrder);
                                });
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $available_grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <button type="button"
                                    class="btn btn-outline-dark cursor-pointer <?php echo e($grade == $selectedGrade ? '  bg-danger text-white' : ''); ?>"
                                    wire:click="$set('selectedGrade','<?php echo e($grade); ?>')"><?php echo e($grade); ?></button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                            <?php if($selectedGrade): ?>
                                <div class="bg-gray rounded p-2 mt-1   ">
                                    <?php echo $grade_text; ?>

                                </div>
                            <?php endif; ?>

                        </div>
                        <?php if(in_array(!null, $available_colors)): ?>
                            <p class="fs-5 mt-3 fw-bold">Color: </p>
                        <?php endif; ?>


                        <div>
                            <div class="d-flex gap-2">
                                <?php $__empty_1 = true; $__currentLoopData = $available_colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <button type="button"
                                        class="btn btn-outline-dark  <?php echo e($color == $selectedColor ? 'bg-danger text-white' : ''); ?>  "
                                        wire:click="$set('selectedColor','<?php echo e($color); ?>')"><?php echo e($color); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>


                            </div>
                            <!-- Include a form field for quantity -->
                            <div class=" mt-3">
                                <label for="quantity">Quantity: only <?php echo e($available_quantity); ?> Available</label>

                                <div class="input-group mt-2" style="max-width: max-content;">
                                    <div class="input-group-prepend">
                                        <button type="button" class="btn btn-danger"
                                            wire:click="decreaseQuantity">-</button>
                                    </div>
                                    <input type="number" class="form-control border-0 text-center"
                                        wire:model="quantity" min="1" max="<?php echo e($available_quantity); ?>"
                                        step="1" wire:change="quantityChanged">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-success"
                                            wire:click="increaseQuantity">+</button>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="mt-3 mb-1">
                            <div class="accordion-container card mt-4" x-data="{ accordion1: false, accordion2: false, accordion3: false }">
                                <div class="d-flex justify-content-between p-2  cursor-pointer bg-gray mb-2"
                                    x-on:click="accordion1 = !accordion1" x-transition>
                                    <span>Details</span>
                                    <span>
                                        <i x-show="accordion1 == false" class="fa fa-plus" aria-hidden="true"></i>
                                        <i x-show="accordion1 == true" class="fa fa-minus" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="content" x-show="accordion1">
                                    <div>
                                        <?php if($detail): ?>
                                            <?php echo $detail; ?>

                                        <?php else: ?>
                                            <p></p>
                                        <?php endif; ?>
                                    </div>
                                </div>




                                <div class="d-flex justify-content-between p-2  cursor-pointer bg-gray mb-2"
                                    x-on:click="accordion2 = !accordion2" x-transition>
                                    <span>Specification</span>

                                    <span>
                                        <i x-show="accordion2 == false" class="fa fa-plus" aria-hidden="true"></i>
                                        <i x-show="accordion2 == true" class="fa fa-minus" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="content" x-show="accordion2">
                                    <?php if($specification): ?>
                                        <?php echo $specification; ?>

                                    <?php else: ?>
                                        <p></p>
                                    <?php endif; ?>

                                </div>


                                <div class="d-flex justify-content-between p-2  cursor-pointer bg-gray mb-2"
                                    x-on:click="accordion3 = !accordion3" x-transition>
                                    <span>Warranty</span>

                                    <span>
                                        <i x-show="accordion3 == false" class="fa fa-plus" aria-hidden="true"></i>
                                        <i x-show="accordion3 == true" class="fa fa-minus" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <div class="content" x-show="accordion3">

                                    <?php if($warranty): ?>
                                        <?php echo $warranty; ?>

                                    <?php else: ?>
                                        <p></p>
                                    <?php endif; ?>
                                </div>


                            </div>


                          
    <div class="row">
        <div class="col-12 col-sm-6 order-sm-1 mt-5">
            <div class="flex-column mb-3 w-100 w-sm-50 float-end ">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.components.klarna-installments-badge', ['price' => $price])->html();
} elseif ($_instance->childHasBeenRendered('l1321710840-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l1321710840-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1321710840-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1321710840-2');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.components.klarna-installments-badge', ['price' => $price]);
    $html = $response->html();
    $_instance->logRenderedChild('l1321710840-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
      <div class="row">

        <div class="col-12 col-sm-6 order-sm-2 ">
            <div class="p-2 fs-5 text-danger fw-bold" id="cashText">
                <h2 style="white-space:nowrap;" class="mb-0 d-sm-inline-block">Cash Value: £ <?php echo e($price ?? 0); ?>.00</h2>
            </div>
        </div>
    </div>



                        </div>



                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="container">
        <div class=" bg-gray  ">
            <div class="row border border-2 border-dark rounded">

                <div class="col-12 col-lg-6 col-md-6 bg-pink-linear rounded p-4 ">
                    <div class="w-75 mx-auto" >
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-12 col-lg-6 col-md-6 bg-pink-linear rounded p-4">
                    <div class=" mx-auto position-relative" style="width: 100%;; margin-left:-40%" >
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>

                </div>


            </div>
        </div>
    </section>

    <div class="container" wire:ignore>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.buy.book-repair', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.buy.book-repair', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/buy/product-specs.blade.php ENDPATH**/ ?>
<div class=" d-flex justify-content-between align-items-cente">
    <!-- -------change radio forms------ -->
  <style>
    .col-md-7 {
        width: 100%;
      
        background: #ffffff;

        border-radius: 15px;
        margin: auto; /* Center the container horizontally */
    }

    @media (max-width: 767px) {
        /* Apply styles for screens smaller than 768px (phones) */
        .col-md-7 {
            width: 100%;
       
        }
        .btn-success{
            margin-top:-20px;
        }
       
    }
</style>

   <div class="my-4 col-12 col-md-7 " style="">
        <div id="paymentForm">
            <!--<h2 class="text-center p-3 fw-bold">PayPal</h2>-->


            <div class="">
                <!--<label for="disabledSelect" class="form-label">Name</label>-->
                <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Your Name" wire:model.debounce.500="paypalDetail.account_name">-->
            
            <div class="row ">
    <label for="exampleFormControlInput1" class="col-sm-2 col-form-label">Name</label>
    <div class="col-sm-10 d-flex align-items-center">
        <input type="text" class="form-control" id="exampleFormControlInput1" style="font-size:12px;" placeholder="Enter Your Name" wire:model.debounce.500="paypalDetail.account_name">
    </div>
</div>

            
            
                <?php $__errorArgs = ['paypalDetail.account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            
            <div class="mt-2 ">
                <!--<label for="disabledSelect" class="form-label">Email Address</label>-->
                <!--<input type="email" type="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter Your Email Address" wire:model.debounce.500="paypalDetail.email">-->
            
            <div class="row">
    <label for="exampleFormControlInput1" class="col-sm-2 col-form-label">Email</label>
    <div class="col-sm-10 d-flex align-items-center">
        <input type="email" class="form-control" id="exampleFormControlInput1" style="font-size:12px;" placeholder="Enter Your Email Address" wire:model.debounce.500="paypalDetail.email">
    </div>
</div>

            
            
            
                <?php $__errorArgs = ['paypalDetail.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-2">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" style="transform: scale(0.8);" >
            
                    <label style="font-size:0.9vw;white-space:nowrap;" class="form-check-label " for="flexCheckDefault">
                        I agreed with Privacy Policy and Terms & Conditions.
                    </label>
                </div>
            </div>

           <div class="cursor-point align-items-center d-grid gap-2 mt-1 col-12 justify-content-center">
    <button class="btn btn-danger text-white" wire:click="submit">Submit</button>
   
   
   
    <?php if($loading): ?>
        <span>Submitting...</span>
    <?php endif; ?>
</div>


        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/sell/components/paypal.blade.php ENDPATH**/ ?>
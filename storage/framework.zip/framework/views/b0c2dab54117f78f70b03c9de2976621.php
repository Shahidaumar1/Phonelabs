<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l630517130-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l630517130-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l630517130-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l630517130-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l630517130-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <section class="bg-pink-linear">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white'])->html();
} elseif ($_instance->childHasBeenRendered('l630517130-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l630517130-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l630517130-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l630517130-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white']);
    $html = $response->html();
    $_instance->logRenderedChild('l630517130-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <div class="container">
            <div class="text-center my-4 p-3 rounded-3 " style="background-color: #afafaf">
                <h2><?php echo e($data['repair_type']->name); ?> on your <br> <span class="text-danger">
                        <?php echo e($data['modal']->name); ?>? <span></h2>
                <span class="tagline "><?php echo $webContent->repair_page5_heading1; ?></span>
            </div>
        </div>
    </section>
    <div class="container">
        <section>
            <div class=" my-5  p-3">
                <div class="row  text-center">
                    <div class="col-lg-4 text-start">

                        <h3>Pre-Repair Checklist</h3>
                        <p>(Stuff to know before your repair)</p>
                        <h4><b class="text-danger"> &#10003; How long?</b> <?php echo e($data['repair_type']->duration ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger">&#10003; Part Used?</b> <?php echo e($data['repair_type']->part_used ?? ''); ?>

                        </h4>
                        <h4> <b class="text-danger"> &#10003; Warranty? </b><?php echo e($data['repair_type']->warranty ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger"> &#10003; Will my data be lost?</b>
                            <?php echo e($data['repair_type']->data_loss ?? ''); ?>

                        </h4>
                        <h4><b class="text-danger">&#10003; Post Repair Advice?</b>
                            <?php echo $data['repair_type']->advice ?? ''; ?></h4>
                        <h4><b class="text-danger">&#10003; What if you can’t fix my
                                device?</b> <?php echo $data['repair_type']->no_fix_no_fee ?? ''; ?>

                        </h4>
                        
                        
                    </div>

                    <div class="col-lg-4 mt-5">
                        <img src="<?php echo e(asset($data['modal']->file) ?? 'https://ik.imagekit.io/qml3d7tgz/iphone1_9JHn-8RLU.jpg'); ?>" style="height:400px; width:281px" />
                    </div>
                    <div class="col-lg-4 mt-5">
                        <p class="text-start">At The <?php echo e($siteSettings->buisness_name ?? ''); ?>  we strive to provide top-notch mobile repair services, offering four convenient repair options: in-store repair, post your device, collect and return device, and fix at my address. For all repair types, except in-store repair, online payment is required to ensure a smooth and secure transaction process.

Our commitment to transparency and your satisfaction is paramount. As part of our Terms of Service and Conditions, we specify the repair time and the parts used for your device, and outline the conditions related to data loss and provide repair advice. In the rare event that we can't fix your device, rest assured that we have a clear response in place to address this situation.

For in-store repair, we offer the flexibility of payment methods, allowing you to choose between paying in-store or online, catering to your preferences. Your trust in "The Phone Lab" is greatly valued, and we look forward to providing you with efficient and reliable mobile repair services.</p>


                    </div>


                </div>

            </div>
        </section>


        <section class="bg-gray ">
            <div class="">
                <div class="row ">

                    <div style :"font-size:14px;" class="col-12 col-lg-5 col-md-5 bg-pink-linear rounded p-4">
                        <div style="font-style:italic; max-width: 350px;">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>

                    <div class="col-12 col-lg-7 col-md-7 bg-pink-linear rounded p-4">
                        <div>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>

                    </div>


                </div>
            </div>
        </section>


        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/livewire/guest/repair-detail.blade.php ENDPATH**/ ?>
<div>
    <div class=" d-flex justify-content-center align-items-center flex-column w-50 ">
        <input type="file" wire:model="image" accept="image/jpg,image/png,image/jpeg" />
        <span wire:loading wire:target="image">loading....</span>
    </div>
    <div class="d-flex  gap-4  flex-wrap  ">
        <table class="table mx-auto p-5">
            <thead>
                <tr>
                    <th><?php echo e($model->name ?? ''); ?></th>
                    <th colspan="7">Select specificatoin and price</th>
                </tr>
            </thead>
            <tbody>
                <div>
                    <tr>
                        <th>Memory Size</th>
                        <?php $__empty_1 = true; $__currentLoopData = $memory_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memory_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <td class="rounded cursor-pointer border border-dark <?php echo e($selectedMemorySize == $memory_size ? 'bg-success text-white' : 'bg-light'); ?> "
                                wire:click="selectMemorySize('<?php echo e($memory_size); ?>')">
                                <?php echo e($memory_size); ?>

                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                        <td><input type="text" placeholder="Other" wire:model.debounce.500="selectedMemorySize"
                                style="width:60px!important; height:30px;border:none" /></td>
                    </tr>

                    <tr>
                        <th>Condition</th>
                        <?php $__empty_1 = true; $__currentLoopData = $conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <td class=" rounded cursor-pointer border border-dark <?php echo e($selectedCondition == $condition ? 'bg-success text-white' : 'bg-light'); ?> "
                                wire:click="selectCondition('<?php echo e($condition); ?>')">
                                <?php echo e($condition); ?>

                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </tr>

                </div>
                <?php if($mobileMode || $tabletMode): ?>





                    <tr>
                        <th>Network</th>
                        <?php $__empty_1 = true; $__currentLoopData = $network_providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <td class="cursor-pointer border border-dark <?php echo e($selectedNetwork == $network['name'] ? 'bg-success' : 'bg-light'); ?>"
                                wire:click="selectNetwork('<?php echo e($network['name']); ?>')">
                                <!-- Click event to select network -->
                                <img src="<?php echo e(asset($network['image'])); ?>" alt="<?php echo e($network['name']); ?>"
                                    style="width: 30px; height: 30px;" /> <!-- Display network image -->
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td>No networks available</td>
                        <?php endif; ?>
                        <td>
                            <input type="text" placeholder="Other" wire:model="selectedNetwork"
                                style="width: 60px; height: 30px; border: none;" />
                        </td>
                    </tr>





                    


                    

                    
                <?php endif; ?>
            </tbody>
        </table>
        <?php $__errorArgs = ['selectedCondition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-sm text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class=" d-flex justify-content-between my-3 align-items-center bg-light ">
        <div class=" d-flex gap-2 cursor-pointer " wire:click="clear">
            <i class="fa fa-times text-dark " style="font-size:20px;" aria-hidden="true"></i>
            <h4 class="fw-bold">Clear</h4>
        </div>
        <div>
            <input type="text" placeholder="Enter Price" wire:model.debounce.500="price" />
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-sm text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="d-flex gap-2 cursor-pointer align-items-center" wire:click="save" id="<?php echo e($rand); ?>">
            <i class="fa fa-plus text-success " style="font-size:20px;" aria-hidden="true"></i>
            <h4 class="fw-bold">Add Price</h4>
            <span wire:loading wire:target="save">saving....</span>
        </div>
    </div>
</div>
<?php /**PATH /home/mobilebitz/test.mobilebitz.co.uk/resources/views/livewire/admin/sell/addon/add-spec.blade.php ENDPATH**/ ?>
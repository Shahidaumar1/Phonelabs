<div>
    <div class="d-flex">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'accessories'])->html();
} elseif ($_instance->childHasBeenRendered('l666459644-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l666459644-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l666459644-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l666459644-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'accessories']);
    $html = $response->html();
    $_instance->logRenderedChild('l666459644-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.components.top-nav', ['active' => 'models'])->html();
} elseif ($_instance->childHasBeenRendered('l666459644-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l666459644-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l666459644-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l666459644-1');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.components.top-nav', ['active' => 'models']);
    $html = $response->html();
    $_instance->logRenderedChild('l666459644-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="container">
                <div class="d-flex justify-content-center gap-2 mt-4">
                    <select aria-label="Default select example" wire:model="selectedCatId" style="width:130px">
                        <option>Select Device</option>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                    <select aria-label="Default select example" wire:model="selectedDeviceId" style="width:130px">
                        <option>Select Brand</option>
                        <?php if($devices): ?>
                        <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="d-flex align-items-center gap-4 justify-content-center my-4">
                    <div>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.components.sub-nav', ['items' => $items])->html();
} elseif ($_instance->childHasBeenRendered('l666459644-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l666459644-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l666459644-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l666459644-2');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.components.sub-nav', ['items' => $items]);
    $html = $response->html();
    $_instance->logRenderedChild('l666459644-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>
                
                </div>
                <div class="d-flex align-items-center gap-4 justify-content-center my-4">
                 <?php if($target == 'Publish'): ?>
                    <button class="btn mt-2" onclick="showM('add-buy-model')" style="border-radius: 5px; color: white; 
                    background-color: #20375E; pading: 10px">
                       
                        Create New
                    </button>
                    
                     <?php endif; ?>
                     
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex gap-2">
                                <i class="fa fa-square cursor-pointer <?php echo e($activeView == 'card' ? 'text-success' : ''); ?>" aria-hidden="true" wire:click="activateView('card')"></i>
                                <i class="fa fa-list cursor-pointer <?php echo e($activeView == 'list' ? 'text-success' : ''); ?>" aria-hidden="true" wire:click="activateView('list')"></i>
                            </div>
                        </div>
                    </div>

                
                <?php if($activeView == 'card'): ?>
                <div>

                    <div class="d-flex justify-content-center gap-4  flex-wrap  " wire:sortable="updateOrderNumber">
                      
                        <?php $__empty_1 = true; $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div style="cursor: move" 
                        class="card border-0 rounded-4 " wire:sortable.item="<?php echo e($model->id); ?>" wire:key="model-<?php echo e($model->id); ?>">
                            <div class="p-2 d-flex justify-content-between align-items-center">
                                <?php if($target != 'Junk'): ?>
                                <div class="form-check form-switch">
                                    <input type="checkbox" role="switch" class="form-check-input" wire:change="toggleStatus(<?php echo e($model->id); ?>)" <?php echo e($model->status == 'Publish' ? 'checked' : ''); ?>>
                                </div>
                                <?php endif; ?>
                                <div class="dropdown dropend" id="<?php echo e(uniqid()); ?>" wire:ignore>
                                    <button class="btn btn-light dropdown-toggle bg-light border-0" type="button" id="<?php echo e(uniqid()); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa fa-ellipsis-h"></i>
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="<?php echo e(uniqid()); ?>">
                                        <li>
                                            <?php if($target != 'Junk'): ?>
                                            <a class="dropdown-item" href="javascirpt:void(0)" wire:click="selectModel('<?php echo e($model->id); ?>')">Edit</a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <?php if($target != 'Junk'): ?>
                                            <a class="dropdown-item" href="javascirpt:void(0)" wire:click="setTopRated('<?php echo e($model->id); ?>')"><?php echo e($model->top_rated ? 'Unset Top Rated' : 'Set Top Rated'); ?>

                                            </a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <?php if($target != 'Junk'): ?>
                                            <a class="dropdown-item" href="javascirpt:void(0)" wire:click="setNewArrival('<?php echo e($model->id); ?>')">
                                                <?php echo e($model->new_arrival ? 'Unset New Arrival' : 'Set New Arrival'); ?></a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <?php if($target == 'Junk'): ?>
                                            <a class="dropdown-item" wire:click="restore('<?php echo e($model->id); ?>')">Restore</a>
                                            <?php else: ?>
                                            <a class="dropdown-item" wire:click="softDelete('<?php echo e($model->id); ?>')">Delete</a>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <a href="<?php echo e(route('accessories-models-add-ons')); ?>" class="position-relative">
                                <img src="<?php echo e($model->file ?? '#'); ?>" class="img-fluid" style="cursor: move; height: 100px; margin: 0px 62px;" />
                                <div class="p-2">
                                    <div class="position-absolute   bg-light rounded p-1" style="right:2px; top:2px;">
                                        <strong><?php echo e($model->price); ?></strong>
                                    </div>
                                    <h4 class="fw-bold text-center text-dark"><?php echo e($model->name); ?></h4>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="plus-card">
                            <i class="fa fa-times text-danger " style="font-size:40px;" aria-hidden="true"></i>
                            <h4 class="fw-bold">No Records !</h4>
                        </div>
                        <?php endif; ?>

                    </div>

                </div>
                <?php endif; ?>
                
                <?php if($activeView == 'list'): ?>
                <div>
                    <div class="d-flex justify-content-end align-items-center">
                        <div class=" d-flex gap-2 cursor-pointer" onclick="showM('add-buy-model')">
                            <i class="fa fa-plus text-success " style="font-size:20px;" aria-hidden="true"></i>
                            <h4 class="fw-bold">Create new</h4>
                        </div>
                    </div>
                    <br>
                    <div class="d-flex justify-content-center gap-4  flex-wrap  ">
                        <table class="table mx-auto p-5">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Model</th>
                                    <th scope="col">Photo</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Actions</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th scope="row">1</th>
                                    <td><?php echo e($model->name); ?></td>
                                    <td>
                                        <img src="<?php echo e($model->file ?? '#'); ?>" style="width: 2rem" />
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" role="switch" class="form-check-input" wire:change="toggleStatus(<?php echo e($model->id); ?>)" <?php echo e($model->status == 'Publish' ? 'checked' : ''); ?> <?php echo e($target == 'Junk' ? 'disabled' : ''); ?>>
                                        </div>
                                    </td>
                                    <td class="cursor-pointer">
                                        <div class="dropdown dropend" id="<?php echo e(uniqid()); ?>" wire:ignore>
                                            <button class="btn btn-light dropdown-toggle bg-light border-0" type="button" id="<?php echo e(uniqid()); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fa fa-ellipsis-h"></i>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="<?php echo e(uniqid()); ?>">
                                                <li>
                                                    <?php if($target != 'Junk'): ?>
                                                    <a class="dropdown-item" href="javascirpt:void(0)" wire:click="selectModel('<?php echo e($model->id); ?>')">Edit</a>
                                                    <?php endif; ?>
                                                </li>
                                                <li>
                                                    <?php if($target != 'Junk'): ?>
                                                    <a class="dropdown-item" href="javascirpt:void(0)" wire:click="setTopRated('<?php echo e($model->id); ?>')"><?php echo e($model->top_rated ? 'Unset Top Rated' : 'Set Top Rated'); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                </li>
                                                <li>
                                                    <?php if($target != 'Junk'): ?>
                                                    <a class="dropdown-item" href="javascirpt:void(0)" wire:click="setNewArrival('<?php echo e($model->id); ?>')">
                                                        <?php echo e($model->new_arrival ? 'Unset New Arrival' : 'Set New Arrival'); ?></a>
                                                    <?php endif; ?>
                                                </li>
                                                <li>
                                                    <?php if($target == 'Junk'): ?>
                                                    <a class="dropdown-item" wire:click="restore('<?php echo e($model->id); ?>')">Restore</a>
                                                    <?php else: ?>
                                                    <a class="dropdown-item" wire:click="softDelete('<?php echo e($model->id); ?>')">Delete</a>
                                                    <?php endif; ?>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">Record Not Found!</td>
                                </tr>
                                <?php endif; ?>


                            </tbody>
                        </table>
                    </div>

                </div>
                <?php endif; ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>


    </div>
    
    <?php if($selectedDevice): ?>
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Add Model','id' => 'add-buy-model']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.model.create', ['device' => $selectedDevice])->html();
} elseif ($_instance->childHasBeenRendered('l666459644-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l666459644-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l666459644-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l666459644-3');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.model.create', ['device' => $selectedDevice]);
    $html = $response->html();
    $_instance->logRenderedChild('l666459644-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Model','id' => 'edit-buy-model']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.model.edit', [])->html();
} elseif ($_instance->childHasBeenRendered('l666459644-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l666459644-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l666459644-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l666459644-4');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.model.edit', []);
    $html = $response->html();
    $_instance->logRenderedChild('l666459644-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>


</div>
  <!----------------------------- footer-------------------------->
        <style>
        .button-sticky {
            height: 60px;
            color: white;
            font-family: sans-serif;
            font-size: 17px;
            line-height: 15px;
            text-align: center;
            position: fixed;
            bottom: -2px;
            z-index: 999;
            overflow-x: auto;
            width:100;
        }

        .home-btn:hover {
            color: orange;
        }

        .button-sticky .col-2 {
            margin-right: 10px;
            /* Adjust this value to set the desired gap */
        }

        .button-sticky .col-2:last-child {
            margin-right: 0;
            /* Remove margin from the last button to prevent extra space */
        }
        </style>

        <div class="button-sticky container bg-blue d-lg-none d-md-none">
            <div class="row justify-content-center">

                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('accessories-categories')); ?>" class="text-white item "> Brands</a>
                </div>

                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('accessories-devices')); ?>" class="text-white "> Models</a>
                </div>

                <div class="col-3  mt-4 ">
                    <a href="<?php echo e(route('accessories-models')); ?>" class="text-white  item "> Accessories</a>
                </div>

                <div class="col-3 mt-4">
                    <a href="<?php echo e(route('accessories-models-add-ons')); ?>" class="text-white  item "> Variations</a>
                </div>
            </div>
        </div>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/accessories/model/index.blade.php ENDPATH**/ ?>
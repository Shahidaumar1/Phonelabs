<div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l4269182505-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4269182505-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4269182505-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4269182505-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4269182505-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <section class="head-sell">
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l4269182505-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l4269182505-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4269182505-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4269182505-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4269182505-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </section>


    <section>

        <div class="container mt-5 ">
            <div class="row">
                <h6 class="text-center fs-1 fw-bold">Sell <?php echo e($model->name); ?>- Mobilebitz</h6>
                
                
                <!-- Parent View -->


                <p class="text-center text-danger">(This enables us to offer you a preliminary estimate.)</p>
              <div class="col-lg-6 p-5 mt-5">
    <img src="<?php echo e($product_spec_image ?? $model->file); ?>" class="img-fluid" alt="Responsive Image" style="max-height: 380px;">
</div>

                
                <?php
                    $product_specs = App\Models\ProductSpec::where('model_id', $model->id)->get();
                ?>
                <div class="col-lg-6  p-5 ">
                    <div>
                        <?php if(in_array(!null, $available_memory_sizes)): ?>
                            <p class="fs-6 fw-bold">Select Memory Size:</p>
                        <?php endif; ?>

                        <?php $__empty_1 = true; $__currentLoopData = $available_memory_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memory_size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($memory_size != null): ?>
                                <button type="button"
                                    class="btn btn-outline-danger <?php echo e($memory_size == $selectedMemorySize ? 'bg-danger text-white' : ''); ?>"
                                    wire:click="$set('selectedMemorySize','<?php echo e($memory_size); ?>')"><?php echo e($memory_size); ?></button>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                        <div>
                            <?php
                                // Define the custom order
                                $customOrder = ['Excellent', 'Good', 'Fair', 'Poor', 'Faulty'];
                                // Sort the grades array based on the custom order
                                usort($available_conditions, function ($a, $b) use ($customOrder) {
                                    return array_search($a, $customOrder) - array_search($b, $customOrder);
                                });
                            ?>
                            <p class="fs-6 mt-3 fw-bold">Select Condition:</p>
                            <div class="d-flex  gap-2 border-0  align-items-center" style="margin-bottom: -7px">
                                <?php $__empty_1 = true; $__currentLoopData = $available_conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <label
                                        class=" cursor-pointer px-3  py-2 rounded-top border border-2  <?php echo e($condition == $selectedCondition ? '  bg-gray text-black' : ''); ?> "
                                        wire:click="$set('selectedCondition','<?php echo e($condition); ?>')">
                                        <?php echo e($condition); ?>

                                    </label>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                            <?php if($selectedCondition): ?>
                                <div class="bg-gray border-0 text-black  rounded p-2 mt-1   ">
                                    <?php echo $condition_text; ?>

                                </div>
                            <?php endif; ?>

                            <div class="mt-3">

                                <?php if($mobileMode || $tabletMode): ?>
                                    <tr>
                                        <th>Network/unlocked</th>
                                        <td>
                                            <div class="form-check form-switch">
                                                <input type="checkbox" role="switch"
                                                    class="form-check-input border border-dark"
                                                    wire:model="network_unlocked" id="<?php echo e($rand . 'nu'); ?>" />
                                            </div>
                                        </td>
                                    </tr>
                                    <!--<tr>-->
                                    <!--    <th>Account/cleared</th>-->
                                    <!--    <td>-->
                                    <!--        <div class="form-check form-switch">-->
                                    <!--            <input type="checkbox" role="switch"-->
                                    <!--                class="form-check-input border border-dark"-->
                                    <!--                wire:change="toggleAccountCleared" id="<?php echo e($rand . 'ac'); ?>" />-->
                                    <!--        </div>-->
                                    <!--    </td>-->
                                    <!--</tr>-->
                                <?php endif; ?>

                                <div class="mt-3 mb-1">
                                    <div class=" mt-5 d-flex align-items-end flex-column  mb-3">
                                        <div class="text-center"  id="cashText">
                                            <h2 class=" text-danger fw-bold">Cash Value: £<?php echo e($price); ?>.00</h2>
                                            <small>select device specification above to see price</small>
                                        </div>
                                        <div class="p-2 fs-3 fw-bold text-secondary ">
                                            
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </section>

 <section class="container">
    <div class="bg-gray ">
        <div class="row border border-2 border-dark rounded">

            <div class="col-12 col-lg-6 col-md-6 order-1 order-md-0 bg-pink-linear rounded p-4">
                <div class="w-100 mx-auto mb-4">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>

            <div class="col-12 col-lg-6 col-md-6 order-0 order-md-1 bg-pink-linear rounded p-4">
                <div class="w-100 mx-auto mb-4">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
                </div>
            </div>

        </div>
    </div>
</section>



    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.sell.booking-form', [])->html();
} elseif ($_instance->childHasBeenRendered('l4269182505-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l4269182505-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4269182505-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4269182505-4');
} else {
    $response = \Livewire\Livewire::mount('guest.sell.booking-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4269182505-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/sell/model-detail.blade.php ENDPATH**/ ?>
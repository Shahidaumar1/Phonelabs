 <div id="content" style="width:100%">
     <?php echo e($slot); ?>

 </div>
<?php /**PATH /Users/mubashir/Downloads/MobileBitz 2/resources/views/components/content.blade.php ENDPATH**/ ?>
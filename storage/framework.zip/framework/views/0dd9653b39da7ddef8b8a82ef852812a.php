<div>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>


    <div class="container mt-3" style="background-color:white">
        <!-- Display branch selection and appointment form -->
        <form x-data="{ step: 0 }" class="p-4 submit-form" wire:submit.prevent="submitForm">
            <!-- Step 1: Select nearest branch -->
            <section id="section-1" x-show="step === 0" x-cloak class="row map-select">
                <legend class="mb-3">
                    <h2 class="find">Find a Nearest Store</h2>
                    <p class="text-center"><em>To calculate the real-time distance of stores from your location, please
                            enter your postal code</em></p>
                </legend>
                <!--  on phone screen-->
                <div class="col-md-6 mt-4   d-lg-none d-md-none" style=" width:840% !important;">
                    <div class="input-group  " style="display: flex; ">
                        <input type="text" class="form-control " wire:model.defer="postalCode" required
                            style="margin-left:-25%" placeholder="Enter Your Post Code">
                        <button type="button" class="btn btn-danger " wire:click="getLatLong"
                            style="margin-top:-32%;height:44px;margin-left:100%">Search</button>
                    </div>

                    <div style="margin-left:-20%; width="120%!important" height="530px"; border: 0;">
                        <!-- Display map or iframe -->
                        <?php if(!empty($mapLink)): ?>
                        <?php echo $mapLink; ?>

                        <?php else: ?>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                            width="120%" height="530px" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php endif; ?>
                    </div>
                </div>
                <!--Show on desktop screen-->
                <div class="col-md-5 mt-4 fpostcode-map d-none d-lg-block d-md-block">
                        <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control search search_input" wire:model.defer="postalCode"
                            required placeholder="Enter Your Post Code">
                        <button type="button" class="btn btn-danger search-btn" wire:click="getLatLong">Search</button>
                    </div>
                    <div class="map-setting" style="width: 100%; height: 570px; border: 0;">
                        <!-- Display map or iframe -->
                        <?php if(!empty($mapLink)): ?>
                        <?php echo $mapLink; ?>

                        <?php else: ?>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus"
                            width="100%" height="530px" style="border: 0" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php endif; ?>
                    </div>
                </div>
                <!---------------------------------on phone screen-------------->
                <div class="col-md-3   d-lg-none d-md-none">
                    <div class="col-lg-12 px-3 boxes" style="width:370px;margin-left:-30%">
                        <!-- Display nearest branches -->
                        <?php if(!empty($nearestBranches)): ?>
                        <?php $__currentLoopData = $nearestBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <p class="fw-bold branch-name" style="font-size:5px"><?php echo e($branch['name']); ?>, <span
                                    class="distance_color"><?php echo e(number_format($branch['distance'], 2)); ?> miles</span></p>
                            <p class="address-town-post-code" style="font-size:7px;margin-top:-10px"><?php echo e($branch['address_line_1']); ?>, <?php echo e($branch['address_line_2'] ?: ''); ?>, <?php echo e($branch['town_city']); ?>, <?php echo e($branch['post_code']); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch['landline_number'])): ?>
                                    <option value="1">Landline: <?php echo e($branch['landline_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['mobile_number'])): ?>
                                    <option value="2">Mobile: <?php echo e($branch['mobile_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['email'])): ?>
                                    <option value="3" selected>Email: <?php echo e($branch['email']); ?></option>
                                    <?php endif; ?>


                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch['id']); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(!empty($branches)): ?>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <p class="fw-bold branch-name"><?php echo e($branch->name); ?></p>
                            <p class="address-town-post-code" style="margin-top:-10px"><?php echo e($branch->address_line_1); ?>, <?php echo e($branch->address_line_2 ?: ''); ?>, <?php echo e($branch->town_city); ?>, <?php echo e($branch->post_code); ?>, UK
                            </p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch->email)): ?>
                                    <option value="3" selected>Email: <?php echo e($branch->email); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->landline_number)): ?>
                                    <option value="1">Landline: <?php echo e($branch->landline_number); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->mobile_number)): ?>
                                    <option value="2">Mobile: <?php echo e($branch->mobile_number); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch->id); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <!---------------------------------desktop screen-------------->
                <div class="col-md-6 d-none d-lg-block d-md-block selection-area">
                    <div class="col-lg-12 px-3 boxes" style="height: 580px;">
                        <!-- Display nearest branches -->
                        <?php if(!empty($nearestBranches)): ?>
                        <?php $__currentLoopData = $nearestBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <h3 class="fw-bold branch-name"><?php echo e($branch['name']); ?>, <span class="distance_color"><?php echo e(number_format($branch['distance'], 2)); ?> miles</span></h3>
                            <p class="address-town-post-code"><?php echo e($branch['address_line_1']); ?>, <?php echo e($branch['address_line_2'] ?: ''); ?>, <?php echo e($branch['town_city']); ?>, <?php echo e($branch['post_code']); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch['email'])): ?>
                                    <option value="1" selected>Email: <?php echo e($branch['email']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['landline_number'])): ?>
                                    <option value="2">Landline: <?php echo e($branch['landline_number']); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch['mobile_number'])): ?>
                                    <option value="3">Mobile: <?php echo e($branch['mobile_number']); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch['id']); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(!empty($branches)): ?>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4 border p-3">
                            <h3 class="fw-bold branch-name"><?php echo e($branch->name); ?></h3>
                            <p class="address-town-post-code"><?php echo e($branch->address_line_1); ?>, <?php echo e($branch->address_line_2
                                ?: ''); ?>, <?php echo e($branch->town_city); ?>, <?php echo e($branch->post_code); ?>, UK</p>
                            <div class="form-select-btn">
                                <select class="form-select" aria-label="Contact Options">
                                    <?php if(!empty($branch->email)): ?>
                                    <option value="1" selected>Email: <?php echo e($branch->email); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->landline_number)): ?>
                                    <option value="2">Landline: <?php echo e($branch->landline_number); ?></option>
                                    <?php endif; ?>
                                    <?php if(!empty($branch->mobile_number)): ?>
                                    <option value="3">Mobile: <?php echo e($branch->mobile_number); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="button" class="btn btn-danger"
                                    wire:click="selectBranch(<?php echo e($branch->id); ?>)" @click="step = 1">Select</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

            </section>

            <!-- Step 2: Appointment Form -->
            <section id="section-2" x-show="step === 1" x-cloak >
                 
                <div class="d-none d-lg-block d-md-block">
                   <h2 class="mb-4 text-danger text-center">
<?php switch(session()->get('serviceType')):
        case (\App\Helpers\ServiceType::ACCESSORIES): ?>
            Fix your accessories at my address
            <?php break; ?>

        <?php case (\App\Helpers\ServiceType::BUY): ?>
            Buy at my address
            <?php break; ?>

        <?php case (\App\Helpers\ServiceType::SELL): ?>
            Sell at my address
            <?php break; ?>

        <?php case (\App\Helpers\ServiceType::REPAIR): ?>
            Fix at my address
            <?php break; ?>

        <?php case (\App\Helpers\ServiceType::UNLOCKING): ?>
            Unlock your device at my address
            <?php break; ?>

        <?php default: ?>
            Fix at my address
    <?php endswitch; ?>

</h2>
                    <p class="mb-4 text-center ">Confirm <span class="text-danger">Date</span>
                        <?php echo e($clinic['appointment_date']); ?> and <span class="text-danger">Time</span>
                        <?php echo e($clinic['appointment_time']); ?> for repairing your device.</p>

                    <div class="row d-flex justify-content-evenly slot-container">
                        <!-- Calendar Column -->
                        <div class="col-md-4 mb-3 left-side">
                            <?php if(Session::has('selectedDate')): ?>
                            <label class="form-label fw-bold container-fluid" aria-placeholder="Date"
                                for="appointment_date"
                                style="font-weight: 400 !important; height: 35px; border-radius: 10px; border: 1px solid silver; padding: 5px 0 5px 16px; box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px; font-size: 15px;"><?php echo e($clinic['appointment_date'] ? date('l jS F', strtotime($clinic['appointment_date'])) :
                                ''); ?></label>
                              <?php endif; ?>
                            <div class="calendar-container" style="width: 100%">
                                <div class="calendar-header d-flex justify-content-between align-items-center">
                                    <button type="button" class="btn btn-link text-danger" wire:click="previousMonth">&lt;</button>
                                    <span><?php echo e($this->currentMonth->format('F Y')); ?></span>
                                    <button type="button" class="btn btn-link text-danger" wire:click="nextMonth">&gt;</button>
                                </div>
                                <table class="table table-bordered calendar-table">
                                    <thead>
                                        <tr>
                                            <th>Mo</th>
                                            <th>Tu</th>
                                            <th>We</th>
                                            <th>Th</th>
                                            <th>Fr</th>
                                            <th>Sa</th>
                                            <th>Su</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($this->calendarDays): ?>
                                        <?php $__currentLoopData = $this->calendarDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="<?php echo e($day['class']); ?>"
                                                wire:click="selectDate('<?php echo e($day['date']); ?>')" <?php if($day['disabled']): ?>
                                                style="pointer-events: none; opacity: 0.5;" <?php endif; ?>>
                                                <?php echo e($day['day']); ?>

                                            </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="7">No dates available</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <!--<div class="calendar-footer d-flex justify-content-between">-->
                                <!--    <button type="button" class="btn btn-secondary" wire:click="cancelDateSelection">Cancel</button>-->
                                <!--    <button type="button" class="btn btn-danger" wire:click="confirmDateSelection">Choose Date</button>-->
                                <!--</div>-->
                            </div>
                            <?php $__errorArgs = ['clinic.appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Time Slot Column -->
                        <div class="col-md-6 mb-8 select-slot-div">
                            <label class="form-label fw-bold" for="appointment_time" style="font-size: 22px;">Select
                                slot</label>
                            <div class="time-slots-grid">
                                <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button"
                                    class="btn btn-outline-secondary time-slot-btn <?php echo e($clinic['appointment_time'] === $timeSlot ? 'active' : ''); ?>"
                                    wire:click="$set('clinic.appointment_time', '<?php echo e($timeSlot); ?>')">
                                    <?php echo e($timeSlot); ?>

                                </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php $__errorArgs = ['clinic.appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <style>
                            .select-slot-div {
                                border: 1px solid #d1d1d1;
                                padding: 20px 20px 0 20px;
                                border-radius: 20px;
                                box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
                                height: 380px;
                            }

                            .time-slots-grid {
                                max-height: 300px;
                                /* Adjust the height as needed */
                                overflow-y: scroll;

                                padding: 10px;
                                /* Optional: add padding for better spacing */
                            }

                            /* Scrollbar styles for WebKit browsers (Chrome, Safari) */
                            .time-slots-grid::-webkit-scrollbar {
                                width: 50px;
                                /* Adjust width as needed */
                            }

                            .time-slots-grid::-webkit-scrollbar-track {
                                background: #dc3545;
                                /* Background of the track */
                            }

                            .time-slots-grid::-webkit-scrollbar-thumb {
                                background-color: #dc3545;
                                /* Scrollbar thumb color */
                                border-radius: 10px;
                                /* Optional: round the corners */
                                border: 2px solid #dc3545;
                                /* Scrollbar thumb border color */
                            }

                            /* Scrollbar styles for Firefox */
                            .time-slots-grid {
                                scrollbar-width: thin;
                                /* "auto" or "thin" */
                            }
                        </style>
                    </div>

                    <div class="selected-datetime mb-4 d-flex justify-content-center" style="margin-left:10%">
                        <?php echo e($clinic['appointment_date'] ? date('l jS F', strtotime($clinic['appointment_date'])) : ''); ?>

                        <?php echo e($clinic['appointment_time'] ? 'at ' . $clinic['appointment_time'] : ''); ?>

                    </div>
                </div>
                <!--  the phone screen---->
                <div class=" d-lg-none d-md-none">
                   <h3 class="mb-2 text-danger text-center" style="white-space: nowrap; margin-top:-25%">Fix at my address</h3>

                   <p class="mb-4 text-center" style="width: 100%; margin: 0 auto;">
    Confirm <span class="text-danger">Date</span> <?php echo e($clinic['appointment_date']); ?> and <b><span class="text-danger">Time</span> <?php echo e($clinic['appointment_time']); ?></b> for repairing your device.
</p>


                    <div class="row slot-container">
                        <!-- Calendar Column -->
                        <div class="col-md-4 mb-3 left-side">
                          <?php if(Session::has('selectedDate')): ?>
                            <label class="form-label fw-bold container-fluid" aria-placeholder="Date"
                                for="appointment_date"
                                style="font-weight: 400 !important; height: 35px; border-radius: 10px; border: 1px solid silver; padding: 5px 0 5px 16px; box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px; font-size: 15px;"><?php echo e($clinic['appointment_date'] ? date('l jS F', strtotime($clinic['appointment_date'])) :
                                ''); ?></label>
                            <?php endif; ?>
                            <div class="calendar-container" style="width: 145%;margin-left:-22%">
                                <div class="calendar-header d-flex justify-content-between align-items-center">
                                    <button type="button" class="btn btn-link text-danger" wire:click="previousMonth">&lt;</button>
                                    <span><?php echo e($this->currentMonth->format('F Y')); ?></span>
                                    <button type="button" class="btn btn-link text-danger" wire:click="nextMonth">&gt;</button>
                                </div>
                                <table class="table table-bordered calendar-table">
                                    <thead>
                                        <tr>
                                            <th>Mo</th>
                                            <th>Tu</th>
                                            <th>We</th>
                                            <th>Th</th>
                                            <th>Fr</th>
                                            <th>Sa</th>
                                            <th>Su</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($this->calendarDays): ?>
                                        <?php $__currentLoopData = $this->calendarDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="<?php echo e($day['class']); ?>"
                                                wire:click="selectDate('<?php echo e($day['date']); ?>')" <?php if($day['disabled']): ?>
                                                style="pointer-events: none; opacity: 0.5;" <?php endif; ?>>
                                                <?php echo e($day['day']); ?>

                                            </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="7">No dates available</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <!--<div class="calendar-footer d-flex justify-content-between">-->
                                <!--    <button type="button" class="btn btn-secondary" wire:click="cancelDateSelection">Cancel</button>-->
                                <!--    <button type="button" class="btn btn-danger" wire:click="confirmDateSelection">Choose Date</button>-->
                                <!--</div>-->
                            </div>
                            <?php $__errorArgs = ['clinic.appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Time Slot Column -->
                    <div class="col-md-7 mb-8" style="width: 150%;">
    <label class="form-label fw-bold" for="appointment_time" style="font-size: 22px;">Select slot</label>
    <div class="time-slots-grid d-flex flex-wrap justify-content-center" style="width:150%;margin-left:-25%">
        <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button type="button"
            class="btn btn-outline-secondary time-slot-btn <?php echo e($clinic['appointment_time'] === $timeSlot ? 'active' : ''); ?>"
            wire:click="$set('clinic.appointment_time', '<?php echo e($timeSlot); ?>')">
            <?php echo e($timeSlot); ?>

        </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__errorArgs = ['clinic.appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>



                        <style>
                            .select-slot-div {
                                border: 1px solid #d1d1d1;

                                border-radius: 20px;
                                box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;

                            }

                            .time-slots-grid {
                                max-height: 300px;
                                /* Adjust the height as needed */
                                overflow-y: scroll;

                                padding: 10px;
                                /* Optional: add padding for better spacing */
                            }

                            /* Scrollbar styles for WebKit browsers (Chrome, Safari) */
                            .time-slots-grid::-webkit-scrollbar {
                                width: 20px;
                                /* Adjust width as needed */
                            }

                            .time-slots-grid::-webkit-scrollbar-track {
                                background: #dc3545;
                                /* Background of the track */
                            }

                            .time-slots-grid::-webkit-scrollbar-thumb {
                                background-color: #dc3545;
                                /* Scrollbar thumb color */
                                border-radius: 10px;
                                /* Optional: round the corners */
                                border: 2px solid #dc3545;
                                /* Scrollbar thumb border color */
                            }

                            /* Scrollbar styles for Firefox */
                            .time-slots-grid {
                                scrollbar-width: thin;
                                /* "auto" or "thin" */
                            }
                        </style>
                    </div>

                    <div style="display: inline;  white-space: nowrap;">
                        <?php echo e($clinic['appointment_date'] ? date('l jS F', strtotime($clinic['appointment_date'])) : ''); ?>

                        <?php echo e($clinic['appointment_time'] ? 'at ' . $clinic['appointment_time'] : ''); ?>

                    </div>

                </div>
            </section <!------- on phone screeen-------->

            <!-- Submit button  desktop-->
            <div class="d-none d-lg-block d-md-block">
                <div class="btn-style ">

                    <button class="button-20 " role="button" type="submit" x-show="step === 1">Next</button>

                 <button class="button-20" role="button" type="button" @click="step = 0" x-show="step === 1"  wire:click="goBack">Go
                        Back</button>
                </div>
            </div>
            <!--------------------phone screen-------------->
            <div class=" d-lg-none d-md-none " style="margin-top:-20%">
                <div class="btn-style ">

                    <button class="button-20" style="margin-right:-23%" role="button" type="submit"
                        x-show="step === 1">Next</button>

                    <button class="button-20" style="margin-left:-20%" role="button" type="button"
                        @click="step = 0" x-show="step === 1" wire:click="goBack">GoBack</button>
                </div>
            </div>

    </div>
    </form>
</div>

<style>
    .submit-form {
        position: relative;
    }

    .button-20 {
        appearance: button;
        /*width: 11%;*/
        background-color: #dc3545;
        background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
        border: 1px solid #dc3545;
        border-radius: 1rem;
        box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px;
        box-sizing: border-box;
        color: #FFFFFF;
        cursor: pointer;
        display: inline-block;
        font-family: Inter, sans-serif;
        font-size: 1rem;
        font-weight: 500;
        line-height: 1.7;
        margin: 0;
        padding: 6px 50px;
        text-align: center;
        text-transform: none;
        transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
        vertical-align: middle;
    }

    .button-20:focus:not(:focus-visible),
    .button-20:focus {
        outline: 0;
    }

    .button-20:hover {
        background-color: #dc3545;
        border-color: #dc3545;
    }

    .button-20:focus {
        background-color: #dc3545;
        border-color: #dc3545;
        box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
    }

    .button-20:active {
        background-color: #dc3545;
        background-image: none;
        border-color: #dc3545;
        box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
    }

    .button-20:active:focus {
        box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
    }

    .button-20:disabled {
        background-image: none;
        box-shadow: none;
        opacity: .65;
        pointer-events: none;
    }

    .calendar-container {
        border: 1px solid #dee2e6;
        border-radius: 10px;
        box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
        padding: 1rem;
        width: max-content;
    }

    .calendar-table {
        margin-bottom: 1rem;
    }

    .calendar-table th,
    .calendar-table td {
        text-align: center;
        vertical-align: middle;
        padding: 0.5rem;
    }

    .calendar-table td {
        cursor: pointer;
    }

    .calendar-table td.today {
        background-color: #f8f9fa;
    }

    .calendar-table td.selected {
        background-color: #dc3545;
        color: white;
    }

    .calendar-table td.disabled {
        color: #dee2e6;
        cursor: not-allowed;
    }

    .time-slots-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 10px;
    }

    .time-slot-btn {
        padding: 10px;
        text-align: center;
    }

    .time-slot-btn.active {
        background-color: #dc3545;
        color: white;
        border-color: #dc3545;
    }

    .selected-datetime {
        font-weight: bold;
    }

    .search {
        width: 70px;
    }

    .map-setting {
        background-color: #fff;
        border-radius: 15px;
        box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);
        padding: 17px 14px 14px;
    }

    .fpostcode-map {
        width: 40%;
        background-color: #fff;
        border-radius: 15px;
        /*box-shadow: 0 0 4px 0 rgba(0, 0, 0, .35);*/
        /*padding: 17px 14px 14px 14px;*/
    }

    .input-group {
        display: flex;
        gap: 20px;
    }

    .form-select-btn {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .distance_color {
        color: #dc3545;
    }

    .search_input {
        border-radius: 20px;
        border-top-right-radius: 20px !important;
        border-bottom-right-radius: 20px !important;
        /*box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;*/
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
    }

    .search-btn {
        border-radius: 20px;
        border-top-left-radius: 20px !important;
        border-bottom-left-radius: 20px !important;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

    }

    .address-town-post-code {
        padding-bottom: 6px;
    }

    .boxes {
        width: 700px;
        margin-top: 25px;
        height: 920px;
        overflow-y: scroll;
        /*scrollbar-color: rgb(233, 163, 163) transparent;*/
        scroll-behavior: smooth;
        /*scroll-padding: 50px;*/
    }

    .boxes div {
        border-radius: 20px;
    }

    .boxes div:nth-child(1) {
        margin-top: 0px !important;
    }

    .boxes::-webkit-scrollbar {
        width: 20px;
        height: 100px;
    }

    .btn-style {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-direction: row-reverse;
        margin-top: 100px;
    }

    .boxes::-webkit-scrollbar-track {
        background: #d1d1d1;
        border-radius: 40px;
    }

    .boxes::-webkit-scrollbar-thumb {
        background-color: #dc3545;
        border-radius: 40px;
        border: 3px solid transparent;
    }

    .find {
        color: rgb(240, 88, 88);
        font-size: 44px;
        font-weight: 900;
        text-align: center;
    }

    .search-btn {
        background-color: #da3847;
        color: white;
    }

    .s-card {
        height: 120px;
    }

    .left-side {
        width: 30%;
    }

    @media (max-width: 576px) {

        h2.find,
        p.text-center {
            margin-left: -20px;
            font-size: 15px;
        }

        .input-group {
            flex-wrap: wrap;
        }

        .input-group .form-control {
            flex: 1 1 100%;
            width: 100%;
            margin-right: 0;
            margin-bottom: 10px;
        }

        .input-group .search-btn {
            flex: 1 1 100%;
            width: 100%;
        }

        /* width: 133%;
        height: 850px;
        border: 0; */
    }

    .slot-container {
        justify-content: center;
    }

    /*///////////// Slot Responsive /////////////*/
    @media (max-width: 1400px) {
        .left-side {
            width: 35%;
        }
    }

    @media (max-width: 1400px) {
        .left-side {
            width: 40%;
        }
    }

    @media (max-width: 1024px) {
        .map-select {
            flex-direction: column;
        }

        .fpostcode-map {
            width: 100%;
        }

        .selection-area {
            width: 100%;
        }

        .boxes {
            width: 100%;
        }
    }

    @media (max-width: 900px) {
        .slot-container {
            flex-direction: column;
        }

        .select-slot-div {
            width: 100%;
        }

        .left-side {
            width: 100%;
        }

    }

    /*///////////// Slot Responsive /////////////*/
    /*-------------------------------------phone reponsive--- start-----------------*/
    @media (max-width: 320px) {

        .col-md-6 {
            flex: 0 0 auto;
            width: 300% !important;
        }
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        flatpickr("#appointment_date", {
            dateFormat: "Y-m-d",
            minDate: "today"
        });
    });
</script>


</div><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/guest/components/clinic-repair-form.blade.php ENDPATH**/ ?>
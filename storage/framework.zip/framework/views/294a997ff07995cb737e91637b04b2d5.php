<?php
use App\Helpers\ServiceType;
use App\Models\DeviceType;
use App\Models\Modal;
use App\Models\Category;
use App\Models\Branch;
$args = 'Publish';
$branches = Branch::all();
?>

<div>
    <div x-data="{ open: false, hover: false }" class="d-none d-lg-block"                                        wire:mouseleave="hideDevices"
>
        <div class="navbar-new-div">
            <nav class="navbar navbar-expand-lg navbar-light pb-4 bg-white shadow-md sticky-top " style="opacity:70%;border-radius:0%;" >
                <div class="container-fluid">
                    <a style="margin-left:40px;">     <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.logo', [])->html();
} elseif ($_instance->childHasBeenRendered('l1110899285-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1110899285-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1110899285-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1110899285-0');
} else {
    $response = \Livewire\Livewire::mount('components.logo', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1110899285-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> </a>

                    <button class="navbar-toggler" type="button" @click="open = !open">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" :class="{ 'show': open }" id="navbarContent">
                        <ul class="navbar-nav mx-auto mt-4 mb-lg-0">
                            <?php $__currentLoopData = ['repair']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($formStatuses->$service): ?>
                                    <li class="nav-item navList" style="font-size:18px;margin-right:20px;"  
                                        @mouseenter="open = true; hover = true" 
                                        @mouseleave="hover = false; setTimeout(() => { if(!hover) open = false }, 200)">
                                        <a class="nav-link navAnchor <?php echo e($selectedService == ucfirst($service) ? 'text-danger' : ''); ?>"
                                           wire:mouseenter="showDevices('<?php echo e(ucfirst($service)); ?>')"
                                           href="#collapse<?php echo e(ucfirst($service)); ?>Device">
                                            <?php echo $webContent->{"mega_nav_$service"}; ?>

                                            <b class="separator"> | </b> 
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            <?php $__currentLoopData = ['About Us', 'Blog', 'Stores']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item navList" style="margin-right:20px;">
                                    <a class="nav-link navAnchor" href="<?php echo e(url(strtolower(str_replace(' ', '', $item)))); ?>"
                                       wire:mouseleave="hideDevices"
                                       @mouseleave="open = false">
                                        <?php echo e($item); ?>

                                        <?php if(!$loop->last): ?>  <b class="separator"> | </b> <?php endif; ?>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($formStatuses->accessories): ?>
                                <li class="nav-item navList">
                                    <a class="nav-link navAnchor" href="<?php echo e(route('khuram')); ?>">
                                        Accessories
                                        <i class="bi bi-chevron-down"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>

                        <div class="d-flex align-items-center">
                            <div class="add-to-cart">
                                <p class="card-quantity">0</p>
                                <i class="bi bi-cart"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>

        <?php if($show): ?>
            <div class="dropmenu card card-body rounded" @mouseenter="hover = true" @mouseleave="hover = false; setTimeout(() => { if(!hover) open = false }, 200)" style="opacity:70%;" >
                <div class="d-flex flex-wrap text-wrap scroll-css">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $devices_count = DeviceType::where('category_id', $category->id)
                                ->where('status', $args)
                                ->count();
                            $devices = DeviceType::where('category_id', $category->id)
                                ->where('status', $args)
                                ->limit(4)
                                ->get();
                        ?>

                        <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex flex-column py-0 my-1">
                                <li class="fw-bolder navList" style="margin-left:20px">
                                    <a href="#" class="navAnchor" style="color: #db3444 !important; padding: 0px !important; margin: 0px !important; white-space: normal;">
                                        <?php echo e($device->name); ?> 
                                    </a>
                                    <?php
                                        // Determine the limit based on the device type
                                        $limit = ($device->name == 'Apple') ? 10 : 5;

                                        $models_count = Modal::where('device_type_id', $device->id)
                                            ->where('status', $args)
                                            ->count();
                                        
                                        $models = Modal::where('device_type_id', $device->id)
                                            ->where('status', $args)
                                            ->limit($limit)
                                            ->get();
                                    ?>

                                    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="navList" style="margin-left:20px;">
                                            <?php if($selectedService == 'Sell'): ?>
                                                <a href="<?php echo e(route('guest-sell-model-detail', $model->id)); ?>" class="navAnchor" style="color: black; display: block; text-align: left; font-weight:normal;padding: 0px !important; margin: 4px 0 0 0 !important">
                                                    <?php echo e($model->name); ?>

                                                </a>
                                            <?php elseif($selectedService == 'Buy'): ?>
                                                <a href="<?php echo e(route('guest-buy-product-specs', $model->id)); ?>" class="navAnchor" style="color: black; display: block; text-align: left; font-weight:normal;padding: 0px !important; margin: 4px 0 0 0 !important">
                                                    <?php echo e($model->name); ?>

                                                </a>
                                            <?php elseif($selectedService == 'Repair'): ?>
                                                <a href="<?php echo e(route('repair-types', ['device' => $device->id, 'modal' => $model->id])); ?>" class="navAnchor" style="color: black; display: block; text-align: left; font-weight:normal;padding: 0px !important; margin: 4px 0 0 0 !important">
                                                    <?php echo e($model->name); ?>

                                                </a>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($models_count > $models->count()): ?>
                                        <li class="navList">
                                            <?php if($selectedService == 'Sell'): ?>
                                                <a href="<?php echo e(route('guest-sell-models', $device->id)); ?>" class="btn text-dark fw-bolder navAnchor" style="font-size: 13px; text-align: left;color:  #db3444 !important;font-size: 15px;">
                                                    See More
                                                </a>
                                            <?php elseif($selectedService == 'Buy'): ?>
                                                <a href="<?php echo e(route('guest-buy-product-specs', $device->id)); ?>" class="btn text-dark fw-bolder navAnchor" style="font-size: 13px; text-align: left;color:  #db3444 !important;font-size: 15px;">
                                                    See More
                                                </a>
                                            <?php elseif($selectedService == 'Repair'): ?>
                                                <a href="<?php echo e(route('modals', $device->id)); ?>" class="btn text-dark fw-bolder navAnchor" style="font-size: 13px; text-align: left;color:  #db3444 !important;font-size: 15px;">
                                                    See More
                                                </a>
                                            <?php endif; ?>
                                        </li>
                                    <?php endif; ?>
                                </li>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <br>
                        <?php if($devices_count > $devices->count()): ?>
                            <?php if($selectedService == 'Sell'): ?>
                                <li class="see-all-devices navList">
                                    <a href="<?php echo e(route('guest-sell-device-types', $category->id)); ?>" class="navAnchor">
                                        <span class="btn text-dark fw-bolder see-all-color" style="font-size: 13px;text-align: right">See all Sell Devices</span>
                                    </a>
                                </li>
                            <?php elseif($selectedService == 'Buy'): ?>
                                <li class="see-all-devices navList">
                                    <a href="<?php echo e(route('guest-buy-products')); ?>" class="navAnchor">
                                        <span class="btn text-dark fw-bolder see-all-color" style="font-size: 13px;text-align: right">See all Buy Devices</span>
                                    </a>
                                </li>
                            <?php elseif($selectedService == 'Repair'): ?>
                                <li class="see-all-devices navList">
                                    <a href="<?php echo e(route('modals', $category->id)); ?>" class="navAnchor">
                                        <span class="btn text-dark fw-bolder see-all-color" style="font-size: 13px;text-align: right">See all Repair Devices</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

<style>
        @import url('https://fonts.googleapis.com/css2?family=Merriweather:wght@300;400;700;900&display=swap');

        .navbar-nav {
            gap: 10px;
            font-weight: 600;
            font-family: "Merriweather", serif;
            font-size:18px;
        }

        .separator {
            color: #db3444;
            
        }

        .navList {
            list-style: none;
            text-decoration: none;
        }
        .navList > a {
            color: red;
        }
        .add-to-cart {
            width: 42px;
            height: 42px;
            padding: 6px;
            background: #db3444;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .add-to-cart i {
            font-size: 22px;
        }

        .card-quantity {
            position: absolute;
            color: white;
            background: black;
            width: 14px;
            height: 14px;
            text-align: center;
            line-height: 12px;
            border-radius: 50%;
            margin: -10px 0 0 -10px;
            padding: 0;
            font-size: 11px;
            font-weight: bold;
        }
        .navAnchor {
            text-decoration: none;
            color: inherit;
        }
        .navAnchor:hover {
            color: #db3444 !important;
        }
        .see-all-color {
            color: #db3444;
        }
        .see-all-devices {
            margin-left: 10px;
        }

        .navbar-new-div {
            position: relative;
        }

        .scroll-css {
            overflow-y: auto;
            max-height: 400px;
        }
        .d-none {
            display: none;
        }
        @media (min-width: 992px) {
            .d-lg-block {
                display: block;
            }
        }
    </style>



<div class="d-md-none d-lg-none">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css"
            integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
            crossorigin="anonymous"></script>
        <link href='https://fonts.googleapis.com/css?family=Rubik' rel='stylesheet'>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"
            integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
            crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="khuram..css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"></script>
        <script src="https://kit.fontawesome.com/87a1c0632c.js" crossorigin="anonymous"></script>
    </head>
    

    <style>
        /* Custom CSS for dropdown positioning */
        .nav-item:hover .dropdown-menu {
            display: none;
        }

        a {
            text-decoration: none !important;
            color: black !important;
            
        }

      a:hover {
            text-decoration: none !important;
            color:#db3444 !important;
            
        }

        .khur a:hover {
            color: red !important;
        }
    </style>

    <style>
        .custom-carousel-inner {
            padding: 1em;
        }

        .navbar-css {
            border-radius: 0px !important;
        }
   
       
   
    

        .dropmenu {
            /*margin: 0 .5em;*/
            /* box-shadow: 2px 6px 8px 0 rgba(22, 22, 26, 0.18); */
            border: none;
            border-radius: 5px !important;
            box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
            z-index: 100;
            height:auto;
            width:60%;
            position:absolute;
            right:120px;
        }

    </style>
    
    <div style="overflow: hidden;">

        <!--top bar for mobile screen ends-->

        <!-- Navbar -->

        <!--two icons in same row -->
        
        <style>
            /* Adjustments to make it fit better */
            .image-container,
            .icon-container {
                height: 100px;
                /* Adjust height as needed */
            }

            .icon-container i {
                font-size: 3rem;
                /* Adjust icon size as needed */
                color: #333;
            }
        </style>
        <!--ends here-->
    </div>


    <!--navbar for mobile screen only-->
    <!--first nav style-->
    
    <style>
        .nav-pills>li>a {
            border-radius: 0;
        }

        /*.search_bar{*/
        /*    border-radius: 20px;*/
        /*    border: .5px solid #202020;*/
        /*}*/
        #wrapper {
            padding-left: 0;
            -webkit-transition: all 0.5s ease;
            -moz-transition: all 0.5s ease;
            -o-transition: all 0.5s ease;
            transition: all 0.5s ease;
            overflow: hidden;
        }

        #wrapper.toggled {
            padding-left: 250px;
            overflow: hidden;
        }

        #sidebar-wrapper {
            z-index: 1000;
            position: absolute;
            left: 250px;
            width: 0;
            height: 100%;
            margin-left: -250px;
            overflow-y: auto;
            background: white;
            color: black;
            -webkit-transition: all 0.5s ease;
            -moz-transition: all 0.5s ease;
            -o-transition: all 0.5s ease;
            transition: all 0.5s ease;
        }

        #wrapper.toggled #sidebar-wrapper {
            width: 250px;
        }

        #page-content-wrapper {
            position: absolute;
            padding: 15px;
            width: 100%;
            overflow-x: hidden;
        }

        .xyz {
            min-width: 360px;
        }

        #wrapper.toggled #page-content-wrapper {
            position: relative;
            margin-right: 0px;
        }

        .fixed-brand {
            width: auto;
        }

        /* Sidebar Styles */

        .sidebar-nav {
            position: absolute;
            top: 0;
            width: 250px;
            margin: 0;
            padding: 0;
            list-style: none;
            margin-top: 2px;
        }

        .sidebar-nav li {
            text-indent: 15px;
            line-height: 40px;
        }

        .sidebar-nav li a {
            display: block;
            text-decoration: none;
            color: black;
        }

        .sidebar-nav li a:hover {
            text-decoration: none;
            color: #fff;
            /*background: rgba(255, 255, 255, 0.2);*/
            background-color: red;
            border-left: red 2px solid;
        }

        .sidebar-nav li a:active,
        .sidebar-nav li a:focus {
            text-decoration: none;
        }

        .sidebar-nav>.sidebar-brand {
            height: 65px;
            font-size: 18px;
            line-height: 60px;
        }

        .sidebar-nav>.sidebar-brand a {
            color: #999999;
        }

        .sidebar-nav>.sidebar-brand a:hover {
            color: #fff;
            background: none;
        }

        .no-margin {
            margin: 0;
        }

        @media (min-width: 768px) {
            #wrapper {
                padding-left: 250px;
            }

            .fixed-brand {
                width: 250px;
            }

            #wrapper.toggled {
                padding-left: 0;
            }

            #sidebar-wrapper {
                width: 250px;
            }

            #wrapper.toggled #sidebar-wrapper {
                width: 250px;
            }

            #wrapper.toggled-2 #sidebar-wrapper {
                width: 50px;
            }

            #wrapper.toggled-2 #sidebar-wrapper:hover {
                width: 250px;
            }

            #page-content-wrapper {
                padding: 20px;
                position: relative;
                -webkit-transition: all 0.5s ease;
                -moz-transition: all 0.5s ease;
                -o-transition: all 0.5s ease;
                transition: all 0.5s ease;
            }

            #wrapper.toggled #page-content-wrapper {
                position: relative;
                margin-right: 0;
                padding-left: 250px;
            }

            #wrapper.toggled-2 #page-content-wrapper {
                position: relative;
                margin-right: 0;
                margin-left: -200px;
                -webkit-transition: all 0.5s ease;
                -moz-transition: all 0.5s ease;
                -o-transition: all 0.5s ease;
                transition: all 0.5s ease;
                width: auto;
            }
        }
    </style>
    <!---->


    <!--second nav style-->
    
    <style>
        .smart-btn button+button {
            --_c: grey;
            flex: calc(.75 + var(--_s, 0));
            background:
                conic-gradient(from -90deg at calc(1.3*var(--b)) 100%, var(--_c) 119deg, #0000 121deg) border-box;
            clip-path: polygon(calc(0.577*var(--h)) 0, 100% 0, 100% 100%, 0 100%);
            margin: 0 0 0 calc(-0.288*var(--h));
            padding: 0 0 0 calc(0.288*var(--h));
        }

        .smart-btn button:focus-visible {
            outline-offset: calc(-2*var(--b));
            outline: calc(var(--b)/2) solid #000;
            background: none;
            clip-path: none;
            margin: 0;
            padding: 0;
        }

        .smart-btn button:focus-visible+button {
            background: none;
            clip-path: none;
            margin: 0;
            padding: 0;
        }

        .smart-btn button:has(+ button:focus-visible) {
            background: none;
            clip-path: none;
            margin: 0;
            padding: 0;
        }

        button:hover,
        button:active:not(:focus-visible) {
            --_s: .75;
        }

        button:active {
            box-shadow: inset 0 0 0 100vmax var(--_c);
            color: #fff;
        }

        .bg-gradient-danger {
            background-image: var(--linear-red);
        }

        .address label.active {
            background: white;
            padding: 9px 16px 13px 16px;
            color: black;
        }

        .label::before {
            content: '+';
            font-weight: 600;
            float: right;
        }

        /* Style for the label when the accordion is checked (open) */
        .accordion:checked+.label::before {
            content: '-';
        }

        /* Style for the content of the accordion */
        .content {
            display: none;
            padding: 10px;
        }

        /* Style for the content when the accordion is checked (open) */
        .accordion:checked+.label+.content {
            display: block;
        }
    </style>

    <!--ends here-->

    <div style="position:relative; left:60px;top:13px;" class="container d-lg-none d-md-none"></div>

    <div class="d-lg-none d-md-none">
        <nav class="navbar navbar-default no-margin bg-white">
            <!-- Brand and toggle get grouped for better mobile display -->
    
            <div class="row justify-content-left">
                <div class="col-2">
                    <div class="navbar-header fixed-brand">
                        <button style="" type="button" class="navbar-toggle fa fa-bars collapsed border-0 fs-1 bg-white"
                            data-toggle="collapse" id="menu-toggle">
                            <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>
                        </button>
                        <!--<a class="navbar-brand" href="#"><i class="fa fa-bars fa-4"></i> M-33</a>-->
        
                    </div>
                </div>
                <div class="col-10"> <!-- Adjust the column size based on your preference -->
            
                    <div class="input-group ">
                        <input style="border-radius: 50px 0 0 50px; padding: 10px; border: 1px solid red; " type="text"
                            class="form-control" placeholder="Enter Email" aria-label="Enter something"
                            aria-describedby="button-addon2">
                        <div class="input-group-append">
                            <button style="border-radius: 0 50px 50px 0;font-size:10px;"
                                class="btn btn-danger text-white w-100" type="button"
                                id="button-addon2">Subscribe</button>
                        </div>
                    </div>
                </div>

            </div>


            <!-- navbar-header-->
        
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <button class="navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2"> <span
                                class="glyphicon glyphicon-th-large" aria-hidden="true"></span>
                        </button>
                    </li>
                </ul>
            </div>
            <!-- bs-example-navbar-collapse-1 -->
            
            
        </nav>
        <div style="background-color:white;" id="wrapper">
            <!-- Sidebar -->
            
            <div style="background-color:white;" id="sidebar-wrapper">
                <div class="accordion-container  mt-2 border-white ">
                    <input type="checkbox" class="accordion d-none " id="accordion-1">
                    <label style="background-color:white;"
                        class="label d-block p-2 bg-gray cursor-pointer border-bottom " for="accordion-1">Sell Your
                        Device </label>
                    <div style="" class="content col-12 bg-white">

                        <!--dynamic data -->
                
                        <style>
                            .accordion-icon::before,
                            .accordion-icon::after {
                                content: '';
                                display: inline-block;
                                width: 8px;
                                height: 8px;
                                border-left: 2px solid currentColor;
                                border-bottom: 2px solid currentColor;
                                transform: rotate(-180deg);
                                transition: transform 0.3s;
                            }

                            .accordion-icon::after {
                                transform: rotate(135deg);
                            }

                            .accordion-icon-open::before {
                                transform: rotate(180deg);
                            }

                            .accordion-icon-open::after {
                                transform: rotate(-180deg);
                            }
                        </style>

                        <div style="margin-top:-50%;">
                            <?php
                            $categories = Category::where('service', ServiceType::SELL)->where('status', $args)->get();
                            ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $categoryId = 'category_' . $category->id; ?>
                            <li style="margin-bottom:-10px;list-style:none;" class="col-12 p-0 m-0 ">
                                <a href="#" class="fw-bolder" style=" font-size: 16px; "
                                    onclick="toggleAccordion('<?php echo e($categoryId); ?>')">
                                    <?php echo e($category->name); ?> 
                                    <span id="icon_<?php echo e($categoryId); ?>" class="special-toggle-icon" style="position:absolute;right:-2px;"></span>
                                    <!--<i style="position:absolute;right:-10px;"-->
                                        <!--id="icon_<?php echo e($categoryId); ?>" class="  bi bi-chevron-down ms-3 fs-5 "></i>-->
                                </a>
                                <ul id="<?php echo e($categoryId); ?>"
                                    style="display: none; border-top: 2px solid #e1e1e1; list-style-type: none; padding: 0;">
                                    <div class="d-flex flex-column">
                                        <?php
                                        $devices_count= DeviceType::where('category_id', $category->id)->where('status',
                                        $args)->count();
                                        $devices= DeviceType::where('category_id', $category->id)->where('status',
                                        $args)->limit(4)->get();
                                        ?>
                                        <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex flex-column">
                                            <?php $deviceId = 'device_' . $device->id; ?>
                                            <li class="fw-bolder" style="margin-bottom:-10px;">
                                                <a href="#"
                                                    style="color: black; white-space: normal; display: block; padding: 5px;font-size:14px;"
                                                    onclick="toggleAccordion('<?php echo e($deviceId); ?>')">
                                                    <?php echo e($device->name); ?>

                                                    <span id="icon_<?php echo e($deviceId); ?>" class="special-toggle-icon" style="position:absolute;right:-2px;"></span>
                                                  <!--    <i style="position:absolute;right:-10px;"
                                                        id="icon_<?php echo e($deviceId); ?>"
                                                        class="bi bi-chevron-down ml-2 fs-5 "></i> -->
                                                </a>
                                                <ul id="<?php echo e($deviceId); ?>"
                                                    style="display: none; list-style-type: none; padding: 0;">
                                                    <?php
                                                    $models_count = Modal::where('device_type_id',
                                                    $device->id)->where('status', $args)->count();
                                                    $models = Modal::where('device_type_id',
                                                    $device->id)->where('status', $args)->limit(7)->get();
                                                    ?>
                                                    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('guest-sell-model-detail', $model->id)); ?>"
                                                            style="color: black; display: block; text-align: left;font-weight:normal;margin-left:10px;">
                                                            <?php echo e($model->name); ?>

                                                        </a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($models_count > $models->count()): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('guest-sell-models', $device->id)); ?>"
                                                            class="btn text-dark fw-bolder"
                                                            style="font-size: 13px; text-align: left;">
                                                            See all models
                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </li>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($devices_count > $devices->count()): ?>
                                        <li>
                                            <a href="<?php echo e(route('guest-sell-device-types', $category->id)); ?>">
                                                <span class="btn text-dark fw-bolder" style="font-size: 13px;">See all
                                                    Devices</span>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                    </div>
                                </ul>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <script>
                            function toggleAccordion(elementId) {
                                var element = document.getElementById(elementId);
                                var icon = document.getElementById('icon_' + elementId);
                                if (element.style.display === "none") {
                                    element.style.display = "block";
                                    icon.classList.add('accordion-icon-open');
                                } else {
                                    element.style.display = "none";
                                    icon.classList.remove('accordion-icon-open');
                                }
                            }
                        </script>
                        <!--ends here-->

                    </div>
                </div> 
                
                <div class="accordion-container  border-white">
                    <input type="checkbox" class="accordion d-none " id="accordion-buy">
                    <label style="background-color:white;"
                        class="label d-block p-2 bg-gray cursor-pointer border-bottom " for="accordion-buy">Buy A
                        Device</label>
                    <div class="content bg-white ">
                        <!--dynamic data for buy a device-->
    
                        <style>
                            .custom-accordion-icon::before,
                            .custom-accordion-icon::after {
                                content: '';
                                display: inline-block;
                                width: 8px;
                                height: 8px;
                                border-left: 2px solid currentColor;
                                border-bottom: 2px solid currentColor;
                                transform: rotate(-180deg);
                                transition: transform 0.3s;
                            }

                            .custom-accordion-icon::after {
                                transform: rotate(135deg);
                            }

                            .custom-accordion-icon-open::before {
                                transform: rotate(180deg);
                            }

                            .custom-accordion-icon-open::after {
                                transform: rotate(-180deg);
                            }
                            .special-toggle-icon::before {
                                content: '\002B'; 
                                font-size: 16px; 
                                font-weight: bold;
                                color: black; 
                            }
                            .accordion-icon-open.special-toggle-icon::before {
                                content: '-'; 
                            }
                        </style>

                        <div style="margin-top:-50%;">
                            <?php
                            $categories = Category::where('service', ServiceType::BUY)->where('status', $args)->get();
                            ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $categoryId = 'custom_category_' . $category->id; ?>
                            <li style="margin-bottom:-10px;list-style:none;" class="col-12 p-0 m-0">
                                <a href="#" class="text-black fw-bolder"
                                    style=" display: block; font-size: 16px;white-space:nowrap; "
                                    onclick="toggleAccordion('<?php echo e($categoryId); ?>')">
                                    <?php echo e($category->name); ?>

                                    <span id="icon_<?php echo e($categoryId); ?>" class="special-toggle-icon" style="position:absolute;right:-2px;"></span>
                                    
                                    <!--<i style="position:absolute;right:-10px;"
                                        id="custom_category_icon_<?php echo e($categoryId); ?>"
                                        class="bi bi-chevron-down fs-5  "></i> -->
                                </a>
                                <ul id="<?php echo e($categoryId); ?>" style="display: none;  list-style: none; padding: 0;">
                                    <div class="">
                                        <?php
                                        $devices_count= DeviceType::where('category_id', $category->id)->where('status',
                                        $args)->count();
                                        $devices= DeviceType::where('category_id', $category->id)->where('status',
                                        $args)->limit(7)->get();
                                        ?>
                                        <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="">
                                            <?php $deviceId = 'custom_device_' . $device->id; ?>
                                            <li class=" mb-2">
                                                <a href="#" class="text-black fw-bold" style="font-size: 16px;"
                                                    onclick="toggleAccordion('<?php echo e($deviceId); ?>')">
                                                    <?php echo e($device->name); ?>

                                                    <span id="icon_<?php echo e($deviceId); ?>" class="special-toggle-icon" style="position:absolute;right:-2px;"></span>
                                                    
                                                <!--    <i style="position:absolute;right:-10px;"
                                                        id="custom_device_icon_<?php echo e($deviceId); ?>"
                                                        class="bi bi-chevron-down ml-2 fs-5  "></i> -->
                                                </a>
                                                <ul id="<?php echo e($deviceId); ?>"
                                                    style="display: none; list-style-type: none; padding: 0;">
                                                    <?php
                                                    $models_count = Modal::where('device_type_id',
                                                    $device->id)->where('status', $args)->count();
                                                    $models = Modal::where('device_type_id',
                                                    $device->id)->where('status', $args)->get();
                                                    ?>
                                                    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('guest-buy-product-specs', $model->id)); ?>"
                                                            style="color: black; display: block; text-align: left;font-size:12px;">
                                                            <?php echo e($model->name); ?>

                                                        </a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($models_count > $models->count()): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('guest-buy-product-specs', $device->id)); ?>"
                                                            class="btn text-dark fw-bolder"
                                                            style="font-size: 13px; text-align: left;">
                                                            See all models
                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </li>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($devices_count > $devices->count()): ?>
                                        <li><a href="<?php echo e(route('guest-buy-product-specs', $category->id)); ?>"
                                                class="btn text-dark fw-bolder"
                                                style="font-size:13px; color: #db3444 !important">See all devices</a></li>
                                        <?php endif; ?>
                                    </div>
                                </ul>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <script>
                            function toggleCustomAccordion(elementId) {
                                var element = document.getElementById(elementId);
                                var icon = document.getElementById('custom_category_icon_' + elementId) || document.getElementById('custom_device_icon_' + elementId);
                                if (element.style.display === "none") {
                                    element.style.display = "block";
                                    icon.classList.add('custom-accordion-icon-open');
                                } else {
                                    element.style.display = "none";
                                    icon.classList.remove('custom-accordion-icon-open');
                                }
                            }
                        </script>
                        <!--ends here-->

                    </div>
                </div>
                <div class="accordion-container  border-white">
                    <input type="checkbox" class="accordion d-none " id="accordion-repair">
                    <label class="label d-block p-2 bg-white cursor-pointer border-bottom "
                        for="accordion-repair">Repair A Device</label>
                    <div style="" class="content bg-white">
                        <style>
                            .custom-accordion-icon::before,
                            .custom-accordion-icon::after {
                                content: '';
                                display: inline-block;
                                width: 8px;
                                height: 8px;
                                border-left: 2px solid currentColor;
                                border-bottom: 2px solid currentColor;
                                transform: rotate(-180deg);
                                transition: transform 0.3s;
                            }

                            .custom-accordion-icon::after {
                                transform: rotate(135deg);
                            }

                            .custom-accordion-icon-open::before {
                                transform: rotate(180deg);
                            }

                            .custom-accordion-icon-open::after {
                                transform: rotate(-180deg);
                            }
                            .special-toggle-icon::before {
                                content: '\002B'; 
                                font-size: 16px; 
                                font-weight: bold;
                                color: black; 
                            }
                            .accordion-icon-open.special-toggle-icon::before {
                                content: '-'; 
                            }
                        </style>

                        <div style="background-color: white;margin-top:-120px;">
                            <?php
                            $categories = Category::where('service', ServiceType::REPAIR)->where('status',
                            $args)->limit(6)->get();
                            ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php $categoryId = 'repair_category_' . $category->id; ?>
                            <li style="list-style:none;" class="mt-2">
                                
                                <p data-bs-toggle="dropdown" aria-expanded="false"
                                    class="justify-content-between bg-white" style="color: #000;">
                                    <span
                                        style="flex-grow: 1; font-size: 15px; font-weight: bolder; white-space: nowrap;">&nbsp;
                                        &nbsp;&nbsp;<?php echo e($category->name); ?></span>

                                    <span >
                                        <i id="repair_icon_<?php echo e($categoryId); ?>" 
                                            style="color: #7c7777; list-style: none;"
                                            onclick="toggleAccordion('<?php echo e($categoryId); ?>')">
                                                <spa id="icon_<?php echo e($categoryId); ?>" class="special-toggle-icon" style="position:absolute;right:8px;" ></spa>
                                            
                                            
                                        </i>
                                                                        
                                    
                                    </span>
                                    
                                    

    
                                  
                                </p>
                                <ul id="<?php echo e($categoryId); ?>" class="" style="display: none;list-style:none; ">
                                    <div class="">
                                        <?php
                                        $devices_count= DeviceType::where('category_id', $category->id)->where('status',
                                        $args)->count();
                                        $devices = DeviceType::where('category_id', $category->id)->where('status',
                                        $args)->limit(7)->get();
                                        ?>
                                        <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $deviceId = 'repair_device_' . $device->id; ?>
                                        <div class="mt-3">
                                            <li>
                                                <p style="color:black; white-space: normal; cursor: pointer;"
                                                    onclick="toggleAccordion('<?php echo e($deviceId); ?>')">
                                                    <strong><?php echo e($device->name); ?></strong>
                                                      <span id="icon_<?php echo e($deviceId); ?>" class="special-toggle-icon" style="position:absolute;right:8px;"></span>
                                    
                                                    
                                                </p>
                                            </li>
                                            <ul id="<?php echo e($deviceId); ?>" style="display: none;list-style:none;">
                                                <?php
                                                $models_count = Modal::where('device_type_id',
                                                $device->id)->where('status', $args)->count();
                                                $models = Modal::where('device_type_id', $device->id)->where('status',
                                                $args)->limit(8)->get();
                                                ?>
                                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(route('repair-types', ['device' => $device->id, 'modal' => $model->id])); ?>"
                                                        style="color: black;line-height: normal;height: auto;white-space:nowrap;margin-left:-40px;"><?php echo e($model->name); ?></a>
                                                </li>
                                                <li class="mx-auto" style="width:90%"></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($models_count > $models->count()): ?>
                                                <li><a href="<?php echo e(route('modals', $device->id)); ?>"
                                                        style="line-height: normal;height: auto;padding:1px;"><span
                                                            class="btn text-dark fw-bolder" style="font-size:13px">See
                                                            more</span></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($devices_count > $devices->count()): ?>
                                        <li><a href="<?php echo e(route('device-types', $category->id)); ?>"><span
                                                    class="btn text-dark fw-bolder" style="font-size:13px">See
                                                    more</span></a></li>
                                        <?php endif; ?>
                                    </div>
                                </ul>
                            </li>
                            <li class="drop-menu-item ml-3" style="border-bottom: 1px solid #e1e1e1;width:90%"></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <script>
                            function toggleRepairAccordion(elementId) {
                                var element = document.getElementById(elementId);
                                var icon = document.getElementById('repair_icon_' + elementId);
                                if (element.style.display === "none") {
                                    element.style.display = "block";
                                    icon.classList.add('custom-accordion-icon-open');
                                } else {
                                    element.style.display = "none";
                                    icon.classList.remove('custom-accordion-icon-open');
                                }
                            }

                            function toggleModelVisibility(deviceId) {
                                var models = document.getElementById(deviceId);
                                if (models.style.display === "none") {
                                    models.style.display = "block";
                                } else {
                                    models.style.display = "none";
                                }
                            }
                        </script>
                    </div>
                    <!--ends here-->

                </div>
                <div class="accordion-container  border-white">
                <input type="checkbox" class="accordion d-none " id="accordion-repair">
                                <div class="">
                    <p style="margin-left:10px" class="mt-5" > <a href="<?php echo e(route('aboutus')); ?>"> About Us</a> </p>
                    <hr>
                    <p class="mt-2"><a href="<?php echo e(route('blog')); ?>" style="margin-left:10px"> Blogs </a></p>
                    <hr>
                    <p class="mt-2"><a href="<?php echo e(route('stores')); ?>" style="margin-left:10px">Find a Store </a></p>
                </div>
                <div style="" class="content bg-white">
                    <style>
                        .custom-accordion-icon::before,
                        .custom-accordion-icon::after {
                            content: '';
                            display: inline-block;
                            width: 8px;
                            height: 8px;
                            border-left: 2px solid currentColor;
                            border-bottom: 2px solid currentColor;
                            transform: rotate(-180deg);
                            transition: transform 0.3s;
                        }

                        .custom-accordion-icon::after {
                            transform: rotate(135deg);
                        }

                        .custom-accordion-icon-open::before {
                            transform: rotate(180deg);
                        }

                        .custom-accordion-icon-open::after {
                            transform: rotate(-180deg);
                        }
                    </style>

         <div style="background-color: white;margin-top:-120px;">
             
        

            </div>
            </div>
            <!--new content ends here-->

        </div>
    </div>
</div>

<!--new scripts-->

<script>


    function changeRadioButton() {

        document.getElementById("text").innerHTML = "<div class=\'fs-6\'><h3>IS A REFURBISHED IPHONE 12 MINI AS GOOD AS A NEW ONE?</h3>When a product gets refurbished, the technicians get it as close to brand new as they can. That means resetting everything so it’s just like the phone is fresh out the box. So, in many ways, it practically is a new phone.</br></br>While some second hand iPhone 12 Mini models may have slight cosmetic marks, it's nothing a case won’t cover and the saving you make on a second-hand model more than makes up for it!<h3 class=\'mt-5\'>DOES A REFURBISHED IPHONE 12 MINI HAVE A WARRANTY?</h3>It does any second-hand iPhone 12 mini you buy with Mazuma will have a 13-month warranty. This will cover electrical or technical faults, so all you have to do is let us know. It doesn’t cover against wear and tear once you’re using it though. Check our full warranty rundown for more info.<h3 class=\'mt-5\'>WILL MY REFURBISHED IPHONE 12 MINI COME IN THE ORIGINAL BOX?</h3>Some of our second hand iPhone 12 Mini listings will be sent to you in their original box looking as good as new. Where a listing doesn’t have its original box, we’ll still package it up carefully in a replacement so you can enjoy that fresh-out-the-box feeling.</div>"

        document.getElementById("style-div").style.background = "#e1e1e1";
        document.getElementById("style-div").style.color = "black";



        document.getElementById("detail").style.background = "#e1e1e1";
        document.getElementById("detail").style.color = "black";

        document.getElementById("specification").style.background = "white";
        document.getElementById("specification").style.color = "gray";

        document.getElementById("warranty").style.background = "white";
        document.getElementById("warranty").style.color = "gray";

        document.getElementById("review").style.background = "white";
        document.getElementById("review").style.color = "gray";


    }

    function changeRadioButton2() {
        document.getElementById("text").innerHTML = "<div class=\'p-3 \'>Touchscreen &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; Haptic Touch</span></br>SIM Size(s)&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; nano-SIM • eSIM</br>Sensor Type(s) &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; LiDAR</br>Screen Type &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	OLED</br>Product Family  &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	iPhone 12 mini</br>Operating System	 &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;iOS 14</br>Chipset  &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	A14</br>Camera Features  &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;Night mode</br>Built in Camera  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;	Yes</br>Bluetooth Version  &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;	&nbsp; 5</br>Item Returns	 &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This item can be returned</div>";

        document.getElementById("style-div").style.background = "#e1e1e1";
        document.getElementById("style-div").style.color = "black";


        document.getElementById("specification").style.background = "#e1e1e1";
        document.getElementById("specification").style.color = "black";

        document.getElementById("detail").style.background = "white";
        document.getElementById("detail").style.color = "gray";

        document.getElementById("warranty").style.background = "white";
        document.getElementById("warranty").style.color = "gray";

        document.getElementById("review").style.background = "white";
        document.getElementById("review").style.color = "gray";


    }

    function changeRadioButton3() {
        document.getElementById("text").innerHTML = "<div class=\'fs-6\'><h3>13 MONTH WARRANTY INCLUDED</h3></br><p class=\'fs-6 fw-bold\'>What’s better than a 12-month warranty for your new device?</p>A 13-month warranty, I hear you say!</br></br><p class=\'fs-6 fw-bold\'>What does the Mobilebitz Shop Warranty 13 cover?</p>Let’s keep this simple! In short, any fault or issue with the phone that is not due to any fault of yours.</br></br><p class=\'fs-6 fw-bold\'>What’s unfortunately not covered?</p>Here at Mobilebitz Shop we know accidents can happen, and your phone is usually with you wherever you go, a pub, a club and skydiving for example. Unfortunately, if your phone is damaged, dropped, or it's stopped working because of any non OEM software upgrades changes, we will not be able to cover you.</br></br>Here’s a little list to make this a little simpler for what we do not cover:</br></br>1.Jailbreak attempts or corruption caused by attempts to unlock a device</br>2.Damage and cracks to a device body or screen</br>3.Liquid damage</br>4.Accidental or intentional damage</br>5.Damaged caused by attempted repairs or third party attempted repairs.</br>6.Use on non-genuine parts in any repair (we check this using Phonecheck)</br>7.Normal wear and tear caused for your use of the device</br>8.Faults caused by a reduction in battery health below our provided capacity</br>9.Use of non-genuine accessories or improper use of accessories</div>";

        document.getElementById("style-div").style.background = "#e1e1e1";
        document.getElementById("style-div").style.color = "black";


        document.getElementById("warranty").style.background = "#e1e1e1";
        document.getElementById("warranty").style.color = "black";

        document.getElementById("detail").style.background = "white";
        document.getElementById("detail").style.color = "gray";

        document.getElementById("specification").style.background = "white";
        document.getElementById("specification").style.color = "gray";

        document.getElementById("review").style.background = "white";
        document.getElementById("review").style.color = "gray";
    }

    function sellStore() {
        document.getElementById("result").innerHTML = " <div class=\'mb-3 mt-3\'><label for=\'disabledSelect\' class=\'form-label fw-bold\'>Choose Store</label><select id=\'disabledSelect\' class=\'form-select\'><option>Select Store</option></select></div><div class=\'mb-3\'><label for=\'disabledSelect\' class=\'form-label fw-bold\'>Appointment Date</label><select id=\'disabledSelect\' class=\'form-select\'><option>Select a date</option></select></div><div class=\'mb-3\'><label for=\'disabledSelect\' class=\'form-label fw-bold\'>Appointment Time</label><select id=\'disabledSelect\' class=\'form-select\'><option>Select a time</option></select></div>";
        document.getElementById("opt1").style.background = "white";
        document.getElementById("opt1").style.color = "black";
        document.getElementById("opt2").style.background = "transparent";
        document.getElementById("opt2").style.color = "gray";

    }

    function postDevice() {
        document.getElementById("result").innerHTML = "<div class=\'mb-3 mt-3\'><label  class=\'form-label fw-bold\'>Address Line 1*:</label><input type=\'text\' class=\'form-control\' placeholder=\'Address Line 1\'></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Address Line 2*:</label><input type=\'text\' class=\'form-control\' placeholder=\'Address Line 2\'></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Town/City*:</label><input type=\'text\' class=\'form-control\' placeholder=\'Town/City\'></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Post Code*:</label><input type=\'text\' class=\'form-control\' placeholder=\'Post Code\'></div>";
        document.getElementById("opt2").style.background = "white";
        document.getElementById("opt2").style.color = "black";
        document.getElementById("opt1").style.background = "transparent";
        document.getElementById("opt1").style.color = "gray";

    }


    function sameAdd() {
        document.getElementById("result1").innerHTML = "<div class=\'mb-3 mt-3\'><label  class=\'form-label fw-bold\'>Address Line 1*:</label><input type=\'text\' class=\'form-control\' placeholder=\'Address Line 1\' disabled></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Address Line 2*:</label><input type=\'text\' class=\'form-control\' placeholder=\'Address Line 2\' disabled></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Town/City*:</label><input type=\'text\' class=\'form-control\' placeholder=\'Town/City\' disabled></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Post Code*:</label><input type=\'text\' class=\'form-control\' placeholder=\'Post Code\' disabled></div>";
        document.getElementById("sameAdd").style.background = "white";
        document.getElementById("sameAdd").style.color = "black";
        document.getElementById("newAdd").style.background = "transparent";
        document.getElementById("newAdd").style.color = "gray";

    }

    function newAddress() {
        document.getElementById("result1").innerHTML = "<div class=\'mb-3 mt-3\'><label  class=\'form-label fw-bold\'>Name:</label><input type=\'text\' class=\'form-control\' ></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Address</label><input type=\'text\' class=\'form-control\'></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Phone Number</label><input type=\'text\' class=\'form-control\' ></div><div class=\'mb-3\'><label  class=\'form-label fw-bold\'>Post Code:</label><input type=\'text\' class=\'form-control\' ><label  class=\'form-label fw-bold\'>Post Code:</label><input type=\'text\' class=\'form-control\' ></div>"
        document.getElementById("newAdd").style.background = "white";
        document.getElementById("newAdd").style.color = "black";
        document.getElementById("sameAdd").style.background = "transparent";
        document.getElementById("sameAdd").style.color = "gray";
    }



    function applePay() {
        document.getElementById("card").innerHTML = "<form id=\'card\'><div class=\'row\'><div class=\'mb-3 col\'><label  class=\'form-label fw-bold\'>Card Holder Name</label><input type=\'text\' class=\'form-control\' required ></div><div class=\'mb-3 col\'><label  class=\'form-label fw-bold\'>Card Number</label><input type=\'text\' placeholder=\'1111-2222-3333-4444\' required minlength=\'16\' maxlength=\'16\' class=\'form-control\'></div></div><div class=\'row\'><div class=\'mb-3 col\'><label  class=\'form-label fw-bold\'>CCV</label><input type=\'number\' class=\'form-control\' required ></div><div class=\'mb-3 col\'><label  class=\'form-label fw-bold\'>Expiry Date</label><input type=\'text\' class=\'form-control\' placeholder=\'MM/YYYY\' required ></div></div><button type=\'submit\' class=\'btn btn-outline-dark fs-6 mt-3 p-2\'>Pay Now</button></form>"

    }
    function googlePay() {

    }
    function klarana() {

    }
    function payPal() {

    }

</script>


<!--ends here-->



<script>
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });

    $("#menu-toggle-2").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled-2");
        $('#menu ul').hide();
    });

    function initMenu() {
        $('#menu ul').hide();
        $('#menu ul').children('.current').parent().show();

        $('#menu li a').click(function (e) {
            var submenu = $(this).next('ul');
            if (submenu.length) {
                toggleSubMenu(submenu);
                return false; // Prevent default anchor behavior
            }
        });
    }

    function toggleSubMenu(submenu) {
        if (submenu.is(':visible')) {
            submenu.slideUp('normal');
        } else {
            $('#menu ul:visible').slideUp('normal');
            submenu.slideDown('normal');
        }
    }

    $(document).ready(function () {
        initMenu();
    });
</script>
<!-------------------------modal--------------->




<!-- Modal -->
<!-- Modal -->


<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true" style="margin-top: 50px;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-center text-center">
                <h5 class="modal-title" id="exampleModalLongTitle">Enter Tracker ID</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body">
                <style>
                    ::-ms-input-placeholder {
                        /* Edge 12-18 */
                        color: lightgray;
                    }

                    ::placeholder {
                        color: lightgray !important;
                    }
                </style>
                <p>Please enter the tracking ID to check your order status:</p>
                <input type="text" class="form-control" id="trackerIdInput" placeholder="#TN202402132223312424753">



            </div>
            <div class="modal-footer justify-content-center">
                <!-- Paragraph to show error message -->
    
                <p class="error-message" id="errorMessage">Invalid tracking number</p>

                <!-- Button to trigger the display of the error message -->
                <button type="button" class="btn w-50 text-white fs-4" style="background-color: #ff0000; height: 50px;"
                    onclick="showErrorMessage()">Track Order</button>
            </div>
        </div>
    </div>
</div>

<script>
    function showErrorMessage() {
        // Show the error message paragraph
        document.getElementById("errorMessage").style.display = "block";
    }
</script>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap');

    .add-to-cart {
        width: 42px;
        height: 42px;
        padding: 6px;
        background: #ea6a6a;
        color: white;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 21px;
        margin: 0 15px;
        position: relative;
    }

    .card-quantity {
        position: absolute;
        top: -4px;
        right: -10px;
        width: 22px;
        height: 22px;
        background: red;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 20px;
        background: #db3444;
        font-size: 15px;
    }

    /* Initially hide the paragraph */
    .nav-item a {
        font-family: "Merriweather", serif;
    }

    .navbar-nav {
        display: flex;
        align-items: center;
        gap: 4px;
        font-weight: 600;
        font-family: "Merriweather", serif;
    }

    .navbar-nav {
        display: flex;
        align-items: center;
        gap: 4px;
        font-weight: 600;
        font-family: "Merriweather", serif;
    }

    .error-message {
        display: none;
        color: #ff0000;
        font-size: 15px;
    }

    .nav-item a {
        font-family: "Merriweather", serif;
    }

    .nav-item a:hover {
        color: #db3444 !important;
    }
    .card-body-a:hover{
        color: #db3444 !important;
    }
    .see-all-devices{
        width: 100%;
        display: flex;
        justify-content: end;
    }
    .see-all-color{
        color: #db3444 !important;
        font-size: 15px;
    }
</style>

</div> 
</div>
</div><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/components/mega-nav.blade.php ENDPATH**/ ?>
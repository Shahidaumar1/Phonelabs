<div class="spinner-border text-<?php echo e($color ?? 'light'); ?>  spinner-border-sm" role="status">
    <span class="visually-hidden">Loading...</span>
</div>
<?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/components/spinner.blade.php ENDPATH**/ ?>
<div>
    <div>
        <!-- --------------------------top bar----------------- -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l2718244432-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2718244432-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2718244432-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2718244432-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2718244432-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <!-- --------------------navbar--------------------- -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l2718244432-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2718244432-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2718244432-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2718244432-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2718244432-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div class="container-fluid mt-5">
            <h1 class="text-center text-danger">Locations</h1>
            <div class="row d-flex align-items-between p-2 mt-5">
                <div class="col-lg-6">
                    <div>
                        <?php if($map_link): ?>
                        <?php echo $map_link; ?>

                        <?php else: ?>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus" width="100%" height="550" style="border: 0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-6">
                    <h4>
                        Enter your postcode, select from the map or pick the store location
                    </h4>

                    <input type="text" class="form-control my-2 w-100 rounded-0" id="postalCode" placeholder="Postcode..." />
                    <button type="button" class="btn w-100 btn-outline-danger my-2 rounded-0" onclick="getLatLong()">
                        Submit
                    </button>

                    <div id="resultContainer"></div>

                    <?php $__env->startPush('scripts'); ?>
                    <script>
                        document.addEventListener('livewire:load', function() {
                            const resultContainer = document.getElementById("resultContainer");

                            Livewire.on('getLatLong', function() {
                                // Call the JavaScript function when the Livewire event is triggered

                                getLatLong();
                            });
                            async function getLatLong() {
                                const postalCode = document.getElementById("postalCode").value;

                                try {
                                    const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                                    const data = await response.json();

                                    if (data.length > 0) {
                                        const result = data[0];
                                        resultContainer.innerHTML = `<p>${result.display_name}</p>`;

                                        Livewire.emit('updateLocation', {
                                            latitude: result.lat,
                                            longitude: result.lon
                                        });
                                    } else {
                                        resultContainer.innerHTML = "<p>No results found for the provided postal code.</p>";
                                    }
                                } catch (error) {
                                    console.error("Error fetching data:", error);
                                }
                            }

                            // Add Livewire listener for location update
                            Livewire.on('updateLocation', (location) => {
                                // Handle location update if needed
                                console.log('Received location update:', location);
                            });

                            // Your existing function call
                            window.getLatLong = getLatLong;
                        });
                    </script>
                    <?php $__env->stopPush(); ?>
                    <h3 class="text-danger mt-4 ">All Branches</h3>
                    <div class="row justify-content-between">
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <li wire:click="getMap(<?php echo e($branch->id); ?>)"><?php echo e($branch->name); ?> >> </li>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>


        <div class="container-fluid mt-5 p-5 branches">
            <h1 class="text-center text-danger">Our Stores</h1>
            <div class="row text-center justify-content-center mt-3">

                <?php $__currentLoopData = $branches->unique('town_city'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 mb-3">
                    <a href="#<?php echo e($branch->town_city); ?>">
                        <button type="button" class="btn bg-black text-white w-100"><?php echo e($branch->town_city); ?></button>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

 <div class="container mt-5">
        <h1 class="text-center text-danger mt-5">Find Our Stores</h1>
        <div class="row justify-content-center mt-5 g-4"> <!-- Added g-4 for spacing -->
            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-3 col-md-6" id="<?php echo e($branch->town_city); ?>">
                <div class="card border-0" >
                    <a href="<?php echo e(route('store-details', $branch->id)); ?>">
                    <img src="<?php echo e($branch->image ? $branch->image : 'https://ik.imagekit.io/qml3d7tgz/118771222_3248867385205903_5573724224360234256_n_nW6iVMHYK.jpg'); ?>" class="card-img-top fixed-size-img" alt="...">
                    <div class="card-body">
                        <h4 class="card-title text-danger"><?php echo e($branch->town_city); ?> - <?php echo e($branch->name); ?></h4>
                        <p class="card-text"><?php echo e($branch->address_line_1); ?>, <?php echo e($branch->address_line_2); ?><?php echo e($branch->address_line_2 != '' ? ', ' : ''); ?> <?php echo e($branch->town_city); ?>, <?php echo e($branch->post_code); ?></p>
                    </div>
                   </a>
                </div>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
    ul {
        list-style-type: none;
    }

    li {
        list-style-type: none;
        color: black;
        cursor: pointer;
    }

    li:hover {
        color: rgb(220, 30, 30);
    }

    p {
        color: black;
        cursor: pointer;
    }

    p:hover {
        color: rgb(220, 30, 30);
    }

    .branches {
        background-color: rgb(242, 242, 242);
    }
        .fixed-size-img {
            width: 100%;
            height: 180px; /* Adjust height as needed */
            object-fit: cover; /* Ensures images are properly scaled */
        }
</style><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/guest/stores/index.blade.php ENDPATH**/ ?>
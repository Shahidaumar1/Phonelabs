 <div id="content" style="width:100%">
     <?php echo e($slot); ?>

 </div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/components/content.blade.php ENDPATH**/ ?>
<div>
        <style>
        .breadcrumb-thread {
            
            display: flex;
            flex-wrap: wrap;
            padding-top: 100px;
            padding-bottom: 50px;
            margin-bottom: 1rem;
            list-style: none;
            background-color: transparent;
            border-radius: .25rem;
        }
        .breadcrumb-thread .breadcrumb-item {
            display: flex;
            align-items: center;
            position: relative;
        }
        .breadcrumb-thread .breadcrumb-item + .breadcrumb-item::before {
            content: '';
            width: 20px;
            height: 2px;
            background-color: #6c757d;
            position: absolute;
            left: -21px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 1;
        }
        .breadcrumb-thread .breadcrumb-item a {
      color: #007bff;
      text-decoration: none;
      padding: 0.5rem 1rem;
      background-color: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 9999px 9999px 9999px 9999px;
      position: relative;
      z-index: 2;
      color:black;
    }
        .breadcrumb-thread .breadcrumb-item a:hover {
            color: #dc3545;
            text-decoration: none;
            border: 1px solid #dc3545;
        }
        .breadcrumb-thread .breadcrumb-item a.active {
            color: #fff;
            background-color: #dc3545;
            border-color: #dc3545;
        }
.btnn-style{
    display:flex;
    align-items: center;
    justify-content: space-between;
    flex-direction: row;
    margin: 50px 0;
    position: relative;
}
.button-20-back {
  appearance: button;
  position: absolute;
  bottom: 0;
  left: 0;
  /*width: 11%;*/
  background-color: #dc3545;
  background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
  border: 1px solid #dc3545;
  border-radius: 1rem;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset,rgba(46, 54, 80, 0.075) 0 1px 1px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Inter,sans-serif;
  font-size: 1rem;
  font-weight: 500;
  line-height: 1.7;
  margin: 0;
  padding: 6px 50px;
  text-align: center;
  text-transform: none;
  transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: middle;
}

.button-20-back:focus:not(:focus-visible),
.button-20-back:focus {
  outline: 0;
}

.button-20-back:hover {
  background-color: #dc3545;
  border-color: #dc3545;
}

.button-20-back:focus {
  background-color: #dc3545;
  border-color: #dc3545;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20-back:active {
  background-color: #dc3545;
  background-image: none;
  border-color: #dc3545;
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
}

.button-20-back:active:focus {
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20-back:disabled {
  background-image: none;
  box-shadow: none;
  opacity: .65;
  pointer-events: none;
}
.button-20-next {
  appearance: button;
  position: absolute;
  bottom: 0;
  right: 0;
  /*width: 11%;*/
  background-color: #dc3545;
  background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
  border: 1px solid #dc3545;
  border-radius: 1rem;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset,rgba(46, 54, 80, 0.075) 0 1px 1px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Inter,sans-serif;
  font-size: 1rem;
  font-weight: 500;
  line-height: 1.7;
  margin: 0;
  padding:6px 50px;
  text-align: center;
  text-transform: none;
  transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: middle;
}

.button-20-next:focus:not(:focus-visible),
.button-20-next:focus {
  outline: 0;
}

.button-20-next:hover {
  background-color: #dc3545;
  border-color: #dc3545;
}

.button-20-next:focus {
  background-color: #dc3545;
  border-color: #dc3545;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20-next:active {
  background-color: #dc3545;
  background-image: none;
  border-color: #dc3545;
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
}

.button-20-next:active:focus {
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20-next:disabled {
  background-image: none;
  box-shadow: none;
  opacity: .65;
  pointer-events: none;
}
.multi-container{
    position: relative;
}
</style>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white'])->html();
} elseif ($_instance->childHasBeenRendered('l1612523661-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1612523661-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1612523661-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1612523661-0');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white']);
    $html = $response->html();
    $_instance->logRenderedChild('l1612523661-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://kit.fontawesome.com/09d3c3a997.js" crossorigin="anonymous"></script>

    <!-- Navigation Bar -->
    <div class="d-none d-lg-block d-md-block" style="display: flex; justify-content: center; align-items: center;  margin: 0;">
     <div class="container mt-3" style="text-align: center;">
    <ul class="breadcrumb-thread" id="form-navigation" style="list-style: none; padding: 0; display: inline-flex; justify-content: center; align-items: center;">
      <li class="breadcrumb-item" style="margin: 0 10px;">
        <a href="#" data-step="0">Repair Info</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0 10px;">
        <a href="#" data-step="1">Select Repair</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0 10px;">
        <a href="#" data-step="2">Personal Detail</a>
      </li>
      <li class="breadcrumb-item" style="margin: 0 10px;">
        <a href="#" data-step="3">Book Repair</a>
      </li>
    </ul>
  </div>
</div>
    <!-- Main Content Section -->
    <div class="container multi-container" id="multi-step-form">
        <!-- Pre-Repair Checklist and Service Information -->
<section id="repair-info-section" class="form-step" style="margin-left:23%">
    <div class="container">
        <div class="row" >
            <!-- Checklist Column -->
            <div class="col-lg-6 col-md-6 ml-lg-5 ml-md-4 mt-5">
                <h3 class="text-danger"><?php echo e($data['modal']['name']); ?> <?php echo e($data['repair_type']['name']); ?></h3>
                <div><br></div>
                <h4><b class="text-danger">&#10003; How long?</b> <?php echo e($data['repair_type']['duration'] ?? ''); ?></h4>
                <h4><b class="text-danger">&#10003; Part Used?</b> <?php echo e($data['repair_type']['part_used'] ?? ''); ?></h4>

                <!-- Hidden Content -->
                <div id="moreContent" style="display: none;">
                    <h4><b class="text-danger">&#10003; Warranty?</b> <?php echo e($data['repair_type']['warranty'] ?? ''); ?></h4>
                    <h4><b class="text-danger">&#10003; Will my data be lost?</b> <?php echo e($data['repair_type']['data_loss'] ?? ''); ?></h4>
                    <h4><b class="text-danger">&#10003; Post Repair Advice?</b> <?php echo $data['repair_type']['advice'] ?? ''; ?></h4>
                    <h4><b class="text-danger">&#10003; What if you can’t fix my device?</b> <?php echo $data['repair_type']['no_fix_no_fee'] ?? ''; ?></h4>
                </div>
                <button id="toggleButton" class="btn bg-white text-danger" onclick="toggleContent()">See More</button>
            </div>

            <div class="col-lg-6 col-md-6  mt-5">
                <img src="<?php echo e(asset($data['modal']['file']) ?? 'https://ik.imagekit.io/qml3d7tgz/iphone1_9JHn-8RLU.jpg'); ?>" style="height:300px; width:220px" />
            </div>
        </div>
    </div>
</section>




        <!-- Form Section Part 1 (Initial Hidden) -->
        <section id="form-section-1" class="form-step" style="display:none;">
            <div>
                <div class="row justify-content-center">
                    <!-- Patient Detail Form Column -->
                    <div class="col-12 col-lg-12 rounded p-4">
                        <div>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.patient-detail-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.patient-detail-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Form Section Part 2 (Initial Hidden) -->
        <section id="form-section-2" class="form-step bg-white" style="display:none;">
            <div class="container">
                <div class="row">
                    <!-- Form Toggle Column -->
                    <div class="col-lg-12">
                        <div class="rounded p-4" style="background-color:white; border: 3px solid black;">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.form-toggle', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Book Repair Component (Initial Hidden) -->
        <section id="book-repair-section" class="form-step" style="display:none;">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.book-repair', ['data' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </section>

        <!-- Back and Next Buttons -->
        <!--<div class="container-fluid mt-4">-->
        <!--    <div class="row justify-content-between">-->
        <!--        <div class="col-auto">-->
        <!--            <span id="back-button"><img src="https://ik.imagekit.io/b6iqka2sz/prev.png?updatedAt=1719938010352" style="width: 150px; height: auto; margin-left: auto;"></span>-->
        <!--        </div>-->
        <!--        <div class="col-auto">-->
        <!--          <span><img id="next-button" src="https://ik.imagekit.io/li8bg5tjv3/1.png?updatedAt=1715028228699" style="width: 150px; height: auto;" /></span>  -->
        <!--        </div>-->
        <!--        <button>Khalli balli</button>-->
        <!--    </div>-->
        <!--</div>-->
        <div class="btnn-style">
            <button class="button-20-back" id="back-button">Go Back</button>
            <button class="button-20-next" id="next-button">Next</button>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            const steps = ['repair-info-section', 'form-section-2', 'form-section-1', 'book-repair-section'];
            let currentStep = <?php echo e($currentStep); ?>;
            let formCompleted = [true, false, false, false]; // Initialize with `true` for intro section and `false` for others

            function showStep(stepIndex) {
                $('.form-step').hide();
                $('#' + steps[stepIndex]).show();

                if (stepIndex === 0 || stepIndex === 1) {
                    $('#back-button').hide();
                } else {
                    $('#back-button').show();
                }
                if (stepIndex == 3) {
                    $('#heading').hide();
                }

                if (stepIndex === 1 || stepIndex === 2 || stepIndex === 3) {
                    $('#next-button').hide();
                } else {
                    $('#next-button').show();
                    $('#next-button').prop('disabled', !formCompleted[stepIndex]);
                    if (!formCompleted[stepIndex]) {
                        $('#next-button').hide(); // Hide the Next button if the form is not validated
                    } else {
                        $('#next-button').show(); // Show the Next button if the form is validated
                    }
                }

                // Update navigation bar
                $('#form-navigation .breadcrumb-item a').removeClass('active');
                $('#form-navigation .breadcrumb-item a[data-step="' + stepIndex + '"]').addClass('active');
            }

            function moveToNextStep() {
                if (currentStep < steps.length - 1) {
                    currentStep++;
                    showStep(currentStep);
                }
            }

            $('#back-button').click(function () {
                if (currentStep > 0) {
                    currentStep--;
                    showStep(currentStep);
                }
            });

            $('#next-button').click(function () {
                moveToNextStep();
            });

            $('#form-navigation .breadcrumb-item a').click(function (e) {
                e.preventDefault();
                const stepIndex = $(this).data('step');
                if (stepIndex <= currentStep) {
                    currentStep = stepIndex;
                    showStep(currentStep);
                }
            });

            Livewire.on('formSubmitted', function () {
                formCompleted[currentStep] = true;
                moveToNextStep();
            });

            Livewire.on('formInvalid', function () {
                formCompleted[currentStep] = false;
                showStep(currentStep);
            });

            // Initial display setup
            showStep(currentStep);
        });

        document.addEventListener('livewire:load', function () {
            Livewire.on('formShown', function () {
                // Hide the grid container when a form is shown
                document.querySelector('.grid-container').style.display = 'none';
            });
        });

        function toggleContent() {
            var moreContent = document.getElementById("moreContent");
            var toggleButton = document.getElementById("toggleButton");

            if (moreContent.style.display === "none") {
                moreContent.style.display = "block";
                toggleButton.textContent = "See Less";
            } else {
                moreContent.style.display = "none";
                toggleButton.textContent = "See More";
            }
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/livewire/2.x/livewire.js"></script>
</div>
<?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/livewire/guest/repair-detail.blade.php ENDPATH**/ ?>
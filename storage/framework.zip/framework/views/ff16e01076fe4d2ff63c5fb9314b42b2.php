 <div id="content" style="width:100%">
     <?php echo e($slot); ?>

 </div>
<?php /**PATH /home/mobilebitz/test.mobilebitz.co.uk/resources/views/components/content.blade.php ENDPATH**/ ?>
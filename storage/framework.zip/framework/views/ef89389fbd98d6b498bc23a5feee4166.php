<div>
    <section class="head">
        <div class="container" x-data={open:false}>
            <nav class="navbar px-3 py-0  navbar-expand-lg navbar-light bg-light"
                style="border-radius: 0px 0px 27px 27px;">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.logo', [])->html();
} elseif ($_instance->childHasBeenRendered('l3687099731-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3687099731-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3687099731-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3687099731-0');
} else {
    $response = \Livewire\Livewire::mount('components.logo', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3687099731-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" x-on:click="open = !open"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent" x-show="open" x-transition>
                    <ul class="navbar-nav m-auto mb-2 mb-lg-0">
                        <!-- ------------------------sell-------- -->

                        <?php if($formStatuses->sell): ?>
                            <a class="btn <?php echo e($selectedService == 'Sell' ? 'bg-danger text-white' : ''); ?> "
                                style="border: none; font-weight: bold;" data-bs-toggle="collapse"
                                wire:click="showDevices('Sell')" href="#collapseSellDevice" role="button"
                                aria-expanded="false" aria-controls="collapseSellDevice">
                                <?php echo $webContent->mega_nav_sell; ?> &nbsp;<i class="bi bi-chevron-down"></i>
                            </a>
                        <?php endif; ?>
                        <?php if($formStatuses->buy): ?>
                            <a class="btn <?php echo e($selectedService == 'Buy' ? 'bg-danger text-white' : ''); ?> "
                                style="border: none; font-weight: bold;" data-bs-toggle="collapse"
                                wire:click="showDevices('Buy')" href="#collapseExample" role="button"
                                aria-expanded="false" aria-controls="collapseExample">
                                <?php echo $webContent->mega_nav_buy; ?> &nbsp;<i class="bi bi-chevron-down"></i>
                            </a>
                        <?php endif; ?>
                        <?php if($formStatuses->repair): ?>
                            <a class="btn <?php echo e($selectedService == 'Repair' ? 'bg-danger text-white' : ''); ?> "
                                style="border: none; font-weight: bold;" data-bs-toggle="collapse"
                                wire:click="showDevices('Repair')" href="#collapseExample" role="button"
                                aria-expanded="false" aria-controls="collapseExample">
                                <?php echo $webContent->mega_nav_repair; ?> &nbsp;<i class="bi bi-chevron-down"></i>
                            </a>
                        <?php endif; ?>
                        <li class="nav-item dropdown">
                            <a style="font-weight:bold;font-size:17px;position:relative;top :5.5px; " class=" "
                                href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                Info<i class="fa fa-chevron-down"></i>
                            </a>
                            <div style="border-radius:15%;" class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="https://mobilebitz.co.uk/aboutus">About Us</a>
                                <a class="dropdown-item" href="https://mobilebitz.co.uk/blog">Blog</a>
                                <a class="dropdown-item" href="https://mobilebitz.co.uk/stores">Stores</a>


                            </div>
                        </li>
                        <?php if($formStatuses->accessroires): ?>
                            <a class="text-dark  mt-2" style="border: none; font-weight: bold;margin-left:10px;"
                                href="<?php echo e(route('khuram')); ?>" aria-expanded="false" aria-controls="collapseExample">
                                Accessroires &nbsp;<i class="bi bi-chevron-down"></i>
                            </a>
                        <?php endif; ?>

                    </ul>
                    <!-- Check and display Facebook link -->
                    <?php if($siteSettings->fb_link_status && $siteSettings->fb_link): ?>
                        <a target="_blank" href="<?php echo e($siteSettings->fb_link); ?>" class="mx-2 facebook">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Facebook_icon.svg/2048px-Facebook_icon.svg.png"
                                style="width: 40px; height: 40px;" alt="Facebook Profile">
                        </a>
                    <?php endif; ?>
                    <!-- Check and display Instagram link -->
                    <?php if($siteSettings->insta_link_status && $siteSettings->insta_link): ?>
                        <a target="_blank" href="<?php echo e($siteSettings->insta_link); ?>" class="mx-2 instagram">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png"
                                style="width: 40px; height: 40px;" alt="Facebook Profile">
                        </a>
                    <?php endif; ?>
                    <!-- Check and display linkedin link -->
                    <?php if($siteSettings->linkedin_link_status && $siteSettings->linkedin_link): ?>
                        <a target="_blank" href="<?php echo e($siteSettings->linkedin_link); ?>" class="mx-2 linkedin">
                            <i class="fa fa-linkedin" style="font-size: 30px;"></i>
                        </a>
                    <?php endif; ?>
                    <!-- Check and display Twitter link -->
                    <?php if($siteSettings->twitter_link_status && $siteSettings->twitter_link): ?>
                        <a target="_blank" href="<?php echo e($siteSettings->twitter_link); ?>" class="mx-2 twitter"><i
                                class="fa fa-twitter-square" style="font-size: 30px;"></i></a>
                    <?php endif; ?>
                    <!-- Check and display TikTok link -->
                    <?php if($siteSettings->tiktok_link_status && $siteSettings->tiktok_link): ?>
                        <a target="_blank" href="<?php echo e($siteSettings->tiktok_link); ?>" class="mx-2 tiktok">
                            <!-- TikTok Color -->
                            <svg width="48px" height="48px" viewBox="0 0 48 48" version="1.1"
                                xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                <title>Tiktok</title>
                                <g id="Icon/Social/tiktok-color" stroke="none" stroke-width="1" fill="none"
                                    fill-rule="evenodd">
                                    <g id="Group-7" transform="translate(8.000000, 6.000000)">
                                        <path
                                            d="M29.5248245,9.44576327 C28.0821306,9.0460898 26.7616408,8.29376327 25.6826204,7.25637551 C25.5109469,7.09719184 25.3493143,6.92821224 25.1928245,6.75433469 C23.9066204,5.27833469 23.209151,3.38037551 23.2336408,1.42290612 L17.3560898,1.42290612 L17.3560898,23.7086204 C17.3560898,27.7935184 15.1520082,29.9535184 12.416498,29.9535184 C11.694049,29.9611102 10.9789469,29.8107429 10.3213959,29.5124571 C9.6636,29.2144163 9.07951837,28.7758041 8.60955918,28.2272327 C8.1398449,27.6789061 7.79551837,27.0340898 7.60180408,26.3385796 C7.4078449,25.6430694 7.36890612,24.9132735 7.48743673,24.2008653 C7.60596735,23.4884571 7.87902857,22.8105796 8.28751837,22.2154776 C8.69625306,21.6198857 9.23037551,21.1212735 9.85241633,20.7546612 C10.474702,20.3878041 11.1694776,20.1617633 11.8882531,20.0924571 C12.6070286,20.023151 13.3324163,20.1122939 14.0129878,20.3535184 L14.0129878,14.3584163 C13.4889061,14.2430694 12.9530694,14.1862531 12.416498,14.1894367 L12.3917633,14.1894367 C10.2542939,14.1943347 8.16604898,14.8325388 6.39127347,16.0234776 C4.61649796,17.2149061 3.23429388,18.9051918 2.41976327,20.8812735 C1.60523265,22.8578449 1.39486531,25.0310694 1.8151102,27.1269061 C2.2351102,29.2227429 3.2671102,31.1469061 4.78033469,32.6564571 C6.29380408,34.1660082 8.22066122,35.1933551 10.3174776,35.6082122 C12.4142939,36.0230694 14.5870286,35.8073143 16.561151,34.9878857 C18.5355184,34.1682122 20.2226204,32.7820898 21.409151,31.0041306 C22.5959265,29.2264163 23.2289878,27.136702 23.228498,24.9992327 L23.228498,12.8155592 C25.5036,14.392702 28.2244163,15.134498 31.1289061,15.1886204 L31.1289061,9.68551837 C30.5869469,9.66568163 30.049151,9.5851102 29.5248245,9.44576327"
                                            id="Fill-1" fill="#FE2C55"></path>
                                        <path
                                            d="M25.195102,6.75428571 C24.7946939,6.47510204 24.4148571,6.1675102 24.0587755,5.83346939 C22.8210612,4.66016327 22.0062857,3.11020408 21.7420408,1.42530612 C21.6622041,0.954367347 21.6220408,0.47755102 21.6220408,0 L15.7444898,0 L15.7444898,22.6408163 C15.7444898,27.5069388 13.5404082,28.5183673 10.804898,28.5183673 C10.0829388,28.5262041 9.36783673,28.3758367 8.71028571,28.0773061 C8.0524898,27.7792653 7.46791837,27.3406531 6.99820408,26.7920816 C6.5282449,26.2437551 6.18440816,25.5989388 5.99044898,24.9034286 C5.7964898,24.2079184 5.75755102,23.4781224 5.87583673,22.7657143 C5.99461224,22.053551 6.26767347,21.3756735 6.67640816,20.7800816 C7.08489796,20.1847347 7.61902041,19.6861224 8.24106122,19.3195102 C8.86334694,18.952898 9.55787755,18.7266122 10.276898,18.6573061 C10.9959184,18.588 11.7208163,18.6773878 12.4016327,18.9183673 L12.4016327,12.9328163 C5.40489796,11.8236735 0,17.4783673 0,23.5760816 C0.00465306122,26.4426122 1.14514286,29.1898776 3.17191837,31.216898 C5.19869388,33.2434286 7.94595918,34.3839184 10.8124898,34.3885714 C16.7730612,34.3885714 21.6220408,30.7444898 21.6220408,23.5760816 L21.6220408,11.3924082 C23.8995918,12.9795918 26.6204082,13.7142857 29.524898,13.7632653 L29.524898,8.26040816 C27.9658776,8.18914286 26.4617143,7.66604082 25.195102,6.75428571"
                                            id="Fill-3" fill="#25F4EE"></path>
                                        <path
                                            d="M21.6220653,23.5764245 L21.6220653,11.392751 C23.8996163,12.9794449 26.6204327,13.7141388 29.5251673,13.7633633 L29.5251673,9.44581224 C28.0822286,9.04613878 26.7617388,8.29381224 25.6824735,7.25617959 C25.5110449,7.09724082 25.3494122,6.92826122 25.1926776,6.75438367 C24.7922694,6.4752 24.4126776,6.16736327 24.056351,5.83356735 C22.8186367,4.66026122 22.0041061,3.11030204 21.7396163,1.42540408 L17.3730857,1.42540408 L17.3730857,23.7111184 C17.3730857,27.7957714 15.1690041,29.9560163 12.4334939,29.9560163 C11.6569224,29.9538122 10.8918612,29.7681796 10.2005143,29.414302 C9.50941224,29.0601796 8.91186122,28.5476082 8.45635102,27.9182204 C7.49071837,27.3946286 6.72712653,26.5636898 6.2865551,25.5571592 C5.84573878,24.5508735 5.75341224,23.4260571 6.02377959,22.3609959 C6.29390204,21.2959347 6.91177959,20.3516082 7.77896327,19.6771592 C8.64639184,19.0027102 9.71365714,18.6365878 10.8122694,18.6365878 C11.3564327,18.6412408 11.8961878,18.7362612 12.4090041,18.9182204 L12.4090041,14.1894857 C10.304351,14.1921796 8.24647347,14.8093224 6.48786122,15.9657306 C4.72924898,17.1221388 3.3470449,18.7666286 2.51047347,20.6978939 C1.67390204,22.6291592 1.41969796,24.7627102 1.77896327,26.8362612 C2.13822857,28.9098122 3.09553469,30.8334857 4.53308571,32.3704653 C6.36271837,33.6848327 8.55945306,34.3906286 10.8122694,34.3884296 C16.7730857,34.3884296 21.6220653,30.7445878 21.6220653,23.5764245"
                                            id="Fill-5" fill="#000000"></path>
                                    </g>
                                </g>
                            </svg>
                        </a>
                    <?php endif; ?>
                    <!-- Check and display Snapchat link -->
                    <?php if($siteSettings->snapchat_link_status && $siteSettings->snapchat_link): ?>
                        <a target="_blank" href="<?php echo e($siteSettings->snapchat_link); ?>" class="mx-2 snapchat"><i
                                class="fa fa-snapchat" style="font-size: 30px;"></i></a>
                    <?php endif; ?>
                </div>
            </nav>
            <div>
                <?php if($show): ?>
                    <div class="card card-body rounded-5" style="width: 100%; z-index: 1000;">
                        <div class="d-flex justify-content-end cursor-pointer" wire:click="toggleShow">
                            <i class="fa fa-times zoom-out-icon" aria-hidden="true"></i>
                        </div>
                        <div class="d-flex align-items-start">
                            <div class="nav flex-column nav-pills me-3 shadow bg-white rounded" id="v-pills-tab"
                                role="tablist" aria-orientation="vertical" style="width: 25%; font-weight: bold;">

                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <button type="button" wire:click="showBrandsAndModel('<?php echo e($category->id); ?>')"
                                        class="nav-link <?php echo e($category->id == $selectedCatId ? 'active' : 'text-black border'); ?>"
                                        style="min-width: max-content; white-space: normal;">
                                        <?php echo e($category->name); ?>

                                    </button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>

                            </div>

                            <div class="phone " id="v-pills-tabContent"
                                style=" width: 70%; border-radius: 5px; margin-left: 10px;">
                                <div class="tab-pane fade show active " id="v-pills-home" role="tabpanel"
                                    aria-labelledby="v-pills-home-tab">
                                    <div class="d-flex gap-5 p-3 overflow-y-scroll overflow-x-scroll text-wrap "
                                        style="height: 45vh; scroll-behavior: smooth;">
                                        <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div
                                                class="d-flex flex-column align-items-start gap-2 text-wrap text-overflow: ellipsis;">
                                                <strong class="text-wrap k"
                                                    style="display: inline-block; max-width: 150%;  text-overflow: ellipsis; ">
                                                    <?php echo e($device->name); ?>

                                                </strong>

                                                
                                                <?php $__empty_2 = true; $__currentLoopData = $device->modals()->where('status', App\Helpers\Status::PUBLISH)->orderBy('order_by')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <?php
                                                        
                                                        $route;
                                                        switch ($selectedService) {
                                                            case 'Sell':
                                                                $route = route('guest-sell-model-detail', $model->id);
                                                                break;
                                                            case 'Buy':
                                                                $route = route('guest-buy-product-specs', $model->id);
                                                                break;
                                                            case 'Repair':
                                                                $route = route('repair-types', [
                                                                    'device' => $device->id,
                                                                    'modal' => $model->id,
                                                                ]);
                                                                break;
                                                            default:
                                                                # code...
                                                                break;
                                                        }
                                                    ?>
                                                    <a href="<?php echo e($route); ?>"
                                                        class="cursor-pointer hover-color k"
                                                        style="min-width: 0;  text-overflow: ellipsis;"><?php echo e($model->name); ?></a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <?php endif; ?>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <style>
            /* .hover-color:hover {
                color: #yourDesiredColor;
                 Change this to the color you want
                 Additional styles can be added here if needed
            }  */

            .k:hover {
                color: #da0a0a;
            }

            .zoom-out-icon {
                transition: transform 0.3s ease-in-out;
            }

            .zoom-out-icon:hover {
                transform: scale(1.5);
            }

            ::-webkit-scrollbar {
                width: 6px;
            }

            ::-webkit-scrollbar-track {
                background: #ffffff;
            }

            ::-webkit-scrollbar-thumb {
                background: #888;
            }

            @media (min-width: 200px) and (max-width: 425px) {
                .navbar_res {
                    width: 14rem !important;
                }

                .scroll_res {
                    height: 57vh;
                }
            }

            @media (min-width: 600px) and (max-width: 768px) {
                .navbar_res {
                    width: 27rem !important;
                }

                .scroll_res {
                    height: 46vh;
                }
            }

            @media (min-width: 900px) and (max-width: 1024px) {
                .navbar_res {
                    width: 44rem !important;
                }

                .scroll_res {
                    height: 45vh;
                }
            }

            @media (min-width: 1024px) and (max-width: 1640px) {
                .navbar_res {
                    width: 60rem !important;
                }

                .scroll_res {
                    height: 45vh;
                }
            }

            @media (min-width: 200px) and (max-width: 425px) {
                .small_icon {
                    display: none;
                }
            }
        </style>
    </section>
</div>
<?php /**PATH /Users/mubashir/Documents/scode/resources/views/livewire/components/mega-nav.blade.php ENDPATH**/ ?>
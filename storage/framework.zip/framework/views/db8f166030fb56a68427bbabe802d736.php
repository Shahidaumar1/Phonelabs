<div>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l4009524434-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4009524434-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4009524434-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4009524434-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4009524434-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <section class="head-sell">
            <div class="container">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l4009524434-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l4009524434-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4009524434-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4009524434-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4009524434-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            </div>
        </section>
        <section class="head-sell mt-5">
            <div class="container">
                 <a href="<?php echo e(route('guest-sell-categories')); ?>">
                        
                    <button class="btn btn-danger btn-sm"  ><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
                  <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
                </svg></button>
                    </a>
                <div class="row d-flex align-items-center">
                    <div class="col-lg-6 p-3 mt-5">
                        <h1 style="font-family: heading; "><?php echo $webContent->brand_page_heading_1; ?></h1>
                        <p style="text-align: justify;"><?php echo $webContent->brand_page_heading_2; ?></p>
                    </div>
                    <div class="col-lg-6 p-3 ">
                        <img src="https://ik.imagekit.io/p2slevyg1/Best_Smartphones_US_2022-scaled.jpg?updatedAt=1698830519194" class="img-fluid">
                    </div>

                </div>
            </div>
            <div class="container mt-5 d-flex justify-content-center">
                <div class="d-flex flex-wrap col-lg-10 justify-content-center align-items-center my-4 gap-5">
                    <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('guest-sell-models', $device->id)); ?>">
                        <div class="card shadow-sm p-3 mb-5 rounded cursor-pointer justify-content-center align-items-center">
                            <img src="<?php echo e($device->file ?? ''); ?>" class="img-fluid" style="height:120px; width:140px;">
                            <!--<div class="card-body">-->
                            <!--    <?php echo e($device->name); ?>-->
                            <!--</div>-->
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        
        <div class="container border rounded p-3 my-3">
            <h2 class="fw-bold"><?php echo $webContent->brand_page_heading_3; ?></h2>
            <p><?php echo $webContent->brand_page_heading_4; ?>.</p>
        </div>
    </div>

</div><?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages swaping and service charges updation\resources\views/livewire/guest/sell/device-types.blade.php ENDPATH**/ ?>
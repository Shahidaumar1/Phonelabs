<div>
    <div class="d-flex">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'sell'])->html();
} elseif ($_instance->childHasBeenRendered('l3903415291-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3903415291-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3903415291-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3903415291-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'sell']);
    $html = $response->html();
    $_instance->logRenderedChild('l3903415291-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.sell.components.top-nav', ['active' => 'add-ons'])->html();
} elseif ($_instance->childHasBeenRendered('l3903415291-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3903415291-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3903415291-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3903415291-1');
} else {
    $response = \Livewire\Livewire::mount('admin.sell.components.top-nav', ['active' => 'add-ons']);
    $html = $response->html();
    $_instance->logRenderedChild('l3903415291-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="container my-4">
                <div class="text-center mb-3">
                    <strong>Select categeory,device and model to seee product specifications with
                        prices.
                    </strong>
                </div>
<div class="row">
    <div class="col-lg-3 col-md-6 mb-3"> <!-- Adjust column width based on screen size -->
        <div>
            <select class="form-select" aria-label="Select Category" wire:model="selectedCatId">
                <option>Select Category</option>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div>
            <select class="form-select" aria-label="Select device" wire:model="selectedDeviceId">
                <option>Select device</option>
                <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div>
            <select class="form-select" aria-label="Select model" wire:model="selectedModelId">
                <option>Select model</option>
                <?php if($selectedDeviceId): ?>
                <?php $__empty_1 = true; $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($model->id); ?>"><?php echo e($model->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                <?php endif; ?>
            </select>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        
        <div class="d-flex flex-column align-items-center justify-content-center gap-4">
               <button class="btn p-3" onclick="showM('add-sell-model-spec')" style="border-radius: 20px; color: white; 
                    background-color: #20375E; pading: 5px">
                       
                        Create New
                    </button>
            
        
        </div>
    </div>
</div>


                <div>
                    <div class="d-flex gap-4 flex-wrap table-responsive ">
                        <div class="table-container " style="overflow-x: auto; width: 100%;">
                            <table class="table  p-5 mb-5 shadow">
                                <thead>
                                    <tr style = "background-color:#c0c0ef">
                                        <th>#</th>
                                        <th>Image</th>
                                        <th>Memory Size</th>
                                        <th>Condition</th>
                                        <th>Price</th>
                                        <?php if($tabletMode || $mobileMode): ?>
                                        <th>N/Unlocked</th>
                                        <?php endif; ?>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $product_specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <th><?php echo e(++$key); ?></th>
                                        <td><img src="<?php echo e($product->image ?? 'https://ik.imagekit.io/qml3d7tgz/iphone_14_pro_space_black_3_RIm6bNsLt.png'); ?>"
                                                style="height:40px; width:50px;" /></td>
                                        <td><?php echo e($product->memory_size ?? '....'); ?></td>
                                        <td><?php echo e($product->condition); ?></td>
                                        <?php if($editableProductSpecId == $product->id): ?>
                                        <td><input style="width:30px; height:30px;" type="text"
                                                wire:keydown.enter="updateProductPrice('<?php echo e($product->id); ?>')"
                                                wire:model.debounce.500="price" id="<?php echo e($product->id); ?>" /></td>
                                        <?php else: ?>
                                        <td wire:click="toggleEditable('<?php echo e($product->id); ?>')">£
                                            <?php echo e($product->price); ?></td>
                                        <?php endif; ?>
                                        <?php if($mobileMode || $tabletMode): ?>
                                        <td><?php echo e($product->network_unlocked ? 'Yes' : 'NO'); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <i class="fa fa-trash text-danger cursor-pointer" aria-hidden="true"
                                                wire:click="delete('<?php echo e($product->id); ?>')"></i>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9">Record Not Found!</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>

            </div>


         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>


        <!----------------------------- footer-------------------------->
        <style>
        .button-sticky {
            height: 60px;
            color: white;
            font-family: sans-serif;
            font-size: 17px;
            line-height: 15px;
            text-align: center;
            position: fixed;
            bottom: -2px;
            z-index: 999;
            overflow-x: auto;
        }

        .home-btn:hover {
            color: orange;
        }

        .button-sticky .col-2 {
            margin-right: 10px;
            /* Adjust this value to set the desired gap */
        }

        .button-sticky .col-2:last-child {
            margin-right: 0;
            /* Remove margin from the last button to prevent extra space */
        }
        </style>

        <div class="button-sticky container bg-blue d-lg-none d-md-none">
            <div class="row justify-content-center">

                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('sell-categories')); ?>" class="text-white item "> Devices</a>
                </div>

                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('sell-devices')); ?>" class="text-white "> Brands</a>
                </div>

                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('sell-models')); ?>" class="text-white  item "> Models</a>
                </div>

                <div class="col-2 mt-4">
                    <a href="<?php echo e(route('sell-models-add-ons')); ?>" class="text-white  item "> Addon</a>
                </div>
            </div>
        </div>

    </div>
    
    <?php if($selectedModel): ?>
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Add  Specs','id' => 'add-sell-model-spec','size' => 'xl']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.sell.addon.add-spec', ['model' => $selectedModelId])->html();
} elseif ($_instance->childHasBeenRendered('l3903415291-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l3903415291-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3903415291-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3903415291-2');
} else {
    $response = \Livewire\Livewire::mount('admin.sell.addon.add-spec', ['model' => $selectedModelId]);
    $html = $response->html();
    $_instance->logRenderedChild('l3903415291-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
    <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/admin/sell/addon/index.blade.php ENDPATH**/ ?>
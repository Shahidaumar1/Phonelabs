[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>
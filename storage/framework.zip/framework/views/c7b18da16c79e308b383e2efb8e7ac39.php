[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/mobilebitz/public_html/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>
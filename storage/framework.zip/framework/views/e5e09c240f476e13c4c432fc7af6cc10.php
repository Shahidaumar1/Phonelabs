<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Contact</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>





<body>


    
    <?php
        $slot = '';
    ?>
    <div class="d-flex justify-content-center">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'buy'])->html();
} elseif ($_instance->childHasBeenRendered('T1xX9w4')) {
    $componentId = $_instance->getRenderedChildComponentId('T1xX9w4');
    $componentTag = $_instance->getRenderedChildComponentTagName('T1xX9w4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T1xX9w4');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'buy']);
    $html = $response->html();
    $_instance->logRenderedChild('T1xX9w4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        <div class="container mt-5">

            <div class="card">
                <h5 class="card-header">Edit Contact</h5>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('contacts.update', $contact->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name"
                                value="<?php echo e($contact->name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email"
                                value="<?php echo e($contact->email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone"
                                value="<?php echo e($contact->phone); ?>">
                        </div>
                        <div class="form-group">
                            <label for="selected_option">Selected Option</label>
                            <input type="text" class="form-control" id="selected_option" name="selected_option"
                                value="<?php echo e($contact->selected_option); ?>">
                        </div>
                        <div class="form-group">
                            <label for="other_option">Other Option</label>
                            <input type="text" class="form-control" id="other_option" name="other_option"
                                value="<?php echo e($contact->other_option); ?>">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" name="message"><?php echo e($contact->message); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(route('contacts.index')); ?>" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>

    </div>
</body>

</html>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mobilebitz/public_html/resources/views/contacts/edit.blade.php ENDPATH**/ ?>
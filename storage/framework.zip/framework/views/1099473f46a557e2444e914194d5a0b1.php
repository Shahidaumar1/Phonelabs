<div>
    <div class="mb-3">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    <div x-data="{ open: false }">
        <span @click="open = true" x-show="open == false"
            wire:click="editable('<?php echo e($repair_type->id); ?>')"><?php echo e($repair_type->name); ?></span>
        <input  x-show="open" type="text" wire:model.lazy="newRepairType"
            @click.away="open = false" />
        
        <a x-show="open" href="javascitp:void(0)" wire:click="delete('<?php echo e($repair_type->id); ?>')"
            style="color: rgb(211, 64, 64)"><i class="fa fa-trash"></i> </a>

    </div>
</div>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/repair/components/repair-type-edit.blade.php ENDPATH**/ ?>
<?php

    $form_name = 'Fix at my address';

?>

<div>

    <?php
        $storedInputValue = Session::get('storedInputValue');
    ?>
    <?php if($storedInputValue): ?>
        <p>Delievry Charges For Postal Repair: $<?php echo e($storedInputValue); ?></p>
    <?php endif; ?>






    <?php
        $storedCollectionRepairPrice = Session::get('collectionRepairPrice');
    ?>
    <?php if($storedCollectionRepairPrice): ?>
        <p style="font-size:1vw">Delivery Charges For Collection Repair: £<?php echo e($storedCollectionRepairPrice); ?></p>
    <?php endif; ?>














    <div class="rounded p-4">
        <div class="z ">
            <div class="col-md-12">
                <?php if($data['service'] == \App\Helpers\ServiceType::REPAIR): ?>
                    <div class="form-check mb-1">
                        <input class="form-check-input" type="checkbox" checked disabled>
                        <label class="form-check-label">
                            <?php echo e($data['modal']['name']); ?> <?php echo e($data['repair_type']['name']); ?>: £ <?php echo e($price ? $price : 0); ?>

                        </label>
                    </div>
                <?php endif; ?>

                <?php if($form_type == 'postal_form'): ?>
                    <?php

                        $form_name = 'Post Your Device';

                    ?>

                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" checked disabled />
                        <label class="form-check-label">
                            Surcharge for UK return delivery : £ 15
                        </label>

                    </div>
                <?php endif; ?>

                <?php if($form_type == 'collection_form'): ?>
                    <?php

                        $form_name = 'Collect My Device';

                    ?>
                <?php endif; ?>

                <div class="my-3" wi re:ign ore.self>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.total-price', ['repairprice' => $price])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.total-price', ['repairprice' => $price]);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>



                <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>




                <?php if($form_type == 'clinic_form'): ?>
                    <?php

                        $form_name = 'Store Repair';

                    ?>
                <?php endif; ?>





                <?php if($success): ?>
                    <div clas s="alert alert-success" role="alert">
                        <h4 class="alert-heading">Congratulations! 🎉 Your order has been successfully placed.
                        </h4>
                        <p>Sit tight while we process your request. Check your email for more instructions.</p>
                        <hr>
                        <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <div class="col-md-5  pt-4 mb-3">
                            <div class=" p-2  "
                                style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 4px">
                                <div class="container p-3">
                                    <div class="accordion" id="payment-accodoion">

                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="headingOne">
                                                <button
                                                    class="accordion-button d-flex justify-content-between collapsed"
                                                    type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapseOne" aria-expanded="false"
                                                    aria-controls="collapseOne">
                                                    <p style="font-size: 1.4rem;"><input type="radio"
                                                            name="radio-payment" style="width: 19px;height: 17px;"
                                                            checked> Pay
                                                        in-store</p>
                                                    <p class="d-md-block d-lg-block"></p>
                                                    <p style="font-size: 1.3rem; color:red;"> £
                                                        <?php echo e($price ? $price : 0); ?>

                                                    </p>
                                                </button>
                                            </h2>
                                            <div id="collapseOne" class="accordion-collapse collapse"
                                                aria-labelledby="headingOne" data-bs-parent="#payment-accordion">
                                                <div class="accordion-body" style="padding-top: 0px;">
                                                    <div class="container">
                                                        <div class="d-felx" style="gap: 10px;">

                                                            <div class>
                                                                <p>Pay at store when you visit our location below</p>
                                                                <p class> <svg xmlns="http://www.w3.org/2000/svg"
                                                                        width="16" height="16"
                                                                        fill="currentColor" class="bi bi-geo-alt-fill"
                                                                        viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6" />
                                                                    </svg> <?php echo e($name); ?>, <?php echo e($address_line_1); ?>,
                                                                    <?php echo e($address_line_2); ?><?php echo e($address_line_2 != '' ? ', ' : ''); ?>

                                                                    <?php echo e($town_city); ?>, <?php echo e($post_code); ?></p>
                                                            </div>
                                                            <div class="details-con">
                                                                <p class><svg xmlns="http://www.w3.org/2000/svg"
                                                                        width="16" height="16"
                                                                        fill="currentColor" class="bi bi-envelope"
                                                                        viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                                                                    </svg> <?php echo e($email); ?></p>
                                                            </div>
                                                            <div class="d-flex justify-content-between">
                                                                <p> <svg xmlns="http://www.w3.org/2000/svg"
                                                                        width="16" height="16"
                                                                        fill="currentColor"
                                                                        class="bi bi-telephone-forward"
                                                                        viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708" />
                                                                    </svg> <?php echo e($landline_number); ?></p>
                                                                <!--<button type="button "-->
                                                                <!--    class="btn btn-light btn-sm"-->
                                                                <!--    style="border: 1px solid grey">Submit-->
                                                                <!--</button>-->
                                                                <button class="btn btn-success" type="button"
                                                                    wire:click="BookRepair">Submit</button>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="accordion-item ">
                                            <h2 class="accordion-header " id="headingTwo">
                                                <button
                                                    class="accordion-button collapsed d-flex  justify-content-between"
                                                    type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapseTwo" aria-expanded="false"
                                                    aria-controls="collapseTwo" onclick="handleRadio(this)">

                                                    <p style="font-size: 1.3rem;">
                                                        <input type="radio" name="radio-payment"
                                                            style="height: 18px; width: 20px">
                                                        Pay with card
                                                    </p>
                                                    <img src="https://ik.imagekit.io/4csyk445b/2560px-Stripe_Logo__revised_2016%205.png?updatedAt=1711551636602"
                                                        alt height="31px">
                                                    <p style="font-size: 1.3rem; color:red;"> £
                                                        <?php echo e($price ? $price : 0); ?>

                                                    </p>

                                                </button>
                                            </h2>
                                            <div id="collapseTwo" class="accordion-collapse collapse"
                                                aria-labelledby="headingTwo" data-bs-parent="#payment-accodoion">
                                                <div class="accordion-body " style="padding-top: 0px;">
                                                    <div class="container">
                                                        <div class="accordion-body p-0">
                                                            <p class="text-center">Securely pay with your card
                                                                using Stripe for hassle-free transactions!</p>
                                                            <!--<input type="text" class="form-control"-->
                                                            <!--    id="inputAddress"-->
                                                            <!--    placeholder="&#xf09d; Card Number"-->
                                                            <!--    style="font-family: Arial, FontAwesome">-->
                                                            <div class="d-flex justify-content-center pt-3">
                                                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l3667338864-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3667338864-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3667338864-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3667338864-1');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l3667338864-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="headingthree">
                                                <button
                                                    class="accordion-button collapsed d-flex  justify-content-between"
                                                    type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapsethree" aria-expanded="false"
                                                    aria-controls="collapsethree" onclick="handleRadio(this)">

                                                    <div> <input type="radio" name="radio-payment"
                                                            style=" width: 19px;height: 17px; font-size: 1.3rem;">
                                                        <img class="img-fluid" style="width: 100px;"
                                                            src="https://ik.imagekit.io/4csyk445b/PayPal_horizontally_Logo_2014.png?updatedAt=1709738114776"
                                                            alt>
                                                    </div>
                                                    <p style="font-size: 1.3rem; color:red;"> £
                                                        <?php echo e($price ? $price : 0); ?>

                                                    </p>

                                                </button>
                                            </h2>
                                            <div id="collapsethree" class="accordion-collapse collapse"
                                                aria-labelledby="collapsethree" data-bs-parent="#payment-accodoion">
                                                <div class="accordion-body">
                                                    <div <p class="text-center">Seamlessly checkout with PayPal
                                                        for a trusted payment experience</p>
                                                        <class= " d-flex justify-content-center">
                                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l3667338864-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l3667338864-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3667338864-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3667338864-2');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l3667338864-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="headingfour">
                                                <button
                                                    class="accordion-button collapsed d-flex  justify-content-between"
                                                    type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapsefour" aria-expanded="false"
                                                    aria-controls="collapsefour" onclick="handleRadio(this)">
                                                    <div class="row g-2">

                                                        <div class="col-1">
                                                            <input type="radio" name="radio-payment"
                                                                style="                                                                 width: 19px;height: 17px; ">
                                                        </div>
                                                        <div class="col-2">
                                                            <img src="https://ik.imagekit.io/4csyk445b/download__13_-removebg-preview%207%20(1).png?updatedAt=1711553724733"
                                                                class="img-fluid" alt>
                                                        </div>
                                                        <div class="col-7">
                                                            <div style="border-radius:5px;" class="border p-1 ">
                                                                <small
                                                                    style="font-size:10px;line-height: 1;white-space:nowrap;">make
                                                                    3 payments of £<?php echo e(number_format($price / 3, 2)); ?>

                                                                    <b>Klarna</b>. </small>
                                                                <small style="font-size:10px;line-height:1;">Terms and
                                                                    condition apply</small>
                                                            </div>
                                                        </div>

                                                        <div class="col-1">
                                                            <h4 style="font-size: 1.3rem; color:red;">
                                                                £<?php echo e($price ? $price : 0); ?>

                                                            </h4>


                                                        </div>

                                                    </div>






                                                </button>
                                            </h2>
                                            <div id="collapsefour"
                                                class="accordio                                                            n-collapse collapse"
                                                a ri a-labelledby="collapsefour" data-bs-parent="#payment-accodoion">
                                                <div class="accordion-body">
                                                    <div class="d-flex justify-content-center">


                                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l3667338864-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l3667338864-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3667338864-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3667338864-3');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l3667338864-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="col-md-2 d-sm-none d-md-none d-lg-block"></div>

                        <div class="col-md-4 col-lg-4 sol-sm-12 ">
                            <!--<div class="mt-2">-->
                            <!--    <div class=" pt-1 justify-content-center">-->
                            <!--        <div class>-->
                            <!--            <div class="container"-->
                            <!--                style="width: 100%; max-width: 380px; height: 350px; border: 2px solid rgba(128, 128, 128, 0.3); border-radius: 8px">-->
                            <!--                <div class="container p-4">-->
                            <!--                    <p class="text-center" style="font-size: 30px;">Repair-->
                            <!--                        Summary</p>-->
                            <!--                    <div class="d-flex pt-1 pb-2 justify-content-between">-->
                            <!--                        <span><b>Model</b> </span>-->
                            <!--                        <span class="text-muted">-->
                            <!--                          <?php echo e($data['modal']['name']); ?> </span>-->
                            <!--                    </div>-->
                            <!--                    <div class="d-flex pt-1 pb-2 justify-content-between">-->
                            <!--                        <span><b>Repair</b> </span>-->
                            <!--                        <span class="text-muted"><?php echo e($data['repair_type']['name']); ?>-->
                            <!--                        </span>-->
                            <!--                    </div>-->
                            <!--                    <div class="d-flex pt-1 pb-2 justify-content-between">-->
                            <!--                        <span> <b>Type</b> </span>-->
                            <!--                        <span class="text-muted">-->


                            <!--                            <p><?php echo e($form_name); ?></p>-->
                            <!--                        </span>-->
                            <!--                    </div>-->
                            <!-- hr -->
                            <!--                    <hr style="  border-top: 2px dotted black;">-->
                            <!--                    <div class="d-flex pt-1 pb-2 justify-content-between">-->
                            <!--                        <span><b>Repair time</b> </span>-->
                            <!--                        <span class="text-muted">1    -->
                            <!--                            Hour</span>-->
                            <!--                    </div>-->
                            <!--                    <div class="d-flex pt-1 pb-1 justify-content-between">-->
                            <!--                        <span><b>Warrenty</b> </span>-->
                            <!--                        <span class="text-muted">12 months</span>-->
                            <!--                    </div>-->
                            <!--                    <div class="d-flex pt-1 pb-3 justify-content-between">-->
                            <!--<span><b>Time</b> </span>-->
                            <!--<span class="text-muted">9.30-->
                            <!--    am</span>-->

                            <!--                    </div>-->
                            <!--                </div>-->
                            <!--                <div class="d-flex justify-content-center">-->
                            <!--<button type="button"-->
                            <!--    class="btn  btn-lg "-->
                            <!--    style="width: 100%; border-radius: 0;background-color: red ; color: white">-->
                            <!--    Proceed To Checkout-->
                            <!--</button>-->

                            <!--                </div>-->
                            <!--            </div>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->







                            <div style="position:relative;top:10px;" class="container">

                                <table class="table table-striped border mt-5">
                                    <thead>



                                        <tr>
                                            <th colspan="2" class="text-center text-danger fw-bolder fs-3">Repair
                                                Summary</th> <!-- Center-aligned heading -->
                                        </tr>



                                        <tr>

                                            <td>Model</td>
                                            <td class="text-end">
                                                <?php echo e($data['modal']['name']); ?>

                                            </td>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="justify-content-between

">

                                            <td>Type</td>
                                            <td class="text-end"><?php echo e($form_name); ?></td>

                                        </tr>





                                        <tr>

                                            <td>Price</td>
                                            <td class="text-end">Â£ <?php echo e($price ?? ''); ?>.00 </td>

                                        </tr>

                                        <tr>

                                            <td>Repair time</td>
                                            <td class="text-end">1 Hour </td>

                                        </tr>


                                        <tr>

                                            <td>Warrenty</td>
                                            <td class="text-end"> 12 months </td>

                                        </tr>

                                    </tbody>
                                </table>
                            </div>










                        </div>
                        </ di v>
                <?php endif; ?>








                <script>
                    function handleRadio(button) {
                        var radio = button.qu erySelector('    input[name="rad      io-payment"]');
                        var isChecked = radio.checked;

                        // Unchec      k all radio b    ut    tons with name       "radio-payment"
                        document.querySelectorAll('input[name="radio-payme      nt"]').forEac h(function(radioBtn) {
                            radioBtn.che ck ed = f al se;
                        });

                        // If radio button was not checked, check it
                        if (!isChecked) {
                            radio.checked = true;
                        }
                    }
                </script>
                <style>
                    .accordion-button:not(.collapsed) {
                        background-color: white;
                        box-shadow: none;
                    }

                    .accordion-button:not(.collapsed)::after {
                        display: none;
                    }

                    .accordion-button::after {
                        display: none;
                    }

                    .accordion-item {
                        justify-content: space-between;
                    }
                </style>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/components/book-repair.blade.php ENDPATH**/ ?>
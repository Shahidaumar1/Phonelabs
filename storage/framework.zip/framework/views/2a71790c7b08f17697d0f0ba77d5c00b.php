<section>
    <style>
        @media only screen and (max-width: 767px) {
            .text-sm {
                font-size: 20px;
                /* Adjust the font size as needed */
                text-align: center;
                /* Center the text */
            }

            .text-m {
                font-size: 25px;
                /* Adjust the font size as needed */
                text-align: center;
                /* Center the text */
                font-weight: bold;
                /* Set the font weight to bold */
                margin-left: 3%;
            }

        }
    </style>
    <style>
        .accordion-button:not(.collapsed) {
            background-color: white;
            box-shadow: none;
        }

        .accordion-button:not(.collapsed)::after {
            display: none;
        }

        .accordion-button::after {
            display: none;
        }

        .accordion-item {
            justify-content: space-between;
        }
    </style>





    <?php if($form_type == 'postal_form'): ?>
        <?php

            $form_name = 'Post Your Device';

        ?>
    <?php endif; ?>



    <?php if($form_type == 'clinic_form'): ?>
        <?php

            $form_name = 'Sell In Store';

        ?>
    <?php endif; ?>


    <?php if($form_type == 'collection_form'): ?>

        <?php

            $form_name = 'Collect My Device';

        ?>







        <?php
            $storedCollectionRepairPrice = Session::get('collectionRepairPrice');
        ?>
        <?php if($storedCollectionRepairPrice): ?>
            <p style="font-size:1vw">Delivery Charges For Collection Repair:
                £<?php echo e($storedCollectionRepairPrice); ?></p>

            <?php
                $price = $price + $storedCollectionRepairPrice;

            ?>
        <?php endif; ?>







    <?php endif; ?>










    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>





    <!-- In the Blade template for OtherComponent -->
    <div>
        <h3>Condition Prices</h3>
        <p>Condition 1 Price: £<?php echo e($condition1Price); ?></p>
        <p>Condition 2 Price: £<?php echo e($condition2Price); ?></p>
        <p>Condition 3 Price: £<?php echo e($condition3Price); ?></p>
        <p>Condition 4 Price: £<?php echo e($condition4Price); ?></p>
        <p>Condition 5 Price: £<?php echo e($condition5Price); ?></p>
        <p>Condition 6 Price: £<?php echo e($condition6Price); ?></p>
    </div>








    <?php if($success): ?>
        <div class="col-4">
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Congratulations! 🎉 Your order has been successfully placed.</h4>
                <p>Sit tight while we process your request. Check your email for more instructions.</p>
                <hr>
                <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
            </div>

        </div>
    <?php else: ?>
        <div class = "container mb-4">


            <div class="row">

                <div class="col-md-5  pt-4 mb-3">
                    <h2 class="text-center" style="color: red;">Payment Details</h2>
                    <p class="text-center">Select your payment option</p>
                    <div class=" p-2  " style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 4px">
                        <div class="container p-3">
                            <div class="accordion" id="payment-accodoion">



                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingthree">
                                        <button style = "padding-bottom: 0px;"
                                            class="accordion-button collapsed d-flex  justify-content-between"
                                            type="button" data-bs-toggle="collapse" data-bs-target="#collapsethree"
                                            aria-expanded="false" aria-controls="collapsethree"
                                            onclick="handleRadio(this)">

                                            <div> <input type="radio" onclick="event.stopPropagation();"
                                                    name="radio-payment"
                                                    style=" width: 19px;height: 17px; font-size: 1.3rem;">
                                                <img class="img-fluid" style="width: 100px;"
                                                    src="https://ik.imagekit.io/4csyk445b/PayPal_horizontally_Logo_2014.png?updatedAt=1709738114776"
                                                    alt>
                                            </div>
                                            <p style="font-size: 1.3rem; color:red;">£ <?php echo e($price ?? ''); ?>.00</p>

                                        </button>
                                    </h2>

                                    <div id="collapsethree" class="accordion-collapse collapse"
                                        aria-labelledby="collapsethree" data-bs-parent="#payment-accodoion">
                                        <div class="accordion-body">
                                            <p style="font-size:0.8vw" class= "text-center">Seamlessly checkout with
                                                PayPal for a trusted payment experience. </p>
                                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.sell.components.paypal', [])->html();
} elseif ($_instance->childHasBeenRendered('l2202084699-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2202084699-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2202084699-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2202084699-0');
} else {
    $response = \Livewire\Livewire::mount('guest.sell.components.paypal', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2202084699-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                            <div class="d-flex justify-content-center">

                                            </div>
                                        </div>
                                    </div>
                                </div>




                                







                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingfour">
                                        <button style="padding-bottom: 0px;"
                                            class="accordion-button d-flex justify-content-between" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapsefour"
                                            aria-expanded="true" aria-controls="collapsefour">
                                            <div>
                                                <p style="font-size: 1.4rem;">
                                                    <input type="radio" name="radio-payment"
                                                        style="width: 19px; height: 17px;" checked> Pay in-BANK
                                                </p>
                                            </div>
                                            <h4 style="font-size: 1.3rem; color: red;">£ <?php echo e($price ?? ''); ?>.00</h4>

                                        </button>
                                    </h2>
                                    <div id="collapsefour" class="accordion-collapse collapse show"
                                        aria-labelledby="headingfour" data-bs-parent="#payment-accodoion">
                                        <div class="accordion-body">

                                            
                                            <!-- -------change radio forms------ -->
                                            <div class="d-flex  align-items-center">
                                                <style>
                                                    .col-7 {
                                                        width: 100%;
                                                        height: 100%;
                                                        background: #ffffff 0% 0% no-repeat padding-box;

                                                        border-radius: 15px;
                                                        margin-left: auto;
                                                        margin-right: auto;
                                                    }

                                                    @media (max-width: 767px) {
                                                        .col-7 {
                                                            width: 100%;
                                                            /* Limit maximum width */
                                                        }

                                                        .btn-success {
                                                            margin-top: -20px;
                                                        }

                                                    }
                                                </style>
                                                <div class="my-4 col-7" style="

          ">
                                                    <div id="paymentForm">
                                                        <!--<h2 class="text-center p-2 fw-bold">Bank Transfer</h2>-->

                                                        <div class="px-1 ">
                                                            <!--<label for="disabledSelect" class="form-label">Account Title</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Title" wire:model.debounce.500="bank.account_title">-->

                                                            <div class="row mb-2">
                                                                <label for="exampleFormControlInput1"
                                                                    style="font-size:1vw;"
                                                                    class="col-sm-2 col-form-label">Title</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text" class="form-control"
                                                                        id="exampleFormControlInput1"
                                                                        style="font-size:12px;"
                                                                        placeholder="Enter Account Title"
                                                                        wire:model.debounce.500="bank.account_title">
                                                                </div>
                                                            </div>




                                                            <?php $__errorArgs = ['bank.account_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger error"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div class="px-1 ">
                                                            <!--<label for="disabledSelect" class="form-label">Account Number</label>-->
                                                            <!--<input type="number" class="form-control" id="exampleFormControlInput1" placeholder="Enter Account Number" wire:model.debounce.500="bank.account_number">-->
                                                            <div class="row mb-2">
                                                                <label for="exampleFormControlInput1"
                                                                    style="font-size:1vw;"
                                                                    class="col-sm-2 col-form-label">Account</label>
                                                                <div class="col-sm-10">
                                                                    <input type="number" class="form-control"
                                                                        id="exampleFormControlInput1"
                                                                        style="font-size:11px;"
                                                                        placeholder="Enter Account Number"
                                                                        wire:model="bank.account_number">
                                                                </div>
                                                            </div>


                                                            <?php $__errorArgs = ['bank.account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger error"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="px-1 ">
                                                            <!--<label for="disabledSelect" class="form-label">Bank Name</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Bank Name" wire:model.debounce.500="bank.name">-->
                                                            <div class="row mb-2">
                                                                <label for="exampleFormControlInput1"
                                                                    style="font-size:1vw;"
                                                                    class="col-sm-2 col-form-label">Bank</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text" class="form-control"
                                                                        id="exampleFormControlInput1"
                                                                        style="font-size:11px;"
                                                                        placeholder="Enter Bank Name"
                                                                        wire:model="bank.name">
                                                                </div>
                                                            </div>



                                                            <?php $__errorArgs = ['bank.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger error"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div class="px-1 ">
                                                            <!--<label for="disabledSelect" class="form-label">Sort Code</label>-->
                                                            <!--<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Sort Code" wire:model.debounce.500="bank.sort_code">-->
                                                            <div class="row mb-2">
                                                                <label for="exampleFormControlInput1"
                                                                    style="font-size:1vw;"
                                                                    class="col-sm-2 col-form-label">S.code</label>
                                                                <div class="col-sm-10">
                                                                    <input type="text" class="form-control"
                                                                        id="exampleFormControlInput1"
                                                                        style="font-size:11px;"
                                                                        placeholder="Enter Sort Code"
                                                                        wire:model="bank.sort_code">
                                                                </div>
                                                            </div>



                                                            <?php $__errorArgs = ['bank.sort_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger error"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="px-2 py-2">
                                                            <div class="form-check">
                                                                <input style="transform: scale(0.8);"
                                                                    class="form-check-input" type="checkbox"
                                                                    value="" id="flexCheckDefault" />
                                                                <label style="font-size:0.9vw;"
                                                                    class="form-check-label" for="flexCheckDefault">
                                                                    Agree with Privacy Policy Terms & Conditions
                                                                </label>
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="cursor-point align-items-center d-grid gap-2 col-12 justify-content-center">

                                                            <button class="btn btn-danger text-white"
                                                                wire:click="submit">Submit</button>


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-md-2 d-sm-none d-md-none d-lg-block"></div>

                <div class="col-md-4 col-lg-4 sol-sm-12 mt-5">
                    <!--<div class="mt-5">-->
                    <!--    <div class=" pt-1 justify-content-center">-->
                    <!--        <div class>-->
                    <!--            <div class="container"-->
                    <!--                style="width: 100%; max-width: 380px; height: 220px; border: 2px solid rgba(128, 128, 128, 0.3); border-radius: 8px">-->
                    <!--                <div class="container p-2">-->
                    <!--                    <p class="text-center"-->
                    <!--                        style="font-size: 2vw;">Sell-->
                    <!--                        Summary</p>-->
                    <!--                    <div-->
                    <!--                        class="d-flex  pb-3 justify-content-between">-->
                    <!--                        <span><b>Model name</b> </span>-->


                    <!--                        <span class="text-muted"><?php echo e($modelName); ?></span>-->
                    <!--                    </div>-->
                    <!--                    <div-->
                    <!--                        class="d-flex  pb-3 justify-content-between">-->
                    <!--                        <span><b>Price</b> </span>-->
                    <!--                        <span class="text-muted">£ <?php echo e($price ?? ''); ?>.00 </span>-->
                    <!--                    </div>-->
                    <!--                    <div  style=" ;"-->
                    <!--                        class="d-flex pb-3 justify-content-between">-->
                    <!--                        <span> <b>Type</b> </span>-->
                    <!--                        <span class="text-muted"> -->
                    <!--                        <p><?php echo e($form_name); ?></p>-->

                    <!--                    </div>-->
                    <!-- hr -->
                    <!--<hr-->
                    <!--    style="  border-top: 2px dotted black;">-->
                    <!--                    <div-->
                    <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                    <!--                        <span></span>-->
                    <!--                        <span class="text-muted"> -->
                    <!--                            </span>-->
                    <!--                    </div>-->
                    <!--                    <div-->
                    <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                    <!--                        <span> </span>-->
                    <!--                        <span-->
                    <!--                            class="text-muted"></span>-->
                    <!--                    </div>-->
                    <!--                    <div-->
                    <!--                        class="d-flex pt-1 pb-3 justify-content-between">-->
                    <!--                        <span></span>-->
                    <!--                        <span class="text-muted"></span>-->
                    <!--                    </div>-->
                    <!--                </div>-->
                    <!--<div class="d-flex justify-content-center">-->
                    <!--    <button type="button"-->
                    <!--        class="btn  btn-lg "-->
                    <!--        style="width: 100%; border-radius: 0;background-color: red ; color: white">-->
                    <!--        Proceed To Checkout-->
                    <!--    </button>-->
                    <!--</div>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->





                    <div style="position:relative;top:10px;" class="container">

                        <table class="table table-striped border mt-5">
                            <thead>



                                <tr>
                                    <th colspan="2" class="text-center text-danger fw-bolder fs-3">Sell Summary
                                    </th>
                                    <!-- Center-aligned heading -->
                                </tr>



                                <tr>

                                    <td>Model</td>
                                    <td class="text-end"><?php echo e($modelName); ?></td>

                                </tr>
                            </thead>
                            <tbody>
                                <tr class="justify-content-between

">

                                    <td>Type</td>
                                    <td class="text-end"><?php echo e($form_name); ?></td>

                                </tr>





                                <tr>

                                    <td>Price</td>


                                    <td class="text-end">£ <?php echo e($price ?? ''); ?>.00 </td>

                                </tr>

                            </tbody>
                        </table>
                    </div>








                </div>







            </div>


        </div>
    <?php endif; ?>






    <script>
        function handleRadio(button) {
            var radio = button.querySelector('input[name="radio-payment"]');
            var isChecked = radio.checked;

            // Uncheck all radio buttons with name "radio-payment"
            document.querySelectorAll('input[name="radio-payment"]').forEach(function(radioBtn) {
                radioBtn.checked = false;
            });

            // If radio button was not checked, check it
            if (!isChecked) {
                radio.checked = true;
            }
        }
    </script>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/guest/sell/booking-form.blade.php ENDPATH**/ ?>
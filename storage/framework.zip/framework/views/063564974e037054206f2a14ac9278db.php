<div>
    <div>
        <!-- --------------------------top bar----------------- -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l3630411695-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3630411695-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3630411695-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3630411695-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3630411695-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <!-- --------------------navbar--------------------- -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l3630411695-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3630411695-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3630411695-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3630411695-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3630411695-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div class="container-fluid mt-5">

            <div class="row d-flex align-items-between p-2 mt-5">
                <div class="col-lg-6">
                    <div>
                        <?php if($map_link): ?>
                        <?php echo $map_link; ?>

                        <?php else: ?>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d19868.378589988257!2d-0.370116!3d51.503174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760d4e05cae911%3A0x2dcb4d18fbda3298!2sMobile%20Bitz%20-%20Head%20Office!5e0!3m2!1sen!2sus!4v1704983208144!5m2!1sen!2sus" width="100%" height="550" style="border: 0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-6">
                    <h1 class="text-danger text-center">
                        Mobile Bitz - <?php echo e($branch->name); ?>

                    </h1>
                    <div class="d-flex flex-row mt-5 gap-3 justify-content-center">
                        <h3>Address:</h3>
                        <p class=""><?php echo e($branch->address_line_1); ?>, <?php echo e($branch->address_line_2); ?><?php echo e($branch->address_line_2 != '' ? ', ' : ''); ?> <?php echo e($branch->town_city); ?>, <?php echo e($branch->post_code); ?>,UK</p>
                    </div>
                    <p class="text-center">**Find us between EE and Accessorize**</p>
                    <div class="d-flex flex-row  gap-3 justify-content-center">
                        <h3>Email:</h3>
                        <p class=""><?php echo e($branch->email); ?></p>
                    </div>
                    <div class="d-flex flex-row  gap-3 justify-content-center">
                        <h3>Call us:</h3>
                        <p class=""> <?php echo e($branch->mobile_number); ?></p>
                    </div>
                    <h3 class="text-center">Opening Hours: </h3>
                    <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-center"><?php echo e($timeSlot->day); ?>: <?php if($timeSlot->status): ?> <?php echo e(date('h:i a', strtotime($timeSlot->opening_time))); ?> To <?php echo e(date('h:i a', strtotime($timeSlot->closing_time))); ?> <?php else: ?> Closed <?php endif; ?> </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <div class="justify-content-around mt-5 row">
                        <div class="col-md-4 mb-2">
                            <a href="<?php echo e(route('guest-sell-categories')); ?>">
                                <button type="button" class="btn w-100 btn-danger my-2 rounded-0">
                                    SELL
                                </button>
                            </a>
                        </div>
                        <div class="col-md-4 mb-2">

                            <a href="<?php echo e(route('guest-buy-products')); ?>">
                                <button type="button" class="btn w-100 btn-danger my-2 rounded-0">
                                    BUY
                                </button>
                            </a>

                        </div>
                        <div class="col-md-4 mb-2">
                            <a href="<?php echo e(route('categories')); ?>">
                                <button type="button" class="btn w-100 btn-danger my-2 rounded-0">
                                    REPAIR
                                </button>
                            </a>
                        </div>
                    </div>






                </div>
            </div>
        </div>



        <!-- <h3 class=" text-center mt-5">Repair Your Device with Confidence</h3> -->
        <div class="container-fluid mt-5">

            <div class="row d-flex align-items-between p-3 mt-5">
                <div class="col-lg-6 mt-5">
                    <h2 class="text-danger">
                        About Our <?php echo e($branch->name); ?>

                    </h2>

                    <?php echo $branch->description; ?>


                </div>
                <div class="col-lg-6 mt-5">
                    <div>
                        <img src="<?php echo e($branch->image ? $branch->image : 'https://ik.imagekit.io/qml3d7tgz/118771222_3248867385205903_5573724224360234256_n_nW6iVMHYK.jpg'); ?>" class="img-fluid" style="border: 0"></img>
                    </div>
                </div>







            </div>
        </div>
    </div>
</div><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/guest/stores/store-details.blade.php ENDPATH**/ ?>
<div>

    <?php

        $form_name = 'Fix at my address';

    ?>

    <div>
        <?php
            $storedInputValue = Session::get('storedInputValue');
        ?>
        <?php if($storedInputValue): ?>
            <p>Delievry Charges For Postal Repair: $<?php echo e($storedInputValue); ?></p>
        <?php endif; ?>






        <?php
            $storedCollectionRepairPrice = Session::get('collectionRepairPrice');
        ?>
        <?php if($storedCollectionRepairPrice): ?>
            <p style="font-size:1vw">Delivery Charges For Collection Repair: £<?php echo e($storedCollectionRepairPrice); ?></p>
        <?php endif; ?>













        <div>
            <div class="rounded p-4">
                <div class="z ">
                    <div class="col-md-12">


                        <?php if($form_type == 'postal_form'): ?>
                                                <?php

                                                    $form_name = 'Post Your Device';

                                                ?>

                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" checked disabled />
                                                    <label class="form-check-label">
                                                        Surcharge for UK return delivery : £ 15
                                                    </label>

                                                </div>
                        <?php endif; ?>

                        <?php if($form_type == 'collection_form'): ?>
                                                <?php

                                                    $form_name = 'Collect My Device';

                                                ?>
                        <?php endif; ?>


                        <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>




                        <?php if($form_type == 'clinic_form'): ?>
                                                <?php

                                                    $form_name = 'Store Repair';

                                                ?>
                        <?php endif; ?>










                        <div style="margin-left:13% ;">
                            <h2 class="text-center" style="color: red;">How would you like to Pay?</h2>
                            <p class="text-center fw-bolder fs-5">Select your payment option</p>

                        </div>

                        <div class="row  d-none d-md-flex d-lg-flex">
                            <div class="col-lg-6 col-12 ">
                                <div class="row">
                                    <div>
                                        <div class=""
                                            style="border: 1px solid rgba(128, 128, 128, 0.367); border-radius: 10px ;">
                                            <div>

                                                <?php if($form_type == 'clinic_form'): ?>
                                                    <section class="accordion" style="margin-left:5%; margin-right: 5%">
                                                        <div class="tab mt-2">
                                                            <input class="form-check-input w-75"
                                                                wire:click="changePm('drop_at')" type="checkbox"
                                                                name="accordion-1" id="cb4" check>

                                                            <label for="cb4" class="tab__label">
                                                                <div class="row  p-2 col-12   rounded">

                                                                    <div class="col-6 text-start ">

                                                                        <b class="fw-5" style="font-size: large;">Pay
                                                                            in-Store</b>

                                                                    </div>

                                                                    <div class="col-6 text-end mt-2">
                                                                        <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                                    </div>

                                                                </div>
                                                            </label>

                                                            <div class="tab__content col-12 d-flex flex-column justify-content-center text-black"
                                                                style="border-top: 1px solid rgba(128, 128, 128, 0.367);">
                                                                <!-- Checkbox -->
                                                                <input class="form-check-input mb-3" type="checkbox"
                                                                    wire:model="isChecked" id="checkBox">

                                                                <div class="d-flex justify-content-center">
                                                                    <p style="font-size:1vw;" class="mt-1 fw-bolder">Pay at
                                                                        store when you visit our location below</p>
                                                                </div>

                                                                <div style="margin-top:-5%;color:#808080 ">
                                                                    <p style="font-size:1vw; "> <svg
                                                                            xmlns="http://www.w3.org/2000/svg" width="16"
                                                                            height="16" fill="currentColor"
                                                                            class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                                                                            <path
                                                                                d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6" />
                                                                        </svg> <?php echo e($name); ?>, <?php echo e($address_line_1); ?>,
                                                                        <?php echo e($address_line_2); ?><?php echo e($address_line_2 != '' ? ', ' : ''); ?>

                                                                        <?php echo e($town_city); ?>, <?php echo e($post_code); ?>

                                                                    </p>
                                                                    <div class="details-con">
                                                                        <p style="margin-top:-4%;font-size:1vw;"><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                width="16" fill="currentColor"
                                                                                class="bi bi-envelope" viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                                                                            </svg> &nbsp; &nbsp;<?php echo e($email); ?></p>
                                                                    </div>
                                                                </div>
                                                                <div style="margin-top:-4%;font-size:1vw;" class="d-flex ">
                                                                    <p style="float: left;font-size:1vw; color:#808080">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16"
                                                                            height="16" fill="currentColor"
                                                                            class="bi bi-telephone-forward"
                                                                            viewBox="0 0 16 16">
                                                                            <path
                                                                                d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708" />
                                                                        </svg>
                                                                        &nbsp; &nbsp; <?php echo e($landline_number); ?>

                                                                    </p>


                                                                    <!-- Button -->
                                                                    <div class="d-flex justify-content-end"
                                                                        style="margin-left:50%">
                                                                        <?php if($pm == 'drop_at'): ?>
                                                                            <button class="btn btn-danger mb-4" type="button"
                                                                                wire:click="BookRepair">
                                                                                Submit
                                                                            </button>
                                                                        <?php endif; ?>
                                                                    </div>

                                                                </div>


                                                            </div>





                                                        </div>

                                                    </section>
                                                <?php endif; ?> 


                                                <section class="accordion" style="margin-left:5%; margin-right:5%;">
                                                    <div class="tab mt-2">
                                                        <input type="checkbox" class="form-check-input"
                                                            wire:click="changePm('stripe')" name="accordion-1" id="cb3"
                                                            check>

                                                        <label for="cb3" class="tab__label">
                                                            <div class="row  p-2 col-12  rounded">

                                                                <div class="col-6 text-start ">
                                                                    <b class="fw-5" style="font-size: large;">Pay With
                                                                        Card</b>
                                                                    <img class="img-fluid " style="width:30%; "
                                                                        src="https://ik.imagekit.io/4csyk445b/2560px-Stripe_Logo__revised_2016%205.png?updatedAt=1711551636602"
                                                                        alt="">
                                                                </div>

                                                                <div class="col-6 text-end mt-2">
                                                                    <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                                </div>

                                                            </div>
                                                        </label>
                                                        <div class="tab__content col-12 d-flex justify-content-center align-items-center"
                                                            style="border-top: 1px solid rgba(128, 128, 128, 0.367);">

                                                            <?php if($pm == 'stripe'): ?>
                                                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2036710408-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2036710408-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2036710408-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2036710408-0');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2036710408-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                            <?php endif; ?>

                                                        </div>
                                                    </div>

                                                </section>

                                                <section class="accordion  " style="margin-left:5%; margin-right:5%">
                                                    <div class="tab mt-2">
                                                        <input class="form-check-input w-75" type="checkbox"
                                                            wire:click="changePm('paypal')" name="accordion-1" id="cb1"
                                                            checked>

                                                        <label for="cb1" class="tab__label">
                                                            <div class="row  p-2 col-12  rounded">

                                                                <div class="col-6 text-start ">
                                                                    <img class="img-fluid w-25"
                                                                        src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png"
                                                                        alt="">
                                                                </div>

                                                                <div class="col-6 text-end mt-2">
                                                                    <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                                </div>

                                                            </div>

                                                        </label>
                                                        <div class="tab__content col-12 d-flex justify-content-center align-items-center"
                                                            style="border-top: 1px solid rgba(128, 128, 128, 0.367);">
                                                            <?php if($pm == 'paypal'): ?>
                                                                <div class=" mt-2">
                                                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2036710408-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2036710408-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2036710408-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2036710408-1');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2036710408-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>


                                                    </div>

                                                </section>

                                                <section class="accordion" style="margin-left:5% ; margin-right:5%">
                                                    <div class="tab mt-2 mb-2">
                                                        <input class="form-check-input w-75"
                                                            wire:click="changePm('klarna')" type="checkbox"
                                                            name="accordion-1" id="cb2" check>

                                                        <label for="cb2" class="tab__label">
                                                            <div class="row  p-2 col-12   rounded">

                                                                <div class="col-6 text-start ">
                                                                    <img class="img-fluid w-25"
                                                                        src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Klarna_Payment_Badge.svg/2560px-Klarna_Payment_Badge.svg.png"
                                                                        alt="">
                                                                </div>

                                                                <div class="col-6 text-end mt-2">
                                                                    <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                                </div>

                                                            </div>
                                                        </label>
                                                        <div
                                                            class="tab__content col-12 d-flex justify-content-center align-items-center">
                                                            <?php if($pm == 'klarna'): ?>
                                                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2036710408-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l2036710408-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2036710408-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2036710408-2');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2036710408-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                            <?php endif; ?>

                                                        </div>
                                                    </div>

                                                </section>

                                            </div>

                                            <style>
                                                :root {
                                                    --primary: #227093;
                                                    --secondary: #ff5252;
                                                    --background: #eee;
                                                    --highlight: #ffda79;
                                                    /* Theme color */
                                                    --theme: var(--primary);
                                                }



                                                /* Core styles/functionality */
                                                .tab input {
                                                    position: absolute;
                                                    opacity: 0;
                                                    z-index: -1;
                                                }

                                                .tab__content {
                                                    max-height: 0;
                                                    overflow: hidden;
                                                    transition: all 0.35s;
                                                }

                                                .tab input:checked~.tab__content {
                                                    max-height: 10rem;
                                                }

                                                /* Visual styles */
                                                .accordion {
                                                    color: var(--theme);
                                                    /* border: 2px solid; */
                                                    border-radius: 0.5rem;
                                                    overflow: hidden;
                                                }

                                                .tab__label,
                                                .tab__close {
                                                    display: flex;
                                                    color: black;
                                                    /* background: var(--theme); */
                                                    cursor: pointer;
                                                }

                                                .tab__label {
                                                    justify-content: space-between;
                                                    padding: 1rem;
                                                }

                                                .tab__label::after {
                                                    /* content: "\276F"; */
                                                    width: 1em;
                                                    height: 1em;
                                                    text-align: center;
                                                    transform: rotate(90deg);
                                                    transition: all 0.35s;
                                                }

                                                .tab input:checked+.tab__label::after {
                                                    transform: rotate(270deg);
                                                }

                                                .tab__content p {
                                                    margin: 0;
                                                    padding: 1rem;
                                                }

                                                .tab__close {
                                                    justify-content: flex-end;
                                                    padding: 0.5rem 1rem;
                                                    font-size: 0.75rem;
                                                }

                                                .accordion--radio {
                                                    --theme: var(--secondary);
                                                }

                                                /* Arrow animation */
                                                .tab input:not(:checked)+.tab__label:hover::after {
                                                    animation: bounce .5s infinite;
                                                }

                                                @keyframes bounce {
                                                    25% {
                                                        transform: rotate(90deg) translate(.25rem);
                                                    }

                                                    75% {
                                                        transform: rotate(90deg) translate(-.25rem);
                                                    }
                                                }
                                            </style>




                                            <div class=" gap-2">
                                                <?php if($form_type == 'clinic_form'): ?>
                                                <?php endif; ?>

                                            </div>
                                        </div>

                                    </div>


                                </div>

                            </div>
                            <div class="col-lg-6">

                                <div style="position:relative;top:10px;" class="container">

                                    <table class="table table-striped border mt-2">
                                        <thead>



                                            <tr>
                                                <th colspan="2" class="text-center text-danger fw-bolder fs-3">
                                                    Repair
                                                    Summary</th> <!-- Center-aligned heading -->
                                            </tr>





                                            <tr>

                                                <td>Model</td>
                                                <td class="text-end">
                                                    <?php echo e($data['modal']['name']); ?>

                                                </td>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="justify-content-between">

                                                <td>Type</td>
                                                <td class="text-end"><?php echo e($form_name); ?></td>

                                            </tr>







                                            <tr>

                                                <td style="white-space: nowrap;">Total Price</td>


                                                <td class="text-end">

                                                    <div>
                                                        
                                                        £ <?php echo e($price ?? ''); ?>.00

                                                </td>

                                            </tr>





                                            <tr>

                                                <td>Repair time</td>
                                                <td class="text-end">1 Hour </td>

                                            </tr>


                                            <tr>

                                                <td>Warranty</td>
                                                <td class="text-end"> 12 months </td>

                                            </tr>

                                        </tbody>
                                    </table>
                                </div>










                            </div>
                        </div>


                        <?php if($pm == 'stripe'): ?>
                        <?php endif; ?>
                        <?php if($pm == 'paypal'): ?>
                        <?php endif; ?>

                        <?php if($pm == 'klarna'): ?>
                        <?php endif; ?>

                        <?php if($pm == 'drop_at' && $form_type == 'clinic_form'): ?>

                            <div class="d-flex justify-content-between align-items-center">
                                <?php if($success): ?>
                                    <div class="alert alert-success" role="alert">
                                        <h4 class="alert-heading">Congratulations! 🎉 Your order has been successfully
                                            placed.
                                        </h4>
                                        <p>Sit tight while we process your request. Check your email for more
                                            instructions.
                                        </p>
                                        <hr>
                                        <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
                                    </div>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>

                        <?php endif; ?>
                    </div>


                    <!----------------------------------------mobile screen------>
                    <div class="row d-md-none d-lg-none " style="width:126%; margin-left:-13%">
                        <div class="col-lg-6 col-12 ">
                            <div class="row">
                                <div>
                                    <div class=""
                                        style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 10px ;">
                                        <div>

                                            <?php if($form_type == 'clinic_form'): ?>
                                                <section class="accordion" style="margin-left:5%; margin-right: 5%">
                                                    <div class="tab mt-2"
                                                        style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 10px">
                                                        <input class="form-check-input w-75"
                                                            wire:click="changePm('drop_at')" type="checkbox"
                                                            name="accordion-1" id="cb5" check>

                                                        <label for="cb5" class="tab__label">
                                                            <div class="row  p-2 col-12   rounded">

                                                                <div class="col-6 text-start ">

                                                                    <b class="fw-5" style="font-size: large;">Pay
                                                                        in-Store</b>

                                                                </div>

                                                                <div class="col-6 text-end mt-2">
                                                                    <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                                </div>

                                                            </div>
                                                        </label>

                                                        <div class="tab__content col-12 d-flex text-black flex-column justify-content-center "
                                                            style="border-top: 2px solid rgba(128, 128, 128, 0.367);">
                                                            <!-- Checkbox -->
                                                            <input class="form-check-input mb-3" type="checkbox"
                                                                wire:model="isChecked" id="checkBox">

                                                            <div class="d-flex justify-content-center">
                                                                <p style="font-size:10px;" class="mt-1 fw-bolder">Pay at
                                                                    store when you visit our location below</p>
                                                            </div>

                                                            <div style="margin-top:-10%; ">
                                                                <p style="font-size:10px;"> <svg
                                                                        xmlns="http://www.w3.org/2000/svg" width="16"
                                                                        height="16" fill="currentColor"
                                                                        class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6" />
                                                                    </svg> <?php echo e($name); ?>, <?php echo e($address_line_1); ?>,
                                                                    <?php echo e($address_line_2); ?><?php echo e($address_line_2 != '' ? ', ' : ''); ?>

                                                                    <?php echo e($town_city); ?>, <?php echo e($post_code); ?>

                                                                </p>
                                                                <div class="details-con">
                                                                    <p style="margin-top:-10%;font-size:10px;"><svg
                                                                            xmlns="http://www.w3.org/2000/svg" width="16"
                                                                            fill="currentColor" class="bi bi-envelope"
                                                                            viewBox="0 0 16 16">
                                                                            <path
                                                                                d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                                                                        </svg> <?php echo e($email); ?></p>
                                                                </div>
                                                            </div>
                                                            <div style="margin-top:-8%;font-size:10px;" class="d-flex ">
                                                                <p style="float: left;font-size:10px;">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16"
                                                                        height="16" fill="currentColor"
                                                                        class="bi bi-telephone-forward" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708" />
                                                                    </svg>
                                                                    <?php echo e($landline_number); ?>

                                                                </p>


                                                                <!-- Button -->
                                                                <div class="d-flex justify-content-end"
                                                                    style="margin-left:23%">
                                                                    <?php if($pm == 'drop_at'): ?>
                                                                        <button class="btn btn-danger mb-4" type="button"
                                                                            wire:click="BookRepair">
                                                                            Submit
                                                                        </button>
                                                                    <?php endif; ?>
                                                                </div>

                                                            </div>


                                                        </div>





                                                    </div>

                                                </section>
                                            <?php endif; ?> 


                                            <section class="accordion" style="margin-left:5%; margin-right:5%;">
                                                <div class="tab mt-2"
                                                    style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 10px">
                                                    <input type="checkbox" class="form-check-input"
                                                        wire:click="changePm('stripe')" name="accordion-1" id="cb6"
                                                        check>

                                                    <label for="cb6" class="tab__label">
                                                        <div class="row  p-2 col-12  rounded">

                                                            <div class="col-6 text-start ">
                                                                <b class="fw-5" style="font-size: large;">Pay With
                                                                    Card</b>
                                                                <img class="img-fluid " style="width:30%; "
                                                                    src="https://ik.imagekit.io/4csyk445b/2560px-Stripe_Logo__revised_2016%205.png?updatedAt=1711551636602"
                                                                    alt="">
                                                            </div>

                                                            <div class="col-6 text-end mt-2">
                                                                <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                            </div>

                                                        </div>
                                                    </label>
                                                    <div class="tab__content col-12 d-flex justify-content-center align-items-center"
                                                        style="border-top: 2px solid rgba(128, 128, 128, 0.367);">

                                                        <?php if($pm == 'stripe'): ?>
                                                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2036710408-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l2036710408-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2036710408-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2036710408-3');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.stripe', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2036710408-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>

                                            </section>

                                            <section class="accordion  " style="margin-left:5%; margin-right:5%">
                                                <div class="tab mt-2"
                                                    style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 10px">
                                                    <input class="form-check-input w-75" type="checkbox"
                                                        wire:click="changePm('paypal')" name="accordion-1" id="cb7"
                                                        checked>

                                                    <label for="cb7" class="tab__label">
                                                        <div class="row  p-2 col-12  rounded">

                                                            <div class="col-6 text-start ">
                                                                <img class="img-fluid w-25"
                                                                    src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png"
                                                                    alt="">
                                                            </div>

                                                            <div class="col-6 text-end mt-2">
                                                                <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                            </div>

                                                        </div>

                                                    </label>
                                                    <div class="tab__content col-12 d-flex justify-content-center align-items-center"
                                                        style="border-top: 2px solid rgba(128, 128, 128, 0.367);">
                                                        <?php if($pm == 'paypal'): ?>
                                                            <div class=" mt-2">
                                                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2036710408-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l2036710408-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2036710408-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2036710408-4');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.paypal', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2036710408-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>


                                                </div>

                                            </section>

                                            <section class="accordion" style="margin-left:5% ; margin-right:5%">
                                                <div class="tab mt-2 mb-2"
                                                    style="border: 2px solid rgba(128, 128, 128, 0.367); border-radius: 10px">
                                                    <input class="form-check-input w-75" wire:click="changePm('klarna')"
                                                        type="checkbox" name="accordion-1" id="cb8" check>

                                                    <label for="cb8" class="tab__label">
                                                        <div class="row  p-2 col-12   rounded">

                                                            <div class="col-6 text-start ">
                                                                <img class="img-fluid w-25"
                                                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Klarna_Payment_Badge.svg/2560px-Klarna_Payment_Badge.svg.png"
                                                                    alt="">
                                                            </div>

                                                            <div class="col-6 text-end mt-2">
                                                                <h3 class="text-danger fw-bold">£<?php echo e($price); ?></h3>
                                                            </div>

                                                        </div>
                                                    </label>
                                                    <div class="tab__content col-12 d-flex justify-content-center align-items-center"
                                                        style="border-top: 2px solid rgba(128, 128, 128, 0.367);">
                                                        <?php if($pm == 'klarna'): ?>
                                                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Repair'])->html();
} elseif ($_instance->childHasBeenRendered('l2036710408-5')) {
    $componentId = $_instance->getRenderedChildComponentId('l2036710408-5');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2036710408-5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2036710408-5');
} else {
    $response = \Livewire\Livewire::mount('payment-methods.klarna', ['price' => $price,'color' => 'success','service' => 'Repair']);
    $html = $response->html();
    $_instance->logRenderedChild('l2036710408-5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>

                                            </section>

                                        </div>

                                        <style>
                                            :root {
                                                --primary: #227093;
                                                --secondary: #ff5252;
                                                --background: #eee;
                                                --highlight: #ffda79;
                                                /* Theme color */
                                                --theme: var(--primary);
                                            }



                                            /* Core styles/functionality */
                                            .tab input {
                                                position: absolute;
                                                opacity: 0;
                                                z-index: -1;
                                            }

                                            .tab__content {
                                                max-height: 0;
                                                overflow: hidden;
                                                transition: all 0.35s;
                                            }

                                            .tab input:checked~.tab__content {
                                                max-height: 10rem;
                                            }

                                            /* Visual styles */
                                            .accordion {
                                                color: var(--theme);
                                                /* border: 2px solid; */
                                                border-radius: 0.5rem;
                                                overflow: hidden;
                                            }

                                            .tab__label,
                                            .tab__close {
                                                display: flex;
                                                color: black;
                                                /* background: var(--theme); */
                                                cursor: pointer;
                                            }

                                            .tab__label {
                                                justify-content: space-between;
                                                padding: 1rem;
                                            }

                                            .tab__label::after {
                                                /* content: "\276F"; */
                                                width: 1em;
                                                height: 1em;
                                                text-align: center;
                                                transform: rotate(90deg);
                                                transition: all 0.35s;
                                            }

                                            .tab input:checked+.tab__label::after {
                                                transform: rotate(270deg);
                                            }

                                            .tab__content p {
                                                margin: 0;
                                                padding: 1rem;
                                            }

                                            .tab__close {
                                                justify-content: flex-end;
                                                padding: 0.5rem 1rem;
                                                font-size: 0.75rem;
                                            }

                                            .accordion--radio {
                                                --theme: var(--secondary);
                                            }

                                            /* Arrow animation */
                                            .tab input:not(:checked)+.tab__label:hover::after {
                                                animation: bounce .5s infinite;
                                            }

                                            @keyframes bounce {
                                                25% {
                                                    transform: rotate(90deg) translate(.25rem);
                                                }

                                                75% {
                                                    transform: rotate(90deg) translate(-.25rem);
                                                }
                                            }
                                        </style>




                                        <div class=" gap-2">
                                            <?php if($form_type == 'clinic_form'): ?>
                                            <?php endif; ?>

                                        </div>
                                    </div>

                                </div>


                            </div>

                        </div>
                        <div class="col-lg-6">

                            <div style="position:relative;top:10px;" class="container">

                                <table class="table table-striped border mt-2">
                                    <thead>



                                        <tr>
                                            <th colspan="2" class="text-center text-danger fw-bolder fs-3">
                                                Repair
                                                Summary</th> <!-- Center-aligned heading -->
                                        </tr>





                                        <tr>

                                            <td>Model</td>
                                            <td class="text-end">
                                                <?php echo e($data['modal']['name']); ?>

                                            </td>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="justify-content-between">

                                            <td>Type</td>
                                            <td class="text-end"><?php echo e($form_name); ?></td>

                                        </tr>







                                        <tr>

                                            <td style="white-space: nowrap;">Total Price</td>


                                            <td class="text-end">

                                                <div>
                                                    
                                                    £ <?php echo e($price ?? ''); ?>.00

                                            </td>

                                        </tr>





                                        <tr>

                                            <td>Repair time</td>
                                            <td class="text-end">1 Hour </td>

                                        </tr>


                                        <tr>

                                            <td>Warranty</td>
                                            <td class="text-end"> 12 months </td>

                                        </tr>

                                    </tbody>
                                </table>
                            </div>










                        </div>
                    </div>


                    <?php if($pm == 'stripe'): ?>
                    <?php endif; ?>
                    <?php if($pm == 'paypal'): ?>
                    <?php endif; ?>

                    <?php if($pm == 'klarna'): ?>
                    <?php endif; ?>

                    <?php if($pm == 'drop_at' && $form_type == 'clinic_form'): ?>

                        <div class="d-flex justify-content-between align-items-center">
                            <?php if($success): ?>
                                <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="successModalLabel">Congratulations! ðŸŽ‰</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <h4>Your order has been successfully placed.</h4>
                                                <p>Sit tight while we process your request. Check your email for more
                                                    instructions.</p>
                                                <hr>
                                                <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <script>
                                    $(document).ready(function () {
                                        // Open the modal when the page loads if $success is true
                                        var successModal = new bootstrap.Modal(document.getElementById('successModal'));
                                        successModal.show();
                                    });
                                </script>
                            <?php else: ?>
                            <?php endif; ?>
                        </div>
                        <!--<div class="d-flex justify-content-between align-items-center">-->
                        <!--    <?php if($success): ?>-->
                        <!--        <div class="alert alert-success" role="alert">-->
                        <!--            <h4 class="alert-heading">Congratulations! 🎉 Your order has been successfully-->
                        <!--                placed.-->
                        <!--            </h4>-->
                        <!--            <p>Sit tight while we process your request. Check your email for more-->
                        <!--                instructions.-->
                        <!--            </p>-->
                        <!--            <hr>-->
                        <!--            <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>-->
                        <!--        </div>-->
                        <!--    <?php else: ?>-->
                        <!--    <?php endif; ?>-->
                        <!--</div>-->

                    <?php endif; ?>
                </div>

            </div>

        </div>

        <!-------------------------------mobil phone------------------><?php /**PATH /Users/mubashir/Documents/vscode (2)/resources/views/livewire/guest/components/book-repair.blade.php ENDPATH**/ ?>
<div>
    <?php
        $tagline = [
            'sell' => 'How you’ll send your device',
            'repair' => 'How would you like us to repair your device?',
            'buy' => 'How you’ll get your device',
        ];

        $heading = [
            'sell' => 'Selling Options',
            'repair' => 'Repair Options',
            'buy' => 'Buying Options',
        ];

        $postalText = [
            'sell' => 'Post Your Device',
            'repair' => 'Postal Repair',
            'buy' => 'Post My Device',
        ];

        $formService = strtolower($data['service']);
    ?>

    <?php if($showGrid): ?>
        <div class="grid-heading">
            <h3 class="text-center text-danger pt-4"><?php echo e($heading[$formService]); ?></h3>
            <p class="text-center"><?php echo e($tagline[$formService]); ?> </p>
        </div>

        <div class="bg-white">
            <section>
                <div class="grid-container" role="grid">
                    <?php if($formStatuses[0]->$formService): ?>
                        <div class="grid-item" wire:click="showForm('clinic_form')">
                            <div class="icon-container text-danger">
                                <img src="https://ik.imagekit.io/b6iqka2sz/Store%20Repair.png?updatedAt=1719830430304" alt="" style="width: 90px; height: 75px;">
                            </div>
                            <div class="option-label text-dark"><?php echo e($optionLabels['Store Repair']); ?> </div>
                            <div class="option-description"><a href="">Choose from one of our 65 nationwide locations.</a></div>
                        </div>
                    <?php endif; ?>

                    <?php if($formStatuses[1]->$formService): ?>
                        <div class="grid-item" wire:click="showForm('postal_form')" style="border: 2px solid black;">
                            <div class="icon-container text-danger">
                                <img src="https://ik.imagekit.io/b6iqka2sz/Postal%20Repair.png?updatedAt=1719830318561" alt="" style="width: 75px; height: 75px;">
                            </div>
                            <div class="option-label text-dark"><?php echo e($optionLabels['Postal Repair']); ?></div>
                            <div class="option-description"><a href="">No stores close to you? Send your device to us!</a></div>
                        </div>
                    <?php endif; ?>

                    <?php if($formStatuses[2]->$formService && $formService != 'buy'): ?>
                        <div class="grid-item mb-5" wire:click="showForm('collection_form')" style="border: 2px solid black;">
                            <div class="icon-container text-danger">
                                <img src="https://ik.imagekit.io/b6iqka2sz/Collect%20My%20Device.png?updatedAt=1719828743169" alt="" style="width: 75px; height: 75px;">
                            </div>
                            <div class="option-label text-dark"><?php echo e($optionLabels['Collect My Device']); ?></div>
                            <div class="option-description"><a href="">We'll pick up your device for repair and return it to you afterward.</a></div>
                        </div>
                    <?php endif; ?>

                    <?php if($formStatuses[3]->$formService && $data['device']['name'] != 'Apple iPad' && $formService == 'repair'): ?>
                        <div class="grid-item mb-5" wire:click="showForm('fix_form')" style="border: 2px solid black;">
                            <div class="icon-container text-danger">
                                <img src="https://ik.imagekit.io/b6iqka2sz/Fix%20At%20My%20Address.png?updatedAt=1719830266710" alt="" style="width: 75px; height: 75px;">
                            </div>
                            <div class="option-label text-dark"><?php echo e($optionLabels['Fix At My Address']); ?></div>
                            <div class="option-description"><a href="">Our technicians will visit your residence to repair your mobile device.</a></div>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    <?php endif; ?>

    <?php if($showForm): ?>
        <section>
            <div style="background-color:black">
                <div wire:loading wire:target="form_type" class="w-100">
                    <div class="overlay rounded d-flex flex-column justify-content-center align-items-center bg-pink-linear text-white" style="height:400px;">
                        <?php if (isset($component)) { $__componentOriginalf26909af655deaf31c8e20175813a5a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf26909af655deaf31c8e20175813a5a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spinner','data' => ['color' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf26909af655deaf31c8e20175813a5a0)): ?>
<?php $attributes = $__attributesOriginalf26909af655deaf31c8e20175813a5a0; ?>
<?php unset($__attributesOriginalf26909af655deaf31c8e20175813a5a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf26909af655deaf31c8e20175813a5a0)): ?>
<?php $component = $__componentOriginalf26909af655deaf31c8e20175813a5a0; ?>
<?php unset($__componentOriginalf26909af655deaf31c8e20175813a5a0); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="bg-white">
                    <div wire:loading.remove wire:target="form_type">
                        <?php if($showForm): ?>
                            <?php if($form_type == 'postal_form'): ?>
                                <div class="bg-white">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.postal-repair-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.postal-repair-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            <?php elseif($form_type == 'clinic_form'): ?>
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.clinic-repair-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.clinic-repair-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <?php elseif($form_type == 'collection_form'): ?>
                                <div wire:ignore>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.collection-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.collection-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            <?php elseif($form_type == 'fix_form'): ?>
                                <div wire:ignore>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.fix-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.fix-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <button class="button-20-back back-button" wire:click="hideForm">Go Back</button>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>

<style>
    .nav-tabs {
        display: flex;
        flex-wrap: nowrap;
        overflow-x: auto;
        border-bottom: none;
        background-color: transparent;
        scrollbar-width: none;
    }

    .nav-item {
        white-space: nowrap;
        color: green;
    }

    .nav-link {
        color: #3E3E3E;
    }

    .nav-link:hover {
        color: black !important;
    }

    .nav-link.active {
        color: #3E3E3E;
    }

    .nav-tabs::-webkit-scrollbar {
        display: none;
    }

    .nav-tabs .nav-link.active {
        background-color: white;
        position: relative;
        z-index: 1;
    }

    .tab-content {
        background-color: #ffffff;
        border-radius: 10px;
        width: 100%;
        margin: 0 auto;
        padding: 20px;
    }

    @media only screen and (max-width: 767px) {
        .tab-content {
            width: 100%;
            margin-left: -2%;
        }
    }

    .tab-content.postal-form {
        background-color: #f0f0f0;
    }

    .tab-content.clinic-form {
        background-color: #e0e0e0;
    }

    .grid-container {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        margin-bottom: 20px;
        padding-left: 200px;
        padding-right: 200px;
        padding-top: 40px;
    }

    .grid-item {
        background-color: hsl(0, 100%, 99%);
        padding: 20px;
        border-radius: 5px;
        text-align: center;
        transition: all 0.3s ease;
        cursor:pointer;
    }

    .grid-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
    }

    .icon-container {
        font-size: 2rem;
        margin-bottom: 10px;
    }

    .option-label {
        font-weight: bold;
        margin-bottom: 5px;
        cursor:text;
    }

    .option-description {
        font-size: 0.9rem;
        color: #666;
        cursor:text;
    }

    a {
        text-decoration: none;
    }

    .back-button {
        display: block;
        margin: 20px 0;
        padding: 10px 20px;
        background-color: #dc3545;
        color: white;
        text-align: center;
        border-radius: 5px;
        cursor: pointer;
    }

    .back-button:hover {
        background-color: #c82333;
    }

    /* Responsive Styles */
    @media (max-width: 576px) {
        .grid-container {
            grid-template-columns: repeat(1, 1fr);
            padding-left: 5px;
            padding-right: 5px;
        }
    }

    .grid-item {
        border: 2px solid black;
    }

    .grid-item:hover .option-label,
    .grid-item:hover .option-description a {
        color: #e21f18 !important; /* Change to desired hover color */
    }
</style>

<script>
    document.addEventListener('livewire:load', function () {
        Livewire.on('formShown', function () {
            document.querySelectorAll('.tab-pane').forEach(function (tabPane) {
                tabPane.classList.remove('active', 'show');
            });
        });

        Livewire.on('BranchSelected', function () {
            document.querySelector('.back-button').style.display = 'none';
        });
        Livewire.on('childGoBack', function () {
            document.querySelector('.back-button').style.display = 'block';
        });
    });
</script>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/guest/components/form-toggle.blade.php ENDPATH**/ ?>
<div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l1372405024-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1372405024-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1372405024-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1372405024-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1372405024-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- --------Navbar------------ -->
    <section class="head-sell">
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', [])->html();
} elseif ($_instance->childHasBeenRendered('l1372405024-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1372405024-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1372405024-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1372405024-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1372405024-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            

        </div>
    </section>
    <section class="head-sell my-5">
        
        <div class="container">
                    <a href="<?php echo e(route('home')); ?>">
                        
                    <button class="btn btn-danger btn-sm"  ><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8m15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
</svg></button>
                    </a>
                    
            <div class="row d-flex align-items-center">
                <div class="col-lg-6 p-3">

                    <p><?php echo $webContent->sell_heading_1; ?><?php echo e($siteSettings->buisness_name ?? ''); ?></p>
                    <h1 style=" font-family: heading;"><?php echo $webContent->sell_heading_2; ?></h1>

                    
                    <p><?php echo $webContent->sell_heading_3; ?></p>
                    <p class="lead"><?php echo $webContent->sell_heading_4; ?></p>
                </div>
                <div class="col-lg-6">
                    <img src="https://ik.imagekit.io/2nuimwatr/online-seller-1.jpg?updatedAt=1698831017024" class="img-fluid">
                </div>
            </div>
        </div>
    </section>
    <!-- ------------product-------- -->
    <section class="about">
        <div class="container">
            <h1 class="text-center " style="color: #E31E24"><?php echo $webContent->sell_heading_5; ?></h1>
            <hr class="w-25 mx-auto">
            <div class="">

                <div class="d-flex flex-wrap align-items-center justify-content-center my-2 gap-3 ">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('guest-sell-device-types', $category->id)); ?>" class="col-md-3 mb-3 mr-5">
                        <div class="card mb-3 mr-3">
                            <!-- Add margin-bottom (mb-3) and margin-right (mr-3) for space between cards -->
                            <img src="<?php echo e($category->file ?? ''); ?>" class="img-thumbnail" style="height:150px;">
                            <div class="icon"><i class="bi bi-tablet"></i></div>
                            <div class="card-body text-dark text-center fs-3">
                                <h4><b><?php echo e($category->name); ?></b></h4>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </div>





            </div>
            
        </div>
    </section>
    
    
    <section class="mobile">
        <div class="container">
            <h1><?php echo $webContent->sell_heading_6; ?></h1>
            <p><?php echo $webContent->sell_heading_7; ?></p>
         

        </div>
    </section>

    <section class="faq mb-5">
        <div class="container">
            <h1><?php echo $webContent->sell_heading_8; ?></h1>
            <p><?php echo e($siteSettings->buisness_name ?? ''); ?> <?php echo $webContent->sell_heading_9; ?></p>

            <div class="row">
                <div class="col-lg-6">
                    <div class="accordion-container 1   rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-1">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-1"> Why should you sell your mobile phone to <?php echo e($siteSettings->buisness_name ?? ''); ?>?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                                <?php echo $webContent->sell_heading_11; ?>

                            </div>
                        </div>





                    </div>

                    <div class="accordion-container 3  rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-3">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-3">What will happen to my phone?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                            <?php echo $webContent->sell_heading_15; ?>

                            </div>
                        </div>





                    </div>

                    <div class="accordion-container 5  rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-5">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-5"> How much is my device worth?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                                <?php echo $webContent->sell_heading_19; ?>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-lg-6">
                    <div class="accordion-container 2   rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-2">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-2">Why should I recycle my phone?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                              <?php echo $webContent->sell_heading_13; ?>

                            </div>
                        </div>





                    </div>

                    <div class="accordion-container 4   rounded-0">

                        <input type="checkbox" class="accordion d-none " id="accordion-4">
                        <label class="label d-block p-2 bg-danger text-white cursor-pointer rounded-0 border-bottom  text-center" for="accordion-4"> What will happen to my phone?</label>
                        <div class="content card rounded-0 text-black bg-white m-0">
                            <div style="font-size: 14px;" class="rounded-0 text-black bg-white m-0">
                                 <?php echo $webContent->sell_heading_17; ?>

                            </div>
                        </div>





                    </div>

                </div>










            </div>
        </div>
    </section>

    <style>
        /* Style for the label when the accordion is checked (open) */

        .label::before {
            content: '+';
            font-weight: 600;
            float: right;
        }

        .text-danger {
            color: #737272 !important;
        }

        .accordion:checked+.label::before {
            content: '-';
            float: right;
        }

        /* Style for the content of the accordion */
        .content {
            display: none;
            background-color: white !important;
            padding: 10px;
        }

        /* Style for the content when the accordion is checked (open) */
        .accordion:checked+.label+.content {
            display: block;

        }

        .bg-danger {
            background-color: #E31E24 !important;
        }
    </style>
</div><?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/livewire/guest/sell/categories.blade.php ENDPATH**/ ?>
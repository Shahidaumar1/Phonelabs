<div>
    <div class="d-flex">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'orders'])->html();
} elseif ($_instance->childHasBeenRendered('l1290016636-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1290016636-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1290016636-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1290016636-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'orders']);
    $html = $response->html();
    $_instance->logRenderedChild('l1290016636-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald033566f468fc7bb3a8d0f946fdab616 = $attributes; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

            <div class="container my-5">
                <div>
                    <div class="">
                        <div class="">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.orders.components.top-nav', ['active' => ''])->html();
} elseif ($_instance->childHasBeenRendered('l1290016636-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1290016636-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1290016636-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1290016636-1');
} else {
    $response = \Livewire\Livewire::mount('admin.orders.components.top-nav', ['active' => '']);
    $html = $response->html();
    $_instance->logRenderedChild('l1290016636-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                        </div>
                        <div class="" style="border: 0px;">
                            <input type="text" wire:model="search" class="form-control mb-4" placeholder="Search..." style="width: 150px;">
                            <div class="d-flex gap-4 flex-wrap table-responsive" style="overflow-x: auto;">
                                <!-- Search Input -->
                                <table class="table p-5">
                                    <thead style="background-color: #C0C0EF !important;">
                                        <tr style="background-color: #C0C0EF !important;">
                                            <th style="background-color: #C0C0EF !important;">Sr. No</th>
                                            <th style="background-color: #C0C0EF !important;">Booking Type</th>
                                            <th style="background-color: #C0C0EF !important;">Date Time</th>
                                            <th style="background-color: #C0C0EF !important;">Customer Email</th>
                                            
                                            <th style="background-color: #C0C0EF !important;">Customer Name</th>
                                            <th style="background-color: #C0C0EF !important;">Order Amount</th>
                                            <th style="background-color: #C0C0EF !important;">Payment Method</th>
                                            <th style="background-color: #C0C0EF !important;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $reversedIndex = count($orders) - $index;
                                        $order = $orders[$reversedIndex - 1]; // Reverse the order of array
                                        ?>
                                        <tr>
<td><?php echo e($reversedIndex); ?></td>
<td><?php echo e($order['Service']); ?></td>
<td><?php echo e($order['date_time']); ?></td>
<td><?php echo e($order['patient']['email']); ?></td>
<td>
    <?php if(!empty($order['patient']['first_name']) && !empty($order['patient']['last_name'])): ?>
        <?php echo e($order['patient']['first_name'] . ' ' . $order['patient']['last_name']); ?>

    <?php else: ?>
        <?php echo e($order['patient']['name']); ?>

    <?php endif; ?>
</td>

                                            <td>
                                                <?php if($order['Service'] === 'Repairing'): ?>
                                                £ <?php echo e($order['repair_detail']['quotePrice'] ?? 0); ?>

                                                <?php elseif($order['Service'] === 'Buy'): ?>
                                                £ <?php echo e($order['repair_detail']['price'] ?? 0); ?>

                                                <?php elseif($order['Service'] === 'Sell'): ?>
                                                £ <?php echo e($order['repair_detail']['specs']['price'] ?? 0); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($order['payment_method'] ?? 'N/A'); ?></td>
                                            <td>
                                                <div class="btn-group" role="group" style="width: 100%;">
                                                    <div style="width: 45%;">
                                                        <button wire:click="deleteOrder(<?php echo e($reversedIndex - 1); ?>)" class="btn btn-sm btn-danger w-100">Delete</button>
                                                    </div>
                                                    <div style="width: 45%;">
                                                        <a href="<?php echo e(route('orders-details', ['orderDetails' => $reversedIndex - 1])); ?>" class="btn btn-sm btn-primary w-100 ms-4">Details</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                document.addEventListener('livewire:load', function() {
                    window.searchTerm = '';

                    Livewire.hook('message.processed', (message, component) => {
                        // Update the table rows based on the search term
                        filterTableRows();
                    });

                    function filterTableRows() {
                        const searchTerm = window.searchTerm.toLowerCase();
                        const tableRows = document.querySelectorAll('.table-row');

                        tableRows.forEach(row => {
                            const rowData = row.innerText.toLowerCase();
                            if (rowData.includes(searchTerm)) {
                                row.style.display = '';
                            } else {
                                row.style.display = 'none';
                            }
                        });
                    }
                });
            </script>
            <script>
                document.addEventListener('livewire:load', function() {
                    Livewire.on('searchChanged', search => {
                        window.searchTerm = search;
                    });
                });
            </script>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $attributes = $__attributesOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__attributesOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/orders/index.blade.php ENDPATH**/ ?>
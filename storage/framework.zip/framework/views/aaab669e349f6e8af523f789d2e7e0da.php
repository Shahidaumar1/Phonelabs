<!-- Include this code in your Blade template or component -->

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l3173853832-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3173853832-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3173853832-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3173853832-0');
} else {
    $response = \Livewire\Livewire::mount('components.top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3173853832-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <section class="repair-types ">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white'])->html();
} elseif ($_instance->childHasBeenRendered('l3173853832-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3173853832-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3173853832-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3173853832-1');
} else {
    $response = \Livewire\Livewire::mount('components.mega-nav', ['theme' => 'white']);
    $html = $response->html();
    $_instance->logRenderedChild('l3173853832-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div class="container p-3 rounded-2 mt-5 d-flex justify-content-between align-items-center"
            style="background-color: #afafaf">
            <div class="d-flex flex-column">
                <h1 class="text-black">Need a Repair?</h1>
                <span class="tagline text-black">Tell Us Which Device You Have…</span>
            </div>

            <div class="d-flex justify-content-end align-items-center">
                
                <!--<h2 class="text-danger mt-3 ml-3 "><b>Students can get 10% Off on all repairs</b></h2>-->
            </div>

        </div>
        <div class="text-center my-4">
            <h2 class="text-danger">Broken <?php echo e($modal->name ?? ''); ?></h2>
            <span class="tagline text-black">We can fix that!</span>
        </div>
    </section>
    <?php if($device): ?>



        <section>
            <div class="container my-5">
                <div class=" d-flex align-items-center justify-content-center text-center">
                    <div class="d-flex gap-5 flex-wrap justify-content-center ">

                        <?php $__empty_1 = true; $__currentLoopData = $device->repair_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $price = App\Models\Price::where('modal_id', $modal->id)
                                    ->where('repair_type_id', $repair_type->id)
                                    ->first();
                                // $d = App\Helpers\SeoUrl::encodeUrl($device->name);
                                // $m = App\Helpers\SeoUrl::encodeUrl($modal->name);
                                // $r = App\Helpers\SeoUrl::encodeUrl($repair_type->name);
                            ?>

                            <?php if($price && $price->price > 0): ?>
                              <div class="card p-3 d-flex justify-content-center align-items-center"
     style="width: 300px; height: 350px; text-align: center; border: 1px solid #ddd; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); overflow: hidden;">
    <a href="<?php echo e(route('repair-detail', ['device' => $device->id, 'modal' => $modal->id, 'repair' => $repair_type->id])); ?>">
        <img src="<?php echo e(asset($repair_type->image) ?? ''); ?>" class="img-fluid p-3" style="height: 150px; width: auto;" alt="<?php echo e($repair_type->name); ?>">
    </a>
    <a href="<?php echo e(route('repair-detail', ['device' => $device->id, 'modal' => $modal->id, 'repair' => $repair_type->id])); ?>">
        <h4 class="text-center text-wrap" style="font-size: 1.2rem; margin: 10px 0;"><?php echo e($repair_type->name); ?></h4>
    </a>
    <h3 style="font-size: 1.5rem; margin: 10px 0;">£ <?php echo e($price->price); ?></h3>
    <a style="text-decoration: none;" href="<?php echo e(route('repair-detail', ['device' => $device->id, 'modal' => $modal->id, 'repair' => $repair_type->id])); ?>">
        <button class="btn btn-danger" type="button">Repair</button>
    </a>
</div>

                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No repair types found.</p>
                        <?php endif; ?>

                        
                    </div>

                    
                    


                </div>

            </div>
        </section>
    <?php endif; ?>
</div>

<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/guest/repair-types.blade.php ENDPATH**/ ?>
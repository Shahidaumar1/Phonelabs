<div>

    <?php if($mainBranch): ?>
    <p>&#128205:<?php echo e($siteBranch->name); ?> , <?php echo e($siteBranch->address_line_1); ?> , <?php echo e($siteBranch->address_line_2); ?> <?php echo e($siteBranch->address_line_2!=''?', ':''); ?> <?php echo e($siteBranch->town_city); ?> , <?php echo e($siteBranch->post_code); ?>,UK</p>
    <p>&#128235: <?php echo e($siteBranch->email); ?></p>
    <p>&#9742: <?php echo e($siteBranch->landline_number); ?> </p>
    <p>&#128222: <?php echo e($siteBranch->mobile_number); ?></p>
    <?php else: ?>
    <div class="mb-3 mt-3 ">
        <legend for="postalCode">
            <h4 class="fw-bold">Find a Store</h4>
        </legend>
        <div class="input-group mb-3">
            <input type="text" id="postalCode" required class="form-control" placeholder="Enter Postal Code">
            <button class="btn btn-outline-danger bg-danger text-white" type="button" id="button-addon2" onclick="getLatLong()">Search</button>
        </div>
        <div id="resultContainer"></div>

        <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('livewire:load', function() {
                const resultContainer = document.getElementById("resultContainer");

                Livewire.on('getLatLong', function() {
                    // Call the JavaScript function when the Livewire event is triggered

                    getLatLong();
                });
                async function getLatLong() {
                    const postalCode = document.getElementById("postalCode").value;

                    try {
                        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                        const data = await response.json();

                        if (data.length > 0) {
                            const result = data[0];
                            resultContainer.innerHTML = `<p>${result.display_name}</p>`;

                            Livewire.emit('updateLocation', {
                                latitude: result.lat,
                                longitude: result.lon
                            });
                        } else {
                            resultContainer.innerHTML = "<p>No results found for the provided postal code.</p>";
                        }
                    } catch (error) {
                        console.error("Error fetching data:", error);
                    }
                }

                // Add Livewire listener for location update
                Livewire.on('updateLocation', (location) => {
                    // Handle location update if needed
                    console.log('Received location update:', location);
                });

                // Your existing function call
                window.getLatLong = getLatLong;
            });
        </script>
        <?php $__env->stopPush(); ?>
        <?php if($nearestBraches): ?>

        <label for="email">Choose Store near you </label>
        <select class="form-control form-select form-control-sm" wire:model.lazy="clinic.name">
            <option>Select Store</option>

            <?php $__empty_1 = true; $__currentLoopData = $nearestBraches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($branch['branch']['name']); ?>"><?php echo e($branch['branch']['name']); ?>, Distance: <?php echo e(number_format($branch['distance'],2) != 0.00 ? number_format($branch['distance'],2) : 0); ?> Mile</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <option value="">Sorry we can not find</option>
            <?php endif; ?>
        </select>
        <?php else: ?>
        <label for="email">Choose Store</label>
    
    
    
    
    <select class="form-control form-select form-control-sm" wire:model.lazy="clinic.name" wire:change="refreshPage">
    <option>Select Store</option>
    <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <option value="<?php echo e($branch['name']); ?>"><?php echo e($branch['name']); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <option value="">Sorry, we cannot find any branches</option>
    <?php endif; ?>

    <?php $__errorArgs = ['clinic.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</select>

<?php $__env->startPush('scripts'); ?>
<script>
    Livewire.on('refreshPage', () => {
        location.reload();
    });
</script>
<?php $__env->stopPush(); ?>

    
    
    
    
    
    
    
    
        <!--<select class="form-control form-select form-control-sm" wire:model.lazy="clinic.name">-->
        <!--    <option>Select Store</option>-->

        <!--    <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>-->
        <!--    <option value="<?php echo e($branch['name']); ?>"><?php echo e($branch['name']); ?></option>-->
        <!--    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>-->

        <!--    <option value="">Sorry we can not find</option>-->
        <!--    <?php endif; ?>-->
        <!--</select>-->

        <!--<?php endif; ?>-->
        <!--<?php $__errorArgs = ['clinic.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
        <!--<span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>-->
        <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->

    </div>
    <?php if($clinic['name']): ?>
    <div class="my-3">
        <label> Selected Store by you in previous session </label>
        <h3 class="text-success ms-3 fw-bold"><?php echo e($clinic['name']); ?></h3>

    </div>
    <?php endif; ?>
    <?php endif; ?>

    <div class="mb-3 mt-3">
        <label for="appointment_date<?php echo e($selectedBranchId); ?>" class="fw-bold">Appointment Date</label>
        <input type="text" id="appointment_date<?php echo e($selectedBranchId); ?>" name="appointment_date" wire:model.lazy="clinic.appointment_date" readonly placeholder="Select a date" onclick="showDatePicker<?php echo e($selectedBranchId); ?>()" />
        <?php $__errorArgs = ['clinic.appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

        <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php echo $datePicker; ?>


        <script>
            function showDatePickerT() {
                const availableDates = <?= json_encode($availableDates) ?>;
                const enabledDates = availableDates.map(date => date.value);
                flatpickr("#appointment_date", {
                    enable: enabledDates,
                    dateFormat: "d-m-Y",
                    inline: true,
                });
            }
        </script>

    </div>
    
    <div class="mb-3 mt-3">
        <label for="appointment_time" class="fw-bold">Appointment Time</label>
        <select class="form-control form-select form-control-sm" id="appointment_time" name="appointment_time" wire:model="clinic.appointment_time">
            <option value="">Select a time</option>
            <?php if($selectedDate): ?>
            <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($timeSlot); ?>"><?php echo e($timeSlot); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label fw-bold">Write Note</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" wire:model.debounce.500="clinic.repair_note" placeholder="Please write any comment..." rows="3"></textarea>
        <?php $__errorArgs = ['clinic.repair_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-xs" style="color: red; font-size:12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div><?php /**PATH /home/mobilebitz/test.mobilebitz.co.uk/resources/views/livewire/guest/components/clinic-repair-form.blade.php ENDPATH**/ ?>
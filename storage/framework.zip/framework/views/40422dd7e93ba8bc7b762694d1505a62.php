<?php echo e($slot); ?>

<?php /**PATH /home/mobilebitz/demo.mobilebitz.co.uk/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
<div>
    <div class="d-flex">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'settings'])->html();
} elseif ($_instance->childHasBeenRendered('l1035774326-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1035774326-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1035774326-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1035774326-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'settings']);
    $html = $response->html();
    $_instance->logRenderedChild('l1035774326-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.settings.components.top-nav', ['active' => 'create'])->html();
} elseif ($_instance->childHasBeenRendered('l1035774326-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1035774326-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1035774326-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1035774326-1');
} else {
    $response = \Livewire\Livewire::mount('admin.settings.components.top-nav', ['active' => 'create']);
    $html = $response->html();
    $_instance->logRenderedChild('l1035774326-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="container">
                <h2 class="text-primary px-5 pt-5 pb-3">Create Branch</h2>
                <form wire:submit.prevent="saveBranch">
                    <div class="row">
                        <div class="col-md-6">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Branch Name:</label>
                                <input type="text" wire:model="name" class="form-control" placeholder="Enter Branch Name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="address_line_1">Address Line 1:</label>
                                <input type="text" wire:model="address_line_1" class="form-control" id="address_line_1" placeholder="Enter Address Line 1">
                                <?php $__errorArgs = ['address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="address_line_2">Address Line 2:</label>
                                <input type="text" wire:model="address_line_2" class="form-control" id="address_line_2" placeholder="Enter Address Line 2">
                                <?php $__errorArgs = ['address_line_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="town_city">Town/City:</label>
                                <input type="text" wire:model="town_city" class="form-control" id="town_city" placeholder="Enter Town/City">
                                <?php $__errorArgs = ['town_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="post_code">Post Code:</label>
                                <input type="text" wire:model="post_code" class="form-control" id="post_code" placeholder="Enter Post Code">
                                <div id="resultContainer">
                                    <p><?php echo e($addressName); ?></p>
                                </div>
                                <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="mobile_number">Mobile Number:</label>
                                <input type="text" wire:model="mobile_number" class="form-control" id="mobile_number" placeholder="Enter Mobile Number">
                                <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="landline_number">Landline Number:</label>
                                <input type="text" wire:model="landline_number" class="form-control" id="landline_number" placeholder="Enter Landline Number">
                                <?php $__errorArgs = ['landline_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" wire:model="email" class="form-control" id="email" placeholder="Enter Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="latitude">Latitude:</label>
                                <input type="number" wire:model="latitude" step="any" class="form-control" id="latitude" placeholder="Enter Latitude">
                                <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="longitude">Longitude:</label>
                                <input type="number" wire:model="longitude" step="any" class="form-control" id="longitude" placeholder="Enter Longitude">
                                <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group"><span class="text-danger" id="locationInfo"></span></div>
                        </div>
                    </div>

                    <div class="row mt-3 justify-content-center">
                        <label for="description" class="form-label">
                            <h2 class="text-primary pt-5 pb-3">About Us <b><?php echo e($name); ?></b></h2>
                        </label>
                        <div class=" mb-2" wire:ignore style="overflow-x: hidden;">

                            <textarea wire:model.debounce.500="description" id="editor" class="form-control"></textarea>

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-2">
                            <label for="map_link" class="form-label">Map Code:</label>
                            <textarea rows="10" wire:model="map_link" class="form-control" id="map_link" placeholder="Enter Map Embedded code"></textarea>

                            <?php $__errorArgs = ['map_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-2"><?php echo $map_link; ?></div>
                        <div class="col-md-6 mb-2">

                            <div class="form-group">
                                <label class="form-label">Branch <strong><?php echo e($name); ?></strong> Image</label>
                                <input type="file" accept="image/*" wire:model="file" onchange="displaySelectedImage(event, 'selectedImage')" id=<?php echo e($rand); ?> /> <br>
                                <span wire:loading wire:target="file">loading...</span>
                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-xs text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="text-center mt-2">
                                    <img id="selectedImage" wire:ignore src="<?php echo e($image); ?>" class="img-fluid" alt="<?php echo e($name); ?> - Image">
                                </div>
                            </div>
                        </div>
                    </div>
                        <h2 class="text-primary px-5 pt-5 pb-3">Appointment Time Slots</h2>
                    <div class=" " style="overflow-x: auto;">
                        <!-- Display time slots -->

                        <table class="table  table-hover" >
                            <thead class="table-primary">
                                <tr>
                                    <th>Day</th>
                                    <th>Opening Time</th>
                                    <th>Closing Time</th>
                                    <th>Status</th>
                                    <!-- Add more columns if needed -->
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($timeSlot['day']); ?></td>
                                    <td>
                                        <input type="time" wire:model="timeSlots.<?php echo e($index); ?>.opening_time" />
                                        <?php $__errorArgs = ["timeSlots.{$index}.opening_time"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                    <td>
                                        <input type="time" wire:model="timeSlots.<?php echo e($index); ?>.closing_time" />
                                        <?php $__errorArgs = ["timeSlots.{$index}.closing_time"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" role="switch" type="checkbox" id="flexSwitch<?php echo e($index); ?>" wire:click="toggleStatus(<?php echo e($index); ?>)" <?php echo e($timeSlot['status'] ? 'checked' : ''); ?> />
                                            <label class="form-check-label" for="flexSwitch<?php echo e($index); ?>"><?php echo e($timeSlot['status'] ? 'Opened' : 'Closed'); ?></label>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                    <div class="d-flex justify-content-end">
                        <div class="form-group">
                            <button type="submit" class="btn " style="border-radius: 20px;color: white;background-color: #20375E;padding: 10px">Create Branch</button>
                        </div>
                    </div>
                </form>
                <div class="row my-5 pb-5">
                    <div class="col-lg-12" wire:ignore id="mapView">
                        <div class="w-100 h-100" id="mapContainer"></div>
                    </div>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>
    </div>
</div>
            <!----------------------------- footer-------------------------->

<style>
.button-sticky {
    height: 60px;
    color: white;
    font-family: sans-serif;
    font-size: 15px;
    line-height: 15px;
    text-align: center;
    position: fixed !important;
    bottom: -2px;
    z-index: 999;
    width: 100%;
 
}

.home-btn:hover {
    color: orange;
}
.button-sticky .col-2 {
    margin-right: 5px; /* Adjust this value to set the desired gap */
}



</style>
<div class="button-sticky container bg-blue d-lg-none d-md-none">
    <div class="row ">

        <div class="col-2  mt-4 ml-1">
            <a href="<?php echo e(route('payment-methods-settings')); ?>" class="text-white item "> Payment</a>
     
     
        </div>

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('site-settings')); ?>" class="text-white  item "> site-settings</a>
        
        </div>

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('branches-settings')); ?>" class="text-white  item "> Branches</a>
        </div>

        <div class="col-2 mt-4">
            <a href="<?php echo e(route('create-branches')); ?>" class="text-white  item ">Create</a>
        </div>
        <div class="col-2 mt-4">
            <a href="<?php echo e(route('services-settings')); ?>" class="text-white  item ">Services</a>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script>
    document.addEventListener('livewire:load', function() {
        const locationInfo = document.getElementById("locationInfo");
        const resultContainer = document.getElementById("resultContainer");
        var mapContainer = document.getElementById("mapContainer");
        document.getElementById('post_code').addEventListener('change', function() {
            getLatLong();
        });
        navigator.geolocation.getCurrentPosition(onSuccess, onError);

        function onSuccess(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;
            window.livewire.find('<?php echo e($_instance->id); ?>').latitude = latitude;
            window.livewire.find('<?php echo e($_instance->id); ?>').longitude = longitude;
            showMap(latitude, longitude);
        }

        function onError(error) {
            console.error("Error getting location:", error.message);
        }
        async function getLatLong() {
            var postalCode = document.getElementById("post_code").value;
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&postalcode=${postalCode}`);
                const data = await response.json();
                if (data.length > 0) {
                    const result = data[0];
                    resultContainer.innerHTML = `<p>${result.display_name}</p>`;
                    window.livewire.find('<?php echo e($_instance->id); ?>').addressName = result.display_name;
                    window.livewire.find('<?php echo e($_instance->id); ?>').latitude = result.lat;
                    window.livewire.find('<?php echo e($_instance->id); ?>').longitude = result.lon;
                    // mapContainer.innerHTML = "";
                    showMap(result.lat, result.lon);
                } else {
                    resultContainer.innerHTML =
                        "<p>No results found for the provided postal code.</p>";
                }
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        }

        function showMap(latitude, longitude) {
            // Create a new div element
            var mapDiv = document.createElement("div");
            // Set the classes for the div
            mapDiv.classList.add("w-100", "h-100");
            mapDiv.setAttribute("style", "min-height: 400px;");
            // Set the id for the div
            mapDiv.id = "mapContainer";
            var mapViewDiv = document.getElementById("mapView");
            mapViewDiv.innerHTML = '';
            mapViewDiv.appendChild(mapDiv);
            var map = L.map("mapContainer").setView([latitude, longitude], 15);
            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: "&copy; OpenStreetMap contributors",
            }).addTo(map);
            const marker = L.marker([latitude, longitude], {
                draggable: true,
            }).addTo(map).bindPopup('<b> Branch location </b>').openPopup();
            marker.on("dragend", (event) => {
                const updatedLatitude = event.target.getLatLng().lat;
                const updatedLongitude = event.target.getLatLng().lng;
                window.livewire.find('<?php echo e($_instance->id); ?>').latitude = updatedLatitude;
                window.livewire.find('<?php echo e($_instance->id); ?>').longitude = updatedLongitude;
            });
        }
    });

    function displaySelectedImage(event, elementId) {
        const selectedImage = document.getElementById(elementId);
        const fileInput = event.target;

        if (fileInput.files && fileInput.files[0]) {
            const reader = new FileReader();

            reader.onload = function(e) {
                selectedImage.src = e.target.result;
            };

            reader.readAsDataURL(fileInput.files[0]);
        }
    }
</script>
<script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
<script>
    let editorInstance = null;
    createEditor();

    function createEditor() {
        if (editorInstance) {
            editorInstance.destroy().then(() => {
                // console.log('Editor destroyed.');
                initializeNewEditor();
            });
        } else {
            initializeNewEditor();
        }
    }

    function initializeNewEditor() {

        ClassicEditor
            .create(document.querySelector('#editor'))
            .then(editor => {
                editorInstance = editor;
                editor.model.document.on('change:data', () => {
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('description', editor.getData());
                });

            })
            .catch(error => {
                console.error(error);
            });
    }
</script><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/settings/branches/create.blade.php ENDPATH**/ ?>
<div>
    <div class="d-flex">

        <div></div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'settings'])->html();
} elseif ($_instance->childHasBeenRendered('l3046413985-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3046413985-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3046413985-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3046413985-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'settings']);
    $html = $response->html();
    $_instance->logRenderedChild('l3046413985-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.settings.components.top-nav', ['active' => 'services'])->html();
} elseif ($_instance->childHasBeenRendered('l3046413985-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3046413985-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3046413985-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3046413985-1');
} else {
    $response = \Livewire\Livewire::mount('admin.settings.components.top-nav', ['active' => 'services']);
    $html = $response->html();
    $_instance->logRenderedChild('l3046413985-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div
                style="font-family: 'Segoe UI', Roboto, 'Helvetica Neue', 'Noto Sans', 'Liberation Sans', Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';">
                <div class="container my-5">

                    <div class="table-responsive" style="overflow-x: auto;">
                        <table class="table  table-hover table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col">
                                        <div class="d-flex">
                                            <span class="flex-fill">Sell</span>
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" role="switch" type="checkbox"
                                                    wire:click="toggleStatus(<?php echo e($formStatuses[4]->id); ?>, 'sell')"
                                                    <?php echo e($formStatuses[4]->sell ? 'checked' : ''); ?> />
                                            </div>
                                        </div>

                                    </th>
                                    <th scope="col">
                                        <div class="d-flex">
                                            <span class="flex-fill">Buy</span>
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" role="switch" type="checkbox"
                                                    wire:click="toggleStatus(<?php echo e($formStatuses[4]->id); ?>, 'buy')"
                                                    <?php echo e($formStatuses[4]->buy ? 'checked' : ''); ?> />
                                            </div>
                                        </div>
                                    </th>
                                    <th scope="col">
                                        <div class="d-flex">
                                            <span class="flex-fill">Repair</span>
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" role="switch" type="checkbox"
                                                    wire:click="toggleStatus(<?php echo e($formStatuses[4]->id); ?>, 'repair')"
                                                    <?php echo e($formStatuses[4]->repair ? 'checked' : ''); ?> />
                                            </div>
                                        </div>
                                    </th>

                                    <!-- <th scope="col">-->
                                    <!--    <div class="d-flex">-->
                                    <!--        <span class="flex-fill">Accessories</span>-->
                                    <!--        <div class="form-check form-switch">-->
                                    <!--            <input class="form-check-input" role="switch" type="checkbox" wire:click="toggleStatus(<?php echo e($formStatuses[4]->id); ?>, 'accessories')" <?php echo e($formStatuses[4]->accessories ? 'checked' : ''); ?> />-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</th>-->

                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" role="switch" type="checkbox"
                                                id="flexSwitchCheckDefault"
                                                wire:click="toggleStatus(<?php echo e($formStatuses[0]->id); ?>, 'sell')"
                                                <?php echo e($formStatuses[0]->sell ? 'checked' : ''); ?> />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Sell In
                                                Store</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch"
                                                id="flexSwitchCheckDefault"
                                                wire:click="toggleStatus(<?php echo e($formStatuses[0]->id); ?>, 'buy')"
                                                <?php echo e($formStatuses[0]->buy ? 'checked' : ''); ?> />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Buy in
                                                Store</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch"
                                                id="flexSwitchCheckDefault"
                                                wire:click="toggleStatus(<?php echo e($formStatuses[0]->id); ?>, 'repair')"
                                                <?php echo e($formStatuses[0]->repair ? 'checked' : ''); ?> />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Store
                                                Repair</label>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch"
                                                id="flexSwitchCheckDefault"
                                                wire:click="toggleStatus(<?php echo e($formStatuses[1]->id); ?>, 'sell')"
                                                <?php echo e($formStatuses[1]->sell ? 'checked' : ''); ?> />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Post Your
                                                Device</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch"
                                                id="flexSwitchCheckDefault"
                                                wire:click="toggleStatus(<?php echo e($formStatuses[1]->id); ?>, 'buy')"
                                                <?php echo e($formStatuses[1]->buy ? 'checked' : ''); ?> />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Post My
                                                Device</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-between">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" role="switch"
                                                    id="flexSwitchCheckDefault1"
                                                    wire:click="toggleStatus(<?php echo e($formStatuses[1]->id); ?>, 'repair')"
                                                    <?php echo e($formStatuses[1]->repair ? 'checked' : ''); ?> />
                                                <label class="form-check-label" for="flexSwitchCheckDefault1">Postal
                                                    Repair</label>
                                            </div>

                                            <!--add postal price method -->
                                            <div class="form-check form-switch">
                                                <input role="switch" type="checkbox" checked class="form-check-input"
                                                    wire:click="toggleCustomStatus">
                                                <p style="width: 167px;font-weight:bold">
                                                    <?php echo e($customToggleStatus ? 'Delievry Charges: On' : 'Delievry Charges: Off'); ?>

                                                </p>

                                                </input>

                                            </div>



                                            <div>
                                                <div style="position: relative;">
                                                    <input type="text" placeholder="Enter Price in £"
                                                        wire:model="inputValue"
                                                        class="form-control mr-2 border-success"
                                                        style="width: 150px; height: 30px; display: inline-block; ">
                                                    <button class="btn btn-success rounded-pill"
                                                        wire:click="storeInput"
                                                        style="position: absolute; right: 0; top: 0; height: 100%; padding: 0 10px;">Save
                                                    </button>
                                                </div>


                                                <?php $__errorArgs = ['inputValue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="error"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <?php
                                                    $storedInputValue = Session::get('storedInputValue');
                                                ?>
                                                <?php if($storedInputValue): ?>
                                                    <p style="font-size:0.8vw">Deleivry Charges For Postal Repair:
                                                        £<?php echo e($storedInputValue); ?></p>
                                                <?php endif; ?>
                                            </div>




                                            <!--ends here-->



                                        </div>
                                    </td>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch"
                                                id="flexSwitchCheckDefault"
                                                wire:click="toggleStatus(<?php echo e($formStatuses[2]->id); ?>, 'sell')"
                                                <?php echo e($formStatuses[2]->sell ? 'checked' : ''); ?> />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Collect My
                                                Device</label>
                                        </div>



                                    </td>
                                    <td></td>
                                    <td>
                                        <div class="d-flex justify-content-between">
                                            <!-- First element -->
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" role="switch"
                                                    id="flexSwitchCheckDefault1"
                                                    wire:click="toggleStatus(<?php echo e($formStatuses[2]->id); ?>, 'repair')"
                                                    <?php echo e($formStatuses[2]->repair ? 'checked' : ''); ?> />
                                                <label class="form-check-label" for="flexSwitchCheckDefault1">Collect
                                                    My Device</label>
                                            </div>

                                            <!-- Second element -->
                                            <div class="form-check form-switch">
                                                <input role="switch" type="checkbox" checked
                                                    class="form-check-input" wire:click="toggleAnotherStatus">
                                                <p style="width: 167px;font-weight:bold">
                                                    <?php echo e($anotherToggleStatus ? 'Delievry Charges: On' : 'Delievry Charges: Off'); ?>

                                                </p>

                                                </input>

                                            </div>



                                            <div>
                                                <div style="position: relative;">
                                                    <input type="text" placeholder="Enter Price in £"
                                                        wire:model="collectionRepairPriceInput"
                                                        class="form-control mr-2 border-success"
                                                        style="width: 150px; height: 30px; display: inline-block; ">
                                                    <button class="btn btn-success rounded-pill"
                                                        wire:click="storeCollectionRepairPrice"
                                                        style="position: absolute; right: 0; top: 0; height: 100%; padding: 0 10px; ">Save</button>
                                                </div>


                                                <?php $__errorArgs = ['collectionRepairPriceInput'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="error"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <?php
                                                    $storedCollectionRepairPrice = Session::get(
                                                        'collectionRepairPrice',
                                                    );
                                                ?>
                                                <?php if($storedCollectionRepairPrice): ?>
                                                    <p style="font-size:0.8vw">Delivery Charges For Collection Repair:
                                                        £<?php echo e($storedCollectionRepairPrice); ?></p>
                                                <?php endif; ?>
                                            </div>


                                            

                                        </div>



                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch"
                                                id="flexSwitchCheckDefault"
                                                wire:click="toggleStatus(<?php echo e($formStatuses[3]->id); ?>, 'repair')"
                                                <?php echo e($formStatuses[3]->repair ? 'checked' : ''); ?> />
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Fix At My
                                                Address</label>
                                        </div>







                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>

            </div>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>





        <!-- File: resources/views/livewire/admin/settings/services-settings.blade.php -->




    </div>

    <div class="container d-flex justify-content-between">

        <div>
            <h2>Create a New Service Charge</h2>
            <form wire:submit.prevent="storeServiceCharge">
                <div>
                    <label for="serviceChargeName">Service Charge Name:</label>
                    <input type="text" id="serviceChargeName" wire:model="serviceChargeName"
                        placeholder="Enter service charge name" required>
                </div>
                <div>
                    <label for="serviceChargePrice">Price:</label>
                    <input type="number" step="0.01" id="serviceChargePrice" wire:model="serviceChargePrice"
                        placeholder="Enter price" required>
                </div>
                <div>
                    <label for="serviceChargeCharges">Is Active:</label>
                    <input type="checkbox" id="serviceChargeCharges" wire:model="serviceChargeCharges">
                </div>
                <button type="submit">Add Service Charge</button>
            </form>
        </div>






        <div>
            <h2>Service Charges</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Active</th>
                        <th>Actions</th> <!-- New column for edit button -->
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $serviceCharges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceCharge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($serviceCharge->name); ?></td>
                            <td><?php echo e($serviceCharge->price); ?></td>
                            <td><?php echo e($serviceCharge->charges ? 'Yes' : 'No'); ?></td>
                            <td>
                                <!-- Edit button to start editing -->
                                <button wire:click="startEdit(<?php echo e($serviceCharge->id); ?>)">Edit</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php if($editingServiceChargeId): ?>
                <!-- Show edit form only when editing -->
                <div>
                    <h3>Edit Service Charge</h3>
                    <form wire:submit.prevent="updateServiceCharge">
                        <div>
                            <label for="serviceChargeName">Service Charge Name:</label>
                            <input type="text" id="serviceChargeName" wire:model="serviceChargeName" required>
                        </div>
                        <div>
                            <label for="serviceChargePrice">Price:</label>
                            <input type="number" step="0.01" id="serviceChargePrice"
                                wire:model="serviceChargePrice" required>
                        </div>
                        <div>
                            <label for="serviceChargeCharges">Is Active:</label>
                            <input type="checkbox" id="serviceChargeCharges" wire:model="serviceChargeCharges">
                        </div>
                        <button type="submit">Update</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>


    </div>

</div>



<!----------------------------- footer-------------------------->

<style>
    .button-sticky {
        height: 60px;
        color: white;
        font-family: sans-serif;
        font-size: 15px;
        line-height: 15px;
        text-align: center;
        position: fixed !important;
        bottom: -2px;
        z-index: 999;
        width: 100%;

    }

    .home-btn:hover {
        color: orange;
    }

    .button-sticky .col-2 {
        margin-right: 5px;
        /* Adjust this value to set the desired gap */
    }
</style>
<div class="button-sticky container bg-blue d-lg-none d-md-none">
    <div class="row ">

        <div class="col-2  mt-4 ml-1">
            <a href="<?php echo e(route('payment-methods-settings')); ?>" class="text-white item "> Payment</a>


        </div>

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('site-settings')); ?>" class="text-white  item "> site-settings</a>

        </div>

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('branches-settings')); ?>" class="text-white  item "> Branches</a>
        </div>

        <div class="col-2 mt-4">
            <a href="<?php echo e(route('create-branches')); ?>" class="text-white  item ">Create</a>
        </div>
        <div class="col-2 mt-4">
            <a href="<?php echo e(route('services-settings')); ?>" class="text-white  item ">Services</a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\mobile bitz with most updated checkout pages\resources\views/livewire/admin/settings/services-settings.blade.php ENDPATH**/ ?>
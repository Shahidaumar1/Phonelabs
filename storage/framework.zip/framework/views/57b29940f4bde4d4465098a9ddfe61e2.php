<div>
    <?php
        $tagline = [
            'Sell' => 'How you’ll send your device',
            'Repair' => 'How would you like us to repair your device?',
            'Buy' => 'How you’ll get your device',
        ];

        $heading = [
            'Sell' => 'Selling Options',
            'Repair' => 'Repair Options',
        ];

        $postalText = [
            'Sell' => 'Post Your Device',
            'Repair' => 'Postal Repair',
            'Buy' => 'Post My Device',
        ];

        $formService = strtolower($data['service']);
    ?>

    <?php if($showGrid): ?>
        <div class="grid-heading">
            <h3 class="text-center text-danger pt-4">What way would you like us to fix your device?</h3>
            <p class="text-center">If your iPhone 14 Plus is damaged, we understand that you would want this repaired in no time so you... <span class="text-danger">Read More</span></p>
        </div>

        <div class="bg-white">
            <section>
                <div class="grid-container" role="grid">
                    <?php if($formStatuses[0]->$formService): ?>
                        <div class="grid-item" wire:click="showForm('clinic_form')">
                            <div class="icon-container text-danger">
                                <i class="fas fa-store"></i>
                            </div>
                            <div class="option-label text-dark">Store Repair</div>
                            <div class="option-description">Choose from one of our 40 nationwide locations.</div>
                        </div>
                    <?php endif; ?>
                    <?php if($formStatuses[1]->$formService): ?>
                        <div class="grid-item" wire:click="showForm('postal_form')">
                            <div class="icon-container text-danger">
                                <i class="fas fa-mail-bulk"></i>
                            </div>
                            <div class="option-label text-dark">Postal Repair</div>
                            <div class="option-description">No stores close to you? Send your device to us!</div>
                        </div>
                    <?php endif; ?>
                    <?php if($formStatuses[2]->$formService && $data['service'] != 'Buy'): ?>
                        <div class="grid-item mb-5" wire:click="showForm('collection_form')">
                            <div class="icon-container text-danger">
                                <i class="fas fa-truck"></i>
                            </div>
                            <div class="option-label text-dark">Collect My Device</div>
                            <div class="option-description">We'll pick up your device for repair and return it to you afterward.</div>
                        </div>
                    <?php endif; ?>
                    <?php if($formStatuses[3]->$formService && $data['device']['name'] != 'Apple iPad' && $data['service'] == 'Repair'): ?>
                        <div class="grid-item mb-5" wire:click="showForm('fix_form')">
                            <div class="icon-container text-danger">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="option-label text-dark">Fix At My Address</div>
                            <div class="option-description">Our technicians will visit your residence to repair your mobile device.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    <?php endif; ?>

    <?php if($showForm): ?>
        <section>
            <div>
                <div wire:loading wire:target="form_type" class="w-100">
                    <div class="overlay rounded d-flex flex-column justify-content-center align-items-center bg-pink-linear text-white" style="height:400px;">
                        <?php if (isset($component)) { $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0 = $attributes; } ?>
<?php $component = App\View\Components\Spinner::resolve(['color' => 'danger'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Spinner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0)): ?>
<?php $attributes = $__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0; ?>
<?php unset($__attributesOriginal9227dab7d867c26b79d09b0ebcea91c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0)): ?>
<?php $component = $__componentOriginal9227dab7d867c26b79d09b0ebcea91c0; ?>
<?php unset($__componentOriginal9227dab7d867c26b79d09b0ebcea91c0); ?>
<?php endif; ?>
                    </div>
                </div>
                <div wire:loading.remove wire:target="form_type">
                    <!-- Render form components conditionally -->
                    <?php if($showForm): ?>
                        <?php if($form_type == 'postal_form'): ?>
                            <div class="bg-white">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.postal-repair-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.postal-repair-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        <?php elseif($form_type == 'clinic_form'): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.components.clinic-repair-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.components.clinic-repair-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php elseif($form_type == 'collection_form'): ?>
                            <div wire:ignore>
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.collection-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.collection-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        <?php elseif($form_type == 'fix_form'): ?>
                            <div wire:ignore>
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('guest.fix-form', [])->html();
} elseif ($_instance->childHasBeenRendered(uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId(uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName(uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(uniqid());
} else {
    $response = \Livewire\Livewire::mount('guest.fix-form', []);
    $html = $response->html();
    $_instance->logRenderedChild(uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        <?php endif; ?>
                        <button wire:click="hideForm" class="back-button">Go Back</button>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>

<style>
    .nav-tabs {
        display: flex;
        flex-wrap: nowrap;
        overflow-x: auto;
        border-bottom: none;
        background-color: transparent;
        scrollbar-width: none;
    }

    .nav-item {
        white-space: nowrap;
        color: green;
    }

    .nav-link {
        color: #3E3E3E;
    }

    .nav-link:hover {
        color: black !important;
    }

    .nav-link.active {
        color: #3E3E3E;
    }

    .nav-tabs::-webkit-scrollbar {
        display: none;
    }

    .nav-tabs .nav-link.active {
        background-color: white;
        position: relative;
        z-index: 1;
    }

    .tab-content {
        background-color: #ffffff;
        border-radius: 10px;
        width: 100%;
        margin: 0 auto;
        padding: 20px;
    }

    @media only screen and (max-width: 767px) {
        .tab-content {
            width: 100%;
            margin-left: -2%;
        }
    }

    .tab-content.postal-form {
        background-color: #f0f0f0;
    }

    .tab-content.clinic-form {
        background-color: #e0e0e0;
    }

    .grid-container {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        margin-bottom: 20px;
        padding-left: 200px;
        padding-right: 200px;
        padding-top: 40px;
    }

    .grid-item {
        background-color: hsl(0, 100%, 99%);
        padding: 20px;
        border-radius: 5px;
        text-align: center;
        transition: all 0.3s ease;
    }

    .grid-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
    }

    .icon-container {
        font-size: 2rem;
        margin-bottom: 10px;
    }

    .option-label {
        font-weight: bold;
        margin-bottom: 5px;
    }

    .option-description {
        font-size: 0.9rem;
        color: #666;
    }

    a {
        text-decoration: none;
    }

    .back-button {
        display: block;
        margin: 20px 0;
        padding: 10px 20px;
        background-color: #dc3545;
        color: white;
        text-align: center;
        border-radius: 5px;
        cursor: pointer;
    }

    .back-button:hover {
        background-color: #c82333;
    }
</style>

<script>
    document.addEventListener('livewire:load', function () {
        Livewire.on('formShown', function () {
            document.querySelectorAll('.tab-pane').forEach(function (pane) {
                pane.style.display = 'none';
            });

            const formElement = document.querySelector('.tab-pane.active.show');
            if (formElement) {
                formElement.style.display = 'block';
            }
        });
    });
</script>
<?php /**PATH /Users/mubashir/Documents/scode/resources/views/livewire/guest/components/form-toggle.blade.php ENDPATH**/ ?>
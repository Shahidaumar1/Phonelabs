<div>
    <div class="d-flex">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'buy'])->html();
} elseif ($_instance->childHasBeenRendered('l1739705292-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1739705292-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1739705292-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1739705292-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'buy']);
    $html = $response->html();
    $_instance->logRenderedChild('l1739705292-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.buy.components.top-nav', ['active' => 'devices'])->html();
} elseif ($_instance->childHasBeenRendered('l1739705292-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1739705292-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1739705292-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1739705292-1');
} else {
    $response = \Livewire\Livewire::mount('admin.buy.components.top-nav', ['active' => 'devices']);
    $html = $response->html();
    $_instance->logRenderedChild('l1739705292-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="container pb-5">
                    <h3 class = "text-center pt-3"><?php echo e($selectedCategory->name ?? ''); ?></h3>
                <div class="d-flex align-items-center  justify-content-center my-4">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.buy.components.sub-nav', ['items' => $items])->html();
} elseif ($_instance->childHasBeenRendered('l1739705292-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l1739705292-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1739705292-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1739705292-2');
} else {
    $response = \Livewire\Livewire::mount('admin.buy.components.sub-nav', ['items' => $items]);
    $html = $response->html();
    $_instance->logRenderedChild('l1739705292-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <div class="d-flex align-items-center  justify-content-center gap-3 my-4">
                    <select class="form-select form-control" aria-label="Default select example" wire:model="selectedCatId" style="width:150px">
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                      <?php if($target == 'Publish'): ?>
                    <button class="btn p-2" onclick="showM('add-buy-device')" style="border-radius: 5px; color: white; 
                    background-color: #20375E; padding: 10px">
                       
                        Create New
                    </button>
                    
                     <?php endif; ?>
                </div>
                
                <div class="d-flex justify-content-center gap-4  flex-wrap  ">
                    <?php if($target == 'Publish'): ?>
                    <div class="plus-card bg-white">
                   <div class="d-flex align-items-center  justify-content-center my-4">               
                         <img src="https://ik.imagekit.io/4csyk445b/Rectangle%201.png?updatedAt=1712154034586" class="img-fluid" style="height: 130px; width: 200px" />
                    </div>
                              <div class="d-flex align-items-center  justify-content-between p-2">
                        <h4 class="fw-bold">Allow Others</h4>
                        
                            <div class="form-check form-switch">
                                <input type="checkbox" role="switch" class="form-check-input border border-dark" <?php if($selectedCategory): ?> wire:change="toggleOthers(<?php echo e($selectedCategory->id); ?>)" <?php echo e($selectedCategory->others == true ? 'checked' : ''); ?> <?php endif; ?>>
                            </div>
                        
                    </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card bg-white cursor-pointer">
                        <div class="p-2 d-flex justify-content-center align-items-center">
                            <a href="<?php echo e(route('buy-models', $device)); ?>">
                            <img src="<?php echo e($device->file ?? '#'); ?>" class="img-fluid" style="height: 140px; width: 200px" />
                        </a>
                        
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center p-3 pb-0">
                            <div class="">
                                <h4 class="fw-bold text-center text-dark"><?php echo e($device->name); ?></h4>
                            </div>
                            <!--check button -->
                            <div class="form-check form-switch">
                                <input type="checkbox" role="switch" class="form-check-input border border-dark" wire:change="toggleStatus(<?php echo e($device->id); ?>)" <?php echo e($device->status == 'Publish' ? 'checked' : ''); ?>>
                            </div>
                            
                            <!--dropdown button -->
                            <div class="dropdown dropend" id="<?php echo e(uniqid()); ?>" wire:ignore>
                                <button class="btn btn-light dropdown-toggle bg-light border-0" type="button" id="<?php echo e(uniqid()); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fa fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="<?php echo e(uniqid()); ?>">
                                    <li>
                                        <?php if($target != 'Junk'): ?>
                                        <a class="dropdown-item" href="javascirpt:void(0)" wire:click="selectDevice('<?php echo e($device->id); ?>')">Edit</a>
                                        <?php endif; ?>
                                    </li>
                                    <li>
                                        <?php if($target == 'Junk'): ?>
                                        <a class="dropdown-item" wire:click="restore('<?php echo e($device->id); ?>')">Restore</a>
                                        <?php else: ?>
                                        <a class="dropdown-item" wire:click="softDelete('<?php echo e($device->id); ?>')">Delete</a>
                                        <?php endif; ?>
                                    </li>
                                </ul>
                            </div>
                        
                        
                        
                            
                        </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="d-flex justify-content-center align-items-center">
                               <div>
                                <h3 class="fw-bold text-center " style="color: darkblue">No Records !</h3>
                                <img src="https://ik.imagekit.io/4csyk445b/archivo_de_documento_no_encontrado__b%C3%BAsqueda_sin_resultado_concepto_ilustraci%C3%B3n_dise%C3%B1o_plano_vector_eps10__elemento_gr%C3%A1fico_moderno_para_p%C3%A1gina_de_inicio__interfaz_de_usuario_de_estado_vac%C3%ADo__infograf%202.png?updatedAt=1712404110308" class = "img-fluid" alt="No Recode icon">
                                
                               </div>
                            </div>
                        <?php endif; ?>
                </div>

            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>
<!----------------------------- footer-------------------------->
<style>
.button-sticky {
    height: 60px;
    color: white;
    font-family: sans-serif;
    font-size: 17px;
    line-height: 15px;
    text-align: center;
    position: fixed;
    bottom: -2px;
    z-index: 999;
    overflow-x:auto;
}

.home-btn:hover {
    color: orange;
}
.button-sticky .col-2 {
    margin-right: 10px; /* Adjust this value to set the desired gap */
}

.button-sticky .col-2:last-child {
    margin-right: 0; /* Remove margin from the last button to prevent extra space */
}

</style>

<div class="button-sticky container bg-blue d-lg-none d-md-none">
    <div class="row justify-content-center">

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('buy-categories')); ?>" class="text-white item  "> Devices</a>
        </div>

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('buy-devices')); ?>" class="text-white  item "> Brands</a>
        </div>

        <div class="col-2  mt-4 ">
            <a href="<?php echo e(route('buy-models')); ?>" class="text-white  item "> Models</a>
        </div>

        <div class="col-2 mt-4">
            <a href="<?php echo e(route('buy-models-add-ons')); ?>" class="text-white  item "> Addon</a>
        </div>
    </div>
</div>


    </div>
    
    <?php if($selectedCategory): ?>
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Add Device','id' => 'add-buy-device']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.buy.device.create', ['category' => $selectedCategory])->html();
} elseif ($_instance->childHasBeenRendered('l1739705292-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l1739705292-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1739705292-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1739705292-3');
} else {
    $response = \Livewire\Livewire::mount('admin.buy.device.create', ['category' => $selectedCategory]);
    $html = $response->html();
    $_instance->logRenderedChild('l1739705292-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Device','id' => 'edit-buy-device']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.buy.device.edit', [])->html();
} elseif ($_instance->childHasBeenRendered('l1739705292-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l1739705292-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1739705292-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1739705292-4');
} else {
    $response = \Livewire\Livewire::mount('admin.buy.device.edit', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1739705292-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
</div><?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/buy/device/index.blade.php ENDPATH**/ ?>
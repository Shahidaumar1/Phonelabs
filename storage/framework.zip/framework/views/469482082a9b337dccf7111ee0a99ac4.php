<div>
    <div class="d-flex" style="background-color: whitesmoke; height: 130vh">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'accessories'])->html();
} elseif ($_instance->childHasBeenRendered('l1383679507-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1383679507-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1383679507-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1383679507-0');
} else {
    $response = \Livewire\Livewire::mount('admin.components.side-nave', ['active' => 'accessories']);
    $html = $response->html();
    $_instance->logRenderedChild('l1383679507-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php if (isset($component)) { $__componentOriginald033566f468fc7bb3a8d0f946fdab616 = $component; } ?>
<?php $component = App\View\Components\Content::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Content::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.components.top-nav', ['active' => 'categories'])->html();
} elseif ($_instance->childHasBeenRendered('l1383679507-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1383679507-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1383679507-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1383679507-1');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.components.top-nav', ['active' => 'categories']);
    $html = $response->html();
    $_instance->logRenderedChild('l1383679507-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="container">
                <div class="mt-5">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.components.sub-nav', ['items' => $items])->html();
} elseif ($_instance->childHasBeenRendered('l1383679507-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l1383679507-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1383679507-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1383679507-2');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.components.sub-nav', ['items' => $items]);
    $html = $response->html();
    $_instance->logRenderedChild('l1383679507-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <div class="d-flex justify-content-end align-items-center ">

                    <?php if($target == 'Publish'): ?>
                    <button class="btn mt-2" onclick="showM('add-buy-cat')" style="border-radius: 5px; color: white; 
                    background-color: #20375E; pading: 10px">
                       
                        Create New
                    </button>
                    
                     <?php endif; ?>

                </div>
                <div>
                    <div class="d-flex justify-content-center gap-4  flex-wrap mt-5" wire:sortable="updateOrderNumber">
                        
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div style="cursor: move" class="card border-0 rounded-4 a" wire:sortable.item="<?php echo e($category->id); ?>" wire:key="category-<?php echo e($category->id); ?>">
                            <div class="p-2 d-flex justify-content-center align-items-center">
                              <a href="<?php echo e(route('accessories-devices', $category)); ?>">
                                <img src="<?php echo e($category->file ?? '#'); ?>" class="img-fluid" style="cursor: move; height: 150px; width: 200px" />
                            </a>
                            </div>
                             <div class="p-2 d-flex justify-content-between align-items-center">
                                <div class="p-2">
                                    <h4 class="fw-bold text-center text-dark"><?php echo e($category->name); ?></h4>
                                </div>
  
                                <!--toggel button -->
                                <div class="form-check form-switch">
                                    <input type="checkbox" role="switch" class="form-check-input" wire:change="toggleStatus(<?php echo e($category->id); ?>)" <?php echo e($category->status == 'Publish' ? 'checked' : ''); ?>>
                                </div>
                                <!--dropdown-->
                                <div class="dropdown dropend" id="<?php echo e($rand); ?>" wire:ignore>
                                    <button class="btn btn-light dropdown-toggle bg-light border-0" type="button" id="<?php echo e($rand); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa fa-ellipsis-v"></i>
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="<?php echo e($rand); ?>">
                                        <li>
                                            <?php if($target != 'Junk'): ?>
                                            <a class="dropdown-item" href="javascirpt:void(0)" wire:click="selectCat('<?php echo e($category->id); ?>')">Edit</a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <span class="dropdown-item" wire:click="addGradeText('<?php echo e($category->id); ?>')">Add Grade Text</span>
                                        </li>
                                        <li>
                                            <?php if($target == 'Junk'): ?>
                                            <a class="dropdown-item" wire:click="restore('<?php echo e($category->id); ?>')">Restore</a>
                                            <?php else: ?>
                                            <a class="dropdown-item" wire:click="softDelete('<?php echo e($category->id); ?>')">Delete</a>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="plus-card">
                            <i class="fa fa-times text-danger " style="font-size:40px;" aria-hidden="true"></i>
                            <h4 class="fw-bold">No Records !</h4>
                        </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald033566f468fc7bb3a8d0f946fdab616)): ?>
<?php $component = $__componentOriginald033566f468fc7bb3a8d0f946fdab616; ?>
<?php unset($__componentOriginald033566f468fc7bb3a8d0f946fdab616); ?>
<?php endif; ?>


    </div>
    
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Add Category','id' => 'add-buy-cat']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.category.create', [])->html();
} elseif ($_instance->childHasBeenRendered('l1383679507-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l1383679507-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1383679507-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1383679507-3');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.category.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1383679507-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Add Grades Text','id' => 'add-grade-text','size' => 'lg']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.category.grade-text', [])->html();
} elseif ($_instance->childHasBeenRendered('l1383679507-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l1383679507-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1383679507-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1383679507-4');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.category.grade-text', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1383679507-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
    <?php if($selectedCat): ?>
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit Category','id' => 'edit-buy-cat']); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accessories.category.edit', [])->html();
} elseif ($_instance->childHasBeenRendered('l1383679507-5')) {
    $componentId = $_instance->getRenderedChildComponentId('l1383679507-5');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1383679507-5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1383679507-5');
} else {
    $response = \Livewire\Livewire::mount('admin.accessories.category.edit', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1383679507-5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
    <?php endif; ?>

</div>
  <!----------------------------- footer-------------------------->
        <style>
        .button-sticky {
            height: 60px;
            color: white;
            font-family: sans-serif;
            font-size: 17px;
            line-height: 15px;
            text-align: center;
            position: fixed;
            bottom: -2px;
            z-index: 999;
            overflow-x: auto;
            width:100;
        }

        .home-btn:hover {
            color: orange;
        }

        .button-sticky .col-2 {
            margin-right: 10px;
            /* Adjust this value to set the desired gap */
        }

        .button-sticky .col-2:last-child {
            margin-right: 0;
            /* Remove margin from the last button to prevent extra space */
        }
        </style>

        <div class="button-sticky container bg-blue d-lg-none d-md-none">
            <div class="row justify-content-center">

                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('accessories-categories')); ?>" class="text-white item "> Brands</a>
                </div>

                <div class="col-2  mt-4 ">
                    <a href="<?php echo e(route('accessories-devices')); ?>" class="text-white "> Models</a>
                </div>

                <div class="col-3  mt-4 ">
                    <a href="<?php echo e(route('accessories-models')); ?>" class="text-white  item "> Accessories</a>
                </div>

                <div class="col-3 mt-4">
                    <a href="<?php echo e(route('accessories-models-add-ons')); ?>" class="text-white  item "> Variations</a>
                </div>
            </div>
        </div>
<?php /**PATH /home/mobilebitz/public_html/resources/views/livewire/admin/accessories/category/index.blade.php ENDPATH**/ ?>